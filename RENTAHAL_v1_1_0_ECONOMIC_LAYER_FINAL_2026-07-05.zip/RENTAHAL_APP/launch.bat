@echo off
REM RENT-A-HAL launcher — runs the boot wizard, which then launches the realm.
REM
REM Replaces direct `python app.py` startup. The wizard performs the safety
REM checks (GPT4All running, model loaded, federation config sane) and only
REM then spawns the realm.
REM
REM Usage: just double-click this file, or run from cmd:
REM     launch.bat

cd /d "%~dp0"

REM Activate venv if it exists, otherwise use system Python
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
)

echo.
echo ====================================================================
echo   RENT-A-HAL Boot Wizard starting...
echo   Open http://localhost:9100 in your browser
echo ====================================================================
echo.

python wizard.py
