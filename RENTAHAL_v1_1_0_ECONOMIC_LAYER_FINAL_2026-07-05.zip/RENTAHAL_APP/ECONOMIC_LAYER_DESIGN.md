# RENT-A-HAL Economic Layer — Design & Sprint Plan

**Scope:** Proof-of-work anti-abuse gating, a tamper-evident ledger,
consumer prepaid balances, and donor payouts. Everything in this
document is **additive** to the existing federation/conscription
architecture — nothing here changes how a standalone, non-monetized
realm behaves. Same discipline as every prior sprint arc: opt-in,
backward compatible, off by default.

**Status:** Design only. Nothing in this document is built yet — this
is the plan to build from, sprint by sprint.

---

## Design principles (carried forward, made explicit)

These aren't new — they're the same principles that shaped
federation/conscription — but money raises the stakes on getting them
right, so they're worth stating plainly before any code exists:

1. **Nothing here is required.** A realm that never touches this
   system behaves exactly as it does today. Every gate, every balance,
   every payout is opt-in config, same posture as `desire = off` for
   federation.
2. **Stateless where possible, append-only where not.** The PoW
   challenge is signed, not stored (Sprint 10). The ledger is
   insert-only with no UPDATE/DELETE (Sprint 11). Both choices exist
   so correctness doesn't depend on trusting an operator not to edit
   history.
3. **Self-report where the stakes are low; require bilateral
   confirmation where the stakes are real money.** Federation's
   `llm_avg_s` self-reporting was fine because lying about it only
   hurts your own routing quality. A donor self-reporting "I served
   this conscripted request, pay me" is a different risk class
   entirely — see Sprint 14's confirmation design.
4. **Reuse existing telemetry, don't duplicate it.** Metrics already
   tracks per-kind duration (`record_capability_duration`) and
   `total_tokens_out`. The ledger debits/credits off the *same*
   numbers already flowing through the system, not a parallel
   accounting path that can drift out of sync with what actually ran.
5. **External money movement goes through a regulated processor, not
   custom rails.** Stripe (Checkout for consumer top-ups, Connect
   Express for donor payouts) — same reasoning as choosing Postgres
   over a hand-rolled append log: don't rebuild what a specialist
   already built correctly.

One honest tradeoff worth naming up front: **this is the first part of
RENT-A-HAL that requires an external database server.** Everything
built so far runs from a single Python process with file-based state
(`federation_state.json`) — genuinely "download and run" on Windows.
Postgres is a real new operational dependency: something has to be
installed, running, and backed up. That's a deliberate, necessary
tradeoff for tamper-evident financial records (§ below explains why
SQLite doesn't clear that bar), but it changes the deployment story for
anyone who turns this on, and the docs need to say so plainly, not
bury it.

---

## Part A — Proof-of-work anti-abuse gate

### A.1 Why Argon2id, not SHA-256

Established last conversation: raw SHA-256 is compute-bound, and a
single RTX 4060 can do ~7 billion hashes/second — RENT-A-HAL's own user
base is unusually GPU-rich, so a compute-bound puzzle is close to
worthless as a toll against exactly the population most likely to
attempt abuse. Argon2id is **memory-hard**: each attempt requires a
dedicated block of RAM (64MB in the design below), and GPUs have
comparatively limited memory bandwidth per parallel thread. This
collapses an attacker's advantage from "billions of parallel attempts"
to a few hundred, regardless of how many ALU cores they have.

### A.2 Stateless challenge/response

The server must not need to remember outstanding challenges — that's a
database write before you even know if a caller is legitimate, and it
breaks the moment there's more than one server process. Standard fix:
sign the challenge.

```
challenge = random_bytes(16)
expiry    = now + 60s
signature = HMAC-SHA256(server_secret, challenge || expiry)
```

Server sends `{challenge, expiry, signature, difficulty}`. Client
solves, submits `{challenge, expiry, signature, nonce}`. Server
re-derives the HMAC (proves *this* server issued it), checks expiry,
then verifies `Argon2id(challenge || nonce)` meets `difficulty`. No
lookup table, no shared state between instances, scales to any number
of server processes for free.

### A.3 Difficulty ladder

Argon2id parameters stay fixed (`memory_cost=64MB, time_cost=2,
parallelism=1` — roughly 50-100ms for one attempt on ordinary
hardware). Difficulty is expressed as required leading-zero bits in the
output, which forces ~2^N attempts on average — the classic hashcash
knob, just sitting on top of a memory-hard primitive instead of a
compute-hard one.

| Tier (public label) | Rolling-window calls | Leading-zero bits | Avg. attempts | Wall-clock cost |
|---|---|---|---|---|
| `free` | 1–10 | — | 0 | none |
| `pi-100` | 11–50 | 4 | ~16 | ~1-2 sec |
| `pi-1000` | 51–200 | 8 | ~256 | ~15-25 sec |
| `pi-10000` | 200+ | 12+ | ~4096+ | minutes, climbing |

Public API responses can use the `pi-N` label; the actual mechanism
underneath never needs to be user-visible.

### A.4 Rate-limit keying

Two different identities depending on which endpoint:

- `/api/ask`, `/api/speak` (anonymous public surface): key on source IP,
  leaky-bucket decay (in-memory dict — genuinely fine for a
  single-instance deployment, no Redis needed until horizontally
  scaled).
- `/federate/checkin`, conscription-adjacent endpoints: key on
  `member_url` instead — that's the identity that actually matters for
  a bad-faith peer realm.

### A.5 Where this lives in the codebase

New module `realm/pow_gate.py`: `generate_challenge()` /
`verify_solution()` / a small `RateLimitTracker` class. Wired into
`app.py` the same way `federation_token_error()` was — a shared gate
function called at the top of each protected endpoint, returning
`None` (proceed) or a ready-to-return HTTP response (`402 Payment
Required` reads better semantically here than `401`, since this is a
cost gate, not an identity gate).

---

## Part B — The ledger

### B.1 Why not SQLite

Not a throughput problem — SQLite's raw write speed would be fine here.
The actual gap is **tamper-evidence**: a SQLite file is bytes on disk;
anyone with filesystem access can edit a row and nothing would ever
notice. That's the property this system needs and SQLite doesn't
provide on its own.

### B.2 Schema shape

Postgres, **append-only** (application-level: no UPDATE/DELETE grants
on the ledger role; only INSERT), with each row hash-chained to the
previous one:

```sql
CREATE TABLE ledger_entries (
    id              BIGSERIAL PRIMARY KEY,
    entry_type      TEXT NOT NULL,       -- 'topup', 'debit', 'payout', 'conscription_credit'
    account_id      TEXT NOT NULL,       -- realm URL, or 'system'
    amount_micros   BIGINT NOT NULL,     -- signed, in millionths of a cent (see B.4)
    reference       TEXT,                -- Stripe charge ID, conscription contract ID, etc.
    metadata        JSONB,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    prev_hash       TEXT NOT NULL,
    row_hash        TEXT NOT NULL        -- SHA256(entry_type||account_id||amount_micros||
                                          --        reference||created_at||prev_hash)
);
CREATE INDEX ON ledger_entries (account_id, created_at);
```

Balance for any account = `SUM(amount_micros) WHERE account_id = X` —
never a stored/mutated running total, always derived. That's what
makes the ledger authoritative rather than a cache that can drift.

### B.3 Verifying the chain

A small, standalone script (no app dependency) walks the table in
`id` order, recomputes each `row_hash` from its own fields plus the
previous row's `row_hash`, and confirms it matches what's stored. Any
mismatch means the row was altered or deleted out of band — this is
the same verification any operator, or any skeptical donor, can run
independently.

### B.4 Units: `amount_micros`

Storing currency as float is the classic source of silent rounding
bugs; storing as integer cents is still too coarse for a $0.0001
transaction (that's 1/100th of a cent). Integer **micros** (millionths
of a US cent, i.e. $0.000001 per unit) gives four more decimal digits
of headroom below your target price point — plenty of room to tune
pricing later without a schema change.

### B.5 Public verifiability — OpenTimestamps

Daily job: take the current chain-tip `row_hash`, submit to
[OpenTimestamps](https://opentimestamps.org/) (free, built on Bitcoin,
no wallet/gas/token — you're borrowing existing miner security, not
running any chain yourself), publish the resulting `.ots` proof file
publicly (repo, or a page on rentahal.com). Anyone can independently
verify "the ledger's state as of this date is exactly what's claimed"
without trusting the database's access controls or Anthropic's — sorry,
*your* — word for it.

---

## Part C — Payment rails

### C.1 Consumer side — prepaid balance, not per-transaction charges

The one point worth restating plainly: **you cannot charge a card
$0.0001 per submit.** Stripe's real fee (~2.9% + $0.30 per charge) is
~3000x the target transaction price — true of every card network, not
a Stripe-specific limitation. This is exactly why Claude, OpenAI, and
every metered API on earth top up an internal balance in one
infrequent transaction instead of charging per call.

**Flow:**
1. Stripe Checkout, one-time top-up ($5/$10/$20 presets + custom).
2. Webhook confirms payment → `ledger_entries` INSERT, `entry_type =
   'topup'`, `account_id = user's realm/account identifier`.
3. Every submit debits the ledger directly (no Stripe involvement at
   all) — this is what makes the 1/100th-cent price point real.
4. Low-balance triggers a one-click top-up prompt (card remembered via
   Stripe Customer object).

**Where the debit hooks into existing code:** `orchestrator.py`'s
`_handle()` already computes `elapsed` and `tokens_out` per query — the
exact same point that calls `record_capability_duration()` today is
where a ledger debit gets appended too. One new call alongside an
existing one, not a parallel accounting system that can drift out of
sync with what actually ran.

### C.2 Donor side — Stripe Connect Express

Structurally a marketplace payout (same shape as Uber/Etsy/DoorDash
paying independent providers) — Connect Express is purpose-built for
this: one-time linking of an existing bank account or card, Stripe
handles the regulatory/KYC burden, not you.

**Payout amount** derives from the same `capability_avg_s` / contract
data already flowing through conscription — no new metric needs
inventing.

### C.3 The subtlety worth designing carefully: donor self-report vs. bilateral confirmation

Federation's `llm_avg_s` self-reporting works because lying about it
only degrades your own routing quality — low stakes, self-correcting.
**A donor self-reporting "I served this, pay me" is a different risk
class**, because now lying is directly profitable. Don't reuse the
self-report trust model for anything that touches real payout.

Design: **both sides confirm.** When `FederationConscriptionProvider`
completes a request against a donor (`_try_one_donor`'s success path,
already the exact moment "this donor did real work" becomes true), the
*requester* logs a claim (`{donor_url, duration, timestamp}`). The
donor independently reports the same request when it processes it. A
payout only releases for entries where both sides' claims match within
a tolerance window. A mismatch — donor claims work the requester never
logged, or vice versa — gets flagged for review, not silently paid or
silently dropped. Same pattern private BitTorrent trackers use for
share-ratio disputes: both peers report, disagreements get surfaced,
not resolved by trusting either side unilaterally.

### C.4 Batching payouts

Trigger a payout once a donor's accrued balance crosses a minimum
(~$5-10) — Stripe's own payout fee would eat a $0.50 payout entirely,
so don't trigger tiny ones. Weekly or monthly batch job, not real-time.

### C.5 One thing I'm not qualified to resolve for you

I'm not a lawyer or accountant, and money movement carries real
regulatory surface — Stripe Connect platforms typically need to handle
1099-K generation for donors crossing IRS reporting thresholds, and
"are we a money transmitter" is a real question whose answer depends on
specifics Stripe's own docs address but I shouldn't paraphrase as legal
advice. Worth a real conversation with an actual advisor before Sprint
14 goes anywhere near live payouts — flagging this once, clearly, not
because it should block the design work, just because it's the one
piece of this whole system where "we tested it thoroughly" isn't
sufficient on its own.

---

## Explicitly deferred (not in scope for the sprints below)

Named so they don't quietly creep into scope later:
- Multi-currency support (USD only for v1)
- Automated chargeback/dispute handling beyond Stripe's own tooling
- Fraud scoring beyond the bilateral-confirmation check in C.3
- A UI for donors to see historical payout tax documents (Stripe
  Express's own dashboard covers this adequately for v1)

---

## Sprint breakdown

Continuing the numbering from the federation arc (which ended at
Sprint 9).

### Sprint 10 — PoW anti-abuse gate ✅ DONE

*Goal:* `/api/ask` and `/api/speak` are protected by tiered,
memory-hard proof-of-work; federation endpoints get the same mechanism
keyed on `member_url`.

- `realm/pow_gate.py`: `generate_challenge()`, `verify_solution()`
  (Argon2id via the `argon2-cffi` package), `RateLimitTracker` (leaky
  bucket, per-IP and per-`member_url` variants)
- Wire into `/api/ask`, `/api/speak` (IP-keyed) and `/federate/checkin`
  (member_url-keyed), mirroring how `federation_token_error()` was
  wired in previously
- `pi-N` tier labels in the public-facing challenge response
- *Acceptance:* a genuine load test proving the difficulty ladder's
  wall-clock costs roughly match the table in A.3 on real hardware, not
  just unit-tested math
- *Risk:* tuning the free-tier threshold (10 calls) against real
  traffic patterns — likely needs one iteration after real usage data,
  flag this as a "ship, then tune" item rather than something to
  perfect pre-launch

**Landed as designed, with one correctness fix found during
implementation, not after:** the HMAC signature must cover
`difficulty_bits`, not just `challenge` and `expiry` — otherwise a
client could solve an easy puzzle and submit it claiming to have
solved a harder one, since nothing would stop it from editing that
field before resubmission. Caught and fixed before any test was
written against the vulnerable version, not as a later patch.

**Federated forwards bypass PoW entirely** (they're already gated by
the token check when one's configured) — this was a deliberate
integration-layer decision, not an oversight: double-gating legitimate
peer traffic with both a token AND a puzzle would be redundant, and
conflating the two threat surfaces (anonymous public callers vs. peer
realms) would have made the wiring harder to reason about for no real
security benefit.

**Real numbers, this hardware** (a shared sandbox CPU, likely slower/
more variable than a real gaming rig): `pi-100` (4 bits) ≈3.2s median,
`pi-1000` (8 bits) ≈15s median across 2-3 trials via
`pow_benchmark.py`. Shape matches the design table; exact numbers will
vary by machine — run `python pow_benchmark.py` on real deployment
hardware before relying on the tuning.

**Tests:** 33 fast unit tests (`test_pow_gate.py`, ~4.5s total — tests
mechanism correctness at low difficulty, not real tier costs) + 8 real
HTTP integration tests (`test_pow_gate_integration.py`, ~4.6s total —
proves the actual wiring into all three endpoints, including the
free-tier/paid-tier/tampered-solution/disabled-config/federated-bypass
paths against a genuinely booted app). Full suite: 1053 passed, zero
regressions.

**Post-launch incident, found on real production traffic (rentahal.com):**
`/federate/checkin` was originally gated by PoW like the other two
protected endpoints — reasonable in isolation, but never tested against
federation's own actual traffic pattern. `[Federation] checkin_interval_s`
defaults to 15 seconds; the PoW gate's free tier allows 10 calls per
10-minute window. At a 15s interval, a realm exhausts that free
allowance in exactly 150 seconds — and the federation check-in client
has no logic to solve a PoW challenge and resubmit, so every check-in
after that point fails outright. Symptom in production: check-ins
succeed for ~2.5 minutes after each restart, then fail continuously
(`Federation check-in failed (N in a row): Federator returned 402`)
until the next restart resets the in-memory counter — an infinite,
self-inflicted degrade/restart cycle for any federated realm.

Fixed by removing the PoW gate from `/federate/checkin` entirely.
`federation_token_error` (already present) is the correct, sufficient
authentication layer for this endpoint — PoW's actual threat model
(anonymous callers burning expensive GPU compute via `/api/ask` or
`/api/speak`) simply doesn't describe a legitimate peer realm's
low-cost, expected, recurring bookkeeping call. The lesson generalizes:
a security control tested thoroughly in isolation can still break a
*different* feature's normal operation if the two are never tested
together against realistic traffic volumes for both. Verified with a
dedicated regression test hammering `/federate/checkin` 50 times in a
row (five times past the old free-tier threshold) with zero PoW
challenges appearing.

### Sprint 11 — Ledger foundation ✅ DONE

*Goal:* an append-only, hash-chained Postgres ledger exists, with a
standalone chain-verification tool.

- Postgres schema (B.2), migration tooling (Alembic, matching the
  Python-first stack)
- `realm/ledger.py`: `append_entry()`, `get_balance(account_id)`,
  `verify_chain()` (importable both as a library call and a standalone
  CLI script)
- No payment integration yet — this sprint proves the ledger primitive
  in isolation, testable with synthetic entries
- *Acceptance:* a test that tampers with a row directly via raw SQL and
  confirms `verify_chain()` catches it

**One deliberate deviation from this section's original text:** built
the migration runner as a small versioned-SQL-file scanner instead of
pulling in Alembic. At one table, a full migration framework (revision
graph, autogenerate, env.py boilerplate) is real tooling weight this
codebase has consistently avoided elsewhere — `FederationMatrix` is a
plain dict + `asyncio.Lock`, not an ORM. Worth revisiting once the
schema grows enough tables (Sprint 13/14 will add more) that a real
migration graph starts earning its keep.

**Append-only is enforced at three layers, not one:** the application
never exposes an UPDATE/DELETE method at all; the hash chain itself
makes any out-of-band tampering detectable regardless of how it
happened; and an optional, NOT-auto-applied hardening script
(`002_ledger_permissions.sql.example`) creates a restricted DB role
with INSERT+SELECT grants only, for real defense in depth once real
money is involved. Not auto-applying it was deliberate — choosing and
storing a credential is an operator decision a migration script has no
business making silently.

**Timestamp handling got more care than it might look like it needed:**
the hash input uses an exact integer (`created_at_epoch_micros`), never
a formatted timestamp string — ISO-format strings have just enough
platform/driver variation (fractional-second padding, `+00:00` vs `Z`)
to make them a fragile hash input. The human-readable `TIMESTAMPTZ`
column is always derived from the same integer, so the two can never
silently disagree.

**Concurrency is real, not assumed:** appends are serialized via a
Postgres advisory lock (`pg_advisory_xact_lock`), acquired *before*
reading the current chain tip — not an in-process `asyncio.Lock`, which
would only protect a single Python process. Verified with an actual
test firing 20 concurrent `append_entry()` calls and confirming the
resulting chain still verifies clean.

**A real, if minor, finding while writing the config docs:** `config_
schema.py`'s metadata parser (`@word:` regex) silently misparses any
`@word:` substring appearing inside ordinary help-text prose — my first
draft of `[Ledger] dsn`'s help text used an example connection string
containing `@host:5432`, which the parser mistook for a real `@host:`
metadata tag. Worked around by rephrasing the example (dotted IP
instead of the word "host" — the regex can't match across a `.`), not
by touching the parser itself, which is a pre-existing fragility
outside this sprint's scope. Worth remembering for anyone writing
config.ini help text that includes an `@` symbol in example URLs,
emails, or similar.

**Tests need Postgres, and gracefully say so when it's absent, at BOTH
levels:** `pytest.importorskip("asyncpg")` handles asyncpg not being
installed at all (it's an optional dependency — most deployments never
touch the economic layer), and a separate reachability check inside the
fixture handles asyncpg being installed but no Postgres actually
running. Verified explicitly: pointing `RENTAHAL_LEDGER_TEST_DSN` at a
nonexistent server produces `3 passed, 22 skipped`, not a single error
— the 3 that still run are the pure-hash-function tests needing no
database at all.

**Numbers:** 25 tests (all against a REAL Postgres instance — each test
gets its own throwaway database, created and dropped around it, since
the hash-chain/append-only design makes shared mutable test state
awkward on purpose), full project suite 1078 passed, zero regressions,
confirmed stable across repeated runs. Real acceptance check: tampered
a row via raw SQL bypassing the application entirely, both in an
ad-hoc manual run and in the automated test suite — `verify_chain()`
and the standalone `ledger_verify.py` CLI both caught it correctly,
reporting the exact row and reason.

### Sprint 12 — Public verifiability ✅ DONE

*Goal:* the ledger's integrity is verifiable by a third party, not just
trusted on the operator's word.

- Daily job anchoring the chain-tip hash via OpenTimestamps
- A public page/endpoint serving the current proof + verification
  instructions
- *Acceptance:* an independent (non-RENT-A-HAL) verification of a real
  submitted proof against Bitcoin's actual chain

**The honest limitation of this sprint, stated plainly rather than
glossed over:** the sandbox this was built in cannot reach
OpenTimestamps' public calendar servers — confirmed directly, not
assumed (`ots stamp` against a test file returned "need at least 2
attestations but received 0"; the real `opentimestamps` library's own
submission code returned HTTP 403 from every one of the four default
calendars). This means the actual acceptance criterion — "an
independent verification of a REAL SUBMITTED proof" — genuinely cannot
be completed from within this development environment. Everything that
CAN be verified from here, was:

- The real `opentimestamps` Python library's actual API (not a guessed
  one) — explored interactively before writing a single line of
  wrapper code
- A genuine, publicly-known, already-Bitcoin-anchored proof
  (`hello-world.txt.ots`, attesting to Bitcoin block 358391, fetched
  from the OpenTimestamps client's own GitHub repo and committed into
  this repo's `tests/fixtures/`) — real local/structural verification
  against it, including extracting the exact documented block height
  and confirming a byte-identical serialize/deserialize round trip
- The full `ots_daily_job.py` pipeline (stamp → upgrade → publish),
  run for real against a real Postgres instance, with the stamp step
  honestly failing (network-restricted sandbox) while the upgrade and
  publish steps succeeded against the seeded real fixture — proving
  that half of the pipeline genuinely works without needing to fake
  anything
- The real `ots` CLI reading back the published proof file
  (`ots info`) and confirming byte-for-byte identical output to the
  known-good fixture

**What genuinely needs to happen on real deployment hardware, not
here:** a live stamp→upgrade→confirm round trip against the real
calendar servers, and full Bitcoin-consensus confirmation (which the
`opentimestamps` library itself says requires a Bitcoin node —
`ots verify` without one fails with "Could not connect to Bitcoin
node," confirmed directly, not assumed). `tests/test_ots_anchor.py`'s
one live-network test is written to skip gracefully with a clear
message when calendars aren't reachable rather than either lying about
coverage or failing CI on a restricted network — worth running
deliberately at least once from wherever this actually deploys.

**Two-tier verification, and the module is explicit about the
boundary:** LOCAL/STRUCTURAL (always available, no network) confirms
the file digest matches, the attestation chain is well-formed, and
recomputes the full Merkle path via the library's own
`Timestamp.all_attestations()` — this alone catches nearly all
realistic tampering. FULL CONFIRMATION (comparing the recomputed
Merkle result against the real Bitcoin block's actual merkle root)
needs either a Bitcoin node or a trusted third-party data source — this
module deliberately does NOT bundle a block-explorer API dependency to
paper over that gap, since doing so would just trade "trust us" for
"trust whichever explorer we picked."

**A second real bug found and fixed before it shipped, not after:**
`app.py` had unconditional top-level imports of `realm.ledger` /
`realm.ots_anchor`, which transitively import `asyncpg` /
`opentimestamps` — both OPTIONAL dependencies. This meant ANY operator
who hadn't installed them would find their entire realm failing to
boot, even with zero interest in the economic layer and `[Ledger] dsn`
left empty. Confirmed directly (simulated missing packages via
`sys.modules` manipulation, watched `import app` fail) before fixing —
moved the imports inside `create_app()`, lazy, only attempted when
`[Ledger] dsn` is actually set, with graceful degradation (a clear log
warning, feature disabled) if the packages turn out to be missing even
then. Four dedicated regression tests confirm this, including a
deliberate "temporarily reintroduce the exact bug and watch the tests
fail" check before restoring the fix — the same discipline as the
Sprint 6 config-schema-parser bugfix's own regression tests.

**Numbers:** 19 tests in `test_ots_anchor.py` (18 pass + the one
honestly-skipping live-network test in this environment), 3 real HTTP
integration tests for the `/api/ledger/proof` + `/api/ledger/proof/info`
endpoints (config-gate absence, empty-ledger 404, and full real-data
serving — including asserting the exact block height 358391 through
the actual endpoint), 4 regression tests for the optional-dependency
bug. Full project suite: 1103 passed, 1 skipped, stable across repeated
runs, smoke test and JS sweep both unaffected.

### Sprint 13 — Consumer balance rail ✅ DONE

*Goal:* a user can top up via Stripe Checkout and spend it down, one
submit at a time, at the real target price point.

- Stripe Checkout integration (top-up presets + custom amount)
- Webhook handler (idempotent — Stripe *will* retry webhook delivery;
  this must not double-credit on a retry)
- Ledger debit wired into `orchestrator.py`'s existing per-query hook
  (§C.1)
- Low-balance UX: cockpit indicator + one-click top-up prompt
- *Acceptance:* a real (test-mode) Stripe top-up, followed by enough
  submits to observably decrement the balance, followed by a
  low-balance prompt firing correctly

**The honest split, same discipline as Sprint 12:** webhook signature
verification — the single most security-critical function in this
entire sprint — is pure local HMAC-SHA256 cryptography, needing zero
network access, and got tested most thoroughly *because* of that: real
valid signatures, real forged signatures (wrong secret), real tampered
payloads, real expired timestamps, all constructed using the exact
algorithm the installed Stripe SDK's own `WebhookSignature.
verify_header` implements (read directly from the SDK source before
writing a single test, not assumed). Checkout session *creation* is
the one piece needing a genuine network call to `api.stripe.com`,
which this sandbox cannot reach (confirmed empirically — `stripe-mock`,
Stripe's own official local test server, was also attempted and
blocked: its GitHub release binary redirects to
`release-assets.githubusercontent.com`, a domain outside this
sandbox's egress allowlist). That one piece is tested via mocking the
SDK call itself, clearly labeled as such in both the module docstring
and the test file, not silently.

**The acceptance criterion, honestly assessed:** the *crediting* side
of "a real top-up" is fully real — genuine signature verification,
genuine idempotent Postgres credit, genuine balance readback, all
proven over actual HTTP against a real database. The *checkout session
creation* half (the literal outbound call to Stripe asking it to open
a payment page) is mocked. Between the two, everything that actually
determines whether money gets credited correctly and safely is real;
only the "ask Stripe to show a payment form" step isn't verifiable
from here.

**Applying the Sprint 12 lesson proactively, not finding it as a bug
again:** the exact same optional-import hazard existed for `stripe`
that Sprint 12 found (after the fact) for `asyncpg`/`opentimestamps` —
this time it was designed correctly from the start (lazy import inside
`create_app()`, gated on `[Billing]` keys being set, graceful
degradation with a clear warning if `stripe` turns out to be missing
anyway) and verified clean on the first attempt, not discovered broken
afterward. Extended the Sprint 12 regression test file to cover all
three optional packages individually and together.

**Two real API-shape findings caught during development, not
guessed around:** (1) a real Stripe webhook payload requires
`"object": "event"` at the top level — a synthetic test payload
missing it crashed deep inside the SDK's own `construct_event`, not in
this codebase's code; fixed by matching the real payload shape
exactly. (2) `stripe.StripeObject` (what `construct_event` actually
returns) does NOT implement Python's `Mapping` protocol despite
supporting `[]` access — no `.get()`, and missing keys raise
`KeyError` instead of returning `None`. Fixed by normalizing to a
plain dict via `.to_dict()` immediately, rather than special-casing
two different access patterns throughout the handler.

**Scope decision worth restating plainly:** a negative balance is NOT
hard-blocked in this sprint. Sprint 10's PoW gate already provides the
anti-abuse backstop; billing's job here is honest economic bookkeeping
plus a UX nudge (the `low_balance` bus event → cockpit banner), not a
second independent rate limiter duplicated across the WebSocket and
HTTP paths. Worth revisiting once real usage patterns are understood —
same "ship, then tune" posture as Sprint 10's own free-call threshold.

**Numbers:** 20 tests in `test_billing.py` (7 pure webhook-security
tests needing zero network/database, 3 mocked-checkout tests, 10 real
Postgres idempotency/crediting tests), 11 orchestrator wiring tests
(`test_orchestrator_billing.py` — a fast in-memory `FakeLedger` for
wiring logic plus one real-Postgres end-to-end confirmation), 7 real
HTTP endpoint integration tests, 7 extended optional-dependency
regression tests, 15 client-side low-balance-banner tests. Full
project suite: 1144 passed, 1 skipped, stable across repeated runs,
smoke test and full JS sweep both unaffected.

### Sprint 14 — Donor payout rail ✅ DONE

*Goal:* a donor realm can link a payout account and receive real money
for conscripted work, with bilateral confirmation protecting against a
single lying party.

- Stripe Connect Express onboarding flow
- Bilateral confirmation mechanism (§C.3) — this is the sprint's real
  complexity, not the Stripe integration itself
- Batched payout job (§C.4)
- *Acceptance:* a synthetic conscription scenario (mirroring Sprint 8's
  test style) where requester and donor claims match → payout credits
  correctly; a mismatched-claim scenario → flagged, not paid

**The acceptance criterion, proven directly, twice, against real
Postgres:** a lying donor claiming work the requester never confirms
gets credited **zero** — verified both in an ad-hoc manual check during
development and in the permanent test suite. A genuinely matched pair
(both sides claim the same donor/requester/rank within the tolerance
window) credits correctly regardless of which side arrives first.
Claims for a different donor, different requester, different rank, or
outside the timing tolerance never falsely match — each dimension
tested independently, not just the happy path.

**Where reconciliation lives, and why:** the FEDERATOR — the same
already-centralized point both a struggling chat realm and its donor
already trust for routing decisions via check-in. Reusing that
existing trust relationship, rather than inventing a new one or trying
to do this in a genuinely decentralized way, was a deliberate
architectural choice consistent with how conscription itself already
works (Sprint 8).

**A real gap found and fixed while wiring the donor side, not
designed in from the start:** the outgoing conscripted request
(`FederationConscriptionProvider._try_one_donor`) never told the donor
*who* the requester was — only that a request was conscripted. Fixed
by adding `X-Federation-Requester-Url` alongside the existing
diagnostic-only `X-Federation-Conscripted` header. Unlike that header,
this one is now genuinely load-bearing, not just for logs.

**Claim submission on both sides is fire-and-forget by design, tested
explicitly:** a Federator that's completely unreachable during claim
submission must never affect the answer already successfully returned
to the user — this is bookkeeping for a later payout, not part of the
request/response path. Verified with a dedicated test that makes the
Federator connection raise `ConnectionError` and confirms the caller
still gets its real answer back.

**Extended, not duplicated, Sprint 13's idempotency guarantee:** the
partial unique index from `004_ledger_idempotency.sql` (originally
scoped to `topup` entries only, protecting against Stripe webhook
redelivery) was widened in `005_donor_payout.sql` to also cover
`conscription_credit` entries — the exact same double-crediting risk,
now via reconciliation running twice on the same matched pair rather
than a webhook retry. One shared mechanism, two triggering scenarios.

**Two mutability categories, kept honestly distinct:** `conscription_
claims` and `donor_payout_accounts` are both intentionally mutable
(matched/credited flip as reconciliation happens; payouts_enabled
flips as onboarding completes) — same category as Sprint 12's
`ots_anchors`, not the ledger's own strictly append-only `ledger_
entries` table. The actual money movement this produces is still an
ordinary append-only ledger row; these two tables are the bookkeeping
that decides whether that row gets written, not a substitute for it.

**The batch job re-verifies with Stripe directly, not just its own
cached flag:** `payout_batch_job.py` calls `check_payouts_enabled`
against the real API before every transfer attempt, and updates its
own `payouts_enabled` flag to match — an account that completed
onboarding once but was later restricted by Stripe (or simply hasn't
finished) is correctly skipped rather than attempted and failing.
Verified with a dedicated test forcing this exact scenario.

**Same honest network-access split as Sprints 12-13:** bilateral
confirmation itself needs zero external network access and got the
most thorough testing because of it. Stripe Connect (account creation,
onboarding links, transfers) needs real calls to `api.stripe.com`,
unreachable from this sandbox — tested via mocking the SDK calls,
clearly labeled throughout rather than silently.

**The Sprint 12 lesson, applied proactively a second time:** `stripe`
is used by `realm/donor_payout.py` exactly like `realm/billing.py` —
lazy-imported in `app.py`, gated on `[Payout] stripe_secret_key` being
set, verified clean on the first attempt (not found broken afterward)
with the same `sys.modules` simulation technique, now covering all
three optional economic-layer packages individually and combined.

**Numbers:** 28 tests in `test_donor_payout.py` (the core bilateral
confirmation logic — real Postgres throughout), 6 requester-side claim
wiring tests, 5 real HTTP integration tests (including one that boots
TWO separate real app instances — a donor realm and a Federator — and
proves a genuine end-to-end round trip: donor answers, fires a claim,
claim lands in the Federator's real database), 6 payout batch job
tests, 1 additional optional-dependency regression test. Full project
suite: 1190 passed, 1 skipped, stable across repeated runs, smoke test
and full JS sweep both unaffected.

---

## Economic layer arc — complete

All five sprints (10-14) are done. What exists now, end to end: a
memory-hard proof-of-work gate protecting the public API surface; a
tamper-evident, publicly-verifiable ledger anchored to Bitcoin; a
consumer prepaid balance rail with idempotent Stripe billing; and a
donor payout rail with bilateral confirmation protecting against a
single lying party. Every piece that could be tested for real, was —
and every piece that couldn't (calendar servers, Stripe's live API)
is honestly documented as such rather than silently mocked, with the
exact commands and expected behavior recorded for whoever runs this on
real, unrestricted infrastructure.

Two significant bugs were caught and fixed during this arc, both
before they shipped rather than after the first time it mattered:
`app.py`'s unconditional imports of optional economic-layer packages
(found in Sprint 12, applied proactively in 13 and 14), and the
missing requester-identity header in conscripted requests (found and
fixed while wiring Sprint 14, not discovered as a production bug
later).

### Sprint 15 — Cockpit integration & acceptance ritual ✅ DONE

*Goal:* everything above is visible and operable from the existing
wizard/cockpit, not curl-only.

- Wizard: balance display, top-up entry point, PoW tier visibility for
  a realm's own recent request history
- Cockpit: donor payout status, pending/confirmed conscription earnings
- Full acceptance ritual (matching the existing `smoke_test.py` +
  `pytest tests/` + manual-check pattern) extended to cover the new
  economic surface end to end

**Wizard additions:** four new informational panels (Ledger, Billing,
Payout, Abuse Gate) — all four deliberately never gate GO, same
posture Vision/Imagine established. `probe_ledger()` does a real
Postgres connection attempt; `probe_stripe_key()` does a real, cheap
Stripe API call (`stripe.Account.retrieve()` with no ID — returns the
platform account the key belongs to, about as lightweight a validity
check as the API offers). The abuse-gate tier table is pure config
display — `realm/pow_gate.py`'s `DEFAULT_TIERS` are Python constants by
design (Sprint 10's own "ship, then tune" note), so this panel exists
purely so an operator can see the ladder without reading source.

**A real, if minor, finding while writing the wizard tests:**
`Config.save_value()` does an in-place line rewrite — it requires the
target section+key to already exist as literal text in the file to
find and replace. This works correctly against the REAL shipped
`config.ini` (which already has `[Ledger]`/`[Billing]`/`[Payout]` with
empty-string defaults, added across Sprints 11-14) but silently no-ops
against a bare-minimum test fixture missing those sections — not a
Sprint 15 bug, a pre-existing property of how this codebase's config
writer has always worked, caught by writing a test with an unrealistic
fixture and fixed by making the fixture match the real file's shape,
same discipline as Sprint 9's original wizard tests already established.

**Cockpit additions:** a persistent (not just low-balance) balance
indicator, polling this realm's own `/api/billing/balance`, and a
donor-earnings indicator that piggybacks on the *existing* federation
status poll (since donor payout status lives on the Federator, keyed
by this realm's own `self_url` — no separate timer needed, just a call
added to the same `renderFederationStatus` that already runs every
20s). Both hidden by default; a realm that's never touched the
economic layer sees neither, keeping the cockpit exactly as
uncluttered as it's always been.

**One real bug caught immediately, before it shipped:** the new
`GET /api/federate/payout/status` endpoint was first written with the
wrong route path (`/payout/status` instead of `/federate/payout/status`,
inconsistent with its sibling `/federate/payout/link`) — caught by
running a real end-to-end HTTP test immediately after writing it,
exactly the discipline this whole arc has tried to apply throughout.

**The full acceptance ritual** (`economic_layer_acceptance.py`) mirrors
`smoke_test.py`'s own style exactly — boot the real app, drive real
HTTP calls, PASS/FAIL per check, exit non-zero on any real failure.
Genuinely ran end to end against real Postgres: **16/16 checks passed**,
covering PoW tiers, ledger tamper detection, OpenTimestamps local
verification against the real bundled fixture, real webhook signature
verification and idempotent crediting, bilateral confirmation (both
the matched-credits-correctly and lying-donor-gets-nothing cases), and
the new payout status endpoint. With Postgres stopped, the same script
correctly reports `5/10 passed, 5 skipped` with exit code 0 — the
parts that don't need Postgres (PoW, OTS local verify) still ran for
real; nothing was falsely reported as passing or failing.

**Numbers:** 12 wizard economic-layer tests, 3 payout status endpoint
tests, 18 new JS tests (cockpit indicators) + 21 extended wizard syntax
tests. Full project suite: 1205 passed, 1 skipped, stable across
repeated runs, smoke test 37/37, full JS sweep clean, and the standalone
acceptance ritual passing 16/16 for real.

**Post-ship incidents, found compiling and deploying for real (not
caught by any test, since they only manifest under Nuitka's actual
compiled-mode behavior):**

1. `app.py` and `wizard.py` resolved config file paths to different
   directories in compiled mode — `app.py` used "next to the exe,"
   `wizard.py` used `%LOCALAPPDATA%\RentAHalSOHO\<version>`. A wizard
   edit could be invisible to the realm, or vice versa. Fixed via
   `realm/ini_location.py`, one shared implementation both entry
   points import.
2. That fix's settings folder name (`RentAHalSOHO`) collided with
   Nuitka's own `--onefile-tempdir-spec` extraction cache folder for
   the same name — both resolve under `%LOCALAPPDATA%` via Nuitka's
   `{CACHE_DIR}` placeholder. Renamed to `RentAHalSOHO-Settings` to
   guarantee no collision regardless of Nuitka's internal caching
   behavior.
3. The first version of that fix had no migration path for a machine
   that already had real, working settings sitting in the *old*
   location — a freshly compiled exe found nothing at the new path and
   fell back to the bundled default template, silently reverting
   rentahal.com's actual production `[Federator] enabled = true` back
   to the template's `false` and taking the Federator offline in
   production. Fixed by having `ensure_default_ini_files()` check every
   known prior location for real settings *before* ever falling back to
   a bundled default — verified directly against the exact scenario
   that caused the incident (a real config sitting at the legacy
   location, a fresh LOCALAPPDATA folder with nothing in it).

None of these three were reachable by the existing test suite before
they happened — Nuitka's actual onefile extraction/caching behavior,
and a machine with genuinely pre-existing production settings, aren't
things a sandboxed test environment can fully simulate. All three are
now covered by dedicated regression tests (`test_ini_location.py`)
that simulate the specific conditions directly, so the same class of
surprise can't recur silently on a future change to this logic.

---

## Economic layer arc — fully complete (Sprints 10-15)

Every sprint in the original plan is done. The whole arc, end to end:
a memory-hard proof-of-work gate protecting the public API surface; a
tamper-evident, publicly-verifiable ledger anchored to Bitcoin; a
consumer prepaid balance rail with idempotent Stripe billing; a donor
payout rail with bilateral confirmation protecting against a single
lying party; and now full visibility from the wizard and cockpit, plus
a standalone acceptance ritual that genuinely proves the whole thing
works together, not just each piece in isolation.

Three real bugs were caught and fixed during this arc, all before they
shipped rather than after: `app.py`'s unconditional imports of
optional economic-layer packages (Sprint 12, applied proactively
thereafter), the missing requester-identity header in conscripted
requests (Sprint 14), and a wrong route path on the payout status
endpoint (Sprint 15, caught within the same session it was written).
Every piece that could be tested for real, was — and every piece that
couldn't (calendar servers, Stripe's live API) is honestly documented
as such throughout, with exact commands and expected behavior recorded
for whoever runs this on real, unrestricted infrastructure.

---

## Dependency chain

**Status: Sprints 10-15 all done (✅ above). The full economic layer arc is complete.**

```
Sprint 10 (PoW) ──────────────────────────────────┐
                                                    │  independent of
Sprint 11 (Ledger) → Sprint 12 (OpenTimestamps)    │  each other until
        │                                          │  Sprint 15
        ├──→ Sprint 13 (Consumer balance)          │
        └──→ Sprint 14 (Donor payout)  ─────────────┘
                        │
                        ▼
              Sprint 15 (Cockpit + acceptance)
```

10, 11→12, and the 13/14 pair can genuinely be built in any order
relative to each other — only 15 needs everything else done first. If
you want the fastest path to something demoable, 10 alone is a
complete, shippable unit on its own (anti-abuse gating with zero
payment infrastructure at all) — worth considering as the actual first
sprint to build regardless of how the rest sequences.
