#!/usr/bin/env python3
"""
ledger_verify.py — Sprint 11: standalone chain-integrity check.

Run this any time you want to independently confirm the ledger hasn't
been tampered with — by an operator doing a routine audit, or by a
donor/consumer who wants to check the system's own honesty claims
before trusting it with real money. No app-level trust required: this
script only needs read access to the ledger_entries table and recomputes
every hash from scratch, exactly like tests/test_ledger.py's tampering
tests do, just against whatever real ledger you point it at.

Usage:
    python ledger_verify.py                          # uses [Ledger] dsn from config.ini
    python ledger_verify.py --dsn postgresql://...    # explicit override
    python ledger_verify.py --account user-alice      # show that account's balance too
"""
import argparse
import asyncio
import configparser
import sys
from pathlib import Path

from realm.ledger import Ledger


def _dsn_from_config() -> str:
    cfg = configparser.ConfigParser()
    cfg.read(Path(__file__).parent / "config.ini")
    if cfg.has_section("Ledger"):
        return cfg.get("Ledger", "dsn", fallback="")
    return ""


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dsn", help="Postgres DSN (overrides config.ini)")
    parser.add_argument("--account", help="also print this account's balance")
    args = parser.parse_args()

    dsn = args.dsn or _dsn_from_config()
    if not dsn:
        print("No DSN provided and [Ledger] dsn is not set in config.ini.")
        print("Pass --dsn postgresql://user:pass@host:port/dbname explicitly.")
        sys.exit(2)

    print(f"Connecting to ledger...")
    ledger = await Ledger.connect(dsn, run_migrations=False)
    try:
        print("Walking the full chain and recomputing every hash...")
        result = await ledger.verify_chain()

        print()
        if result.valid:
            print(f"✅ CHAIN VALID — {result.checked_count} entries checked, "
                 f"zero discrepancies.")
        else:
            print(f"❌ CHAIN INVALID")
            print(f"   Checked {result.checked_count} entries before finding "
                 f"a problem.")
            print(f"   First bad row: id={result.first_bad_id}")
            print(f"   Reason: {result.reason}")
            print()
            print("   This means the ledger has been altered outside the "
                 "application — either directly via SQL, or via a "
                 "credential that shouldn't have UPDATE/DELETE access. "
                 "See realm/migrations/002_ledger_permissions.sql.example "
                 "for how to lock that down going forward.")

        if args.account:
            balance = await ledger.get_balance(args.account)
            print()
            print(f"Balance for '{args.account}': {balance} micros "
                 f"(${balance / 1_000_000:.6f})")

        sys.exit(0 if result.valid else 1)
    finally:
        await ledger.close()


if __name__ == "__main__":
    asyncio.run(main())
