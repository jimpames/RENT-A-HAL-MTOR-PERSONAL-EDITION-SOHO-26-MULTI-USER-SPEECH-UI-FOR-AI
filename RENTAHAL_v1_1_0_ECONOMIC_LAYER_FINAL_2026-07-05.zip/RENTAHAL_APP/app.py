"""
app.py — RENT-A-HAL integrated launcher.

  python app.py                       # uses config.ini
  python app.py --port 9999           # override port
  python app.py --host 0.0.0.0 --port 9999
  RENTAHAL_FAKE_ENGINES=1 python app.py    # echo engines, no network

Designed for Windows venv. No torch imports at module load.
Heavy ML deps (kokoro_onnx, etc.) are loaded LAZILY by their providers,
only if the user actually enables them and the package is installed.
Missing packages = the provider reports unavailable and the chain skips it.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import configparser
import json
import logging
import os
import re
import sys
import time
import uuid
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

import aiohttp
import uvicorn
from fastapi import APIRouter, FastAPI, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# Make `realm` importable whether launched from APP/ or installed
APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

from realm.event_bus import EventBus
from realm.intent import IntentClassifier
from realm.engine_chain import (
    LLMChain, TTSChain,
    build_llm_chain, build_tts_chain,
    EchoLLMProvider, EchoTTSProvider,
    VisionChain, ImagineChain,
    build_vision_chain, build_imagine_chain,
    EchoVisionProvider, EchoImagineProvider,
)
from realm.orchestrator import Orchestrator
from realm.realm_core import ConnectionManager
from realm.config_schema import get_config as get_schema_config
from realm.gpu_probe import probe_cuda
from realm.federation import (
    FederationMatrix, FederationConfig, FederationState, FederationClient,
    FEDERATOR_DEFAULTS, DEGRADED_AVG_S, CONSCRIPTION_RANKS,
)
from realm.federation_provider import (
    FederationLLMProvider, FederationLLMFallbackProvider,
    FederationConscriptionProvider,
)
from realm.pow_gate import PowGate
from realm.ini_location import (
    resolve_ini_dir, ensure_default_ini_files, is_compiled,
    known_legacy_ini_dirs,
)
# NOTE: Ledger/ots_anchor are deliberately NOT imported here at module
# level — see the lazy import inside create_app(), guarded by whether
# [Ledger] dsn is actually configured. asyncpg and opentimestamps-client
# are OPTIONAL dependencies (requirements.txt); an unconditional import
# here would make the ENTIRE realm fail to boot for any operator who
# hasn't installed them, even if they never touch the economic layer at
# all — confirmed as a real bug during Sprint 12 development, not a
# hypothetical one, and fixed before it shipped.

# ============================================================================
# CONFIG
# ============================================================================

# Compiled-EXE behavior: INI files live in %LOCALAPPDATA%\RentAHalSOHO-Settings\
# <version>\, NOT inside the Nuitka extraction temp dir and NOT "next
# to the exe" — LOCALAPPDATA is always writable regardless of where the
# exe itself is installed (e.g. Program Files, which needs elevation).
#
# realm/ini_location.py is the SINGLE SHARED implementation of this
# resolution logic — wizard.py imports the exact same function. This
# used to be two independently-maintained copies that quietly drifted
# apart (app.py resolved "next to the exe," wizard.py resolved
# LOCALAPPDATA), meaning an edit made through the wizard could be
# completely invisible to the realm, or vice versa, depending on which
# exe's directory happened to have a stray config.ini sitting in it.
# Found while reviewing the Nuitka compile command, fixed by deleting
# the second copy rather than trying to keep two copies in sync by hand.
_IS_COMPILED = is_compiled()
INI_DIR = resolve_ini_dir(APP_DIR)

if _IS_COMPILED:
    # First-run bootstrap: a fresh LOCALAPPDATA folder has nothing in
    # it. Copies default config.ini/federation.ini from the bundled
    # templates (see the compile command's --include-data-files) —
    # idempotent, never overwrites an existing/edited file.
    ensure_default_ini_files(INI_DIR, APP_DIR,
                             legacy_dirs=known_legacy_ini_dirs())

CONFIG_PATH = INI_DIR / "config.ini"
FEDERATION_CONFIG_PATH = INI_DIR / "federation.ini"

# Startup diagnostics — show exactly where the realm looks for INIs.
# Surfaces config-not-found at boot time BEFORE the realm tries to
# serve traffic. Logged at INFO so it appears in normal startup output.
_logger_for_ini = logging.getLogger("rentahal.ini")
_logger_for_ini.info("Realm INI lookup: compiled_mode=%s", _IS_COMPILED)
_logger_for_ini.info("Realm INI lookup: INI_DIR=%s", INI_DIR)
_logger_for_ini.info("Realm INI lookup: config.ini exists=%s (%s)",
                     CONFIG_PATH.exists(), CONFIG_PATH)
_logger_for_ini.info("Realm INI lookup: federation.ini exists=%s (%s)",
                     FEDERATION_CONFIG_PATH.exists(), FEDERATION_CONFIG_PATH)


# ─── Cached GPU identity (probed once at module load) ────────────────
# Surfaces the ACTUAL hardware in the cockpit footer instead of a
# hardcoded string. Every operator sees their own card name. Falls
# back gracefully to "GPU unknown" if nvidia-smi isn't available.
_gpu_probe = probe_cuda()
GPU_DEVICE_NAME = (_gpu_probe.get("device_name") or "").strip() or "GPU unknown"


def load_ini() -> configparser.ConfigParser:
    """Loads config.ini, then layers federation.ini on top if present.

    Federation lives in its own file because: (1) operators frequently
    edit federation settings without touching the rest of the realm
    config, (2) federation.ini can be deployed/templated by ops tools
    independently, (3) the principle of least surprise — a feature this
    distinctive deserves its own config file."""
    cfg = configparser.ConfigParser()
    if not cfg.read(CONFIG_PATH, encoding="utf-8"):
        raise SystemExit(f"config.ini not found at {CONFIG_PATH}")
    # Federation config is OPTIONAL. If federation.ini doesn't exist,
    # the [Federation] and [Federator] sections stay absent and all
    # federation features stay defaulted-off. No error, no warning.
    if FEDERATION_CONFIG_PATH.exists():
        try:
            cfg.read(FEDERATION_CONFIG_PATH, encoding="utf-8")
        except Exception as e:
            # Don't crash the realm if federation.ini is malformed —
            # log and continue with federation off.
            logging.getLogger(__name__).warning(
                "federation.ini load failed (%s); federation disabled", e)
    return cfg


def cfg_get(cfg, section, key, default=""):
    """Safe getter — returns default for missing section or key."""
    if cfg.has_section(section):
        return cfg.get(section, key, fallback=default)
    return default


def cfg_int(cfg, section, key, default=0):
    try:
        return int(cfg_get(cfg, section, key, str(default)))
    except (ValueError, TypeError):
        return default


def federation_token_error(configured_token: str, provided_token: str
                           ) -> Optional[JSONResponse]:
    """Shared gate for every federation-facing endpoint. Loose-end fix:
    the `token` field/header has been SENT by every federation client
    (check-in payload, X-Federation-Token on /api/ask + /api/speak) since
    Sprints 6-9, but nothing anywhere ever validated it — federation
    was effectively open regardless of what an operator set.

    Behavior: if configured_token is empty (the default — nobody has
    set [Federation] token), this returns None unconditionally, i.e.
    NO validation happens at all. This preserves today's actual
    behavior with zero config changes for every existing deployment;
    requiring a token is something an operator now opts INTO by
    setting one, not something retroactively imposed. Once set, EVERY
    federation-facing endpoint enforces it consistently — checkin,
    the two query-forwarding endpoints, and the admin/observability
    surface (matrix/contracts/revoke) all go through this same
    function, rather than one endpoint being the accidental exception.

    Returns a ready-to-return 401 JSONResponse on mismatch, or None if
    the caller should proceed."""
    if not configured_token:
        return None
    if provided_token == configured_token:
        return None
    return JSONResponse({"error": "invalid or missing federation token"},
                        status_code=401)


def cfg_bool(cfg, section, key, default=False):
    val = cfg_get(cfg, section, key, "true" if default else "false")
    return str(val).strip().lower() in ("1", "true", "yes", "on")


# ============================================================================
# LOGGING
# ============================================================================

def setup_logging(cfg):
    log_file = cfg_get(cfg, "Logging", "log_file", "webgui_detailed.log")
    log_level = cfg_get(cfg, "Logging", "log_level", "INFO").upper()
    max_bytes = cfg_int(cfg, "Logging", "log_max_bytes", 10485760)
    backups = cfg_int(cfg, "Logging", "log_backup_count", 5)

    fmt = logging.Formatter("%(asctime)s [%(name)s] %(levelname)s: %(message)s")
    root = logging.getLogger()
    root.setLevel(getattr(logging, log_level, logging.INFO))
    # Avoid duplicate handlers on reload
    for h in list(root.handlers):
        root.removeHandler(h)
    fh = RotatingFileHandler(APP_DIR / log_file, maxBytes=max_bytes,
                             backupCount=backups, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(fh)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    root.addHandler(sh)
    return logging.getLogger("rentahal")


# ============================================================================
# CHAINS — built from config; nothing hardcoded
# ============================================================================

def build_chains_from_config(cfg):
    if os.environ.get("RENTAHAL_FAKE_ENGINES"):
        # All-echo for protocol-level testing without any network
        return (LLMChain([EchoLLMProvider()]),
                TTSChain([EchoTTSProvider()]),
                VisionChain([EchoVisionProvider()]),
                ImagineChain([EchoImagineProvider()]))

    llm_cfg = {
        "llm_order":           cfg_get(cfg, "LLMChain", "llm_order",
                                       "gpt4all,claude,huggingface,echo"),
        "gpt4all_host":        cfg_get(cfg, "GPT4All", "host", "localhost"),
        "gpt4all_port":        cfg_get(cfg, "GPT4All", "port", "4891"),
        "gpt4all_model":       cfg_get(cfg, "GPT4All", "model", "Llama 3 8B Instruct"),
        "gpt4all_timeout":     cfg_get(cfg, "GPT4All", "timeout", "60"),
        "claude_api_key":      cfg_get(cfg, "Claude", "api_key", ""),
        "claude_model":        cfg_get(cfg, "Claude", "model_name", "claude-haiku-4-5-20251001"),
        "claude_max_tokens":   cfg_get(cfg, "Claude", "max_tokens", "500"),
        "huggingface_api_key": cfg_get(cfg, "HuggingFace", "api_key", ""),
        "huggingface_model":   cfg_get(cfg, "HuggingFace", "default_models",
                                       "meta-llama/Meta-Llama-3-8B-Instruct").split(",")[0].strip(),
    }
    tts_cfg = {
        "tts_order":            cfg_get(cfg, "TTSChain", "tts_order",
                                        "kokoro_service,sapi5,kokoro,elevenlabs,openai,pyttsx3"),
        "kokoro_service_host":  cfg_get(cfg, "KokoroService", "host", ""),
        "kokoro_service_port":  cfg_get(cfg, "KokoroService", "port", "9998"),
        "kokoro_service_timeout": cfg_get(cfg, "KokoroService", "timeout", "30"),
        "kokoro_service_deferred": cfg_get(cfg, "KokoroService", "deferred", "false"),
        "kokoro_speed":         cfg_get(cfg, "Kokoro", "speed", "1.0"),
        "kokoro_model_path":    cfg_get(cfg, "Kokoro", "model_path", ""),
        "kokoro_voices_path":   cfg_get(cfg, "Kokoro", "voices_path", ""),
        "kokoro_voice":         cfg_get(cfg, "Kokoro", "voice", "af_sarah"),
        "kokoro_onnx_provider": cfg_get(cfg, "Kokoro", "onnx_provider", "CUDAExecutionProvider"),
        "kokoro_cudnn_conv_algo_search": cfg_get(cfg, "Kokoro", "cudnn_conv_algo_search", "DEFAULT"),
        "elevenlabs_api_key":   cfg_get(cfg, "ElevenLabs", "api_key", ""),
        "elevenlabs_voice_id":  cfg_get(cfg, "ElevenLabs", "voice_id", "EXAVITQu4vr4xnSDxMaL"),
        "elevenlabs_model_id":  cfg_get(cfg, "ElevenLabs", "model_id", "eleven_turbo_v2_5"),
        "openai_api_key":       cfg_get(cfg, "OpenAITTS", "api_key", ""),
        "openai_tts_model":     cfg_get(cfg, "OpenAITTS", "model", "tts-1"),
        "openai_tts_voice":     cfg_get(cfg, "OpenAITTS", "voice", "alloy"),
    }
    vision_cfg = {
        "vision_order":  cfg_get(cfg, "VisionChain", "vision_order", "llava,echo"),
        "llava_host":    cfg_get(cfg, "LLaVA", "host", "localhost"),
        "llava_port":    cfg_get(cfg, "LLaVA", "port", "11434"),
        "llava_model":   cfg_get(cfg, "LLaVA", "model", "llava"),
        "llava_timeout": cfg_get(cfg, "LLaVA", "timeout", "60"),
    }
    imagine_cfg = {
        "imagine_order":          cfg_get(cfg, "ImagineChain", "imagine_order",
                                          "automatic1111,echo"),
        "automatic1111_host":    cfg_get(cfg, "Automatic1111", "host", "localhost"),
        "automatic1111_port":    cfg_get(cfg, "Automatic1111", "port", "7860"),
        "automatic1111_steps":   cfg_get(cfg, "Automatic1111", "steps", "20"),
        "automatic1111_width":   cfg_get(cfg, "Automatic1111", "width", "512"),
        "automatic1111_height":  cfg_get(cfg, "Automatic1111", "height", "512"),
        "automatic1111_sampler": cfg_get(cfg, "Automatic1111", "sampler", "Euler a"),
        "automatic1111_timeout": cfg_get(cfg, "Automatic1111", "timeout", "120"),
    }
    return (build_llm_chain(llm_cfg), build_tts_chain(tts_cfg),
            build_vision_chain(vision_cfg), build_imagine_chain(imagine_cfg))


# ============================================================================
# WEATHER HANDLER — used by the Orchestrator when intent.kind == 'weather'
# ============================================================================

def make_weather_handler(cfg):
    api_key = cfg_get(cfg, "Weather", "api_key", "")
    units = cfg_get(cfg, "Weather", "units", "imperial")
    onecall = cfg_get(cfg, "Weather", "onecall_url",
                      "https://api.openweathermap.org/data/3.0/onecall")
    geocode_direct = "https://api.openweathermap.org/geo/1.0/direct"

    async def handler(slots, user_guid):
        if not api_key or "YOUR_" in api_key:
            return "The weather realm needs an OpenWeatherMap API key in config.ini."
        location = slots.get("location", "").strip() or "Newburgh"
        try:
            async with aiohttp.ClientSession() as s:
                # Geocode the city name to lat/lon
                async with s.get(geocode_direct,
                                 params={"q": location, "limit": 1, "appid": api_key},
                                 timeout=10) as r:
                    geo = await r.json()
                if not geo:
                    return f"I couldn't find a place called {location}."
                lat, lon = geo[0]["lat"], geo[0]["lon"]
                # Get current weather
                async with s.get(onecall, params={
                    "lat": lat, "lon": lon,
                    "exclude": "minutely,hourly,alerts",
                    "units": units, "appid": api_key,
                }, timeout=10) as r:
                    w = await r.json()
            cur = w.get("current", {})
            temp = cur.get("temp")
            cond = (cur.get("weather") or [{}])[0].get("description", "")
            unit_str = "Fahrenheit" if units == "imperial" else "Celsius"
            return (f"In {location}, it's currently {temp:.0f} degrees {unit_str} "
                    f"with {cond}.") if temp is not None else \
                   f"I got data for {location} but couldn't read the temperature."
        except Exception as e:
            return f"Weather lookup failed: {e}"

    return handler


# ─── Music handler ────────────────────────────────────────────────
# Legal architecture:
#   - We search DuckDuckGo's HTML endpoint (a public web page, no API key,
#     no quota, no ToS issue). DuckDuckGo's HTML endpoint exists precisely
#     for programmatic use and has no rate limits in practice.
#   - We parse the page for a YouTube watch?v=<ID> link. The first match
#     is the video the user gets.
#   - The realm sends only the video ID to the browser via a bus event.
#   - The browser embeds youtube.com/embed/<ID>?autoplay=1 — the standard
#     YouTube IFrame pattern that's documented and definitively works.
#   - YouTube serves the video, ads, and player UI directly to the user's
#     browser from the user's IP. The realm never touches YouTube.

# Regex captures all URL forms YouTube IDs appear in:
#   www.youtube.com/watch?v=ABCDEF       — direct link
#   youtu.be/ABCDEF                       — short link
#   youtube.com%2Fwatch%3Fv%3DABCDEF      — URL-encoded (DDG redirect wrapper)
# Video IDs are exactly 11 characters of [A-Za-z0-9_-].
# The regex handles either '=' or '%3D' between v and the ID, and either
# '?' or '%3F' as separators (DDG's uddg=... wrappers URL-encode the
# embedded target URL).
_YT_ID_RE = re.compile(
    r"(?:"
    r"youtube\.com(?:/|%2F)watch(?:\?|%3F)(?:[^\"\'\s<>]*?(?:&|%26))?"
    r"v(?:=|%3D)"
    r"|youtu\.be(?:/|%2F)"
    r")"
    r"([A-Za-z0-9_\-]{11})"
)


def make_music_handler(cfg):
    """Music handler — searches DuckDuckGo for the user's query and finds
    the first YouTube video ID. Pushes the ID to the browser via a
    'music_search_request' bus event. Browser embeds the video directly
    from YouTube. No YouTube API call, no API key, ever."""
    log = logging.getLogger("rentahal.music")

    # Allow sysop to disable music entirely
    enabled = cfg_get(cfg, "Music", "enabled", "true").lower() in (
        "true", "yes", "1", "on")
    # Allow sysop to customize the search suffix (e.g. add "official video")
    suffix = cfg_get(cfg, "Music", "search_suffix", "official music video").strip()
    timeout_s = float(cfg_get(cfg, "Music", "search_timeout_s", "10"))

    async def handler(slots, user_guid, bus):
        if not enabled:
            return "Music realm is disabled on the server."
        query = (slots.get("query") or "").strip()
        if not query:
            return ("Music search needs a song name. "
                    "Try: music player london calling newline.")

        full_query = f"{query} {suffix}".strip() if suffix else query
        video_id = None
        error_detail = ""
        try:
            # DuckDuckGo's HTML endpoint is meant for programmatic use.
            # We send a polite User-Agent so they know who's calling.
            timeout = aiohttp.ClientTimeout(total=timeout_s)
            headers = {
                "User-Agent": ("Mozilla/5.0 (RENT-A-HAL Music Search; "
                               "+https://rentahal.com)"),
            }
            url = "https://html.duckduckgo.com/html/"
            log.info("Music: searching DDG for %r", full_query)
            async with aiohttp.ClientSession(timeout=timeout,
                                             headers=headers) as s:
                async with s.get(url, params={"q": full_query}) as r:
                    log.info("Music: DDG returned status=%d", r.status)
                    if r.status != 200:
                        error_detail = f"DuckDuckGo returned status {r.status}"
                    else:
                        body = await r.text()
                        log.info("Music: DDG body length=%d chars",
                                 len(body))
                        m = _YT_ID_RE.search(body)
                        if m:
                            video_id = m.group(1)
                            log.info("Music: extracted video_id=%s",
                                     video_id)
                        else:
                            # Capture a hint of what came back so we can
                            # adjust the regex if needed
                            youtube_mention = "youtube.com" in body.lower()
                            error_detail = (
                                f"no YouTube link found in results "
                                f"(body had youtube.com mention: {youtube_mention})"
                            )
                            log.warning("Music: %s", error_detail)
        except asyncio.TimeoutError:
            error_detail = "search timed out"
            log.warning("Music: search timed out for %r", full_query)
        except Exception as e:
            error_detail = f"search error: {e}"
            log.exception("Music: search error for %r", full_query)

        if not video_id:
            return (f"Couldn't find a YouTube video for {query}. "
                    f"({error_detail})" if error_detail
                    else f"Couldn't find a YouTube video for {query}.")

        # Publish the bus event so the browser can embed the video.
        # We include the query so the panel can show what was searched.
        log.info("Music: publishing video_id=%s for user=%s",
                 video_id, user_guid)
        await bus.publish("music_search_request",
                          user_guid=user_guid,
                          query=query,
                          video_id=video_id)
        return f"Playing {query} on YouTube."

    return handler


# ─── Vision handler ────────────────────────────────────────────────
# The webcam frame arrives out of band (the browser attaches it to the
# prompt_text message when it guesses a vision intent — see intent.py's
# _on_prompt for why that's a guess, not a certainty). Runs the frame
# through the VisionChain (LLaVA, falling through to the Echo floor).
# The description text IS the answer — it flows through the same
# query_result -> answer-box -> TTS path as every other kind. When the
# Echo floor fires, we also publish the shared easter_egg_video bus
# event so the client's video panel can show the Magoo clip alongside
# the spoken apology.

def make_vision_handler(cfg, vision_chain):
    log = logging.getLogger("rentahal.vision")

    async def handler(image_b64, slots, user_guid, bus):
        if not image_b64:
            # The browser's pre-emptive capture guess didn't pan out
            # (permission denied, capture failed, or the phrase matched
            # a vision trigger but no webcam access was available).
            return ("I didn't get a picture to look at. Make sure the "
                    "camera is enabled and try again.")
        text = await vision_chain.describe(image_b64, prompt="What do you see?")
        if vision_chain.last_provider == EchoVisionProvider.name:
            log.info("Vision: floor fired for user=%s, playing easter egg",
                     user_guid)
            await bus.publish("easter_egg_video", user_guid=user_guid,
                              youtube_id=EchoVisionProvider.EASTER_EGG_YOUTUBE_ID,
                              source="vision")
        return text

    return handler


# ─── Imagine handler ───────────────────────────────────────────────
# Runs the free-form prompt through the ImagineChain (Automatic1111,
# falling through to the Echo floor). Mirrors the music handler's
# shape: publishes the actual payload for the panel via the bus, and
# returns a short spoken confirmation text. On the Echo floor, we
# publish the shared easter_egg_video event (the rickroll) instead of
# the stub image — the floor firing means "nothing is actually
# generating art," so showing a real image there would be misleading.

def make_imagine_handler(cfg, imagine_chain):
    log = logging.getLogger("rentahal.imagine")

    async def handler(slots, user_guid, bus):
        prompt = (slots.get("prompt") or "").strip()
        if not prompt:
            return ("Imagine what? Try: imagine a kitten wearing a hat.")

        image_b64 = await imagine_chain.generate(prompt)
        if image_b64 is None:
            # No provider at all answered — not even the Echo floor.
            # Only happens if an operator explicitly configured
            # imagine_order without echo in it.
            log.warning("Imagine: no provider answered for user=%s", user_guid)
            return "No image model is currently online."

        if imagine_chain.last_provider == EchoImagineProvider.name:
            log.info("Imagine: floor fired for user=%s, playing easter egg",
                     user_guid)
            await bus.publish("easter_egg_video", user_guid=user_guid,
                              youtube_id=EchoImagineProvider.RICKROLL_YOUTUBE_ID,
                              source="imagine")
            return "No image model is currently online."

        log.info("Imagine: publishing image for user=%s, prompt=%r",
                 user_guid, prompt)
        await bus.publish("imagine_result", user_guid=user_guid,
                          prompt=prompt, image_b64=image_b64)
        return f"Here's what I imagined for {prompt}."

    return handler


# ─── Service-finder handler ───────────────────────────────────────
# Legal architecture:
#   - We call BizData (https://bizdata-web.vercel.app), a free REST wrapper
#     around the OpenStreetMap Overpass API. No API key, no quota.
#   - BizData expects a location STRING (city name), so we reverse-geocode
#     the user's lat/lon via Nominatim (OpenStreetMap's official geocoder,
#     also free, no API key) to get the city name.
#   - All data comes from OpenStreetMap (open data, ODbL license).
#   - We display "Powered by OpenStreetMap contributors" attribution to
#     respect OSM's license requirement.
#   - The bizdata_url is config-driven so a sysop can swap to a different
#     OSM-backed endpoint (or self-hosted Overpass) without code changes.

import math


def _haversine_miles(lat1: float, lon1: float,
                     lat2: float, lon2: float) -> float:
    """Great-circle distance between two points in miles. Standard
    formula; the constants are Earth's radius (3959 mi)."""
    R = 3959.0
    lat1r, lat2r = math.radians(lat1), math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(lat1r) * math.cos(lat2r) * math.sin(dlon / 2) ** 2)
    return R * 2 * math.asin(math.sqrt(a))


def _compass_bearing(lat1: float, lon1: float,
                     lat2: float, lon2: float) -> str:
    """Return a coarse compass bearing word (north, northeast, etc.)
    from point 1 to point 2. Used for spoken summaries: 'Joe's Barber,
    0.3 miles north on Main Street'."""
    lat1r, lat2r = math.radians(lat1), math.radians(lat2)
    dlon = math.radians(lon2 - lon1)
    x = math.sin(dlon) * math.cos(lat2r)
    y = (math.cos(lat1r) * math.sin(lat2r) -
         math.sin(lat1r) * math.cos(lat2r) * math.cos(dlon))
    bearing = math.degrees(math.atan2(x, y))
    bearing = (bearing + 360) % 360
    directions = ["north", "northeast", "east", "southeast",
                  "south", "southwest", "west", "northwest"]
    idx = int((bearing + 22.5) % 360 // 45)
    return directions[idx]


def make_service_handler(cfg, get_user_location):
    """Service-finder handler — given a category from the intent, find the
    top 3 nearby businesses via BizData (OpenStreetMap data).

    The realm requires the user's location to have been previously sent
    by the browser via a 'client_location' message. The handler asks the
    orchestrator for the current user's location via the get_user_location
    callable; if no location, returns a friendly error message.

    Publishes a 'service_results' bus event with the structured results,
    and returns a brief spoken summary string for TTS."""
    log = logging.getLogger("rentahal.service")

    enabled = cfg_get(cfg, "Service", "enabled", "true").lower() in (
        "true", "yes", "1", "on")
    bizdata_url = cfg_get(cfg, "Service", "bizdata_url",
                          "https://bizdata-web.vercel.app/api/businesses")
    nominatim_url = cfg_get(cfg, "Service", "nominatim_url",
                            "https://nominatim.openstreetmap.org/reverse")
    radius_km = float(cfg_get(cfg, "Service", "radius_km", "5"))
    max_results = int(cfg_get(cfg, "Service", "max_results", "3"))
    timeout_s = float(cfg_get(cfg, "Service", "timeout_s", "12"))

    async def handler(slots, user_guid, bus):
        if not enabled:
            return "Service finder is disabled on the server."

        category = (slots.get("category") or "").strip()
        category_label = (slots.get("category_label") or category
                          or "service").strip()
        if not category:
            unmatched = slots.get("category_unmatched", "").strip()
            if unmatched:
                return (f"I don't recognize {unmatched} as a service category. "
                        "Try: haircut, pharmacy, coffee, gas station, bank.")
            return ("Service finder needs a category. "
                    "Try: service finder haircut newline.")

        loc = get_user_location(user_guid)
        if not loc:
            return ("I need your location first. Tap 'Share location' "
                    "when your browser asks, then try again.")

        lat, lon = loc["lat"], loc["lon"]
        log.info("Service: %s for user=%s at (%f,%f)",
                 category, user_guid, lat, lon)

        # Reverse-geocode lat/lon → city name (for BizData's location param)
        city_name = None
        timeout = aiohttp.ClientTimeout(total=timeout_s)
        headers = {
            "User-Agent": ("RENT-A-HAL Service Finder "
                           "(+https://rentahal.com)"),
        }
        try:
            async with aiohttp.ClientSession(timeout=timeout,
                                             headers=headers) as s:
                async with s.get(nominatim_url, params={
                    "lat": lat, "lon": lon, "format": "json",
                    "zoom": 14, "addressdetails": 1,
                }) as r:
                    log.info("Service: Nominatim returned %d", r.status)
                    if r.status == 200:
                        nom = await r.json()
                        addr = nom.get("address", {}) if isinstance(nom, dict) else {}
                        # Prefer city, fall back to town/village/county
                        city_name = (addr.get("city") or addr.get("town") or
                                     addr.get("village") or addr.get("county") or
                                     addr.get("state"))
                        log.info("Service: resolved to %r", city_name)
        except Exception as e:
            log.warning("Service: Nominatim error: %s", e)

        if not city_name:
            return ("I couldn't figure out what city you're in. "
                    "Your location might be too imprecise.")

        # Call BizData with the resolved city + OSM category
        businesses = []
        try:
            async with aiohttp.ClientSession(timeout=timeout,
                                             headers=headers) as s:
                async with s.get(bizdata_url, params={
                    "location": city_name,
                    "category": category,
                    "limit": 50,
                    "radius_km": radius_km,
                }) as r:
                    log.info("Service: BizData returned %d", r.status)
                    if r.status == 200:
                        data = await r.json()
                        businesses = data.get("businesses", [])
                        log.info("Service: %d businesses returned for %r",
                                 len(businesses), category)
                    else:
                        body = (await r.text())[:200]
                        log.warning("Service: BizData %d body: %s",
                                    r.status, body)
        except Exception as e:
            log.exception("Service: BizData error: %s", e)
            return f"The service-finder backend is unreachable right now."

        if not businesses:
            return (f"I couldn't find any {category_label} near you. "
                    "Coverage might be sparse in your area.")

        # Compute distance from user, sort by distance, take top N
        scored = []
        for b in businesses:
            blat = b.get("lat")
            blon = b.get("lon")
            if not isinstance(blat, (int, float)):
                continue
            if not isinstance(blon, (int, float)):
                continue
            dist = _haversine_miles(lat, lon, blat, blon)
            bearing = _compass_bearing(lat, lon, blat, blon)
            scored.append({
                "name": b.get("name", "Unknown"),
                "category": b.get("category", category),
                "address": b.get("address", "") or "",
                "phone": b.get("phone", "") or "",
                "website": b.get("website", "") or "",
                "lat": blat,
                "lon": blon,
                "opening_hours": b.get("opening_hours", "") or "",
                "distance_mi": round(dist, 2),
                "bearing": bearing,
            })

        if not scored:
            return (f"I found {category_label} listings but none with "
                    "usable coordinates.")

        scored.sort(key=lambda x: x["distance_mi"])
        top = scored[:max_results]

        # Publish bus event with the structured results
        await bus.publish("service_results",
                          user_guid=user_guid,
                          category=category,
                          category_label=category_label,
                          city=city_name,
                          results=top)

        # Build the brief spoken summary — just the top result
        first = top[0]
        addr_clean = first["address"].split(",")[0].strip() if first["address"] else ""
        addr_phrase = f" on {addr_clean}" if addr_clean else ""
        summary = (
            f"Top {category_label} result: {first['name']}, "
            f"{first['distance_mi']} miles {first['bearing']}{addr_phrase}."
        )
        if len(top) > 1:
            summary += (f" {len(top)} options on screen — tap any one "
                        "for phone and directions.")
        return summary

    return handler


def make_news_handler(cfg):
    """News handler — POSTs to the Kokoro service's /news endpoint and
    pushes the story bundle to the browser as a 'news_bundle' bus event,
    so the browser can render playable cards. Returns a brief spoken
    summary for TTS."""
    host = cfg_get(cfg, "KokoroService", "host", "localhost").strip()
    port = int(cfg_get(cfg, "KokoroService", "port", "9998"))
    base = f"http://{host}:{port}" if host else ""

    async def handler(slots, user_guid, bus):
        if not base:
            return "News realm needs the Kokoro service running."
        params = {}
        if "feed" in slots:
            params["source"] = slots["feed"]
        if "category" in slots:
            params["category"] = slots["category"]
        params["limit"] = "30"
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"{base}/news", params=params) as r:
                    if r.status != 200:
                        return f"News service returned status {r.status}."
                    data = await r.json()
        except Exception as e:
            return f"Couldn't reach news service: {e}"

        if not data.get("enabled"):
            return "News module is disabled on the server."
        stories = data.get("stories", [])
        if not stories:
            if "feed" in slots:
                return f"No stories from feed '{slots['feed']}' yet. The first refresh may still be running."
            return "No news stories yet. The first refresh may still be running."

        # Rewrite audio URLs to come through THIS realm (so the browser
        # works uniformly through Cloudflare Tunnel etc).
        for story in stories:
            if story.get("audio_url") and story["audio_url"].startswith("/"):
                audio_id = story["audio_url"].rsplit("/", 1)[-1]
                story["audio_url"] = f"/api/news/audio/{audio_id}"

        # Push the bundle to the browser so it can render the list
        await bus.publish("news_bundle", user_guid=user_guid,
                          stories=stories,
                          filter_feed=slots.get("feed", ""),
                          filter_category=slots.get("category", ""),
                          total=len(stories))

        # Brief spoken summary — count + a hint of what's there. The
        # browser will show the full list with per-story play buttons.
        sources_seen = []
        for s in stories[:5]:
            if s["source"] not in sources_seen:
                sources_seen.append(s["source"])
        scope = ""
        if "feed" in slots:
            scope = f" from {slots['feed']}"
        elif "category" in slots:
            scope = f" from {slots['category']}-leaning sources"
        sources_str = ", ".join(sources_seen[:3])
        if len(sources_seen) > 3:
            sources_str += " and others"
        return (f"I have {len(stories)} stories{scope} ready. "
                f"Top sources include {sources_str}. "
                f"Click any story below to hear it.")

    return handler


# ============================================================================
# THE APP
# ============================================================================

def make_roundup_handler(cfg):
    """ROUNDUP handler — voice trigger for radio-station style news.

    User says "computer roundup newline" → realm classifies as kind=roundup
    → orchestrator routes here → we fetch NPR + Guardian stories in
    parallel from the Kokoro service, build the shuffled roundup
    payload, and publish a 'news_roundup_start' bus event.

    The browser's `bus_news_roundup_start` handler then calls
    `startRoundup(msg.stories)` — same code path as the button click,
    but with the stories already in hand (no second fetch).

    Returns a brief spoken summary for TTS: "Starting news roundup
    with N stories from NPR and The Guardian."
    """
    host = cfg_get(cfg, "KokoroService", "host", "localhost").strip()
    port = int(cfg_get(cfg, "KokoroService", "port", "9998"))
    base = f"http://{host}:{port}" if host else ""
    default_count = int(cfg_get(cfg, "News", "roundup_count", "20"))

    async def handler(slots, user_guid, bus):
        if not base:
            return "Roundup needs the Kokoro service running."

        # Parallel fetch of both feeds — same pattern as the /news/roundup
        # HTTP endpoint. Each returns [] on any error so a single feed
        # outage doesn't break the whole roundup.
        async def fetch_source(source: str, limit: int):
            params = {"source": source, "limit": str(limit)}
            try:
                timeout = aiohttp.ClientTimeout(total=10)
                async with aiohttp.ClientSession(timeout=timeout) as s:
                    async with s.get(f"{base}/news", params=params) as r:
                        if r.status != 200:
                            return []
                        data = await r.json()
                        return data.get("stories", []) if data.get("enabled") else []
            except Exception:
                return []

        npr_stories, guardian_stories = await asyncio.gather(
            fetch_source("NPR", default_count),
            fetch_source("The Guardian", default_count),
        )

        # Reuse the same pure builder the HTTP endpoint uses — single
        # source of truth for shuffle / cap / URL-rewrite / slim logic.
        bundle = _build_roundup(npr_stories, guardian_stories, default_count)
        stories = bundle["stories"]

        if not stories:
            return ("No NPR or Guardian stories ready yet. "
                    "The first refresh may still be running.")

        # Push the playlist to the browser. Browser's bus_news_roundup_start
        # handler kicks off startRoundup() with these stories pre-loaded.
        await bus.publish("news_roundup_start",
                          user_guid=user_guid,
                          stories=stories,
                          total=len(stories))

        # Brief spoken summary — keeps the TTS short so the intro tone
        # and first story arrive quickly. The browser will play the
        # intro alert mp3 (or synth fallback) right after this speaks.
        return (f"Starting news roundup with {len(stories)} stories "
                f"from NPR and The Guardian.")

    return handler


def _build_roundup(npr_stories, guardian_stories, count):
    """Pure function: take two source lists, return the shuffled+slimmed
    roundup payload. Separated from the HTTP wrapper so it's directly
    testable without spinning up a TestClient.

    - Combines NPR + Guardian
    - Shuffles for radio-style variety
    - Caps at `count`
    - Rewrites audio URLs to /api/news/audio/<id> (Cloudflare-friendly)
    - Strips fields the browser doesn't need (smaller payload)

    Returns the dict that the HTTP handler returns on success.
    """
    import random
    combined = list(npr_stories or []) + list(guardian_stories or [])
    random.shuffle(combined)
    slim = []
    for story in combined[:count]:
        audio_url = story.get("audio_url", "")
        if audio_url and audio_url.startswith("/"):
            # Same URL rewrite as /news endpoint — route through realm
            audio_id = audio_url.rsplit("/", 1)[-1]
            audio_url = f"/api/news/audio/{audio_id}"
        slim.append({
            "title": story.get("title", "(untitled)"),
            "source": story.get("source", ""),
            "audio_url": audio_url,
            "link": story.get("link", ""),
        })
    return {"enabled": True, "stories": slim, "total": len(slim)}


def create_app(cfg, logger):
    bus = EventBus()
    llm_chain, tts_chain, vision_chain, imagine_chain = build_chains_from_config(cfg)
    classifier = IntentClassifier(bus)
    weather_handler = make_weather_handler(cfg)
    news_handler = make_news_handler(cfg)
    music_handler = make_music_handler(cfg)
    roundup_handler = make_roundup_handler(cfg)
    vision_handler = make_vision_handler(cfg, vision_chain)
    imagine_handler = make_imagine_handler(cfg, imagine_chain)
    # service_handler needs a way to look up the user's geolocation, which
    # the orchestrator caches per user_guid. We define a closure that the
    # handler will call with a guid; it returns {"lat", "lon"} or None.
    # The orchestrator is defined right after this, so we use a holder.
    _orch_holder = {}
    def _get_user_location(guid):
        orch = _orch_holder.get("orch")
        if not orch:
            return None
        state = orch.users.get(guid)
        return state.location if state else None
    service_handler = make_service_handler(cfg, _get_user_location)
    # Metrics config (operator cockpit gauges). Reasonable defaults if
    # the [Metrics] section is missing.
    metrics_window = int(cfg_get(cfg, "Metrics", "window_size", "20"))
    metrics_interval = float(cfg_get(cfg, "Metrics",
                                     "broadcast_interval_s", "2.0"))
    # LLM answer-length ceiling, applied to all providers and forwarded
    # across federation. Read here at create_app() scope so both the
    # orchestrator (which passes it on every llm.generate call) and the
    # /api/ask handler (which caps inbound federated requests to it)
    # share one source of truth. Default 1500 ≈ 1100 words.
    max_response_tokens = int(cfg_get(cfg, "LLMChain",
                                       "max_response_tokens", "1500"))

    # ─── Sprint 11/12/13: Ledger + public proof + billing ───────────
    # Opt-in like everything else — empty [Ledger] dsn (the default)
    # means this whole feature is absent, no Postgres connection ever
    # attempted, matching the "most realms never touch the economic
    # layer" posture the whole design is built around.
    #
    # The Ledger itself needs an ASYNC connection (a real Postgres
    # pool), which can't happen here at create_app() call time — this
    # function runs synchronously, before the event loop FastAPI will
    # actually serve requests on is running. Instead: read the config
    # synchronously now, connect for real inside lifespan()'s startup
    # phase (below), and stash the result in this holder dict — same
    # "holder dict bridges sync construction and async-populated state"
    # pattern already used for _orch_holder above. Read BEFORE
    # Orchestrator is constructed (unlike Sprint 12's original
    # placement) specifically so billing_cfg can be handed to the
    # constructor directly — the Ledger connection itself still can't
    # exist yet, but Orchestrator.ledger is a plain mutable attribute
    # lifespan() sets once the real connection succeeds, further down.
    ledger_dsn = cfg_get(cfg, "Ledger", "dsn", "")
    _ledger_holder: dict = {}
    # Lazy import — see the top-of-file note on why this can't be a
    # normal module-level import. Only attempted at all if an operator
    # has actually set [Ledger] dsn; if the packages turn out to be
    # missing anyway, disable the feature gracefully (same as a
    # connection failure below) rather than crashing the whole realm.
    Ledger = None
    ots_local_verify = None
    ots_deserialize = None
    if ledger_dsn:
        try:
            from realm.ledger import Ledger
            from realm.ots_anchor import (
                local_verify as ots_local_verify,
                deserialize as ots_deserialize,
            )
        except ImportError as e:
            logger.warning(
                "Ledger: [Ledger] dsn is set but the required packages "
                "aren't installed (%s). Install asyncpg and "
                "opentimestamps-client (see requirements.txt) to use the "
                "economic layer. Disabling for this run.", e)
            ledger_dsn = ""

    # Sprint 13: billing is a SEPARATE opt-in layer on top of the
    # Ledger — [Ledger] dsn alone doesn't enable it; both a real
    # Postgres connection AND real Stripe keys are required. `stripe`
    # is ALSO an optional dependency (requirements.txt), so it gets the
    # exact same lazy-import treatment Sprint 12 established for
    # asyncpg/opentimestamps — applied proactively here, not found as a
    # bug afterward this time.
    billing_cfg = None
    create_checkout_session = None
    verify_webhook = None
    handle_checkout_completed_event = None
    WebhookVerificationError = None
    stripe_secret_key = cfg_get(cfg, "Billing", "stripe_secret_key", "")
    stripe_webhook_secret = cfg_get(cfg, "Billing", "stripe_webhook_secret", "")
    if ledger_dsn and stripe_secret_key and stripe_webhook_secret:
        try:
            from realm.billing import (
                BillingConfig, create_checkout_session, verify_webhook,
                handle_checkout_completed_event, WebhookVerificationError,
            )
            billing_cfg = BillingConfig(
                stripe_secret_key=stripe_secret_key,
                stripe_webhook_secret=stripe_webhook_secret,
                price_per_submit_micros=int(cfg_get(
                    cfg, "Billing", "price_per_submit_micros", "100")),
                low_balance_threshold_micros=int(cfg_get(
                    cfg, "Billing", "low_balance_threshold_micros", "10000")),
                checkout_success_url=cfg_get(cfg, "Billing", "checkout_success_url", ""),
                checkout_cancel_url=cfg_get(cfg, "Billing", "checkout_cancel_url", ""),
            )
            logger.info("Billing: configured (price_per_submit=%d micros)",
                       billing_cfg.price_per_submit_micros)
        except ImportError as e:
            logger.warning(
                "Billing: [Billing] stripe keys are set but the `stripe` "
                "package isn't installed (%s). Install it (see "
                "requirements.txt) to use the economic layer. Disabling "
                "for this run.", e)

    # Sprint 14: donor payout — a THIRD opt-in layer, only meaningful
    # for a realm acting as the Federator (that's where bilateral
    # claim reconciliation happens — see realm/donor_payout.py's
    # module docstring for why the Federator is the natural place).
    # [Payout] stripe_secret_key alone gates this (separate from
    # [Billing]'s own key, since a realm could plausibly run the
    # Federator role — and thus need Payout — without ever accepting
    # consumer top-ups itself, or vice versa).
    payout_cfg = None
    _claim_store_holder: dict = {}
    _donor_account_store_holder: dict = {}
    payout_stripe_secret_key = cfg_get(cfg, "Payout", "stripe_secret_key", "")
    if ledger_dsn and payout_stripe_secret_key:
        try:
            from realm.donor_payout import PayoutConfig
            payout_cfg = PayoutConfig(
                stripe_secret_key=payout_stripe_secret_key,
                conscription_payout_rate_micros=int(cfg_get(
                    cfg, "Payout", "conscription_payout_rate_micros", "80")),
                minimum_payout_micros=int(cfg_get(
                    cfg, "Payout", "minimum_payout_micros", "5000000")),
                claim_match_tolerance_s=float(cfg_get(
                    cfg, "Payout", "claim_match_tolerance_s", "60.0")),
                unmatched_claim_max_age_s=float(cfg_get(
                    cfg, "Payout", "unmatched_claim_max_age_s", "3600.0")),
                onboarding_refresh_url=cfg_get(cfg, "Payout", "onboarding_refresh_url", ""),
                onboarding_return_url=cfg_get(cfg, "Payout", "onboarding_return_url", ""),
            )
            logger.info("Payout: configured (rate=%d micros/confirmed request)",
                       payout_cfg.conscription_payout_rate_micros)
        except ImportError as e:
            logger.warning(
                "Payout: [Payout] stripe_secret_key is set but the "
                "`stripe` package isn't installed (%s). Disabling for "
                "this run.", e)

    orchestrator = Orchestrator(bus, llm_chain, tts_chain,
                                weather_handler=weather_handler,
                                gmail_handler=None,
                                news_handler=news_handler,
                                music_handler=music_handler,
                                service_handler=service_handler,
                                roundup_handler=roundup_handler,
                                vision_handler=vision_handler,
                                imagine_handler=imagine_handler,
                                metrics_window=metrics_window,
                                metrics_broadcast_interval_s=metrics_interval,
                                max_response_tokens=max_response_tokens,
                                # ledger starts None — lifespan() sets
                                # orchestrator.ledger directly once the
                                # real async Postgres connection
                                # succeeds (see startup below). billing_cfg
                                # is plain config, safe to pass now.
                                ledger=None,
                                billing_cfg=billing_cfg)
    _orch_holder["orch"] = orchestrator

    # ─── Sprint 10: proof-of-work abuse gate ────────────────────────
    # OPT-IN like everything else — [AbuseGate] enabled = true is the
    # default (unlike federation's desire=off default), since this is
    # protecting a publicly-reachable endpoint from day one rather than
    # opting INTO a cooperative network. An operator who genuinely wants
    # it off (e.g. a fully trusted LAN-only deployment) can still set
    # enabled = false.
    abuse_gate_enabled = cfg_get(cfg, "AbuseGate", "enabled", "true").lower() in (
        "true", "1", "yes", "on")
    abuse_gate_secret_cfg = cfg_get(cfg, "AbuseGate", "secret", "")
    if abuse_gate_secret_cfg:
        abuse_gate_secret = abuse_gate_secret_cfg.encode("utf-8")
    else:
        # No explicit secret configured — generate an ephemeral one at
        # boot. This is safe (see PowGate's docstring: the secret only
        # needs to be consistent for the ~60s life of one challenge,
        # not across restarts) but DOES mean a restart invalidates any
        # challenge someone was mid-solve on — a minor, one-time
        # inconvenience, not a security concern. Set an explicit value
        # in config.ini if running multiple processes that need to
        # verify each other's issued challenges.
        import secrets as _secrets_mod
        abuse_gate_secret = _secrets_mod.token_bytes(32)
        if abuse_gate_enabled:
            logger.info(
                "AbuseGate: no [AbuseGate] secret configured — using an "
                "ephemeral one generated at boot (regenerates on restart, "
                "invalidating any in-flight challenge). Set an explicit "
                "secret in config.ini for stability across restarts.")
    abuse_gate_window_s = float(cfg_get(cfg, "AbuseGate",
                                        "free_calls_window_s", "600.0"))
    abuse_gate_challenge_ttl_s = float(cfg_get(cfg, "AbuseGate",
                                               "challenge_ttl_s", "60.0"))
    pow_gate = PowGate(
        secret=abuse_gate_secret,
        window_s=abuse_gate_window_s,
        challenge_ttl_s=abuse_gate_challenge_ttl_s,
        enabled=abuse_gate_enabled,
    )

    async def _submit_donor_conscription_claim(requester_url: str) -> None:
        """Sprint 14 — the DONOR side of bilateral confirmation.
        Called from /api/ask after successfully answering a request
        that identified itself as conscripted (X-Federation-Conscripted
        header + a requester identity via X-Federation-Requester-Url —
        see FederationConscriptionProvider._try_one_donor for the
        matching requester-side submission). Fire-and-forget: a claim
        submission failure must never affect the answer already
        returned to the caller — worst case, this realm simply doesn't
        get credited for this one request."""
        cfg = federation_cfg
        if cfg is None or not cfg.master_url or not cfg.self_url:
            return
        url = cfg.master_url.rstrip("/") + "/conscription-claim"
        headers = {"Content-Type": "application/json"}
        if cfg.token:
            headers["X-Federation-Token"] = cfg.token
        body = {
            "role": "donor",
            "donor_url": cfg.self_url,
            "requester_url": requester_url,
            "rank": "chat",
        }
        try:
            timeout = aiohttp.ClientTimeout(total=10.0)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.post(url, json=body, headers=headers) as r:
                    if r.status != 200:
                        logger.info(
                            "Payout: donor-side claim submission to %s "
                            "returned HTTP %d (non-fatal)", url, r.status)
        except Exception as e:
            logger.info(
                "Payout: donor-side claim submission to %s failed: %s "
                "(non-fatal)", url, e)

    def _pow_gate_response(payload: dict, key: str):
        """Shared helper for every protected endpoint. Returns a ready-
        to-return JSONResponse if the caller needs to solve/resolve a
        puzzle, or None if the request should proceed — same "None
        means proceed" convention as federation_token_error(), so
        wiring this into an endpoint is the same two-line shape.
        `payload["pow_solution"]`, if present, carries the client's
        attempted solution from a previous 402 challenge."""
        result = pow_gate.check(key, payload.get("pow_solution"))
        if result.allowed:
            return None
        return JSONResponse(result.response_body, status_code=result.status_code)

    # ─── Federation wiring ─────────────────────────────────────────
    # Federation is OPT-IN. If [Federation] desire = off (default), the
    # check-in client never starts and the FederationLLMProvider stays
    # in is_available=False, so the LLM chain skips it. Realm behaves
    # exactly as it did before federation existed.
    federation_cfg = FederationConfig.from_cfg(cfg)
    # Sprint 6: boot-time facts, not live health — "did the operator
    # configure a REAL vision/imagine provider" is a one-time question
    # about vision_order/imagine_order in config.ini, unlike is_available()
    # which re-probes on every call. Computed once here rather than in
    # the stats closure below because _federation_stats() must stay
    # synchronous (FederationState.get_stats() is called synchronously
    # from the check-in loop) and is_available()/probe_local() are both
    # async. A node with ONLY the Echo floor configured (vision_order =
    # echo, or the section simply absent) correctly reports as not
    # configured — we never want an instant-answering floor to look like
    # the fastest possible real vision/imagine peer to the rest of the
    # federation.
    #
    # CAPABILITY_CHAINS is the data-driven registry that replaces what
    # used to be two copy-pasted if-blocks (one for vision, one for
    # imagine). Adding a FUTURE chain-based capability (say, an audio-
    # transcription chain with its own Echo floor) is now a one-line
    # addition here, not a third copy-pasted block. Each entry maps a
    # capability name to (chain, EchoProviderClass) — the chain's own
    # provider list is inspected once at boot to determine "configured"
    # (a REAL, non-Echo provider present), exactly as vision/imagine
    # always did.
    CAPABILITY_CHAINS = {
        "vision": (vision_chain, EchoVisionProvider),
        "imagine": (imagine_chain, EchoImagineProvider),
    }
    capability_configured = {
        name: any(not isinstance(p, echo_cls) for p in chain.providers)
        for name, (chain, echo_cls) in CAPABILITY_CHAINS.items()
    }
    vision_configured = capability_configured["vision"]
    imagine_configured = capability_configured["imagine"]
    # Sprint 7: same question for chat, symmetric with vision/imagine
    # above — feeds conscription's configured_ranks below. Note this is
    # a DIFFERENT vocabulary from capability_avg_s's "llm" key: the
    # capability-reporting dict (Sprint 6) and the conscription-rank
    # list (Sprint 7) are deliberately separate namespaces — see
    # CONSCRIPTION_RANKS' docstring in federation.py for why.
    chat_configured = any(not isinstance(p, EchoLLMProvider)
                          for p in llm_chain.providers)

    def _federation_stats() -> dict:
        # Adapter from orchestrator's Metrics to federation's expected
        # stats dict shape. The metrics object updates rolling avgs
        # whenever the orchestrator records LLM/TTS call timings.
        #
        # CRITICAL: if our LOCAL LLM is dead, we self-report the
        # DEGRADED_AVG_S sentinel for llm_avg_s, NOT the real rolling
        # avg. Why: when local LLM died, the rolling avg reflects
        # FEDERATED call latency (e.g. 20s) — which is "healthy enough"
        # to be advertised as a peer. But we can't actually serve
        # federation traffic; the receiver's federation path is
        # hop-blocked. By reporting the sentinel, the Federator's
        # best_peer_for naturally deprioritizes us — peers route to
        # other realms whose LOCAL LLM is alive.
        #
        # When local LLM recovers (next query goes to GPT4All/Claude/HF),
        # the orchestrator flips the flag back to True and we go back
        # to advertising real numbers. Self-healing, same as the
        # FederationLLMFallbackProvider design.
        m = orchestrator.metrics
        llm_avg = (float(m.ai_avg_service_s or 0.0)
                   if m.local_llm_available
                   else DEGRADED_AVG_S)
        # Same sentinel logic for TTS — when our local TTS is dead, we
        # report the sentinel so peers don't try to federate TTS to us.
        # Without this, after Kokoro dies and federation rescue answers,
        # tts_avg_s would reflect FEDERATED synth latency (round-trip
        # cost) — which looks "healthy enough" to other realms but we
        # can't actually serve, since our local TTS is dead.
        tts_avg = (float(m.tts_avg_service_s or 0.0)
                   if m.local_tts_available
                   else DEGRADED_AVG_S)
        # Loose-end fix: generalized capability reporting, config-driven
        # via [Federation] report_capabilities (default "vision,imagine"
        # — zero behavior change from before this existed). Two
        # different signals depending on the capability's nature:
        #
        #   CHAIN-BASED (currently vision, imagine — anything in
        #   CAPABILITY_CHAINS above): the full Sprint-6 safeguard
        #   applies — only reported when a REAL (non-Echo) provider is
        #   actually configured. An instant-answering Echo floor never
        #   gets to masquerade as the fastest real peer for that
        #   capability. This is the strong signal.
        #
        #   ANYTHING ELSE in report_capabilities (weather, music,
        #   service, roundup, ask, or any future intent kind — Metrics
        #   already tracks per-kind timing for ALL of them via Sprint
        #   6's record_capability_duration, regardless of whether this
        #   registry knows about them): reported if it's been served at
        #   least once this session (m.avg_for(kind) has real samples).
        #   This is a WEAKER signal — these aren't chain/provider-based,
        #   so there's no "floor vs real provider" distinction to make.
        #   A weather query that fails fast due to a missing API key
        #   would look deceptively "fast" here, the same class of risk
        #   vision/imagine were explicitly protected against. Operators
        #   adding non-chain-based names to report_capabilities should
        #   understand this limitation — it's why the default list only
        #   contains the two capabilities that DO have the strong
        #   safeguard available.
        capability_avg_s = {}
        for name in federation_cfg.report_capabilities:
            if name in capability_configured:
                if capability_configured[name]:
                    capability_avg_s[name] = float(m.avg_for(name) or 0.0)
            else:
                avg = m.avg_for(name)
                if avg > 0:
                    capability_avg_s[name] = float(avg)
        # Sprint 7: configured_ranks feeds FederationConfig.
        # eligible_conscription_ranks() over in FederationClient._do_checkin
        # — "which of the three conscription-vocabulary ranks does this
        # node actually have a real provider for right now." Unlike
        # capability_avg_s above, this stays fixed to exactly the three
        # CONSCRIPTION_RANKS — conscription's vocabulary is intentionally
        # not as open-ended as capability reporting; see CONSCRIPTION_
        # RANKS' docstring in federation.py.
        configured_ranks = []
        if chat_configured:
            configured_ranks.append("chat")
        if vision_configured:
            configured_ranks.append("vision")
        if imagine_configured:
            configured_ranks.append("imagine")
        return {
            "llm_avg_s": llm_avg,
            "tts_avg_s": tts_avg,
            "tokens_out": int(m.total_tokens_out),
            "capability_avg_s": capability_avg_s,
            "configured_ranks": configured_ranks,
        }
    federation_state = FederationState(federation_cfg, _federation_stats)

    # ─── Degraded watchdogs (LLM + TTS, independent) ────────────────
    # Wall-clock watchdogs that cap how long each chain can be federated-
    # only before declaring DEGRADED. When degraded, the federation
    # providers REFUSE to federate; chain falls through to Echo (LLM) or
    # pyttsx3 (TTS); operator sees a loud signal. Cleared by the existing
    # pre-flight probe recovery hook when local comes back. See
    # realm/degraded_tracker.py for the full design rationale.
    from realm.degraded_tracker import DegradedTracker

    # Operator-signal callback: fired ONCE per transition into degraded.
    # Pushes a bus_status_update so the cockpit badge flashes red and
    # shows the degraded label. The orchestrator's per-query badge update
    # then continues showing the Echo/pyttsx3 floor on subsequent queries.
    def _on_degraded(chain_label: str, elapsed_s: float) -> None:
        logger.error(
            "DEGRADED WATCHDOG (%s): Local %s has been federated-only "
            "for %.0fs (threshold %.0fs). Federation REFUSED for this "
            "chain. Queries fall through to %s. OPERATOR: check local "
            "engine. Pre-flight probe will auto-clear degraded the "
            "moment local responds.",
            chain_label, chain_label, elapsed_s,
            (llm_degraded_after_s if chain_label == "LLM"
             else tts_degraded_after_s),
            "Echo" if chain_label == "LLM" else "pyttsx3")
        # Best-effort cockpit notification. Bus publish is sync from a
        # sync callback — use create_task on the running loop.
        try:
            loop = asyncio.get_event_loop()
            channel = "llm" if chain_label == "LLM" else "tts"
            sentinel = (f"LocalSystem{chain_label}Degraded.xpy")
            loop.create_task(bus.publish(
                "status_update", channel=channel,
                provider=sentinel, state="degraded"))
        except Exception as e:
            logger.warning("Degraded badge broadcast failed: %s", e)

    def _on_recovered_from_degraded(chain_label: str) -> None:
        # The existing pre-flight probe recovery hook already pushes
        # the "recovered" status_update. This callback fires from the
        # tracker AFTER the probe recovery hook already cleared things,
        # so it's a quiet INFO log. The double-callback is intentional:
        # the probe recovery hook flashes the badge BACK TO LOCAL with
        # the local provider name; the tracker recovery is just a
        # bookkeeping log line.
        logger.info(
            "DEGRADED WATCHDOG (%s): Local %s recovered. Federation "
            "re-enabled for this chain.", chain_label, chain_label)

    # Read thresholds (one per chain, independent). Defaults match the
    # shipping config.ini values; fallback handles older configs.
    def _read_degraded_threshold(section: str, default: int = 300) -> float:
        try:
            return float(cfg.get(section, "local_degraded_after_s",
                                 fallback=str(default)).strip())
        except Exception:
            return float(default)

    llm_degraded_after_s = _read_degraded_threshold("LLMChain")
    tts_degraded_after_s = _read_degraded_threshold("TTSChain")

    llm_degraded_tracker = DegradedTracker(
        chain_label="LLM",
        degraded_after_s=llm_degraded_after_s,
        on_degraded=_on_degraded,
        on_recovered=_on_recovered_from_degraded,
    )
    tts_degraded_tracker = DegradedTracker(
        chain_label="TTS",
        degraded_after_s=tts_degraded_after_s,
        on_degraded=_on_degraded,
        on_recovered=_on_recovered_from_degraded,
    )

    # Insert the federation provider at the HEAD of the LLM chain so it
    # gets first crack at each request. If is_available() returns False
    # (the common case — local LLM is fast enough), the chain falls
    # through to the next provider exactly as before.
    federation_llm_provider = FederationLLMProvider(federation_state)
    llm_chain.providers.insert(0, federation_llm_provider)

    # The TAIL federation provider — RESCUE mode. Sits between the local
    # providers (GPT4All, Claude, HF) and the Echo floor. Gate is "all
    # local providers failed" not "local is slow." Fires when local LLM
    # has died, falls back to Echo if peer also unreachable. Self-heals:
    # when local LLM recovers, GPT4All.generate() starts succeeding, the
    # chain never reaches this provider, routing returns to local.
    #
    # Position: we want this to be the LAST provider before Echo. The
    # Echo provider is the always-available "I can't help" floor. We
    # insert immediately before it so federation rescue gets one last
    # try before the user sees "no language model is currently online."
    fallback_provider = FederationLLMFallbackProvider(federation_state)
    # Find Echo's position. If for any reason there's no Echo (unusual),
    # append to the end.
    echo_idx = next(
        (i for i, p in enumerate(llm_chain.providers)
         if isinstance(p, EchoLLMProvider)),
        len(llm_chain.providers),
    )
    llm_chain.providers.insert(echo_idx, fallback_provider)

    # Sprint 9: the conscription-consuming provider. Sits right before
    # Echo, after ordinary federation (HEAD + FALLBACK) has had its
    # chance — see FederationConscriptionProvider's docstring for why
    # that ordering makes sense (ordinary best-peer routing already
    # finds the genuinely best native chat peer when one exists;
    # conscription only matters when that wasn't enough).
    conscription_provider = FederationConscriptionProvider(federation_state)
    echo_idx2 = next(
        (i for i, p in enumerate(llm_chain.providers)
         if isinstance(p, EchoLLMProvider)),
        len(llm_chain.providers),
    )
    llm_chain.providers.insert(echo_idx2, conscription_provider)

    federation_client = FederationClient(federation_state)

    # ─── Pre-flight probe recovery callbacks ──────────────────────
    # When a federation provider's pre-flight probe finds local LLM/TTS
    # alive (after we thought it was busy/dead), it fires this callback
    # which performs the rescue dance:
    #   1. Clear the stale rolling avg (so the head provider's threshold
    #      gate stops firing on every subsequent query)
    #   2. Flip local_*_available flag back to True
    #   3. Fire an immediate Federator check-in so peer advice updates
    #      across the federation immediately (other realms stop routing
    #      to us with stale "dead" sentinel; we stop being advised peers
    #      we don't need)
    #   4. Broadcast the cockpit badge update so the operator sees the
    #      flash back to local in real time
    async def _on_llm_local_recovery(local_provider_name: str) -> None:
        orchestrator.metrics.reset_ai_window_to_local_recovery()
        logger.info(
            "Federation: LOCAL LLM RECOVERED — flashing cockpit to %s, "
            "firing out-of-band check-in", local_provider_name)
        await bus.publish("status_update",
                          channel="llm",
                          provider=local_provider_name,
                          state="recovered")
        # Best-effort immediate check-in. If it fails, the regular 15s
        # loop will catch up shortly.
        try:
            await federation_client.immediate_checkin()
        except Exception as e:
            logger.warning("Out-of-band check-in failed: %s", e)

    async def _on_tts_local_recovery(local_provider_name: str) -> None:
        orchestrator.metrics.reset_tts_window_to_local_recovery()
        logger.info(
            "Federation: LOCAL TTS RECOVERED — flashing cockpit to %s, "
            "firing out-of-band check-in", local_provider_name)
        await bus.publish("status_update",
                          channel="tts",
                          provider=local_provider_name,
                          state="recovered")
        try:
            await federation_client.immediate_checkin()
        except Exception as e:
            logger.warning("Out-of-band check-in failed: %s", e)

    # Attach chain + recovery + degraded tracker to LLM federation providers.
    # Both head and fallback share the SAME tracker — a realm cycling
    # between slow-local (head) and dead-local (fallback) is still
    # continuously degraded; the tracker spans both providers.
    federation_llm_provider.attach(
        llm_chain, _on_llm_local_recovery,
        degraded_tracker=llm_degraded_tracker)
    fallback_provider.attach(
        llm_chain, _on_llm_local_recovery,
        degraded_tracker=llm_degraded_tracker)
    conscription_provider.attach(
        llm_chain, _on_llm_local_recovery,
        degraded_tracker=llm_degraded_tracker)

    # ─── TTS federation providers (head + tail) ────────────────────
    # Symmetric architecture to LLM. Reads the same federation state,
    # uses the same hop limit, same sentinel reporting, same self-healing
    # via probe + recovery. Public surface is POST /api/speak (defined
    # below in the API routes).
    from realm.federation_tts_provider import (
        FederationTTSProvider, FederationTTSFallbackProvider,
    )
    tts_head_provider = FederationTTSProvider(federation_state)
    tts_head_provider.attach(
        tts_chain, _on_tts_local_recovery,
        degraded_tracker=tts_degraded_tracker)
    tts_chain.providers.insert(0, tts_head_provider)

    tts_fallback_provider = FederationTTSFallbackProvider(federation_state)
    tts_fallback_provider.attach(
        tts_chain, _on_tts_local_recovery,
        degraded_tracker=tts_degraded_tracker)
    # Insert IMMEDIATELY AFTER the preferred local TTS provider, BEFORE
    # the OS-level "robot voice" fallbacks (SAPI5 / pyttsx3).
    #
    # Why not at the end of the chain? When KokoroService dies, SAPI5
    # always succeeds on Windows — the chain stops there and the
    # operator-visible "robot voice degraded floor" plays through. The
    # FALLBACK federation provider at the end of the chain is never
    # reached, so federation TTS rescue never fires.
    #
    # By inserting BEFORE SAPI5, we match the LLM chain's semantic:
    # federate to a peer BEFORE falling through to the degraded floor.
    # Operator's failover test now correctly federates BOTH LLM and TTS
    # to the healthy peer instead of producing robot voice locally.
    #
    # Position is at index 2: after [0] HEAD federation and [1]
    # KokoroService (the preferred local). If KokoroService is healthy,
    # this provider's should_federate() returns False and the chain
    # never reaches us. If KokoroService is dead, we fire the rescue.
    # If federation is also dead (no peer available), should_federate()
    # returns False and the chain falls through to SAPI5 → Kokoro
    # in-process → ElevenLabs → OpenAI → pyttsx3 as before.
    tts_chain.providers.insert(2, tts_fallback_provider)

    # ─── Federator server-side (only when this realm IS the Federator) ──
    federator_enabled = cfg_get(cfg, "Federator", "enabled",
                                FEDERATOR_DEFAULTS["enabled"]).lower() in \
                        ("true", "1", "yes", "on")
    federation_matrix: Optional[FederationMatrix] = None
    if federator_enabled:
        state_file_name = cfg_get(cfg, "Federator", "state_file",
                                  FEDERATOR_DEFAULTS["state_file"])
        state_path = APP_DIR / state_file_name
        missed_after_s = float(cfg_get(cfg, "Federator", "missed_after_s",
                                       FEDERATOR_DEFAULTS["missed_after_s"]))
        bump = float(cfg_get(cfg, "Federator", "peer_advice_bump_s",
                             FEDERATOR_DEFAULTS["peer_advice_bump_s"]))
        # Sprint 8: Federator-side conscription decision-engine controls.
        # See FEDERATOR_DEFAULTS in federation.py for the full
        # explanation of each. All independent of any individual
        # member's own donor consent (Sprint 7) — this is the
        # Federator OPERATOR's separate layer of control.
        conscription_enabled = cfg_get(
            cfg, "Federator", "conscription_enabled",
            FEDERATOR_DEFAULTS["conscription_enabled"]).lower() in \
            ("true", "1", "yes", "on")
        conscription_trigger_avg_s = float(cfg_get(
            cfg, "Federator", "conscription_trigger_avg_s",
            FEDERATOR_DEFAULTS["conscription_trigger_avg_s"]))
        conscription_idle_avg_s = float(cfg_get(
            cfg, "Federator", "conscription_idle_avg_s",
            FEDERATOR_DEFAULTS["conscription_idle_avg_s"]))
        default_conscription_max_minutes = float(cfg_get(
            cfg, "Federator", "default_conscription_max_minutes",
            FEDERATOR_DEFAULTS["default_conscription_max_minutes"]))
        max_donors_per_rank = int(cfg_get(
            cfg, "Federator", "max_donors_per_rank",
            FEDERATOR_DEFAULTS["max_donors_per_rank"]))
        federation_matrix = FederationMatrix(
            state_file=state_path,
            missed_after_s=missed_after_s,
            peer_advice_bump_s=bump,
            conscription_enabled=conscription_enabled,
            conscription_trigger_avg_s=conscription_trigger_avg_s,
            conscription_idle_avg_s=conscription_idle_avg_s,
            default_conscription_max_minutes=default_conscription_max_minutes,
            max_donors_per_rank=max_donors_per_rank,
        )
        logger.info("Federator: enabled, persisting to %s", state_path)

    manager = ConnectionManager(ping_interval=20.0, stale_after=75.0)
    schema_cfg = get_schema_config(INI_DIR / "config.ini")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        logger.info("Realm starting up")
        await classifier.attach()
        await orchestrator.attach()
        # Sprint 11/12: connect the ledger now that the event loop is
        # actually running. A connection failure here is logged, not
        # fatal — the whole economic layer is optional, and a realm
        # whose Postgres happens to be down shouldn't fail to boot over
        # a feature most deployments don't even have configured.
        if ledger_dsn:
            try:
                ledger = await Ledger.connect(ledger_dsn)
                _ledger_holder["ledger"] = ledger
                # Sprint 13: this is what actually turns on the
                # orchestrator's per-query debit hook — it was
                # constructed with ledger=None above specifically
                # because this connection couldn't exist yet at that
                # point. Only meaningfully activates billing when
                # billing_cfg was ALSO set (both checked together in
                # Orchestrator._handle before any debit is attempted).
                orchestrator.ledger = ledger
                logger.info("Ledger: connected (public proof endpoint active)")
                # Sprint 14: ClaimStore/DonorAccountStore reuse the SAME
                # connection pool the ledger just opened — one Postgres
                # instance, one pool, multiple stores over it (same
                # pattern as OtsAnchorStore in Sprint 12).
                if payout_cfg is not None:
                    from realm.donor_payout import ClaimStore, DonorAccountStore
                    _claim_store_holder["store"] = ClaimStore(ledger, payout_cfg)
                    _donor_account_store_holder["store"] = DonorAccountStore(ledger)
                    logger.info("Payout: claim reconciliation active")
            except Exception as e:
                logger.warning("Ledger: connection failed (%s) — "
                               "/api/ledger/proof will report unavailable "
                               "until this is fixed and the realm restarts",
                               e)
        # Bus -> websocket relay: every bus event becomes a JSON message
        async def ws_relay(ev):
            guid = ev.payload.get("user_guid")
            payload = {"type": f"bus_{ev.type}",
                       "ts": ev.ts,
                       **{k: v for k, v in ev.payload.items() if k != "user_guid"}}
            if guid and guid != "anonymous":
                await manager.safe_send(guid, payload)
            else:
                await manager.broadcast(payload)
        await bus.subscribe_all(ws_relay)
        reap_task = asyncio.create_task(manager.ping_and_reap_loop())
        # Federation: start the check-in client. If desire=off or self_url
        # is unset, start() is a no-op and we never call out to a Federator.
        await federation_client.start()
        # Boot-time engine availability report
        llm_status = await llm_chain.detect()
        tts_status = await tts_chain.detect()
        logger.info("LLM providers: %s", llm_status)
        logger.info("TTS providers: %s", tts_status)
        # Seed the local-LLM-available flag from boot detect, so we
        # don't advertise ourselves as a healthy peer before the first
        # query has had a chance to update the flag. Without this, a
        # realm booting with GPT4All already dead would briefly look
        # healthy in the federation matrix until its first query.
        # Local = any LLM provider that is not federation/echo and
        # currently reports is_available.
        local_llm_alive = any(
            available
            for name, available in llm_status.items()
            if available
            and "Federation" not in name
            and "Echo" not in name
        )
        orchestrator.metrics.set_local_llm_available(local_llm_alive)
        logger.info("Local LLM available at boot: %s", local_llm_alive)
        # Same for TTS — seed the flag so we don't briefly mis-advertise
        # at boot. Local TTS = any TTS provider that isn't federation
        # (no Echo TTS — pyttsx3 is the always-available floor and IS
        # local).
        local_tts_alive = any(
            available
            for name, available in tts_status.items()
            if available and "Federation" not in name
        )
        orchestrator.metrics.set_local_tts_available(local_tts_alive)
        logger.info("Local TTS available at boot: %s", local_tts_alive)
        logger.info("Federation: desire=%s self=%s master=%s federator=%s",
                    federation_cfg.desire, federation_cfg.self_url or "(unset)",
                    federation_cfg.master_url or "(unset)",
                    "yes" if federator_enabled else "no")
        yield
        logger.info("Realm shutting down")
        await federation_client.stop()
        reap_task.cancel()
        await orchestrator.detach()
        if "ledger" in _ledger_holder:
            await _ledger_holder["ledger"].close()

    app = FastAPI(lifespan=lifespan, title="RENT-A-HAL Star Trek Realm")

    # CORS — let any web page on any origin call our /api/* endpoints.
    # This is what makes Little Johnny's first AI app work when he opens
    # his .html file from his desktop (file:// origin) and POSTs to
    # https://rentahal.com/api/ask. Without this, his browser blocks
    # the response per same-origin policy even though the server answers
    # 200 OK. The WebSocket at /ws is unaffected by CORS middleware
    # (browsers apply CORS to fetch/XHR only, not to WebSockets).
    #
    # Operators who want to restrict callers can set [CORS] allowed_origins
    # to a comma-separated list. Default "*" maximizes API friendliness;
    # there are no secrets behind the API (it's the same surface as curl).
    cors_origins_raw = cfg_get(cfg, "CORS", "allowed_origins", "*").strip()
    if cors_origins_raw == "*":
        cors_origins = ["*"]
    else:
        cors_origins = [o.strip() for o in cors_origins_raw.split(",") if o.strip()]
    cors_allow_credentials = cfg_get(
        cfg, "CORS", "allow_credentials", "false").strip().lower() == "true"
    # Note: a wildcard origin with credentials=True is rejected by browsers
    # per the CORS spec, so guard against that combination.
    if cors_origins == ["*"] and cors_allow_credentials:
        logger.warning("[CORS] allowed_origins=* + allow_credentials=true is "
                       "invalid; ignoring allow_credentials")
        cors_allow_credentials = False
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=cors_allow_credentials,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type"],
    )
    logger.info("CORS: allowed_origins=%s allow_credentials=%s",
                cors_origins, cors_allow_credentials)

    app.state.bus = bus
    app.state.llm_chain = llm_chain
    app.state.tts_chain = tts_chain
    app.state.manager = manager
    app.state.classifier = classifier
    app.state.orchestrator = orchestrator

    static_dir = APP_DIR / "static"
    if static_dir.is_dir():
        app.mount("/static", StaticFiles(directory=static_dir), name="static")
    templates_dir = APP_DIR / "templates"
    templates = Jinja2Templates(directory=templates_dir) if templates_dir.is_dir() else None

    api = APIRouter(prefix="/api")

    def _read_supporters() -> dict:
        """Read the [Supporters] section into a render-ready dict.

        Returns:
          {
            "enabled": bool,
            "title": str,
            "intro": str,
            "links": [{"name": str, "url": str, "desc": str}, ...],
          }

        Operator-controlled: schema scans link_N_name / link_N_url /
        link_N_desc for N=1,2,3,... and stops at the first missing name.
        Empty list when section absent or enabled=false. Used by both
        the /supporters route and the cockpit footer (which checks
        'enabled' to decide whether to render the link).

        Defensive parsing: Python's configparser does NOT strip inline
        comments after `;` on the same line as a value (only full-line
        comments). So an operator who writes `enabled = true ; comment`
        gets the literal string `true ; comment`, which our truthy
        check would reject. We strip inline `;` and `#` markers from
        every value before checking — what the operator clearly meant.

        Backward-compat: when the [Supporters] section doesn't exist
        (older config.ini files predating 2026-06-22), we return
        disabled with empty links — zero behavior change for older
        deployments."""
        def _strip_inline_comment(s: str) -> str:
            """Remove an inline ` ; comment` from the end of a value.

            Two design decisions:
            1. We require WHITESPACE before the `;` — `https://x.com;a=b`
               keeps the `;` because there's no space (it's part of the
               value). `enabled = true ; flip` has a space, so we strip.
            2. We do NOT strip `#` — URLs legitimately use `#` for
               fragments (`https://example.com/page#section`). Inline
               `#` comments in INI files are not standard configparser
               behavior anyway.

            Used defensively because configparser leaves inline `;`
            comments in values, which is a paste-error footgun for
            operators who copy snippets from documentation that
            includes annotations like `enabled = true ; turn this on`."""
            if s is None:
                return ""
            import re
            # Split on first whitespace-then-semicolon
            m = re.search(r"\s+;", s)
            if m:
                s = s[:m.start()]
            return s.strip()

        if not cfg.has_section("Supporters"):
            return {"enabled": False, "title": "", "intro": "", "links": []}
        section = cfg["Supporters"]
        # All reads go through _strip_inline_comment so paste-errors
        # like `enabled = true ; flip this` resolve to operator intent.
        enabled = _strip_inline_comment(
            section.get("enabled", "false")).lower() in (
            "true", "yes", "on", "1")
        title = _strip_inline_comment(
            section.get("title", "Ways to support this project"))
        intro = _strip_inline_comment(section.get("intro", ""))
        links = []
        # Scan link_1_*, link_2_*, ... — stop at first missing name
        n = 1
        while True:
            name_key = f"link_{n}_name"
            if name_key not in section:
                break
            name = _strip_inline_comment(section.get(name_key, ""))
            if not name:
                break
            url = _strip_inline_comment(section.get(f"link_{n}_url", ""))
            desc = _strip_inline_comment(section.get(f"link_{n}_desc", ""))
            # Skip entries with no URL — name alone isn't useful
            if url:
                links.append({"name": name, "url": url, "desc": desc})
            n += 1
            # Safety cap — no operator legitimately has 1000 supporter links
            if n > 100:
                break
        return {"enabled": enabled, "title": title, "intro": intro,
                "links": links}

    @app.get("/", response_class=HTMLResponse)
    async def index(request: Request):
        branding = ({k: cfg.get("Branding", k) for k in cfg["Branding"]}
                    if cfg.has_section("Branding") else
                    {"page_title": "RENT-A-HAL", "banner_heading": "RENT-A-HAL"})
        # Backward-compat: tagline was added 2026-06-21. Older config.ini
        # files won't have it. Fall back to the iconic default so existing
        # installs don't lose the BETA-5 line after upgrade.
        if "tagline" not in branding:
            branding["tagline"] = "BETA-5 System Terminal"
        # Pass supporters_enabled so the footer can conditionally render
        # the "Support this project" link. The full supporters dict is
        # only loaded by /supporters itself — index only needs the flag.
        supporters_info = _read_supporters()
        if templates:
            return templates.TemplateResponse(request, "index.html",
                {"b": branding,
                 "supporters_enabled": supporters_info["enabled"],
                 "gpu_name": GPU_DEVICE_NAME})
        return HTMLResponse(f"<h1>{branding.get('banner_heading', 'RENT-A-HAL')}</h1>"
                            "<p>templates/index.html not found</p>")

    @app.get("/supporters", response_class=HTMLResponse)
    async def supporters(request: Request):
        """Operator-controlled 'ways to support this project' page.

        Returns 404 when the [Supporters] section is missing or has
        enabled=false. This is deliberate: an operator who hasn't
        opted in doesn't accidentally serve an empty supporters page.

        When enabled, renders the configured title/intro/links from
        config.ini. No defaults baked in — what shows up is exactly
        what the operator put in their own config.ini, nothing more."""
        info = _read_supporters()
        if not info["enabled"]:
            return HTMLResponse(
                "<h1>404</h1><p>Not configured.</p>", status_code=404)
        branding = ({k: cfg.get("Branding", k) for k in cfg["Branding"]}
                    if cfg.has_section("Branding") else
                    {"page_title": "RENT-A-HAL"})
        if templates:
            return templates.TemplateResponse(request, "supporters.html",
                {"b": branding, "s": info})
        # Fallback raw HTML — keeps the route working even if the template
        # file is missing (unusual but defensive)
        rows = "".join(
            f'<li><a href="{lk["url"]}" target="_blank" rel="noopener">'
            f'{lk["name"]}</a> &mdash; {lk["desc"]}</li>'
            for lk in info["links"])
        return HTMLResponse(
            f"<h1>{info['title']}</h1><p>{info['intro']}</p><ul>{rows}</ul>")

    @api.get("/config")
    async def frontend_config():
        return schema_cfg.frontend_config()

    @api.get("/setup_status")
    async def setup_status():
        llm = await llm_chain.detect()
        tts = await tts_chain.detect()
        ready = any(llm.values()) and any(tts.values())
        return {
            "llm": llm, "tts": tts, "ready": ready,
            "last_llm": llm_chain.last_provider,
            "last_tts": tts_chain.last_provider,
            "instructions": {
                "GPT4All": "Open GPT4All → Settings → Enable API Server "
                           "(port 4891) → load Llama 3 8B Instruct",
                "Kokoro":  "Install kokoro-onnx, download kokoro-v0_19.onnx, "
                           "set Kokoro.model_path in config.ini",
                "ElevenLabs": "Paste your ElevenLabs API key in config.ini [ElevenLabs]",
                "OpenAI TTS": "Paste your OpenAI key in config.ini [OpenAITTS]",
            },
        }

    @api.post("/ask")
    async def ask(payload: dict, request: Request):
        """REST shortcut: text in, text out (no TTS). For curl/ngrok testing.

        Honors X-Federation-Hops header: if >= max_federation_hops, this
        request was forwarded by a federation peer. We must NOT re-forward
        — we run locally even if our own LLM is slow. The federation
        provider sees allow_federation=False and skips itself.

        Honors `max_tokens` in the request body: federation senders pass
        their configured ceiling so federated answers don't get truncated
        at our chain's default. We CAP the value at our local ceiling
        (max_response_tokens) so a Little Johnny client can't ask for
        100K tokens and pin our GPU."""
        text = (payload.get("text") or "").strip()
        if not text:
            return JSONResponse({"error": "missing 'text'"}, status_code=400)
        # Read federation hop counter from header (default 0 = direct request)
        hops_raw = request.headers.get("X-Federation-Hops", "0")
        try:
            hops = int(hops_raw)
        except (ValueError, TypeError):
            hops = 0
        # Loose-end fix: validate the federation token, but ONLY for
        # calls that identify themselves as federated (presence of the
        # X-Federation-Hops header at all — even "0" — is what the
        # federation providers always send; an ordinary local/curl
        # caller never sets it). A direct curl call to /api/ask stays
        # exactly as open as the README documents, regardless of
        # whether a token is configured — the token protects the
        # federation network, not this endpoint's general availability.
        if "X-Federation-Hops" in request.headers:
            token_error = federation_token_error(
                federation_cfg.token if federation_cfg else "",
                request.headers.get("X-Federation-Token", ""))
            if token_error is not None:
                return token_error
        else:
            # Sprint 10: PoW gate for DIRECT/anonymous callers only — a
            # federated forward is already gated by the token check
            # above (when a token is configured) and shouldn't also
            # need to solve a puzzle; that would double-gate legitimate
            # peer traffic for no real benefit. IP-keyed, matching the
            # design doc's "anonymous public surface" identity.
            pow_response = _pow_gate_response(
                payload, request.client.host if request.client else "unknown")
            if pow_response is not None:
                return pow_response
        # Hop limit comes from the federation config (default 1)
        max_hops = federation_cfg.max_federation_hops if federation_cfg else 1
        allow_federation = hops < max_hops
        # max_tokens: caller-supplied request, capped at our configured
        # ceiling. If caller didn't send any, use our ceiling.
        ceiling = max_response_tokens
        try:
            requested = int(payload.get("max_tokens", ceiling))
        except (ValueError, TypeError):
            requested = ceiling
        # Guard the floor too — negative or zero would be silly; use a
        # minimum sensible answer length.
        if requested < 50:
            requested = 50
        effective_max_tokens = min(requested, ceiling)
        intent = classifier.classify(text)
        if intent.kind == "weather":
            answer = await weather_handler(intent.slots, "anonymous")
        elif intent.kind == "imagine":
            # Text-only shortcut still works for imagine — the prompt
            # lives entirely in intent.slots, no image needed (unlike
            # vision, which needs a webcam frame this endpoint has no
            # way to provide, so vision intentionally isn't handled
            # here). The returned "answer" is imagine_handler's spoken
            # confirmation text, same shape as weather above — the
            # actual generated image (or the rickroll on the Echo
            # floor) is published via the bus as usual, but a bare
            # curl call has no websocket connection listening for it.
            # This endpoint is documented as "text in, text out"; a
            # caller who wants to SEE the image should use the
            # WebSocket path instead.
            answer = await imagine_handler(intent.slots, "anonymous", bus)
        else:
            answer = await llm_chain.generate(text,
                                              max_tokens=effective_max_tokens,
                                              allow_federation=allow_federation)
        # Sprint 14: donor-side bilateral confirmation. Only fires when
        # this request identified itself as conscripted (see
        # FederationConscriptionProvider._try_one_donor, which sets
        # both headers together) AND we actually produced a real
        # answer — no answer means we didn't genuinely serve this
        # request, so no claim should be submitted for it. Fire-and-
        # forget, same reasoning as the requester-side submission: a
        # claim failure must never affect the response already being
        # returned.
        if (answer and request.headers.get("X-Federation-Conscripted") == "1"
                and federation_cfg is not None):
            requester_url = request.headers.get("X-Federation-Requester-Url", "")
            if requester_url and federation_cfg.self_url:
                await _submit_donor_conscription_claim(requester_url)
        return {"intent": intent.kind, "answer": answer,
                "provider": llm_chain.last_provider}

    @api.post("/speak")
    async def speak(payload: dict, request: Request):
        """REST endpoint for federated TTS synth. Mirrors /api/ask:
        text in, audio out (base64-encoded). Used by peer realms'
        FederationTTSProvider and FederationTTSFallbackProvider when
        they overflow/rescue TTS to us.

        Honors X-Federation-Hops same as /api/ask. With hops >= 1, we
        synthesize using our LOCAL TTS chain only (federation TTS
        providers see allow_federation=False and skip themselves) —
        prevents cascade across multiple peers.

        Returns: {"audio_b64": "<base64 WAV>", "provider": "<name>"}
        On TTS failure: {"audio_b64": "", "provider": "none"} with
        HTTP 200. Callers should treat empty audio_b64 as "synthesis
        failed" and fall through to their own chain.

        Public surface: same CORS as /api/ask. The Little Johnny
        principle — anyone can hit it, federation traffic is just one
        of many legitimate callers."""
        text = (payload.get("text") or "").strip()
        if not text:
            return JSONResponse({"error": "missing 'text'"}, status_code=400)
        hops_raw = request.headers.get("X-Federation-Hops", "0")
        try:
            hops = int(hops_raw)
        except (ValueError, TypeError):
            hops = 0
        # Same token validation as /api/ask — see federation_token_error's
        # docstring and /api/ask's comment for the full reasoning.
        if "X-Federation-Hops" in request.headers:
            token_error = federation_token_error(
                federation_cfg.token if federation_cfg else "",
                request.headers.get("X-Federation-Token", ""))
            if token_error is not None:
                return token_error
        else:
            # Sprint 10: same PoW gate as /api/ask, same reasoning —
            # direct/anonymous callers only, federated forwards already
            # gated by the token check above.
            pow_response = _pow_gate_response(
                payload, request.client.host if request.client else "unknown")
            if pow_response is not None:
                return pow_response
        max_hops = federation_cfg.max_federation_hops if federation_cfg else 1
        allow_federation = hops < max_hops
        audio = await tts_chain.synth(text, allow_federation=allow_federation)
        return {
            "audio_b64": audio or "",
            "provider": tts_chain.last_provider,
        }

    # --------- News proxy endpoints ---------
    # The browser hits /api/news on the realm; the realm forwards to the
    # Kokoro service. Two reasons: (1) the browser only needs to know the
    # realm's origin (works through Cloudflare Tunnel uniformly), and
    # (2) we can rewrite audio URLs so they ALSO go through the realm.
    _kokoro_service_host = cfg_get(cfg, "KokoroService", "host", "localhost").strip()
    _kokoro_service_port = int(cfg_get(cfg, "KokoroService", "port", "9998"))
    _kokoro_service_base = (f"http://{_kokoro_service_host}:{_kokoro_service_port}"
                            if _kokoro_service_host else "")

    @api.get("/news")
    async def get_news(source: str = "", category: str = "", limit: int = 50):
        """Proxy to the Kokoro service's /news endpoint; rewrite audio URLs
        to go through this realm (so audio works the same way the rest of
        the page does — same origin, no CORS, ngrok-friendly)."""
        if not _kokoro_service_base:
            return JSONResponse({"enabled": False, "stories": [],
                                 "error": "kokoro service not configured"},
                                status_code=503)
        params = {"limit": str(limit)}
        if source:
            params["source"] = source
        if category:
            params["category"] = category
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"{_kokoro_service_base}/news",
                                 params=params) as r:
                    if r.status != 200:
                        return JSONResponse({"error": f"service status {r.status}"},
                                            status_code=r.status)
                    data = await r.json()
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=503)
        # Rewrite audio URLs to come through THIS realm
        for story in data.get("stories", []):
            if story.get("audio_url") and story["audio_url"].startswith("/"):
                # /audio/abc123 -> /api/news/audio/abc123
                audio_id = story["audio_url"].rsplit("/", 1)[-1]
                story["audio_url"] = f"/api/news/audio/{audio_id}"
        return data

    @api.get("/news/feeds")
    async def get_news_feeds():
        """Proxy /news/feeds — list of configured feeds."""
        if not _kokoro_service_base:
            return {"enabled": False, "feeds": []}
        try:
            timeout = aiohttp.ClientTimeout(total=5)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"{_kokoro_service_base}/news/feeds") as r:
                    return await r.json()
        except Exception as e:
            return {"enabled": False, "feeds": [], "error": str(e)}

    @api.get("/news/audio/{audio_id}")
    async def get_news_audio(audio_id: str):
        """Proxy /audio/{id} — streams the WAV through the realm so browsers
        on Cloudflare Tunnel etc. don't need to talk directly to the service."""
        if not _kokoro_service_base:
            return JSONResponse({"error": "service not configured"}, status_code=503)
        try:
            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"{_kokoro_service_base}/audio/{audio_id}") as r:
                    if r.status != 200:
                        return JSONResponse({"error": f"audio status {r.status}"},
                                            status_code=r.status)
                    data = await r.read()
                    return Response(content=data, media_type="audio/wav")
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=503)

    @api.get("/news/roundup")
    async def get_news_roundup(count: int = 20):
        """Returns a shuffled mix of NPR + Guardian stories for radio-style
        auto-playback. The browser plays /static/newsroundupaudioalert.mp3
        first (intro tones), then advances through the returned stories one
        by one — each story's audio_url plays in turn until the user hits
        SILENCE or says 'stop stop'.

        Returns: { "enabled": bool, "stories": [...] }
        Each story has: title, source, audio_url, link

        We pull from both NPR and The Guardian (the two highest-quality
        non-paywalled English-language news feeds in Kokoro's catalog),
        interleave by random shuffle, and cap at `count` (default 20)
        so the round-trip stays small.
        """
        if not _kokoro_service_base:
            return JSONResponse({"enabled": False, "stories": [],
                                 "error": "kokoro service not configured"},
                                status_code=503)
        # Pull NPR and Guardian as two separate fetches so we get a
        # balanced mix even if one source has many more stories cached.
        # The Kokoro /news endpoint accepts source=<name> as a filter.
        async def fetch_source(source: str, limit: int):
            params = {"source": source, "limit": str(limit)}
            try:
                timeout = aiohttp.ClientTimeout(total=10)
                async with aiohttp.ClientSession(timeout=timeout) as s:
                    async with s.get(f"{_kokoro_service_base}/news",
                                     params=params) as r:
                        if r.status != 200:
                            return []
                        data = await r.json()
                        return data.get("stories", []) if data.get("enabled") else []
            except Exception:
                return []
        # Fetch both in parallel — saves ~one round-trip vs sequential
        npr_stories, guardian_stories = await asyncio.gather(
            fetch_source("NPR", count),
            fetch_source("The Guardian", count),
        )
        # Combine, shuffle, cap, slim — pure logic, separately testable
        return _build_roundup(npr_stories, guardian_stories, count)

    # ─── Federation endpoints ──────────────────────────────────────
    # These come in two flavors depending on whether THIS realm is
    # acting as the Federator or as a federation member.
    #
    # ALL realms expose /api/federation/status — operator-visible
    # current state (DESIRE / MASTER / STATE / best peer URLs).
    # The UI polls this.
    #
    # Only realms with [Federator] enabled = true expose /api/federate/checkin
    # — that's where members POST their stats. The Federator replies
    # with peer advice.
    #
    # The path prefix /api/federate/ keeps the surface consistent with
    # the Federator URL the user sees in the brainstorm:
    #   https://rentahal.com/federate/federator → https://rentahal.com/api/federate/checkin
    # (the /federate/federator was your shorthand; the actual endpoint
    # is /api/federate/checkin to live alongside /api/ask etc.)

    @api.get("/federation/status")
    async def federation_status():
        """Operator-visible federation state for the cockpit UI.

        Always returns a snapshot of THIS realm's federation participation
        (whether or not it's the Federator). UI uses this to draw the
        DESIRE / MASTER / STATE badge in the metrics area."""
        return federation_state.to_ui_dict()

    if federator_enabled and federation_matrix is not None:
        @api.post("/federate/checkin")
        async def federate_checkin(payload: dict):
            """Federator-side: receive a member's stats, return peer advice.

            This is the entire federation protocol. Members POST their
            current LLM/TTS averages and tokens-out; we update the matrix
            and reply with the URL of the best peer for LLM and for TTS
            (or null if no alive peer is better than themselves).

            Sprint 6: members MAY additionally POST capability_avg_s (a
            sparse dict for anything beyond llm/tts — vision, imagine,
            ...) and node_type. Both are optional and additive.

            Loose-end fix: this endpoint has accepted a `token` field in
            the payload since it was first written, but never actually
            validated it against anything — federation was effectively
            open regardless of what an operator configured. Now
            validated via federation_token_error: if THIS realm (acting
            as Federator) has [Federation] token set, incoming check-ins
            must match it exactly or get a 401. Empty token (the
            default) means no validation at all — zero behavior change
            for every existing deployment that's never set one.
            """
            member_url = (payload.get("member_url") or "").strip()
            if not member_url:
                return JSONResponse({"error": "missing member_url"},
                                    status_code=400)
            token_error = federation_token_error(
                federation_cfg.token if federation_cfg else "",
                payload.get("token") or "")
            if token_error is not None:
                return token_error
            # NOT gated by PoW (see the incident this comment documents):
            # check-in is a legitimate, expected, HIGH-FREQUENCY (every
            # [Federation] checkin_interval_s, 15s by default), LOW-COST
            # bookkeeping call — not the kind of expensive-compute
            # anonymous-abuse surface the PoW gate (Sprint 10) exists to
            # protect. The math makes this concrete: at a 15s interval, a
            # realm exhausts the PoW gate's 10-calls-per-10-minute free
            # tier in 150 seconds, and the check-in CLIENT has no ability
            # to solve a PoW challenge and resubmit — it would simply
            # fail every check-in from that point forward until a
            # restart reset the in-memory counter, then repeat the same
            # cycle. Confirmed as a genuine, guaranteed-to-recur
            # production issue (not a hypothetical), not a hypothetical
            # edge case — every federated realm running more than ~2.5
            # minutes would eventually hit this. federation_token_error
            # above is the correct, sufficient authentication layer for
            # this endpoint; PoW's threat model (anonymous callers
            # burning expensive GPU compute) simply doesn't apply here.
            try:
                llm_avg_s = float(payload.get("llm_avg_s", 0.0))
                tts_avg_s = float(payload.get("tts_avg_s", 0.0))
                tokens_out = int(payload.get("tokens_out", 0))
            except (TypeError, ValueError):
                return JSONResponse({"error": "invalid stats"},
                                    status_code=400)
            # Sparse, defensively parsed — one bad entry doesn't reject
            # the whole check-in (a member on an unknown-to-us newer
            # capability shouldn't get bounced by an older Federator).
            #
            # capability_avg_s_for_upsert stays None when the payload
            # key is genuinely ABSENT (a pre-Sprint-6 client that's
            # never heard of this field) — passing None to upsert()
            # means "don't touch existing capability data," preserving
            # true backward compat. When the key IS present — even as
            # an empty dict — we pass the (possibly empty) parsed dict,
            # which upsert() then uses to REPLACE the stored set
            # wholesale. That's what lets a node correctly clear a
            # capability it no longer reports (operator disabled LLaVA
            # and restarted) instead of advertising a stale average
            # forever. capability_avg_s (below) stays a plain dict
            # regardless, for the best_peer computation loop further
            # down — that loop only needs "what did THIS check-in
            # mention," never "what should be preserved."
            raw_caps = payload.get("capability_avg_s")
            capability_avg_s = {}
            if isinstance(raw_caps, dict):
                for k, v in raw_caps.items():
                    try:
                        capability_avg_s[str(k)] = float(v)
                    except (TypeError, ValueError):
                        continue
            capability_avg_s_for_upsert = (
                capability_avg_s if isinstance(raw_caps, dict) else None)
            raw_ranks = payload.get("conscription_eligible_ranks") or []
            conscription_eligible_ranks = (
                [str(r) for r in raw_ranks if isinstance(r, str)]
                if isinstance(raw_ranks, list) else [])
            node_type = str(payload.get("node_type") or "chat")
            raw_max_minutes = payload.get("conscription_max_minutes")
            try:
                conscription_max_minutes = (float(raw_max_minutes)
                                            if raw_max_minutes is not None
                                            else None)
            except (TypeError, ValueError):
                conscription_max_minutes = None
            await federation_matrix.upsert(
                member_url, llm_avg_s, tts_avg_s, tokens_out,
                capability_avg_s=capability_avg_s_for_upsert,
                conscription_eligible_ranks=conscription_eligible_ranks,
                node_type=node_type,
                conscription_max_minutes=conscription_max_minutes)
            # Find best peer for LLM and TTS, excluding the caller
            best_llm = await federation_matrix.best_peer_for(
                "llm", exclude_url=member_url)
            best_tts = await federation_matrix.best_peer_for(
                "tts", exclude_url=member_url)
            # Sprint 6: best peer for whatever OTHER capabilities this
            # member itself reported — "you told me you care about
            # vision, here's who's best at vision among your peers."
            # We don't compute peers for capabilities the caller didn't
            # mention; no point advising a chat-only node about imagine.
            best_peer = {}
            for kind in capability_avg_s:
                peer = await federation_matrix.best_peer_for(
                    kind, exclude_url=member_url)
                if peer:
                    best_peer[kind] = peer
            # Sprint 8: only evaluate conscription for the CALLER's own
            # native rank — a vision-native node has no reason to be
            # told about a chat contract, it doesn't need extra chat
            # capacity. node_type outside the three known ranks (a typo,
            # or a genuinely new rank we don't understand yet) simply
            # never triggers this — no contracts, no errors.
            conscriptions = []
            if node_type in CONSCRIPTION_RANKS:
                conscriptions = await federation_matrix.maybe_assign_conscription(
                    node_type, requester_url=member_url)
            # Sprint 9: donor-side visibility — evaluated for EVERY
            # check-in regardless of the caller's own node_type/rank,
            # since a vision-native node can be a donor for chat (a
            # DIFFERENT rank from its own). Cheap (see get_donor_contracts
            # docstring), so no reason to gate this behind anything.
            donor_contracts = await federation_matrix.get_donor_contracts(member_url)
            return {
                "best_llm_peer": best_llm,
                "best_tts_peer": best_tts,
                "best_peer": best_peer,
                # Multi-donor: "conscriptions"/"donor_contracts" are the
                # authoritative full lists. "conscription"/"donor_contract"
                # (singular, first-or-null) are kept for any client still
                # reading the pre-multi-donor shape.
                "conscription": conscriptions[0] if conscriptions else None,
                "conscriptions": conscriptions,
                "donor_contract": donor_contracts[0] if donor_contracts else None,
                "donor_contracts": donor_contracts,
                "your_state": "HEALTHY",       # we just received their check-in
                "matrix_size": len(federation_matrix.members),
            }

        @api.get("/federate/matrix")
        async def federate_matrix(request: Request):
            """Observability: dump the current matrix. Members aren't
            credentials; the URLs are already advertised publicly via
            the check-in protocol — but once an operator sets
            [Federation] token, this endpoint (and the other two
            admin/observability endpoints below) requires it too via
            X-Federation-Token, consistently. No token configured =
            no validation at all, same as every other federation-
            facing endpoint in this file."""
            token_error = federation_token_error(
                federation_cfg.token if federation_cfg else "",
                request.headers.get("X-Federation-Token", ""))
            if token_error is not None:
                return token_error
            return {
                "members": await federation_matrix.snapshot(),
                "missed_after_s": federation_matrix.missed_after_s,
            }

        @api.get("/federate/contracts")
        async def federate_contracts(request: Request):
            """Observability: dump all currently active conscription
            contracts (Sprint 8/9), keyed by rank. Complements the
            matrix dump: the matrix shows PER-MEMBER stats, this shows
            the Federator's own current DECISIONS (who's helping whom,
            and until when — note assigned_at/expires_at are the
            Federator's own time.monotonic() values, meaningless to
            compare against any other clock). Same token gate as
            /federate/matrix above."""
            token_error = federation_token_error(
                federation_cfg.token if federation_cfg else "",
                request.headers.get("X-Federation-Token", ""))
            if token_error is not None:
                return token_error
            return {"contracts": await federation_matrix.get_all_contracts()}

        @api.post("/federate/contracts/revoke")
        async def federate_revoke_contract(payload: dict, request: Request):
            """Manually force-expire conscription contract(s) without
            editing federation.ini and restarting the Federator.
            Previously the ONLY way to end a contract early was waiting
            for its natural expiry or restarting the process (which
            clears ALL contracts, not just the one in question).

            Same token gate as /federate/matrix and /federate/contracts
            above — this write action is no longer the accidental
            exception to an otherwise-unenforced admin surface; all
            three (plus /federate/checkin, /api/ask, /api/speak) now go
            through the same federation_token_error check consistently.

            Body: {"rank": "chat"} revokes ALL donors currently
            contracted for that rank (the original single-donor
            behavior, still the common case). {"rank": "chat",
            "donor_url": "https://..."} revokes ONLY that donor,
            leaving any other donor helping the same rank untouched.

            Returns the list of contracts that were actually revoked
            (empty list if none matched)."""
            token_error = federation_token_error(
                federation_cfg.token if federation_cfg else "",
                request.headers.get("X-Federation-Token", ""))
            if token_error is not None:
                return token_error
            rank = str(payload.get("rank") or "").strip().lower()
            if not rank:
                return JSONResponse({"error": "missing 'rank'"},
                                    status_code=400)
            donor_url = payload.get("donor_url") or None
            revoked = await federation_matrix.revoke_contract(rank, donor_url)
            return {"revoked": len(revoked) > 0, "contracts": revoked,
                   # Backward-compat single-contract field.
                   "contract": revoked[0] if revoked else None}

        if payout_cfg is not None:
            @api.post("/federate/conscription-claim")
            async def federate_conscription_claim(payload: dict, request: Request):
                """Sprint 14 — bilateral confirmation. Either the
                REQUESTER (after FederationConscriptionProvider
                successfully gets an answer from a donor) or the DONOR
                (after successfully answering a request that arrived
                with X-Federation-Conscripted: 1) submits a claim here.
                See realm/donor_payout.py's module docstring for the
                full reasoning — a payout only ever happens once BOTH
                sides' claims for the same piece of work match.

                Same token gate as every other federation admin
                endpoint once [Federation] token is configured.

                Body: {"role": "requester"|"donor", "donor_url": "...",
                "requester_url": "...", "rank": "chat",
                "claimed_at": <unix epoch seconds, optional>}."""
                token_error = federation_token_error(
                    federation_cfg.token if federation_cfg else "",
                    request.headers.get("X-Federation-Token", ""))
                if token_error is not None:
                    return token_error
                store = _claim_store_holder.get("store")
                if store is None:
                    return JSONResponse(
                        {"error": "payout claim store not connected"},
                        status_code=503)
                role = payload.get("role", "")
                donor_url_field = (payload.get("donor_url") or "").strip()
                requester_url_field = (payload.get("requester_url") or "").strip()
                rank_field = payload.get("rank", "")
                claimed_at = payload.get("claimed_at")
                if not donor_url_field or not requester_url_field:
                    return JSONResponse(
                        {"error": "missing donor_url or requester_url"},
                        status_code=400)
                try:
                    result = await store.submit_claim(
                        role, donor_url_field, requester_url_field, rank_field,
                        claimed_at=float(claimed_at) if claimed_at else None)
                except ValueError as e:
                    return JSONResponse({"error": str(e)}, status_code=400)
                return {
                    "claim_id": result.claim_id,
                    "matched": result.matched,
                    "matched_claim_id": result.matched_claim_id,
                    "credited": result.credited,
                    "credit_amount_micros": result.credit_amount_micros,
                }

            @api.get("/federate/conscription-claims/unmatched")
            async def federate_conscription_claims_unmatched(request: Request,
                                                              max_age_s: float = None):
                """Observability: claims still waiting for their pair —
                or, if max_age_s is given, only the ones old enough to
                be considered abandoned (a lying or genuinely-failed
                party) rather than just not-yet-matched. Same token
                gate as the other admin endpoints."""
                token_error = federation_token_error(
                    federation_cfg.token if federation_cfg else "",
                    request.headers.get("X-Federation-Token", ""))
                if token_error is not None:
                    return token_error
                store = _claim_store_holder.get("store")
                if store is None:
                    return JSONResponse(
                        {"error": "payout claim store not connected"},
                        status_code=503)
                claims = await store.get_unmatched_claims(max_age_s=max_age_s)
                return {"unmatched_claims": claims}

            @api.post("/federate/payout/link")
            async def federate_payout_link(payload: dict, request: Request):
                """Starts (or restarts) Stripe Connect Express
                onboarding for a donor realm. Real network call to
                api.stripe.com. Returns a one-time URL to redirect the
                donor operator to."""
                token_error = federation_token_error(
                    federation_cfg.token if federation_cfg else "",
                    request.headers.get("X-Federation-Token", ""))
                if token_error is not None:
                    return token_error
                donor_url_field = (payload.get("donor_url") or "").strip()
                if not donor_url_field:
                    return JSONResponse({"error": "missing donor_url"},
                                        status_code=400)
                account_store = _donor_account_store_holder.get("store")
                if account_store is None:
                    return JSONResponse(
                        {"error": "payout account store not connected"},
                        status_code=503)
                from realm.donor_payout import (
                    create_connect_account, create_onboarding_link,
                )
                try:
                    existing = await account_store.get_account(donor_url_field)
                    if existing:
                        stripe_account_id = existing["stripe_account_id"]
                    else:
                        stripe_account_id = await asyncio.to_thread(
                            create_connect_account, payout_cfg, donor_url_field)
                        await account_store.link_account(
                            donor_url_field, stripe_account_id)
                    onboarding_url = await asyncio.to_thread(
                        create_onboarding_link, payout_cfg, stripe_account_id)
                except Exception as e:
                    logger.warning("Payout: onboarding link creation failed: %s", e)
                    return JSONResponse(
                        {"error": "onboarding link creation failed"},
                        status_code=502)
                return {"onboarding_url": onboarding_url}

            @api.get("/federate/payout/status")
            async def federate_payout_status(donor_url: str, request: Request):
                """Sprint 15 — cockpit visibility: is this donor's
                Stripe Connect account onboarded, and what's their
                current accrued (confirmed) balance? A donor realm's
                own cockpit polls this against the Federator directly
                (CORS is already permissive — see app.py's own CORS
                setup) to show 'moonlighting earnings' without needing
                a separate endpoint on the donor's own side.

                Same token gate as the other admin endpoints. Balance
                comes straight from the shared ledger — the SAME
                number /api/billing/balance would show if queried with
                this donor_url as account_id, since conscription
                credits and consumer debits share one ledger."""
                token_error = federation_token_error(
                    federation_cfg.token if federation_cfg else "",
                    request.headers.get("X-Federation-Token", ""))
                if token_error is not None:
                    return token_error
                account_store = _donor_account_store_holder.get("store")
                ledger = _ledger_holder.get("ledger")
                if account_store is None or ledger is None:
                    return JSONResponse(
                        {"error": "payout store not connected"},
                        status_code=503)
                account = await account_store.get_account(donor_url)
                balance = await ledger.get_balance(donor_url)
                return {
                    "donor_url": donor_url,
                    "linked": account is not None,
                    "payouts_enabled": bool(account and account["payouts_enabled"]),
                    "balance_micros": balance,
                    "balance_usd": round(balance / 1_000_000, 6),
                }

    if ledger_dsn:
        @api.get("/ledger/proof")
        async def ledger_proof():
            """Serves the current OpenTimestamps proof file as a raw
            download — literally the same bytes ots_daily_job.py writes
            to its --public-dir. `curl .../api/ledger/proof -o ledger.ots`
            then `ots verify ledger.ots` (with a Bitcoin node, or
            `ots upgrade` first if it's still pending) is a complete,
            independent verification path that trusts nothing this
            realm says — only Bitcoin's own consensus."""
            ledger = _ledger_holder.get("ledger")
            if ledger is None:
                return JSONResponse(
                    {"error": "ledger not connected"}, status_code=503)
            async with ledger._pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT ots_proof FROM ots_anchors ORDER BY id DESC LIMIT 1")
            if row is None:
                return JSONResponse(
                    {"error": "no anchor exists yet — run ots_daily_job.py"},
                    status_code=404)
            return Response(content=bytes(row["ots_proof"]),
                            media_type="application/octet-stream",
                            headers={"Content-Disposition":
                                    'attachment; filename="ledger.ots"'})

        @api.get("/ledger/proof/info")
        async def ledger_proof_info():
            """Human/machine-readable status: what the current anchor
            claims, whether it's Bitcoin-confirmed yet, and exactly how
            to verify it yourself. This is the honest version of "trust
            us" — every number here is independently re-checkable."""
            ledger = _ledger_holder.get("ledger")
            if ledger is None:
                return JSONResponse(
                    {"error": "ledger not connected"}, status_code=503)
            async with ledger._pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT * FROM ots_anchors ORDER BY id DESC LIMIT 1")
            if row is None:
                return JSONResponse(
                    {"error": "no anchor exists yet — run ots_daily_job.py"},
                    status_code=404)
            dts = ots_deserialize(bytes(row["ots_proof"]))
            digest = bytes.fromhex(row["chain_tip_hash"])
            result = ots_local_verify(dts, digest)
            bitcoin_attestations = [
                {"block_height": a.bitcoin_block_height,
                 "derived_merkle_root": a.derived_msg_hex}
                for a in result.attestations if a.kind == "bitcoin"]
            return {
                "chain_tip_hash": row["chain_tip_hash"],
                "stamped_at": row["stamped_at"].isoformat(),
                "is_complete": row["is_complete"],
                "bitcoin_attestations": bitcoin_attestations,
                "how_to_verify_independently": [
                    "1. Download the proof: "
                    "curl <this realm>/api/ledger/proof -o ledger.ots",
                    "2. pip install opentimestamps-client",
                    "3. ots verify ledger.ots  (needs a Bitcoin node for "
                    "full confirmation — a pruned node is enough — or "
                    "compare bitcoin_attestations above against a public "
                    "block explorer's data for that block height "
                    "yourself)",
                    "This does not require trusting this realm, its "
                    "operator, or Anthropic — only Bitcoin's own "
                    "consensus and the OpenTimestamps protocol.",
                ],
            }

    if billing_cfg is not None:
        @api.post("/billing/checkout")
        async def billing_checkout(payload: dict):
            """Creates a Stripe Checkout Session for a balance top-up
            and returns the URL to redirect the user to. Real network
            call to api.stripe.com — the stripe SDK's HTTP layer is
            synchronous/blocking, so it's run in a thread via
            asyncio.to_thread rather than blocking the event loop (the
            same reason realm/ots_anchor.py's calendar submission code
            stays a standalone sync module rather than forcing async
            throughout — here the caller genuinely IS a live async
            endpoint, so the thread-offload is the right tool,
            whereas ots_anchor.py's caller is a standalone script with
            no event loop to protect).

            Body: {"account_id": "...", "amount_micros": 5000000}.
            amount_micros must be one of billing_cfg.topup_presets_micros
            unless the operator wants to allow arbitrary amounts (not
            validated here beyond Stripe's own ~$0.50 minimum — see
            create_checkout_session)."""
            account_id = (payload.get("account_id") or "").strip()
            if not account_id:
                return JSONResponse({"error": "missing account_id"},
                                    status_code=400)
            try:
                amount_micros = int(payload.get("amount_micros", 0))
            except (TypeError, ValueError):
                return JSONResponse({"error": "invalid amount_micros"},
                                    status_code=400)
            try:
                url = await asyncio.to_thread(
                    create_checkout_session, billing_cfg, account_id,
                    amount_micros)
            except ValueError as e:
                return JSONResponse({"error": str(e)}, status_code=400)
            except Exception as e:
                logger.warning("Billing: checkout session creation failed: %s", e)
                return JSONResponse(
                    {"error": "checkout session creation failed"},
                    status_code=502)
            return {"checkout_url": url}

        @api.post("/billing/webhook")
        async def billing_webhook(request: Request):
            """Stripe webhook receiver. Signature-verified (see
            realm/billing.py's verify_webhook — pure local cryptography,
            the security-critical function in this whole sprint) and
            idempotent (a redelivered event correctly no-ops rather
            than double-crediting — see DuplicateEntryError). Always
            returns 200 once the signature verifies, regardless of
            whether this delivery actually added a new credit — that's
            what tells Stripe to stop retrying. Returns 400 (NOT 200)
            on a signature failure — Stripe doesn't retry on 4xx either,
            but a 200 here would look like "processed successfully" to
            anyone monitoring response codes, masking a forgery attempt."""
            raw_body = await request.body()
            sig_header = request.headers.get("Stripe-Signature", "")
            try:
                event = verify_webhook(
                    raw_body, sig_header, billing_cfg.stripe_webhook_secret)
            except WebhookVerificationError as e:
                logger.warning("Billing: webhook signature verification "
                               "failed: %s", e)
                return JSONResponse({"error": "invalid signature"},
                                    status_code=400)
            ledger = _ledger_holder.get("ledger")
            if ledger is None:
                # Signature was valid but we can't credit anything right
                # now — ask Stripe to retry rather than silently losing
                # a legitimate payment.
                return JSONResponse({"error": "ledger not connected"},
                                    status_code=503)
            try:
                result = await handle_checkout_completed_event(event, ledger)
            except Exception as e:
                logger.warning("Billing: webhook handling failed: %s", e)
                return JSONResponse({"error": "webhook handling failed"},
                                    status_code=500)
            return {"handled": result.handled, "credited": result.credited,
                   "duplicate": result.duplicate}

        @api.get("/billing/balance")
        async def billing_balance(account_id: str):
            """Current balance for an account, in micros (see
            realm/ledger.py's convention — 1,000,000 micros = $1.00)."""
            ledger = _ledger_holder.get("ledger")
            if ledger is None:
                return JSONResponse({"error": "ledger not connected"},
                                    status_code=503)
            balance = await ledger.get_balance(account_id)
            return {"account_id": account_id, "balance_micros": balance,
                   "balance_usd": round(balance / 1_000_000, 6)}

    app.include_router(api)

    @app.websocket("/ws")
    async def ws_endpoint(websocket: WebSocket):
        await websocket.accept()
        # User identity priority:
        #   1. ?user_guid=... in the URL (set by browser localStorage, per-device,
        #      survives Cloudflare/CDN/Chrome-sync/HTTPS-cookie weirdness)
        #   2. user_guid cookie (legacy fallback)
        #   3. fresh UUID (first-ever visit)
        user_guid = (
            websocket.query_params.get("user_guid")
            or websocket.cookies.get("user_guid")
            or str(uuid.uuid4())
        )
        # Defensive: reject empty / clearly bogus guids; assign fresh
        if not user_guid or len(user_guid) < 8:
            user_guid = str(uuid.uuid4())
        await manager.connect(websocket, user_guid)
        try:
            await websocket.send_json({"type": "set_cookie",
                                       "name": "user_guid", "value": user_guid})
            await websocket.send_json({"type": "user_info",
                                       "data": {"guid": user_guid,
                                                "nickname": f"user_{user_guid[:8]}"}})
            # Tell the browser its connection token. Every event we send
            # will be stamped with this token + a seq, and the browser
            # must echo both back in any ACK. This makes ACKs collision-
            # proof across reconnects, multiple tabs, and realm restarts.
            conn_token = manager.get_conn_token(user_guid)
            if conn_token is not None:
                await websocket.send_json({"type": "conn_token",
                                           "value": conn_token})
            while True:
                data = await websocket.receive_json()
                manager.touch(user_guid)
                mtype = data.get("type")
                if mtype == "voice_prompt" or mtype == "prompt_text":
                    text = data.get("text", "")
                    nonce = data.get("nonce", uuid.uuid4().hex[:12])
                    # Optional webcam frame — the browser attaches this
                    # when it guesses the user is about to ask a vision
                    # question (see intent.py's _on_prompt for how a
                    # wrong guess is handled harmlessly). Absent for
                    # every other prompt.
                    image_b64 = data.get("image_b64")
                    await bus.publish("prompt_text", text=text,
                                      nonce=nonce, user_guid=user_guid,
                                      image_b64=image_b64)
                elif mtype == "ack":
                    # Browser confirms it processed an event. We check
                    # that the conn_token matches the current connection
                    # — if it doesn't, this is a stale ACK from a
                    # previous session (page reload, tab switch) and we
                    # silently discard it.
                    ack_token = data.get("conn_token", "")
                    ack_seq = data.get("seq")
                    if isinstance(ack_seq, int) and isinstance(ack_token, str):
                        await manager.ack_received(user_guid, ack_token, ack_seq)
                elif mtype == "ping":
                    await bus.publish("ping", user_guid=user_guid,
                                      nonce=data.get("nonce", ""))
                elif mtype == "pong":
                    pass
                elif mtype == "client_location":
                    # Browser sends lat/lon after user grants geolocation
                    # permission. Forward to bus so the orchestrator can
                    # cache it for the service-finder realm.
                    lat = data.get("lat")
                    lon = data.get("lon")
                    if isinstance(lat, (int, float)) and isinstance(lon, (int, float)):
                        await bus.publish("client_location",
                                          user_guid=user_guid,
                                          lat=lat, lon=lon)
                else:
                    await manager.safe_send(websocket,
                        {"type": "error",
                         "message": f"unknown message type: {mtype}"})
        except WebSocketDisconnect:
            logger.info("Client %s disconnected", user_guid)
        except Exception:
            logger.exception("ws loop error for %s", user_guid)
        finally:
            await manager.disconnect(user_guid)

    return app


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(description="RENT-A-HAL launcher")
    parser.add_argument("--host", default=None, help="bind host (overrides config)")
    parser.add_argument("--port", type=int, default=None,
                        help="bind port (overrides config; default 9999)")
    parser.add_argument("--reload", action="store_true",
                        help="uvicorn auto-reload (dev only)")
    args = parser.parse_args()

    cfg = load_ini()
    logger = setup_logging(cfg)
    host = args.host or cfg_get(cfg, "Server", "host", "0.0.0.0")
    port = args.port or cfg_int(cfg, "Server", "port", 9999)

    logger.info("=" * 60)
    logger.info("RENT-A-HAL Star Trek Realm — booting on %s:%d", host, port)
    logger.info("Config: %s", CONFIG_PATH)
    if os.environ.get("RENTAHAL_FAKE_ENGINES"):
        logger.warning("RENTAHAL_FAKE_ENGINES set — chains will use EchoProviders")
    logger.info("=" * 60)

    app = create_app(cfg, logger)
    uvicorn.run(app, host=host, port=port, log_config=None,
                ws_ping_interval=None, ws_ping_timeout=None)


if __name__ == "__main__":
    main()
