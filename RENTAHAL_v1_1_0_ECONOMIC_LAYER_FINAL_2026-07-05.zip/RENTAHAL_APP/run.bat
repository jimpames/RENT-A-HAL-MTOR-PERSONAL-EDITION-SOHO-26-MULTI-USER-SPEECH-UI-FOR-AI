@echo off
REM RENT-A-HAL Star Trek Realm — Windows launcher
REM Activates venv if present, then launches app.py

setlocal

cd /d "%~dp0"

if exist "venv\Scripts\activate.bat" (
    echo Activating venv...
    call venv\Scripts\activate.bat
) else (
    echo No venv detected. To create one:
    echo   py -m venv venv
    echo   venv\Scripts\activate
    echo   pip install -r requirements.txt
    echo.
)

echo.
echo Launching RENT-A-HAL on port 9999...
echo Browser:  http://localhost:9999
echo Bolt to ngrok in another window:  ngrok http 9999
echo.
python app.py %*

endlocal
