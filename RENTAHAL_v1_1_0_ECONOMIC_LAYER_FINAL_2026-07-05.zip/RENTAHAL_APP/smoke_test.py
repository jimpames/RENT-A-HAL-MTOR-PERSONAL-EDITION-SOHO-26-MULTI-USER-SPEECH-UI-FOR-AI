"""
smoke_test.py — end-to-end against the REAL app.py.

  RENTAHAL_FAKE_ENGINES=1 python smoke_test.py

Boots the real FastAPI app with EchoLLM + EchoTTS providers (no network),
connects a websocket client, drives the full Star Trek voice loop:

  voice_prompt -> bus_intent_classified -> bus_query_processing
              -> bus_query_result -> bus_tts_started -> bus_tts_chunk
              -> bus_tts_complete

Then proves STOP STOP aborts active TTS and REPEAT REPEAT replays.

Exits non-zero on any failure. Logs each check.
"""

import asyncio
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("RENTAHAL_FAKE_ENGINES", "1")

sys.path.insert(0, str(Path(__file__).resolve().parent))

import uvicorn
import websockets

import app as app_module

PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok)))
    icon = PASS if ok else FAIL
    print(f"  [{icon}] {name}" + (f"  ({detail})" if detail and not ok else ""))


async def collect(ws, want, timeout=8):
    """Read messages until we've seen all `want` types, or timeout."""
    seen = {}
    deadline = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < deadline:
        try:
            raw = await asyncio.wait_for(ws.recv(), timeout=0.2)
        except asyncio.TimeoutError:
            continue
        except Exception:
            break
        msg = json.loads(raw)
        seen.setdefault(msg["type"], []).append(msg)
        if all(t in seen for t in want):
            return seen
    return seen


async def main():
    cfg = app_module.load_ini()
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)

    port = 9911
    config = uvicorn.Config(app, host="127.0.0.1", port=port,
                            log_level="warning",
                            ws_ping_interval=None, ws_ping_timeout=None)
    server = uvicorn.Server(config)
    server_task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)

    url = f"ws://127.0.0.1:{port}/ws"
    print(f"\n== Booting real app.py on {port} (FAKE_ENGINES on) ==\n")

    # ── 1. Connection + greeting ─────────────────────────────────
    async with websockets.connect(url) as ws:
        msg = json.loads(await ws.recv())
        check("set_cookie issued", msg["type"] == "set_cookie")
        msg = json.loads(await ws.recv())
        check("user_info delivered", msg["type"] == "user_info")

        # ── 2. Voice prompt -> full bus pipeline ─────────────────
        print("\n== Voice loop: 'what is the realm' ==")
        await ws.send(json.dumps({"type": "voice_prompt",
                                  "text": "what is the realm",
                                  "nonce": "n1"}))
        seen = await collect(ws, [
            "bus_intent_classified", "bus_query_queued", "bus_query_processing",
            "bus_query_result", "bus_tts_started", "bus_tts_chunk",
            "bus_tts_complete",
        ], timeout=8)
        for evtype in ("bus_intent_classified", "bus_query_processing",
                       "bus_query_result", "bus_tts_complete"):
            check(f"event fired: {evtype}", evtype in seen)
        if "bus_intent_classified" in seen:
            check("intent classified as 'ask'",
                  seen["bus_intent_classified"][0].get("kind") == "ask")
        if "bus_query_result" in seen:
            r = seen["bus_query_result"][0]
            check("LLM produced an answer", len(r.get("text", "")) > 0)
            check("metric: prompt echoed back",
                  r.get("prompt") == "what is the realm")
            check("metric: elapsed_s present and positive",
                  isinstance(r.get("elapsed_s"), (int, float)) and r["elapsed_s"] > 0)
            check("metric: started_at < ended_at",
                  r.get("started_at", 0) < r.get("ended_at", 0))
            check("metric: tokens_out present",
                  r.get("tokens_out") is not None and r["tokens_out"] > 0)
            check("metric: tokens_per_sec computed",
                  r.get("tokens_per_sec") is not None and r["tokens_per_sec"] > 0)
            check("metric: echo provider marked approximate",
                  r.get("tokens_approx") is True)

        # ── 2b. Vision: "take a look" + a webcam frame, Echo floor ──
        # FAKE_ENGINES boots VisionChain([EchoVisionProvider()]) — no
        # LLaVA running, so this exercises the floor path: the handler
        # must still answer with text AND fire the shared
        # easter_egg_video event (Mr. Magoo) since nothing is online.
        print("\n== Vision loop: 'take a look' (Echo floor) ==")
        import base64 as _b64
        fake_frame = _b64.b64encode(b"not a real jpeg, just smoke-test bytes").decode()
        await ws.send(json.dumps({"type": "voice_prompt",
                                  "text": "take a look",
                                  "image_b64": fake_frame,
                                  "nonce": "n1v"}))
        seen_v = await collect(ws, [
            "bus_intent_classified", "bus_query_result", "bus_easter_egg_video",
        ], timeout=8)
        if "bus_intent_classified" in seen_v:
            check("vision: intent classified as 'vision'",
                  seen_v["bus_intent_classified"][0].get("kind") == "vision")
        check("vision: query_result fired", "bus_query_result" in seen_v)
        if "bus_query_result" in seen_v:
            check("vision: floor answered with text",
                  len(seen_v["bus_query_result"][0].get("text", "")) > 0)
        check("vision: easter_egg_video fired on floor", "bus_easter_egg_video" in seen_v)
        if "bus_easter_egg_video" in seen_v:
            egg = seen_v["bus_easter_egg_video"][0]
            check("vision: easter egg source is 'vision'",
                  egg.get("source") == "vision")
            check("vision: easter egg youtube_id present",
                  bool(egg.get("youtube_id")))

        # ── 2c. Imagine: "imagine a kitten", Echo floor (rickroll) ──
        print("\n== Imagine loop: 'imagine a kitten' (Echo floor) ==")
        await ws.send(json.dumps({"type": "voice_prompt",
                                  "text": "imagine a kitten wearing a hat",
                                  "nonce": "n1i"}))
        seen_i = await collect(ws, [
            "bus_intent_classified", "bus_query_result", "bus_easter_egg_video",
        ], timeout=8)
        if "bus_intent_classified" in seen_i:
            check("imagine: intent classified as 'imagine'",
                  seen_i["bus_intent_classified"][0].get("kind") == "imagine")
            check("imagine: prompt slot captured",
                  seen_i["bus_intent_classified"][0].get("slots", {}).get("prompt")
                  == "a kitten wearing a hat")
        check("imagine: query_result fired", "bus_query_result" in seen_i)
        check("imagine: easter_egg_video fired on floor (rickroll)",
              "bus_easter_egg_video" in seen_i)
        if "bus_easter_egg_video" in seen_i:
            egg = seen_i["bus_easter_egg_video"][0]
            check("imagine: easter egg source is 'imagine'",
                  egg.get("source") == "imagine")
            check("imagine: easter egg is the rickroll video",
                  egg.get("youtube_id") == "dQw4w9WgXcQ")
        # imagine_result must NOT fire on the floor path — a real image
        # only gets published when a real provider (not Echo) answers.
        check("imagine: imagine_result did NOT fire on floor path",
              "bus_imagine_result" not in seen_i)

    # ── 3. STOP STOP aborts active TTS ────────────────────────────
    # Re-connect for a fresh session, swap in a slow TTS provider
    async with websockets.connect(url) as ws:
        # Drain greeting
        await ws.recv(); await ws.recv()

        # Inject a slow TTS so we have time to STOP it
        from realm.engine_chain import TTSChain, TTSProvider
        import base64

        class SlowTTS(TTSProvider):
            name = "SlowTTS"
            async def is_available(self): return True
            async def synth(self, text):
                await asyncio.sleep(1.5)
                return base64.b64encode(b"slow").decode()

        app.state.orchestrator.tts = TTSChain([SlowTTS()])

        print("\n== STOP STOP: aborts slow TTS mid-synth ==")
        await ws.send(json.dumps({"type": "voice_prompt",
                                  "text": "what is happening",
                                  "nonce": "n2"}))
        # Wait until TTS has started
        started = False
        for _ in range(80):
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=0.1)
            except asyncio.TimeoutError:
                continue
            msg = json.loads(raw)
            if msg["type"] == "bus_tts_started":
                started = True
                break
        check("slow TTS started", started)

        # Fire STOP STOP
        await ws.send(json.dumps({"type": "voice_prompt",
                                  "text": "stop stop", "nonce": "n3"}))
        # Wait for tts_aborted
        aborted = False
        for _ in range(80):
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=0.1)
            except asyncio.TimeoutError:
                continue
            msg = json.loads(raw)
            if msg["type"] == "bus_tts_aborted":
                aborted = True
                break
        check("STOP STOP aborts TTS", aborted)

    # ── 4. HTTP surface ──────────────────────────────────────────
    import aiohttp
    print("\n== HTTP API surface ==")
    async with aiohttp.ClientSession() as s:
        async with s.get(f"http://127.0.0.1:{port}/api/config") as r:
            cfg_json = await r.json()
        check("/api/config returns frontend scope",
              "VoiceLoop" in cfg_json and "Branding" in cfg_json)
        leaked = any("api_key" in v for k, v in cfg_json.items()
                     if k in ("Claude", "OpenAITTS", "ElevenLabs", "Weather"))
        check("/api/config has NO secrets", not leaked)
        async with s.get(f"http://127.0.0.1:{port}/api/setup_status") as r:
            status = await r.json()
        check("/api/setup_status returns ready=true with echo providers",
              status.get("ready") is True)
        async with s.post(f"http://127.0.0.1:{port}/api/ask",
                          json={"text": "ping?"}) as r:
            ans = await r.json()
        check("/api/ask returns an answer",
              "answer" in ans and len(ans["answer"]) > 0)
        async with s.get(f"http://127.0.0.1:{port}/") as r:
            html = await r.text()
        check("/ serves the Star Trek UI", "Star Trek" in html or "Computer" in html)

    # ── 5. Per-device routing: two clients with distinct guids ──────
    # Regression test for "my phone's weather played on my desktop".
    # Each device passes ?user_guid=X in the URL; the realm must
    # route events to ONLY the requesting device.
    print("\n== Per-device routing isolation ==")
    url_alice = f"ws://127.0.0.1:{port}/ws?user_guid=alice-device-aaaa"
    url_bob   = f"ws://127.0.0.1:{port}/ws?user_guid=bob-device-bbbb"
    alice_ok = False
    isolation_ok = False
    try:
        async with websockets.connect(url_alice) as ws_alice, \
                   websockets.connect(url_bob) as ws_bob:
            # Drain greetings from both
            for ws in (ws_alice, ws_bob):
                for _ in range(2):
                    try:
                        await asyncio.wait_for(ws.recv(), timeout=2)
                    except Exception:
                        pass

            # Alice asks
            await ws_alice.send(json.dumps({
                "type": "voice_prompt", "text": "alice prompt",
                "nonce": "a1"}))

            # Collect everything for 2 seconds from BOTH sockets
            async def drain(ws, label, bucket, until):
                try:
                    while True:
                        remaining = until - asyncio.get_event_loop().time()
                        if remaining <= 0: break
                        raw = await asyncio.wait_for(ws.recv(),
                                                     timeout=remaining)
                        bucket.append((label, json.loads(raw)))
                except Exception:
                    pass

            bucket = []
            deadline = asyncio.get_event_loop().time() + 2.0
            await asyncio.gather(
                drain(ws_alice, "alice", bucket, deadline),
                drain(ws_bob,   "bob",   bucket, deadline))

            alice_msgs = [m for who, m in bucket if who == "alice"]
            bob_msgs   = [m for who, m in bucket if who == "bob"]

            alice_ok = any(m.get("type") == "bus_query_result"
                           for m in alice_msgs)
            # Bob must NOT see Alice's events
            isolation_ok = not any(
                m.get("type") in ("bus_query_result", "bus_tts_chunk",
                                  "bus_query_processing", "bus_tts_started")
                for m in bob_msgs)
    except Exception as e:
        # The bug we're testing for: when both clients share a guid, the
        # realm closes one of the sockets. If we hit ConnectionClosed here,
        # the realm is NOT respecting per-device identity.
        check(f"per-device connections stable (no force-close)", False,
              detail=str(e))
        check("Alice receives her own query result", False)
        check("Bob does NOT receive Alice's events "
              "(prevents phone→desktop leak)", False)
    else:
        check("per-device connections stable (no force-close)", True)
        check("Alice receives her own query result", alice_ok)
        check("Bob does NOT receive Alice's events "
              "(prevents phone→desktop leak)", isolation_ok)

    server.should_exit = True
    await server_task

    failed = [n for n, ok in results if not ok]
    print(f"\n{'='*60}\n{len(results) - len(failed)}/{len(results)} checks passed")
    if failed:
        print("FAILED:", *failed, sep="\n  - ")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
