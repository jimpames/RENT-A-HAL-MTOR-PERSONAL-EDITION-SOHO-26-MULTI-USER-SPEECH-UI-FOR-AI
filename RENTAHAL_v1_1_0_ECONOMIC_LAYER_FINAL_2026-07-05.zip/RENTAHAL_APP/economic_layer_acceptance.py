"""
economic_layer_acceptance.py — Sprint 15: the full acceptance ritual
for everything built in Sprints 10-14, mirroring smoke_test.py's own
style and spirit exactly (boot the REAL app, drive REAL HTTP calls,
report PASS/FAIL per check, exit non-zero on any failure).

    RENTAHAL_FAKE_ENGINES=1 python economic_layer_acceptance.py

Unlike smoke_test.py, this script's checks are genuinely OPT-IN at the
infrastructure level: if Postgres isn't reachable, every Postgres-
dependent section is SKIPPED (not failed) with a clear message, same
"opt-in, gracefully degrades" philosophy as every other piece of this
economic layer. Run with a real local Postgres (see README.md /
ECONOMIC_LAYER_DESIGN.md for setup) to actually exercise these checks.

Covers, in order:
  1. Proof-of-work gate (Sprint 10) — free tier, paid tier challenge,
     solving and resubmitting
  2. Ledger (Sprint 11) — append, verify_chain clean, tamper detection
  3. OpenTimestamps local verification (Sprint 12) — against the real,
     bundled, already-Bitcoin-anchored fixture (no live network needed
     for this part — see tests/fixtures/README.md for provenance)
  4. Billing (Sprint 13) — real webhook signature verification, real
     idempotent crediting, redelivery does not double-credit
  5. Orchestrator debit wiring (Sprint 13)
  6. Donor payout bilateral confirmation (Sprint 14) — matched claims
     credit, a lying unmatched claim does not
  7. Payout status endpoint (Sprint 15) — donor earnings visible via
     the same endpoint the cockpit polls

Real Stripe API calls (checkout session creation, Connect onboarding,
transfers) are NOT exercised here — same documented restriction as
every other network-dependent piece of this arc (see
ECONOMIC_LAYER_DESIGN.md's Sprint 12-14 notes for the specifics).
Everything here that CAN be real, is.
"""
import asyncio
import hashlib
import hmac
import json
import os
import sys
import time
import uuid
from pathlib import Path

os.environ.setdefault("RENTAHAL_FAKE_ENGINES", "1")
sys.path.insert(0, str(Path(__file__).resolve().parent))

PASS = "\033[92mPASS\033[0m"
SKIP = "\033[93mSKIP\033[0m"
FAILC = "\033[91mFAIL\033[0m"
results = []


def check(name, ok, detail="", skipped=False):
    results.append((name, "skip" if skipped else bool(ok)))
    icon = SKIP if skipped else (PASS if ok else FAILC)
    print(f"  [{icon}] {name}" + (f"  ({detail})" if detail and not ok else ""))


async def postgres_reachable(dsn: str) -> bool:
    try:
        import asyncpg
        conn = await asyncio.wait_for(asyncpg.connect(dsn), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


def sign_webhook(payload_bytes: bytes, secret: str) -> str:
    ts = int(time.time())
    signed_payload = f"{ts}.{payload_bytes.decode()}"
    sig = hmac.new(secret.encode(), signed_payload.encode(), hashlib.sha256).hexdigest()
    return f"t={ts},v1={sig}"


async def main() -> int:
    base_dsn = os.environ.get(
        "RENTAHAL_LEDGER_TEST_DSN",
        "postgresql://postgres:rentahal_test@localhost:5432/postgres")

    print("=" * 60)
    print("Economic Layer Acceptance Ritual (Sprints 10-15)")
    print("=" * 60)

    # ── 1. Proof-of-work gate (Sprint 10) ──────────────────────
    print("\n[1/7] Proof-of-work gate")
    try:
        from realm.pow_gate import PowGate, solve_challenge
        gate = PowGate(secret=b"acceptance-ritual-secret-32-bytes", enabled=True)
        r1 = gate.check("203.0.113.1", None)
        check("free tier serves without a challenge", r1.allowed)

        for _ in range(9):
            gate.check("203.0.113.1", None)
        r2 = gate.check("203.0.113.1", None)
        check("past free threshold issues a challenge",
             not r2.allowed and r2.response_body.get("error") == "proof_of_work_required")

        solution = solve_challenge(r2.response_body)
        r3 = gate.check("203.0.113.1", solution)
        check("solving the real puzzle is accepted", r3.allowed)
    except Exception as e:
        check("proof-of-work gate section", False, str(e))

    # ── 2. Ledger (Sprint 11) ──────────────────────────────────
    print("\n[2/7] Ledger — hash-chain integrity")
    pg_up = await postgres_reachable(base_dsn)
    ledger_dsn = None
    db_name = None
    if not pg_up:
        check("ledger append + verify_chain", False, skipped=True,
             detail="Postgres not reachable")
    else:
        try:
            import asyncpg
            from realm.ledger import Ledger
            db_name = f"rentahal_acceptance_{uuid.uuid4().hex[:12]}"
            admin_conn = await asyncpg.connect(base_dsn)
            await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
            await admin_conn.close()
            ledger_dsn = base_dsn.rsplit("/", 1)[0] + f"/{db_name}"

            ledger = await Ledger.connect(ledger_dsn)
            await ledger.append_entry("topup", "acceptance-user", 1_000_000,
                                      reference="evt_acceptance_1")
            result = await ledger.verify_chain()
            check("chain verifies clean after real appends", result.valid)

            raw_conn = await asyncpg.connect(ledger_dsn)
            await raw_conn.execute(
                "UPDATE ledger_entries SET amount_micros = 99999999 WHERE id = 1")
            await raw_conn.close()
            tampered = await ledger.verify_chain()
            check("tampering via raw SQL is detected", not tampered.valid)
            await ledger.close()
        except Exception as e:
            check("ledger section", False, str(e))

    # ── 3. OpenTimestamps local verification (Sprint 12) ───────
    print("\n[3/7] OpenTimestamps — local verification against real fixture")
    try:
        from realm.ots_anchor import deserialize, local_verify
        fixture_dir = Path(__file__).parent / "tests" / "fixtures"
        ots_bytes = (fixture_dir / "hello-world.txt.ots").read_bytes()
        original = (fixture_dir / "hello-world.txt").read_bytes()
        dts = deserialize(ots_bytes)
        digest = hashlib.sha256(original).digest()
        verify_result = local_verify(dts, digest)
        check("real Bitcoin-anchored proof verifies locally",
             verify_result.has_complete_attestation)
        block_heights = [a.bitcoin_block_height for a in verify_result.attestations
                        if a.kind == "bitcoin"]
        check("attests to the documented block (358391)",
             358391 in block_heights)
    except Exception as e:
        check("OpenTimestamps section", False, str(e))

    # ── 4-7: everything needing a booted app + Postgres + Stripe SDK ──
    if not pg_up:
        for label in ["Billing crediting + idempotency",
                     "Orchestrator debit wiring",
                     "Donor payout bilateral confirmation",
                     "Payout status endpoint"]:
            print(f"\n[.../7] {label}")
            check(label, False, skipped=True, detail="Postgres not reachable")
        return _print_summary()

    try:
        import stripe  # noqa: F401
        stripe_available = True
    except ImportError:
        for label in ["Billing crediting + idempotency",
                     "Donor payout bilateral confirmation",
                     "Payout status endpoint"]:
            print(f"\n[.../7] {label}")
            check(label, False, skipped=True, detail="stripe package not installed")
        stripe_available = False

    import aiohttp
    import uvicorn
    import app as app_module

    fed_ini = Path(f"/tmp/economic_acceptance_{uuid.uuid4().hex[:8]}.ini")
    webhook_secret = "whsec_acceptance_ritual"
    fed_ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = /tmp/economic_acceptance_state_{uuid.uuid4().hex[:8]}.json\n"
        f"[Ledger]\ndsn = {ledger_dsn}\n"
        + ("[Billing]\nstripe_secret_key = sk_test_fake\n"
           f"stripe_webhook_secret = {webhook_secret}\n"
           "price_per_submit_micros = 100\n"
           "low_balance_threshold_micros = 10000\n"
           "[Payout]\nstripe_secret_key = sk_test_fake\n"
           "conscription_payout_rate_micros = 80\n"
           if stripe_available else ""))
    cfg = app_module.load_ini()
    cfg.read(fed_ini)
    logger = app_module.setup_logging(cfg)
    realm_app = app_module.create_app(cfg, logger)

    server = uvicorn.Server(uvicorn.Config(
        realm_app, host="127.0.0.1", port=9990, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)

    try:
        async with aiohttp.ClientSession() as s:
            if stripe_available:
                print("\n[4/7] Billing — real webhook signature + idempotent crediting")
                payload = json.dumps({
                    "id": "evt_acceptance_ritual", "object": "event",
                    "api_version": "2024-06-20", "created": int(time.time()),
                    "type": "checkout.session.completed",
                    "data": {"object": {
                        "id": "cs_acceptance", "object": "checkout.session",
                        "client_reference_id": "acceptance-consumer",
                        "amount_total": 1000, "currency": "usd",
                        "metadata": {}}},
                }).encode()
                sig = sign_webhook(payload, webhook_secret)
                async with s.post("http://127.0.0.1:9990/api/billing/webhook",
                                  data=payload,
                                  headers={"Stripe-Signature": sig,
                                          "Content-Type": "application/json"}) as r:
                    body = await r.json()
                    check("real signed webhook credits the account",
                         r.status == 200 and body.get("credited") is True)

                async with s.post("http://127.0.0.1:9990/api/billing/webhook",
                                  data=payload,
                                  headers={"Stripe-Signature": sig,
                                          "Content-Type": "application/json"}) as r:
                    body = await r.json()
                    check("redelivery does not double-credit",
                         r.status == 200 and body.get("credited") is False
                         and body.get("duplicate") is True)

                async with s.get("http://127.0.0.1:9990/api/billing/balance",
                                 params={"account_id": "acceptance-consumer"}) as r:
                    bal = await r.json()
                    check("balance reflects exactly one credit",
                         bal["balance_micros"] == 10_000_000)

                print("\n[5/7] Orchestrator — /api/ask still works with billing configured")
                async with s.post("http://127.0.0.1:9990/api/ask",
                                  json={"text": "what is the realm"}) as r:
                    check("query succeeds with billing active", r.status == 200)

                print("\n[6/7] Donor payout — bilateral confirmation")
                now = time.time()
                async with s.post(
                        "http://127.0.0.1:9990/api/federate/conscription-claim",
                        json={"role": "requester", "donor_url": "https://acceptance-donor.example",
                             "requester_url": "https://acceptance-requester.example",
                             "rank": "chat", "claimed_at": now}) as r:
                    r1 = await r.json()
                    check("first claim (requester) does not match alone",
                         r1["matched"] is False)

                async with s.post(
                        "http://127.0.0.1:9990/api/federate/conscription-claim",
                        json={"role": "donor", "donor_url": "https://acceptance-donor.example",
                             "requester_url": "https://acceptance-requester.example",
                             "rank": "chat", "claimed_at": now + 3}) as r:
                    r2 = await r.json()
                    check("matching donor claim credits correctly",
                         r2["matched"] is True and r2["credited"] is True
                         and r2["credit_amount_micros"] == 80)

                async with s.post(
                        "http://127.0.0.1:9990/api/federate/conscription-claim",
                        json={"role": "donor", "donor_url": "https://lying-acceptance-donor.example",
                             "requester_url": "https://acceptance-victim.example",
                             "rank": "chat"}) as r:
                    r3 = await r.json()
                    check("unmatched (lying) claim is NOT credited",
                         r3["matched"] is False and r3["credited"] is False)

                print("\n[7/7] Payout status — cockpit visibility")
                async with s.get(
                        "http://127.0.0.1:9990/api/federate/payout/status",
                        params={"donor_url": "https://acceptance-donor.example"}) as r:
                    status = await r.json()
                    check("confirmed donor balance visible via status endpoint",
                         status["balance_micros"] == 80)
                async with s.get(
                        "http://127.0.0.1:9990/api/federate/payout/status",
                        params={"donor_url": "https://lying-acceptance-donor.example"}) as r:
                    status2 = await r.json()
                    check("lying donor's balance correctly shows zero",
                         status2["balance_micros"] == 0)
    finally:
        server.should_exit = True
        await task
        fed_ini.unlink(missing_ok=True)
        if db_name:
            try:
                import asyncpg
                admin_conn = await asyncpg.connect(base_dsn)
                await admin_conn.execute(
                    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                    "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
                await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
                await admin_conn.close()
            except Exception:
                pass

    return _print_summary()


def _print_summary() -> int:
    passed = sum(1 for _, ok in results if ok is True)
    skipped = sum(1 for _, ok in results if ok == "skip")
    failed = [name for name, ok in results if ok is False]
    total = len(results)
    print("\n" + "=" * 60)
    print(f"{passed}/{total} checks passed, {skipped} skipped"
         + (f", {len(failed)} FAILED" if failed else ""))
    if failed:
        print("FAILED:", *failed, sep="\n  - ")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
