Twenty-some years ago I was a kid watching Star Trek, wishing I could just talk to a computer and have it understand me — see what I see, answer what I ask, help with what I need. I never stopped wanting that. I just eventually decided to build it myself.

I'm proud to introduce RENT-A-HAL — a local, multi-user, federated AI voice realm you run on your own hardware.

**What it is**

RENT-A-HAL is a voice-first AI system: say "Computer," ask anything, get an answer — spoken back to you in real time. It listens, sees, and creates, all through one interface, all running on a single consumer GPU:

• Chat — natural conversation, powered by a local LLM
• Vision — show it something through your webcam and ask what it sees
• Imagine — describe an image and watch it generate one, live

No cloud dependency required. No data leaving your building unless you choose to let it.

**Why it's built the way it is**

Every mode runs through the same conversation, the same interface, at the same time — because a voice assistant shouldn't force you to think in terms of "modes" at all. Ask a question, glance at your camera, generate an image, ask a follow-up — it's one continuous exchange, not three separate tools bolted together.

And it's built to degrade honestly. If a model isn't loaded, RENT-A-HAL tells you plainly rather than pretending or breaking — and it never sends your voice, your camera, or your questions anywhere you haven't explicitly chosen to send them.

**Who it's for**

- **MSPs** can deploy RENT-A-HAL as a fleet — an "AI array" — across client sites, with realms able to share overflow compute with each other on your own private federation network. One client's idle GPU cycles can quietly help another's busy hour.
- **Schools** get a genuinely local AI assistant — nothing about a student's question needs to leave the building to get an answer.
- **Law firms and medical practices** get the same thing for client and patient conversations: local processing, on hardware you control, for work where confidentiality isn't optional.
- **Anyone running their own AI on their own terms** — hobbyists, small businesses, labs — gets a real, working, multi-modal voice assistant without renting someone else's cloud by the token.

**How it works, briefly**

RENT-A-HAL runs entirely on local, open models — GPT4All for language, LLaVA for vision, Automatic1111 for image generation, Kokoro for speech — orchestrated through a single realm that any number of users on a LAN (or beyond, if you choose) can talk to at once, each kept cleanly isolated from the others. Realms can optionally federate with each other, sharing capacity when one is busy and another is idle, and — for anyone who wants to build a real business on this — there's a full economic layer underneath: tamper-evident usage accounting, consumer billing, and payouts for realms that lend their spare capacity to the network.

All of it opt-in. All of it off by default. A realm that never touches federation or billing runs exactly like a simple, private, standalone assistant — because that's what most people actually want first.

RENT-A-HAL is a project of N2NHU Lab for Applied AI, built by me with Claude (Anthropic) as a genuine engineering partner throughout — sprint by sprint, feature by feature, real hardware testing the whole way. It's free, and it's yours to run.

Bringing the future to the present.

#AI #LocalAI #VoiceAI #OpenSource #MSP #EdTech #LegalTech #HealthTech #PrivacyFirst #RENTAHAL
