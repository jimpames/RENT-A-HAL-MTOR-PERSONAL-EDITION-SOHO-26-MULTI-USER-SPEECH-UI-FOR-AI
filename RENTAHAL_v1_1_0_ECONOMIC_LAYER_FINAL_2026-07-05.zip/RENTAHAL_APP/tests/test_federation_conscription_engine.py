"""
Sprint 8 tests — the Federator-side conscription decision engine.

This is where conscription stops being inert. Covers:

  MemberRecord.node_type / conscription_max_minutes
    - node_type stored, backward-compat default "chat" for old records
    - to_dict always includes node_type (not sparse); conscription_max_
      minutes IS sparse (only written when reported)
    - from_dict round-trips both, tolerates malformed conscription_max_minutes

  FederationMatrix.upsert — node_type/conscription_max_minutes wiring
    - stored and overwritten every check-in
    - not passing conscription_max_minutes resets it to None (donor
      that stops reporting a preference falls back to Federator default,
      rather than being stuck with a stale one forever)

  FederationMatrix._select_conscription_donor_unsafe (via public wrapper
  tests calling maybe_assign_conscription, which exercises it internally)
    - excludes members native to the rank (not a "conscript" at all)
    - excludes members who haven't reported eligibility for the rank
    - excludes dead members
    - excludes members too busy at their own native duty
    - picks the MOST IDLE among qualifying donors, not the fastest-ever
    - excludes the requester itself

  FederationMatrix.maybe_assign_conscription — full decision lifecycle
    - no contract when native capacity is fine (below trigger)
    - no contract when native capacity is bad but no donor qualifies
    - contract assigned when native capacity bad AND donor available
    - existing live contract returned unchanged (no reassignment thrash)
    - expired contract cleared and re-evaluated from scratch
    - contract length = min(Federator default, donor's own preference)
    - conscription_enabled=False always returns None regardless of
      everything else
    - unknown/no native peers at all for a rank is treated as "under
      strain" (DEGRADED sentinel), not as "no problem"

  Wire protocol (checkin endpoint via real HTTP, mirroring Sprints 6/7's
  integration-check style)
    - node_type is now actually stored (the gap this sprint closes)
    - conscription contract appears in the response when warranted
    - conscription is null when not warranted
    - FederationClient stores state.conscription from the response
"""
import sys
import time
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import (
    FederationMatrix, FederationConfig, FederationState, FederationClient,
    MemberRecord, DEGRADED_AVG_S, RANK_TO_CAPABILITY_KIND, CONSCRIPTION_RANKS,
)

pytestmark = pytest.mark.asyncio


# ─── MemberRecord.node_type / conscription_max_minutes ──────────────

def test_node_type_defaults_to_chat():
    rec = MemberRecord(url="https://a.com")
    assert rec.node_type == "chat"


def test_to_dict_always_includes_node_type():
    rec = MemberRecord(url="https://a.com", node_type="vision")
    d = rec.to_dict()
    assert d["node_type"] == "vision"


def test_from_dict_missing_node_type_defaults_chat():
    """Old-format record from before this field existed."""
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 0, "last_seen": 1.0}
    rec = MemberRecord.from_dict(d)
    assert rec.node_type == "chat"


def test_from_dict_round_trips_node_type():
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 0, "last_seen": 1.0, "node_type": "imagine"}
    rec = MemberRecord.from_dict(d)
    assert rec.node_type == "imagine"


def test_conscription_max_minutes_defaults_none():
    rec = MemberRecord(url="https://a.com")
    assert rec.conscription_max_minutes is None


def test_to_dict_omits_conscription_max_minutes_when_none():
    rec = MemberRecord(url="https://a.com")
    d = rec.to_dict()
    assert "conscription_max_minutes" not in d


def test_to_dict_includes_conscription_max_minutes_when_set():
    rec = MemberRecord(url="https://a.com", conscription_max_minutes=10.0)
    d = rec.to_dict()
    assert d["conscription_max_minutes"] == 10.0


def test_from_dict_round_trips_conscription_max_minutes():
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 0, "last_seen": 1.0, "conscription_max_minutes": 5.0}
    rec = MemberRecord.from_dict(d)
    assert rec.conscription_max_minutes == 5.0


def test_from_dict_malformed_conscription_max_minutes_defaults_none():
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 0, "last_seen": 1.0, "conscription_max_minutes": "garbage"}
    rec = MemberRecord.from_dict(d)
    assert rec.conscription_max_minutes is None


def test_rank_to_capability_kind_mapping():
    assert RANK_TO_CAPABILITY_KIND == {"chat": "llm", "vision": "vision",
                                       "imagine": "imagine"}


# ─── upsert — node_type / conscription_max_minutes wiring ───────────

async def test_upsert_stores_node_type():
    m = FederationMatrix(missed_after_s=60.0)
    rec = await m.upsert("https://a.com", 2.0, 1.0, 0, node_type="vision")
    assert rec.node_type == "vision"


async def test_upsert_default_node_type_is_chat():
    m = FederationMatrix(missed_after_s=60.0)
    rec = await m.upsert("https://a.com", 2.0, 1.0, 0)
    assert rec.node_type == "chat"


async def test_upsert_stores_conscription_max_minutes():
    m = FederationMatrix(missed_after_s=60.0)
    rec = await m.upsert("https://a.com", 2.0, 1.0, 0,
                         conscription_max_minutes=7.5)
    assert rec.conscription_max_minutes == 7.5


async def test_upsert_not_passing_conscription_max_minutes_resets_to_none():
    """A donor that stops reporting a preference falls back to the
    Federator's default ceiling — it must NOT be stuck with a stale
    preference forever."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 2.0, 1.0, 0, conscription_max_minutes=5.0)
    rec = await m.upsert("https://a.com", 2.0, 1.0, 0)   # no ranks/minutes this time
    assert rec.conscription_max_minutes is None


# ─── Helpers for decision-engine tests ───────────────────────────────

async def _seed(m: FederationMatrix, url: str, node_type: str,
                native_avg: float, eligible_ranks=None, max_minutes=None,
                stale=False):
    """Seed a member with a given native-duty avg. native_avg is
    interpreted per node_type via RANK_TO_CAPABILITY_KIND — for a chat
    node this sets llm_avg_s, for vision/imagine it sets
    capability_avg_s[node_type]."""
    kind = RANK_TO_CAPABILITY_KIND.get(node_type, "llm")
    if kind == "llm":
        rec = await m.upsert(url, native_avg, 1.0, 0,
                             node_type=node_type,
                             conscription_eligible_ranks=eligible_ranks,
                             conscription_max_minutes=max_minutes)
    else:
        rec = await m.upsert(url, 1.0, 1.0, 0,
                             capability_avg_s={kind: native_avg},
                             node_type=node_type,
                             conscription_eligible_ranks=eligible_ranks,
                             conscription_max_minutes=max_minutes)
    if stale:
        rec.last_seen = time.monotonic() - 9999
    return rec


def _matrix(**kw):
    defaults = dict(missed_after_s=60.0, conscription_enabled=True,
                    conscription_trigger_avg_s=10.0,
                    conscription_idle_avg_s=2.0,
                    default_conscription_max_minutes=15.0,
                    max_donors_per_rank=2)
    defaults.update(kw)
    return FederationMatrix(**defaults)


# ─── Donor selection (exercised via maybe_assign_conscription) ──────

async def test_donor_must_not_be_native_to_the_rank():
    m = _matrix()
    # A chat-native node with a great avg must NOT be picked as a
    # "donor" for chat — it's just... a normal chat node.
    await _seed(m, "https://chat-native.example", "chat", 0.1)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)   # triggers demand
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert contracts == []    # only chat-native members exist, no real donor


async def test_donor_must_have_reported_eligibility():
    m = _matrix()
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    # Vision node is idle but has NOT reported chat eligibility
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=[])
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert contracts == []


async def test_donor_must_be_alive():
    m = _matrix()
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-stale.example", "vision", 0.1,
               eligible_ranks=["chat"], stale=True)
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert contracts == []


async def test_donor_must_not_be_too_busy_at_own_job():
    m = _matrix(conscription_idle_avg_s=2.0)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    # Vision node reports eligibility but is itself SLOW at vision (5.0
    # > idle threshold 2.0) — not actually idle, must be excluded.
    await _seed(m, "https://vision-busy.example", "vision", 5.0,
               eligible_ranks=["chat"])
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert contracts == []


async def test_donor_excludes_the_requester_itself():
    m = _matrix()
    # A single member that's both the requester AND (hypothetically)
    # eligible — must never conscript itself into its own overflow.
    await _seed(m, "https://only-member.example", "vision", 0.1,
               eligible_ranks=["chat"])
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://only-member.example")
    assert contracts == []    # no OTHER candidate exists


async def test_donor_picked_when_all_conditions_met():
    m = _matrix()
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"])
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert len(contracts) == 1
    assert contracts[0]["peer_url"] == "https://vision-idle.example"
    assert contracts[0]["native_role"] == "vision"
    assert contracts[0]["conscripted_as"] == "chat"


async def test_donor_selection_picks_most_idle_among_qualifiers():
    m = _matrix()
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-somewhat-idle.example", "vision", 1.5,
               eligible_ranks=["chat"])
    await _seed(m, "https://imagine-very-idle.example", "imagine", 0.2,
               eligible_ranks=["chat"])
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert len(contracts) == 1
    assert contracts[0]["peer_url"] == "https://imagine-very-idle.example"


# ─── Full decision lifecycle ─────────────────────────────────────────

async def test_no_contract_when_native_capacity_is_fine():
    m = _matrix(conscription_trigger_avg_s=10.0)
    await _seed(m, "https://chat-fast.example", "chat", 1.0)   # well under trigger
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"])
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-fast.example")
    assert contracts == []


async def test_no_native_peers_at_all_is_treated_as_under_strain():
    """Zero chat-native members at all -> DEGRADED sentinel -> treated
    as maximally under strain, not as 'no data, assume fine'."""
    m = _matrix()
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"])
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://someone-else.example")
    assert len(contracts) == 1
    assert contracts[0]["peer_url"] == "https://vision-idle.example"


async def test_conscription_enabled_false_always_returns_none():
    m = _matrix(conscription_enabled=False)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"])
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert contracts == []


async def test_existing_live_contract_returned_unchanged():
    m = _matrix(max_donors_per_rank=1)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"])
    first = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    # A second, faster donor shows up — must NOT displace the existing
    # live contract (no reassignment thrash every check-in cycle). With
    # max_donors_per_rank=1, the cap also prevents ADDING it as a
    # second simultaneous donor.
    await _seed(m, "https://imagine-super-idle.example", "imagine", 0.01,
               eligible_ranks=["chat"])
    second = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert second == first
    assert len(second) == 1
    assert second[0]["peer_url"] == "https://vision-idle.example"


async def test_second_donor_added_when_demand_persists_and_cap_allows():
    """The actual multi-donor behavior: with room under the cap, a
    SECOND donor gets added on a later call while the rank is still
    under strain — incrementally, not both at once."""
    m = _matrix(max_donors_per_rank=2)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"])
    first = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert len(first) == 1

    await _seed(m, "https://imagine-idle.example", "imagine", 0.05,
               eligible_ranks=["chat"])
    second = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert len(second) == 2
    urls = {c["peer_url"] for c in second}
    assert urls == {"https://vision-idle.example", "https://imagine-idle.example"}


async def test_donor_cap_prevents_a_third_donor():
    m = _matrix(max_donors_per_rank=2)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    await _seed(m, "https://imagine-idle.example", "imagine", 0.05,
               eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")

    # A third qualifying donor appears, but the cap is already reached.
    await _seed(m, "https://another-vision.example", "vision", 0.02,
               eligible_ranks=["chat"])
    third = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert len(third) == 2   # unchanged — cap held


async def test_second_donor_selection_excludes_the_first_donor():
    """When looking for an ADDITIONAL donor, the one already contracted
    for this rank must not be re-selected as if it were a fresh
    candidate."""
    m = _matrix(max_donors_per_rank=2)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.05,
               eligible_ranks=["chat"])   # the most idle candidate
    first = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert first[0]["peer_url"] == "https://vision-idle.example"

    # No OTHER donor exists yet — the second call must not just
    # re-return the same one as a "new" addition.
    second = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert len(second) == 1   # still just the one; nobody else qualifies


async def test_expired_contract_is_cleared_and_reevaluated():
    m = _matrix(default_conscription_max_minutes=15.0)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"])
    first = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert first[0]["peer_url"] == "https://vision-idle.example"
    # Force the contract into the past.
    m.active_contracts["chat"][0]["expires_at"] = time.monotonic() - 1
    # A different, now better-qualified donor is available.
    await _seed(m, "https://imagine-idle.example", "imagine", 0.01,
               eligible_ranks=["chat"])
    second = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    assert len(second) == 1
    assert second[0]["peer_url"] == "https://imagine-idle.example"


async def test_contract_length_uses_federator_default_when_donor_silent():
    m = _matrix(default_conscription_max_minutes=15.0)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"], max_minutes=None)
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    contract = contracts[0]
    expected_expiry = contract["assigned_at"] + 15.0 * 60.0
    assert contract["expires_at"] == pytest.approx(expected_expiry)


async def test_contract_length_respects_donors_shorter_preference():
    m = _matrix(default_conscription_max_minutes=15.0)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"], max_minutes=5.0)   # donor wants shorter
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    contract = contracts[0]
    expected_expiry = contract["assigned_at"] + 5.0 * 60.0
    assert contract["expires_at"] == pytest.approx(expected_expiry)


async def test_contract_length_donor_longer_preference_capped_by_federator():
    """A donor CANNOT get a longer contract than the Federator allows,
    even if it would be willing to."""
    m = _matrix(default_conscription_max_minutes=10.0)
    await _seed(m, "https://chat-slow.example", "chat", 20.0)
    await _seed(m, "https://vision-idle.example", "vision", 0.1,
               eligible_ranks=["chat"], max_minutes=30.0)   # donor OK with longer
    contracts = await m.maybe_assign_conscription(
        "chat", requester_url="https://chat-slow.example")
    contract = contracts[0]
    expected_expiry = contract["assigned_at"] + 10.0 * 60.0   # federator ceiling wins
    assert contract["expires_at"] == pytest.approx(expected_expiry)


async def test_conscription_ranks_vocabulary_matches_rank_to_capability_kind():
    assert set(CONSCRIPTION_RANKS) == set(RANK_TO_CAPABILITY_KIND.keys())


# ─── Wire protocol integration (real app boot, real HTTP) ───────────

async def _boot_federator(tmp_path, ini_overrides: str = ""):
    import os
    os.environ["RENTAHAL_FAKE_ENGINES"] = "1"
    import app as app_module
    cfg = app_module.load_ini()
    fed_ini = tmp_path / "federator.ini"
    fed_ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n{ini_overrides}\n")
    cfg.read(fed_ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


async def test_checkin_endpoint_actually_stores_node_type(tmp_path):
    """THE gap this sprint closes: node_type was sent since Sprint 6
    but never stored. Confirm it's stored now, via real HTTP."""
    import asyncio, uvicorn, aiohttp
    app = await _boot_federator(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9944, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9944/api/federate/checkin", json={
                "member_url": "https://vision-box.example", "llm_avg_s": 5.0,
                "tts_avg_s": 1.0, "tokens_out": 0, "node_type": "vision"}) as r:
                data = await r.json()
                assert "conscription" in data
                assert data["conscription"] is None   # vision node, no demand data
            async with s.get("http://127.0.0.1:9944/api/federate/matrix") as r:
                matrix = await r.json()
                assert matrix["members"]["https://vision-box.example"]["node_type"] == "vision"
    finally:
        server.should_exit = True
        await task


async def test_checkin_endpoint_assigns_real_contract_over_http(tmp_path):
    import asyncio, uvicorn, aiohttp
    app = await _boot_federator(
        tmp_path,
        "conscription_trigger_avg_s = 10.0\nconscription_idle_avg_s = 2.0\n")
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9945, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            # Idle vision donor checks in first, opted in.
            await s.post("http://127.0.0.1:9945/api/federate/checkin", json={
                "member_url": "https://vision-donor.example", "llm_avg_s": 1.0,
                "tts_avg_s": 1.0, "tokens_out": 0, "node_type": "vision",
                "capability_avg_s": {"vision": 0.1},   # its own native duty is idle
                "conscription_eligible_ranks": ["chat"],
                "conscription_max_minutes": 5.0})
            # Struggling chat node checks in and should get a contract.
            async with s.post("http://127.0.0.1:9945/api/federate/checkin", json={
                "member_url": "https://chat-struggling.example",
                "llm_avg_s": 25.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "chat"}) as r:
                data = await r.json()
                assert data["conscription"] is not None
                assert data["conscription"]["peer_url"] == "https://vision-donor.example"
                assert data["conscription"]["conscripted_as"] == "chat"
    finally:
        server.should_exit = True
        await task


# ─── FederationClient stores the contract from the response ────────

class _MockResp:
    def __init__(self, body, status=200):
        self._body = body
        self.status = status
    async def json(self):
        return self._body
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass


async def test_client_stores_conscription_contract_from_response():
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    client = FederationClient(state)

    def mock_post(url, json=None):
        return _MockResp({
            "best_llm_peer": None, "best_tts_peer": None,
            "conscription": {"peer_url": "https://donor.example",
                             "native_role": "vision", "conscripted_as": "chat"},
        })
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()
    assert state.conscription == {"peer_url": "https://donor.example",
                                  "native_role": "vision",
                                  "conscripted_as": "chat"}


async def test_client_conscription_none_when_response_has_no_contract():
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    client = FederationClient(state)

    def mock_post(url, json=None):
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None,
                          "conscription": None})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()
    assert state.conscription is None


async def test_client_conscription_none_when_key_absent_entirely():
    """A pre-Sprint-8 Federator's response has no 'conscription' key."""
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    client = FederationClient(state)

    def mock_post(url, json=None):
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()
    assert state.conscription is None


async def test_to_ui_dict_includes_conscription():
    cfg = FederationConfig(desire=True)
    state = FederationState(cfg, lambda: {})
    state.conscription = {"peer_url": "https://d.example", "conscripted_as": "chat"}
    d = state.to_ui_dict()
    assert d["conscription"] == {"peer_url": "https://d.example",
                                 "conscripted_as": "chat"}
