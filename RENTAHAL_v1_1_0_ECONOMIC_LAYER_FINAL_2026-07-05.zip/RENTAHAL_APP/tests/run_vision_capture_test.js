// run_vision_capture_test.js — regression tests for the vision webcam
// capture-before-send path.
//
// Architecture invariants this test LOCKS IN:
//   - VISION_TRIGGERS is a client-side heuristic check, mirroring the
//     phrases in intent.py's PHRASE_INTENTS table (must match exactly
//     the six vision phrases, or a future intent.py edit could silently
//     desync from this file)
//   - sendPrompt() captures a webcam frame BEFORE sending when the
//     trigger matches — same pattern as SERVICE_TRIGGERS + ensureLocation
//   - Capture failure (permission denied, no camera) does NOT block the
//     send — it sends without image_b64, letting the server-side
//     handler answer with a friendly apology (fail open, not fail closed)
//   - captureWebcamFrame() releases the camera immediately after
//     grabbing one frame — not a live stream
//   - image_b64 only gets attached to the outgoing message when present

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── VISION_TRIGGERS matches intent.py's PHRASE_INTENTS exactly ────

const triggersMatch = html.match(/const VISION_TRIGGERS =\s*\n?\s*(\/.+?\/i);/s);
assert(triggersMatch, 'VISION_TRIGGERS regex constant found');

const VISION_PHRASES = [
  'what do you see', 'what can you see', 'can you see',
  'take a look', 'look at this', 'look at that',
];
if (triggersMatch) {
  // Reconstruct the regex from source and test each phrase actually
  // matches — proves the constant is functionally correct, not just
  // present.
  let re;
  try {
    // eslint-disable-next-line no-eval
    re = eval(triggersMatch[1]);
  } catch (e) {
    re = null;
  }
  assert(re !== null, 'VISION_TRIGGERS regex is syntactically valid');
  if (re) {
    for (const phrase of VISION_PHRASES) {
      assert(re.test(phrase),
             `VISION_TRIGGERS matches "${phrase}"`,
             'must stay in sync with intent.py PHRASE_INTENTS');
    }
    // False-positive guard — same phrases intent.py's own test file
    // (test_vision_intent.py) locks in on the server side.
    assert(!re.test('look up the weather'),
           'VISION_TRIGGERS does NOT match "look up the weather"');
    assert(!re.test('look for a pharmacy'),
           'VISION_TRIGGERS does NOT match "look for a pharmacy"');
  }
}

// ─── sendPrompt() wiring ─────────────────────────────────────────

const sendPromptIdx = html.indexOf('function sendPrompt(text)');
const actuallySendIdx = html.indexOf('function _actuallySendPrompt(');
assert(sendPromptIdx > 0 && actuallySendIdx > sendPromptIdx,
       'sendPrompt found before _actuallySendPrompt');
const sendPromptSrc = (sendPromptIdx > 0 && actuallySendIdx > sendPromptIdx)
  ? html.slice(sendPromptIdx, actuallySendIdx) : '';

assert(sendPromptSrc.includes('VISION_TRIGGERS.test(trimmed)'),
       'sendPrompt checks VISION_TRIGGERS before sending');
assert(sendPromptSrc.includes('captureWebcamFrame()'),
       'sendPrompt calls captureWebcamFrame() on a vision-trigger match');
assert(/captureWebcamFrame\(\)\s*\n?\s*\.then\(imageB64 => _actuallySendPrompt\(trimmed, imageB64\)\)/.test(sendPromptSrc),
       'successful capture is passed through to _actuallySendPrompt');
assert(/\.catch\(e => \{[\s\S]*?_actuallySendPrompt\(trimmed, null\)/.test(sendPromptSrc),
       'capture failure still sends the prompt (fail open, image_b64=null)');

// ─── _actuallySendPrompt only attaches image_b64 when present ──────

const actuallySendEndIdx = html.indexOf('\n}', actuallySendIdx);
const actuallySendSrc = html.slice(actuallySendIdx, actuallySendEndIdx + 2);
assert(/if \(imageB64\) msg\.image_b64 = imageB64;/.test(actuallySendSrc),
       '_actuallySendPrompt only sets image_b64 when truthy '
       + '(no image_b64:null spam on every non-vision prompt)');

// ─── captureWebcamFrame() implementation ────────────────────────

const captureIdx = html.indexOf('function captureWebcamFrame()');
assert(captureIdx > 0, 'captureWebcamFrame function found');
const captureSrc = captureIdx > 0
  ? html.slice(captureIdx, html.indexOf('\n}', captureIdx + 2000) + 2)
  : '';

if (captureIdx > 0) {
  assert(/getUserMedia\(\{ video: \{ facingMode: 'user' \} \}\)/.test(captureSrc),
         'requests front-facing camera via getUserMedia');
  assert(/stream\.getTracks\(\)\.forEach\(t => t\.stop\(\)\)/.test(captureSrc),
         'releases the camera immediately after capture (not a live stream)');
  assert(/canvas\.toDataURL\('image\/jpeg'/.test(captureSrc),
         'captures a single frame as JPEG (compact for the websocket)');
  assert(/dataUrl\.split\(','\)\[1\]/.test(captureSrc),
         'strips the data: URL prefix before resolving (raw base64 only)');
  assert(/if \(!navigator\.mediaDevices \|\| !navigator\.mediaDevices\.getUserMedia\)/.test(captureSrc),
         'gracefully rejects when getUserMedia is unsupported (older browsers)');
}

// ─── Server side accepts it (websocket message shape) ──────────────
// Not this file's job to verify app.py, but a quick sanity check that
// the field name matches exactly what the backend expects (Sprint 4).

assert(/msg\.image_b64 = imageB64/.test(html) || /image_b64:/.test(html),
       'outgoing message field is named image_b64 (matches app.py websocket handler)');

// ─── Summary ─────────────────────────────────────────────────

if (failCount > 0) {
  console.log(`\nFAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`\nOK: ${passCount} vision capture tests passed`);
}
