"""
Loose-end fix — /api/ask now supports the 'imagine' intent, text-only.
Flagged as a gap back in Sprint 4/9 (weather was the only special-cased
intent; music/service/news/roundup/vision/imagine all fell through to
plain LLM generate). imagine is easy to add since its prompt lives
entirely in intent.slots — no image needed, unlike vision.
"""
import asyncio
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

os.environ["RENTAHAL_FAKE_ENGINES"] = "1"


async def _boot(tmp_path):
    import app as app_module
    cfg = app_module.load_ini()
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


@pytest.mark.asyncio
async def test_api_ask_imagine_returns_text_answer(tmp_path):
    import uvicorn, aiohttp
    app = await _boot(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9948, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9948/api/ask", json={
                "text": "imagine a kitten wearing a hat"}) as r:
                assert r.status == 200
                data = await r.json()
                assert data["intent"] == "imagine"
                # Echo floor (FAKE_ENGINES) — floor text, no crash.
                assert isinstance(data["answer"], str)
                assert len(data["answer"]) > 0
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_api_ask_weather_still_works_unaffected(tmp_path):
    """Sanity check: adding the imagine branch didn't disturb the
    existing weather special-case."""
    import uvicorn, aiohttp
    app = await _boot(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9949, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9949/api/ask", json={
                "text": "weather in Boston"}) as r:
                assert r.status == 200
                data = await r.json()
                assert data["intent"] == "weather"
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_api_ask_plain_question_still_falls_through_to_llm(tmp_path):
    import uvicorn, aiohttp
    app = await _boot(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9950, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9950/api/ask", json={
                "text": "what is the capital of France"}) as r:
                assert r.status == 200
                data = await r.json()
                assert data["intent"] == "ask"
    finally:
        server.should_exit = True
        await task
