"""
test_chain_probe.py — LLMChain.probe_local and TTSChain.probe_local.

These methods give federation providers a "second chance for local"
right before they commit to a federated call. Critical to making
peering rock solid against the race where rolling avg stays elevated
from recent federated calls even after local recovered.

Both methods:
  - Skip federation providers (they wrap peers, not local)
  - LLM: also skip echo (offline fallback, not real LLM)
  - Return the first local provider that reports is_available
  - Return None if no local is available
  - Tolerate exceptions in is_available — log + continue, don't crash
"""
import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ─── Helpers ───────────────────────────────────────────────────────


def _make_provider(name, available, raises=None):
    """Returns a mock provider for chain testing."""
    p = MagicMock()
    p.name = name
    if raises is not None:
        p.is_available = AsyncMock(side_effect=raises)
    else:
        p.is_available = AsyncMock(return_value=available)
    return p


# ─── LLMChain.probe_local ──────────────────────────────────────────


@pytest.mark.asyncio
async def test_llm_probe_returns_first_available_local():
    """Skip federation providers, return the first local one that's up."""
    from realm.engine_chain import LLMChain
    chain = LLMChain([
        _make_provider("Federation (peer realms)", True),       # skip
        _make_provider("GPT4All (Llama 3 8B Instruct)", True),  # win
        _make_provider("Claude", True),                         # not reached
    ])
    result = await chain.probe_local()
    assert result is not None
    assert result.name == "GPT4All (Llama 3 8B Instruct)"


@pytest.mark.asyncio
async def test_llm_probe_skips_federation_head_and_tail():
    """Both federation provider variants must be skipped."""
    from realm.engine_chain import LLMChain
    chain = LLMChain([
        _make_provider("Federation (peer realms)", True),         # skip head
        _make_provider("Federation Fallback (peer realms)", True),# skip tail
        _make_provider("GPT4All", True),                          # win
    ])
    result = await chain.probe_local()
    assert result.name == "GPT4All"


@pytest.mark.asyncio
async def test_llm_probe_skips_echo():
    """Echo is the offline fallback floor — not a real LLM. Must skip."""
    from realm.engine_chain import LLMChain
    chain = LLMChain([
        _make_provider("Federation (peer realms)", True),
        _make_provider("Echo (offline fallback)", True),    # skip
        _make_provider("GPT4All", True),                    # win
    ])
    result = await chain.probe_local()
    assert result.name == "GPT4All"


@pytest.mark.asyncio
async def test_llm_probe_returns_none_when_all_local_dead():
    """Federation + Echo around dead locals → None.
    Caller (federation provider) treats None as 'no local available',
    proceeds with federated call as designed."""
    from realm.engine_chain import LLMChain
    chain = LLMChain([
        _make_provider("Federation (peer realms)", True),
        _make_provider("GPT4All", False),     # dead
        _make_provider("Claude", False),      # no key
        _make_provider("Echo (offline fallback)", True),  # skip
    ])
    result = await chain.probe_local()
    assert result is None


@pytest.mark.asyncio
async def test_llm_probe_tolerates_is_available_exceptions():
    """If a provider's is_available raises (e.g. network blip), skip it
    rather than crashing the probe. Other providers might still answer."""
    from realm.engine_chain import LLMChain
    chain = LLMChain([
        _make_provider("GPT4All", None, raises=ConnectionError("blip")),
        _make_provider("Claude", True),
    ])
    result = await chain.probe_local()
    assert result is not None
    assert result.name == "Claude"


@pytest.mark.asyncio
async def test_llm_probe_empty_chain_returns_none():
    """No providers at all → None. Edge case but cheap to guard."""
    from realm.engine_chain import LLMChain
    chain = LLMChain([])
    result = await chain.probe_local()
    assert result is None


@pytest.mark.asyncio
async def test_llm_probe_only_federation_returns_none():
    """Chain with only federation providers (no locals to probe) → None."""
    from realm.engine_chain import LLMChain
    chain = LLMChain([
        _make_provider("Federation (peer realms)", True),
        _make_provider("Federation Fallback (peer realms)", True),
    ])
    result = await chain.probe_local()
    assert result is None


# ─── TTSChain.probe_local ──────────────────────────────────────────


@pytest.mark.asyncio
async def test_tts_probe_returns_first_available_local():
    from realm.engine_chain import TTSChain
    chain = TTSChain([
        _make_provider("Federation TTS (peer realms)", True),       # skip
        _make_provider("Kokoro Service (localhost:9998)", True),    # win
        _make_provider("pyttsx3", True),                            # not reached
    ])
    result = await chain.probe_local()
    assert result.name == "Kokoro Service (localhost:9998)"


@pytest.mark.asyncio
async def test_tts_probe_skips_federation_head_and_tail():
    from realm.engine_chain import TTSChain
    chain = TTSChain([
        _make_provider("Federation TTS (peer realms)", True),
        _make_provider("Federation TTS Fallback (peer realms)", True),
        _make_provider("Kokoro Service", True),
    ])
    result = await chain.probe_local()
    assert result.name == "Kokoro Service"


@pytest.mark.asyncio
async def test_tts_probe_returns_none_when_all_locals_dead():
    """No Echo TTS equivalent — pyttsx3 is the local floor. When even
    that's dead, probe returns None."""
    from realm.engine_chain import TTSChain
    chain = TTSChain([
        _make_provider("Federation TTS (peer realms)", True),
        _make_provider("Kokoro", False),
        _make_provider("pyttsx3", False),
    ])
    result = await chain.probe_local()
    assert result is None


@pytest.mark.asyncio
async def test_tts_probe_tolerates_exceptions():
    from realm.engine_chain import TTSChain
    chain = TTSChain([
        _make_provider("Kokoro", None, raises=ConnectionError("blip")),
        _make_provider("Kokoro Service", True),
    ])
    result = await chain.probe_local()
    assert result.name == "Kokoro Service"


# ─── TTS probe SKIPS floor providers (RNL failover bug, 2026-06-23) ──
# Bug: probe_local found SAPI5 (Windows built-in TTS, always available)
# and returned it as "local TTS responding." The FALLBACK federation
# provider then aborted the rescue, the chain fell through to SAPI5,
# user heard robot voice instead of getting federated to peer's Kokoro.
#
# Fix: probe skips SAPI5 and pyttsx3 the same way LLM probe skips Echo —
# they are floor providers, not real local TTS recovery signals.


@pytest.mark.asyncio
async def test_tts_probe_skips_sapi5_floor_provider():
    """When KokoroService is dead and SAPI5 (the Windows floor) is the
    only available provider, probe must return None — NOT SAPI5. SAPI5
    is the degraded floor, not a real local TTS provider. Returning it
    would cause the federation FALLBACK provider to abort the rescue.

    This is the test that catches the RNL failover production bug."""
    from realm.engine_chain import TTSChain
    chain = TTSChain([
        _make_provider("Federation TTS (peer realms)", True),       # skipped
        _make_provider("Kokoro Service (localhost:9998)", False),   # dead
        _make_provider("SAPI5 (Windows TTS)", True),                # FLOOR — must skip
        _make_provider("pyttsx3 (cross-platform fallback)", True),  # FLOOR — must skip
    ])
    result = await chain.probe_local()
    assert result is None, (
        "REGRESSION: probe_local returned a floor provider (SAPI5 or "
        "pyttsx3). This breaks federation TTS rescue — the FALLBACK "
        "provider will abort the rescue because it thinks local recovered, "
        "and the chain will fall through to robot voice every time Kokoro "
        "dies. See realm/engine_chain.py:TTSChain.probe_local.")


@pytest.mark.asyncio
async def test_tts_probe_skips_pyttsx3_floor_provider():
    """Symmetric test for pyttsx3 alone — also a floor provider, also
    must be skipped."""
    from realm.engine_chain import TTSChain
    chain = TTSChain([
        _make_provider("Kokoro Service", False),
        _make_provider("pyttsx3 (cross-platform fallback)", True),
    ])
    result = await chain.probe_local()
    assert result is None


@pytest.mark.asyncio
async def test_tts_probe_returns_real_local_when_floors_also_available():
    """When a REAL local TTS (Kokoro Service) is healthy AND the floors
    are also available, probe correctly returns the real local. The
    floor providers are skipped during probing but still serve as the
    final-resort fallback if everything else fails."""
    from realm.engine_chain import TTSChain
    chain = TTSChain([
        _make_provider("Federation TTS (peer realms)", True),       # skipped
        _make_provider("Kokoro Service", True),                     # ← WIN
        _make_provider("SAPI5 (Windows TTS)", True),                # skipped
        _make_provider("pyttsx3 (cross-platform fallback)", True),  # skipped
    ])
    result = await chain.probe_local()
    assert result.name == "Kokoro Service"


# ─── TTSChain.synth respects allow_federation ─────────────────────


@pytest.mark.asyncio
async def test_tts_chain_synth_passes_allow_federation_to_providers():
    """allow_federation is the hop-limit signal. Federation TTS providers
    must receive it. Non-federation providers don't accept the kwarg
    (TypeError) and we fall back to calling without it."""
    from realm.engine_chain import TTSChain
    # Mock federation provider accepts allow_federation
    fed_provider = MagicMock()
    fed_provider.name = "Federation TTS (peer realms)"
    fed_provider.is_available = AsyncMock(return_value=True)
    fed_provider.synth = AsyncMock(return_value=None)  # falls through
    # Mock local provider does NOT accept allow_federation (raises TypeError)
    local_provider = MagicMock()
    local_provider.name = "Kokoro"
    local_provider.is_available = AsyncMock(return_value=True)
    async def synth_legacy(text):
        return "ZmFrZQ=="
    local_provider.synth = synth_legacy

    chain = TTSChain([fed_provider, local_provider])
    result = await chain.synth("hello", allow_federation=False)
    # Federation provider's synth was called with allow_federation=False
    fed_provider.synth.assert_called_once()
    call_kwargs = fed_provider.synth.call_args.kwargs
    assert call_kwargs.get("allow_federation") is False
    # Final result came from local (federation returned None)
    assert result == "ZmFrZQ=="


# ─── [Debug] ui_verbose config flag (v1.0.3 diagnostic hot-patch) ──


def test_debug_ui_verbose_present_in_frontend_config():
    """The [Debug] ui_verbose flag must reach the frontend via /api/config.
    The frontend gates [music-diag] and [service-diag] console.log lines
    on this flag. If the flag isn't exposed to the frontend, the diagnostics
    silently disappear — operators won't have observability into the
    intermittent UI render bug."""
    from realm.config_schema import Config
    from pathlib import Path
    cfg = Config(Path(__file__).parent.parent / "config.ini")
    fe = cfg.frontend_config()
    assert "Debug" in fe, (
        "[Debug] section missing from frontend payload. The diagnostic "
        "console.log lines will be silently disabled. Check the "
        "@scope: frontend annotation on [Debug] ui_verbose in config.ini.")
    assert "ui_verbose" in fe["Debug"]


def test_debug_ui_verbose_defaults_true():
    """v1.0.3 ships ui_verbose=true so we capture diagnostics in
    production without operator intervention. v1.1+ may flip this to
    false once the underlying intermittent UI bug is identified."""
    from realm.config_schema import Config
    from pathlib import Path
    cfg = Config(Path(__file__).parent.parent / "config.ini")
    fe = cfg.frontend_config()
    assert fe["Debug"]["ui_verbose"] is True, (
        "ui_verbose default flipped. v1.0.x ships true so operators see "
        "diagnostics by default. Flipping to false silences the "
        "[music-diag] and [service-diag] console output.")


def test_debug_ui_verbose_is_bool_type():
    """The type coercion must produce a real Python bool, not a string.
    The frontend's isUiVerboseEnabled() tolerates string 'true' defensively
    but the canonical path is bool->bool."""
    from realm.config_schema import Config
    from pathlib import Path
    cfg = Config(Path(__file__).parent.parent / "config.ini")
    fe = cfg.frontend_config()
    assert isinstance(fe["Debug"]["ui_verbose"], bool), (
        "ui_verbose must coerce to Python bool. Got "
        + type(fe["Debug"]["ui_verbose"]).__name__)
