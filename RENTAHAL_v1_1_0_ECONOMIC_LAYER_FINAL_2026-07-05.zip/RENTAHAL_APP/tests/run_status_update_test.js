// run_status_update_test.js — verifies the bus_status_update handler
// that flashes the LLM/TTS badge when a federation provider's pre-flight
// probe finds local recovered. This is the "operator sees recovery the
// moment it happens" UX, before the next per-query update lands.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else { console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
         failCount++; }
}

// ─── Locate the bus_status_update case ────────────────────────

const caseIdx = html.indexOf("case 'bus_status_update':");
assert(caseIdx > 0, "bus_status_update case exists in handleMsg switch");

const caseEnd = html.indexOf('break;', caseIdx);
const caseBody = html.slice(caseIdx, caseEnd + 6);

// ─── Two channels: llm and tts ─────────────────────────────────

assert(/msg\.channel\s*===\s*['"]llm['"]/.test(caseBody),
       "Handler routes msg.channel === 'llm' to status-llm badge");
assert(/msg\.channel\s*===\s*['"]tts['"]/.test(caseBody),
       "Handler routes msg.channel === 'tts' to status-tts badge");

// ─── Both branches call setStatus with provider name ────────────

assert(/setStatus\(\s*['"]status-llm['"]/.test(caseBody),
       "LLM branch calls setStatus on status-llm");
assert(/setStatus\(\s*['"]status-tts['"]/.test(caseBody),
       "TTS branch calls setStatus on status-tts");

// ─── Badge text uses msg.provider ──────────────────────────────

const llmFormat = /['"]LLM:\s*['"]\s*\+\s*msg\.provider/.test(caseBody);
assert(llmFormat, "LLM badge format is 'LLM: <provider name>'");
const ttsFormat = /['"]TTS:\s*['"]\s*\+\s*msg\.provider/.test(caseBody);
assert(ttsFormat, "TTS badge format is 'TTS: <provider name>'");

// ─── Guarded against missing provider field ────────────────────

// We require BOTH the channel check AND the provider check to fire
// — protects against malformed events that arrive without a provider.
assert(/msg\.channel\s*===\s*['"]llm['"]\s*&&\s*msg\.provider/.test(caseBody),
       "LLM branch guards against missing msg.provider");
assert(/msg\.channel\s*===\s*['"]tts['"]\s*&&\s*msg\.provider/.test(caseBody),
       "TTS branch guards against missing msg.provider");

// ─── 'ok' status color — recovery is good news ─────────────────

const okCount = (caseBody.match(/['"]ok['"]/g) || []).length;
assert(okCount >= 2,
       "Both badge updates use 'ok' status (green color, recovery is good)");

// ─── Explanatory comment present ───────────────────────────────

assert(/recover|probe|pre-flight|flash/i.test(caseBody),
       "Handler has explanatory comment about recovery/probe");

// ─── Summary ───────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} status-update tests passed`);
  process.exit(0);
}
