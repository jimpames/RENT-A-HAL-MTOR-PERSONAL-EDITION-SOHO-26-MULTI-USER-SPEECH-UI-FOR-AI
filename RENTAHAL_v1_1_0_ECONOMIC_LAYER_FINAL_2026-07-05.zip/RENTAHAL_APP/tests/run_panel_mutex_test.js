// run_panel_mutex_test.js — regression tests for the "one card area at a
// time" mutual exclusion. User reported: news / service / music all
// reliably fail on second invocation when another panel is already open.
// Root cause: independent panels with no enforced mutex; stale DOM state
// from one panel breaks the next.
//
// Fix: nukeAllCardPanels() hides ALL three card-bearing panels AND clears
// their content. Called BEFORE any new panel is opened, on every entry
// path (voice and button).
//
// Help panel is EXCLUDED from the nuke — it's documentation, not search
// results. Help panel and a card panel can coexist (user can read
// commands while seeing results).

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── nukeAllCardPanels exists and clears all three card panels ──

assert(/function nukeAllCardPanels/.test(html),
       'nukeAllCardPanels function defined');

const nukeIdx = html.indexOf('function nukeAllCardPanels');
const nukeEndIdx = html.indexOf('\nfunction ', nukeIdx + 1);
assert(nukeIdx > 0 && nukeEndIdx > nukeIdx,
       'nukeAllCardPanels extractable');
const nukeSrc = html.slice(nukeIdx, nukeEndIdx);

// Hides each card panel
assert(/news-panel[\s\S]*?style\.display\s*=\s*['"]none['"]/.test(nukeSrc),
       'nuke hides news-panel');
assert(/music-panel[\s\S]*?style\.display\s*=\s*['"]none['"]/.test(nukeSrc),
       'nuke hides music-panel');
assert(/services-panel[\s\S]*?style\.display\s*=\s*['"]none['"]/.test(nukeSrc),
       'nuke hides services-panel');

// Clears each card panel's content
assert(/news-stories[\s\S]*?innerHTML\s*=\s*['"]['"]/.test(nukeSrc),
       'nuke clears news-stories container');
assert(/music-player-container[\s\S]*?innerHTML\s*=\s*['"]['"]/.test(nukeSrc),
       'nuke clears music-player-container (also stops YouTube playback)');
assert(/services-results[\s\S]*?innerHTML\s*=\s*['"]['"]/.test(nukeSrc),
       'nuke clears services-results container');

// Also clears status lines so prior status doesn't bleed through
assert(/news-status/.test(nukeSrc),
       'nuke clears news-status line');
assert(/music-status/.test(nukeSrc),
       'nuke clears music-status line');
assert(/services-status/.test(nukeSrc),
       'nuke clears services-status line');

// Stops in-flight TTS audio so it doesn't overlap with new content
assert(/player\.pause/.test(nukeSrc),
       'nuke stops in-flight TTS audio (no overlap when switching realms)');

// CRITICAL: does NOT touch help panel (it's documentation, can coexist)
assert(!/help-panel/.test(nukeSrc),
       'nuke does NOT touch help-panel (documentation can coexist with results)');

// ─── Every voice-path event handler nukes before opening ─────

// bus_news_bundle — voice path for news
const newsBundleIdx = html.indexOf("case 'bus_news_bundle'");
const newsBundleEnd = html.indexOf('break;', newsBundleIdx);
const newsBundleSrc = html.slice(newsBundleIdx, newsBundleEnd);
assert(/nukeAllCardPanels\(\)/.test(newsBundleSrc),
       'bus_news_bundle handler nukes other panels before opening news');

// bus_music_search_request — voice path for music
const musicReqIdx = html.indexOf("case 'bus_music_search_request'");
const musicReqEnd = html.indexOf('break;', musicReqIdx);
const musicReqSrc = html.slice(musicReqIdx, musicReqEnd);
assert(/nukeAllCardPanels\(\)/.test(musicReqSrc),
       'bus_music_search_request handler nukes other panels before opening music');

// bus_service_results — voice path for service finder
const serviceResIdx = html.indexOf("case 'bus_service_results'");
const serviceResEnd = html.indexOf('break;', serviceResIdx);
const serviceResSrc = html.slice(serviceResIdx, serviceResEnd);
assert(/nukeAllCardPanels\(\)/.test(serviceResSrc),
       'bus_service_results handler nukes other panels before opening services');

// ─── Button-click paths nuke too ─────────────────────────────

// News button calls showNews; that function nukes before opening
const showNewsIdx = html.indexOf('function showNews()');
const showNewsEnd = html.indexOf('\nfunction ', showNewsIdx);
const showNewsSrc = html.slice(showNewsIdx, showNewsEnd);
assert(/nukeAllCardPanels\(\)/.test(showNewsSrc),
       'showNews button handler nukes before opening');

// Music and Services buttons go through sendPrompt, which triggers
// the realm and ultimately the event handlers (already covered above).
// askMusic and askService themselves don't directly open panels —
// they delegate via sendPrompt → realm → bus event. That path is
// already protected by the event-handler nuke calls.

// ─── Order matters: nuke MUST happen BEFORE the open ──────────

// In each event handler, nukeAllCardPanels must appear BEFORE the
// open/render call. If it were after, the new panel would be opened
// then immediately hidden — terrible UX.
const newsNukeIdx = newsBundleSrc.indexOf('nukeAllCardPanels');
const newsOpenIdx = newsBundleSrc.indexOf("'block'");
assert(newsNukeIdx > 0 && newsOpenIdx > newsNukeIdx,
       'news: nuke runs BEFORE display:block (would self-hide otherwise)');

const musicNukeIdx = musicReqSrc.indexOf('nukeAllCardPanels');
const musicOpenIdx = musicReqSrc.indexOf('openMusicPanel');
assert(musicNukeIdx > 0 && musicOpenIdx > musicNukeIdx,
       'music: nuke runs BEFORE openMusicPanel');

const serviceNukeIdx = serviceResSrc.indexOf('nukeAllCardPanels');
const serviceOpenIdx = serviceResSrc.indexOf('openServicesPanel');
assert(serviceNukeIdx > 0 && serviceOpenIdx > serviceNukeIdx,
       'service: nuke runs BEFORE openServicesPanel');

// ─── Diagnostic logging ──────────────────────────────────────

assert(/console\.log\(['"`]\[panels\]/.test(nukeSrc),
       'nuke logs [panels] message for diagnostics');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} panel-mutex tests passed`);
  process.exit(0);
}
