"""
Regression tests for the Windows TTS path.

Two providers in play:
  - SAPI5TTSProvider:  Windows-only, direct win32com bypass of pyttsx3 to
                       avoid the runAndWait() COM message-pump deadlock.
  - Pyttsx3TTSProvider: cross-platform fallback (Linux/macOS), self-disables
                       on Windows so SAPI5 is the Windows path.

These tests pass on Linux. The Linux sandbox can't exercise win32com itself,
but we DO verify:
  * SAPI5TTSProvider.is_available() returns False on non-Windows (no crash,
    no log spam, just a clean "not available" that lets the chain fall through)
  * Pyttsx3TTSProvider on Linux still works (the original cross-platform path)
  * Pyttsx3TTSProvider on simulated-Windows correctly self-disables
"""

import asyncio
import base64
import queue
import sys
import threading
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.engine_chain import (Pyttsx3TTSProvider, SAPI5TTSProvider,
                                TTSChain, EchoTTSProvider)

pytestmark = pytest.mark.asyncio


# ---- SAPI5 provider behavior on non-Windows ----

async def test_sapi5_unavailable_on_non_windows_without_crashing():
    """SAPI5 needs pywin32 (Windows-only). On Linux/macOS the provider must
    report unavailable without raising, so the chain falls through cleanly."""
    provider = SAPI5TTSProvider()
    available = await provider.is_available()
    # win32com cannot import on Linux. is_available must return False, and
    # the provider's _init_error must explain why.
    if sys.platform != "win32":
        assert available is False, \
            "SAPI5TTSProvider must self-disable when win32com isn't available"
        assert provider._init_error is not None, \
            "SAPI5TTSProvider should record an init error explaining why"


async def test_sapi5_synth_returns_none_when_unavailable():
    """If is_available is False, synth must return None — never raise."""
    provider = SAPI5TTSProvider()
    audio = await provider.synth("anything")
    if sys.platform != "win32":
        assert audio is None


# ---- Pyttsx3 cross-platform fallback ----

class FakePyttsx3Engine:
    def __init__(self):
        self.owner_thread = threading.get_ident()
        self.call_count = 0

    def save_to_file(self, text, path):
        self.call_count += 1
        if threading.get_ident() != self.owner_thread:
            open(path, "wb").close()
            return
        with open(path, "wb") as f:
            f.write(b"RIFF" + b"\x00" * 200 + text.encode("utf-8"))

    def runAndWait(self): pass
    def stop(self): pass


def install_fake_pyttsx3(monkeypatch):
    fake_mod = type(sys)("pyttsx3")
    fake_mod.init = lambda: FakePyttsx3Engine()
    monkeypatch.setitem(sys.modules, "pyttsx3", fake_mod)


async def test_pyttsx3_self_disables_on_windows(monkeypatch):
    """On Windows we want SAPI5, not pyttsx3. Pyttsx3 provider must refuse."""
    install_fake_pyttsx3(monkeypatch)
    with patch.object(sys, "platform", "win32"):
        provider = Pyttsx3TTSProvider()
        available = await provider.is_available()
        assert available is False, \
            "Pyttsx3TTSProvider must self-disable on Windows (SAPI5 takes over)"


async def test_pyttsx3_works_on_linux_and_macos(monkeypatch):
    """Cross-platform path still works for Linux/macOS dev."""
    install_fake_pyttsx3(monkeypatch)
    # Pretend we're on linux even if the host is something else
    with patch.object(sys, "platform", "linux"):
        provider = Pyttsx3TTSProvider()
        # is_available() probes pyttsx3; with the fake module it succeeds
        available = await provider.is_available()
        assert available is True, "Pyttsx3 should work via fake module on Linux"
        audio = await provider.synth("hello world")
        assert audio is not None
        assert len(base64.b64decode(audio)) > 100


async def test_pyttsx3_rejects_empty_wav_on_linux(monkeypatch):
    class BrokenEngine:
        def save_to_file(self, text, path): open(path, "wb").close()
        def runAndWait(self): pass
        def stop(self): pass
    fake_mod = type(sys)("pyttsx3")
    fake_mod.init = lambda: BrokenEngine()
    monkeypatch.setitem(sys.modules, "pyttsx3", fake_mod)
    with patch.object(sys, "platform", "linux"):
        provider = Pyttsx3TTSProvider()
        audio = await provider.synth("anything")
        assert audio is None, "empty WAV must not be returned as 'success'"


# ---- Chain behavior with the new ordering ----

async def test_tts_chain_falls_through_dead_sapi5_to_echo():
    """The TTS chain must continue past a dead SAPI5 on non-Windows."""
    chain = TTSChain([SAPI5TTSProvider(), EchoTTSProvider()])
    audio = await chain.synth("hello")
    assert audio is not None
    if sys.platform != "win32":
        assert chain.last_provider == "Echo TTS (test)", \
            f"chain should have fallen through to echo; landed on {chain.last_provider}"
