"""
Loose-end fix — federation token validation, finally actually enforced.

The token field/header has been SENT by every federation client since
Sprints 6-9 (check-in payload's "token" field, X-Federation-Token header
on /api/ask + /api/speak forwarding calls) but never validated ANYWHERE.
Federation was effectively open regardless of what an operator set.

This closes that gap consistently across all six federation-facing
endpoints, via one shared function (federation_token_error):
  - POST /api/federate/checkin      (body field "token")
  - GET  /api/federate/matrix       (header X-Federation-Token)
  - GET  /api/federate/contracts    (header X-Federation-Token)
  - POST /api/federate/contracts/revoke  (header X-Federation-Token)
  - POST /api/ask   (header, ONLY for calls carrying X-Federation-Hops)
  - POST /api/speak   (same)

Core invariants:
  - Empty configured token (the default) = zero validation anywhere,
    zero behavior change for every existing deployment
  - Once set, mismatched/missing token on any of the six = 401
  - /api/ask and /api/speak stay fully open to ORDINARY direct callers
    (no X-Federation-Hops header) regardless of token config — the
    "Little Johnny principle" is preserved exactly; only calls that
    identify themselves as federated forwards get gated
"""
import asyncio
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import DEGRADED_AVG_S


# ─── federation_token_error — pure function ─────────────────────────

def test_empty_configured_token_never_errors():
    from app import federation_token_error
    assert federation_token_error("", "") is None
    assert federation_token_error("", "anything") is None
    assert federation_token_error("", "wrong-guess") is None


def test_matching_token_no_error():
    from app import federation_token_error
    assert federation_token_error("secret123", "secret123") is None


def test_mismatched_token_returns_401():
    from app import federation_token_error
    err = federation_token_error("secret123", "wrong")
    assert err is not None
    assert err.status_code == 401


def test_missing_token_when_required_returns_401():
    from app import federation_token_error
    err = federation_token_error("secret123", "")
    assert err is not None
    assert err.status_code == 401


# ─── Full HTTP integration across all six endpoints ─────────────────

async def _boot_federator_with_token(tmp_path, token=""):
    os.environ["RENTAHAL_FAKE_ENGINES"] = "1"
    import app as app_module
    cfg = app_module.load_ini()
    fed_ini = tmp_path / "federator.ini"
    fed_ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n"
        "[Federation]\n"
        f"token = {token}\n")
    cfg.read(fed_ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


async def _run_server(app, port):
    import uvicorn
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=port, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    return server, task


@pytest.mark.asyncio
async def test_checkin_open_when_no_token_configured(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="")
    server, task = await _run_server(app, 9960)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9960/api/federate/checkin", json={
                "member_url": "https://a.example", "llm_avg_s": 1.0,
                "tts_avg_s": 1.0, "tokens_out": 0}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_checkin_rejects_wrong_token(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9961)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9961/api/federate/checkin", json={
                "member_url": "https://a.example", "llm_avg_s": 1.0,
                "tts_avg_s": 1.0, "tokens_out": 0, "token": "wrong-secret"}) as r:
                assert r.status == 401
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_checkin_accepts_correct_token(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9962)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9962/api/federate/checkin", json={
                "member_url": "https://a.example", "llm_avg_s": 1.0,
                "tts_avg_s": 1.0, "tokens_out": 0, "token": "correct-secret"}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_checkin_rejects_missing_token_when_required(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9963)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9963/api/federate/checkin", json={
                "member_url": "https://a.example", "llm_avg_s": 1.0,
                "tts_avg_s": 1.0, "tokens_out": 0}) as r:   # no token field at all
                assert r.status == 401
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_matrix_endpoint_requires_token_when_configured(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9964)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:9964/api/federate/matrix") as r:
                assert r.status == 401
            async with s.get("http://127.0.0.1:9964/api/federate/matrix",
                             headers={"X-Federation-Token": "correct-secret"}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_matrix_endpoint_open_when_no_token_configured(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="")
    server, task = await _run_server(app, 9965)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:9965/api/federate/matrix") as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_contracts_endpoint_requires_token(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9966)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:9966/api/federate/contracts") as r:
                assert r.status == 401
            async with s.get("http://127.0.0.1:9966/api/federate/contracts",
                             headers={"X-Federation-Token": "correct-secret"}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_revoke_endpoint_requires_token(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9967)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9967/api/federate/contracts/revoke",
                              json={"rank": "chat"}) as r:
                assert r.status == 401
            async with s.post("http://127.0.0.1:9967/api/federate/contracts/revoke",
                              json={"rank": "chat"},
                              headers={"X-Federation-Token": "correct-secret"}) as r:
                assert r.status == 200   # succeeds, even if revoked=False
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_ask_stays_open_to_ordinary_callers_regardless_of_token(tmp_path):
    """THE Little Johnny principle: a direct curl call to /api/ask (no
    X-Federation-Hops header) must NEVER be gated by the token, even
    when one is configured — the token protects the federation network,
    not this endpoint's general public availability."""
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9968)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9968/api/ask",
                              json={"text": "what is the realm"}) as r:
                assert r.status == 200   # no federation headers at all — always open
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_ask_gates_federated_calls_when_token_configured(tmp_path):
    """A call that DOES identify itself as federated (X-Federation-Hops
    present) must be gated once a token is configured."""
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9969)
    try:
        async with aiohttp.ClientSession() as s:
            # Federated call, no token — rejected.
            async with s.post("http://127.0.0.1:9969/api/ask",
                              json={"text": "what is the realm"},
                              headers={"X-Federation-Hops": "0"}) as r:
                assert r.status == 401
            # Federated call, correct token — accepted.
            async with s.post("http://127.0.0.1:9969/api/ask",
                              json={"text": "what is the realm"},
                              headers={"X-Federation-Hops": "0",
                                      "X-Federation-Token": "correct-secret"}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_ask_federated_call_open_when_no_token_configured(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="")
    server, task = await _run_server(app, 9970)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9970/api/ask",
                              json={"text": "what is the realm"},
                              headers={"X-Federation-Hops": "0"}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_tts_stays_open_to_ordinary_callers(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9971)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9971/api/speak",
                              json={"text": "hello"}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_tts_gates_federated_calls_when_token_configured(tmp_path):
    import aiohttp
    app = await _boot_federator_with_token(tmp_path, token="correct-secret")
    server, task = await _run_server(app, 9972)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9972/api/speak",
                              json={"text": "hello"},
                              headers={"X-Federation-Hops": "0"}) as r:
                assert r.status == 401
            async with s.post("http://127.0.0.1:9972/api/speak",
                              json={"text": "hello"},
                              headers={"X-Federation-Hops": "0",
                                      "X-Federation-Token": "correct-secret"}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


# ─── FederationClient sends the checkin token correctly (sending side) ──

@pytest.mark.asyncio
async def test_federation_client_sends_configured_token():
    """Sanity check the SENDING side already worked (Sprint 6+) — this
    is the receiving side that was the actual gap."""
    from unittest.mock import patch
    from realm.federation import FederationConfig, FederationState, FederationClient

    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate",
                           token="my-secret")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    client = FederationClient(state)

    class _MockResp:
        status = 200
        async def json(self): return {"best_llm_peer": None, "best_tts_peer": None}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    captured = {}
    def mock_post(url, json=None):
        captured["payload"] = json
        return _MockResp()

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()

    assert captured["payload"]["token"] == "my-secret"
