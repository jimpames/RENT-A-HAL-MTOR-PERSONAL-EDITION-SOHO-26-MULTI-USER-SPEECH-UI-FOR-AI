"""
Sprint 9 tests — the conscription CONSUMING side, and donor-side
visibility. This is the sprint that closes the loop: Sprint 8 built the
Federator's decision engine, but nothing acted on the contract it
handed out. This sprint does.

  FederationConscriptionProvider.should_federate — pure-logic gate
    - False when allow_federation is False (hop limit)
    - False when operator opted out (cfg.desire = False)
    - False when member_state != HEALTHY
    - False when no active contract at all
    - False when the contract is for a DIFFERENT rank (not 'chat' —
      this provider is chat-specific)
    - False when the contract's peer_url IS our own self_url
    - True on the happy path

  FederationConscriptionProvider.generate — wire behavior
    - routes to contract['peer_url'], not best_llm_peer
    - returns None (falls through) on non-200, timeout, empty answer
    - records last_usage with conscripted=True
    - pre-flight local probe short-circuits to local recovery, same as
      the other two providers

  Donor-side visibility (get_donor_contract / wire protocol)
    - a member with no active contract anywhere gets None
    - a member who IS the donor for an active contract gets it back
    - the checkin endpoint surfaces donor_contract for ANY caller,
      regardless of their own node_type/rank
    - FederationClient stores state.donor_contract from the response
    - to_ui_dict surfaces both conscription and donor_contract

  The cross-process clock correctness point (documented, not just
  tested as an aside): this provider must never independently compare
  expires_at against its own time.monotonic() — only the Federator's
  most recent check-in response is authoritative. Verified by
  confirming should_federate has no such comparison at all.
"""
import inspect
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import FederationConfig, FederationState
from realm.federation_provider import FederationConscriptionProvider

pytestmark = pytest.mark.asyncio


def _make_provider(desire=True, member_state="HEALTHY",
                   contract=None, contracts=None,
                   self_url="https://me.example"):
    """contract= sets a single contract (convenience for most tests);
    contracts= sets an explicit list (for multi-donor tests). If both
    are given, contracts wins."""
    cfg = FederationConfig(desire=desire, self_url=self_url)
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": 0, "tts_avg_s": 0, "tokens_out": 0})
    fed_state.member_state = member_state
    if contracts is not None:
        fed_state.conscriptions = contracts
    else:
        fed_state.conscriptions = [contract] if contract else []
    return FederationConscriptionProvider(fed_state)


DEFAULT_CONTRACT = {
    "peer_url": "https://donor.example",
    "native_role": "vision",
    "conscripted_as": "chat",
    "assigned_at": 0.0,
    "expires_at": 99999999.0,
}


# ─── should_federate — pure logic gate ──────────────────────────────

def test_should_federate_happy_path():
    p = _make_provider(contract=DEFAULT_CONTRACT)
    assert p.should_federate(allow_federation=True)


def test_should_federate_false_on_hop_limit():
    p = _make_provider(contract=DEFAULT_CONTRACT)
    assert not p.should_federate(allow_federation=False)


def test_should_federate_false_when_desire_off():
    p = _make_provider(desire=False, contract=DEFAULT_CONTRACT)
    assert not p.should_federate(allow_federation=True)


def test_should_federate_false_when_not_healthy():
    p = _make_provider(member_state="DEGRADED", contract=DEFAULT_CONTRACT)
    assert not p.should_federate(allow_federation=True)


def test_should_federate_false_when_no_contract():
    p = _make_provider(contract=None)
    assert not p.should_federate(allow_federation=True)


def test_should_federate_false_when_contract_is_different_rank():
    """This provider is chat-specific. A vision/imagine contract must
    not be consumed here."""
    contract = dict(DEFAULT_CONTRACT, conscripted_as="vision")
    p = _make_provider(contract=contract)
    assert not p.should_federate(allow_federation=True)


def test_should_federate_false_when_peer_is_self():
    contract = dict(DEFAULT_CONTRACT, peer_url="https://me.example")
    p = _make_provider(contract=contract, self_url="https://me.example")
    assert not p.should_federate(allow_federation=True)


def test_should_federate_false_when_contract_missing_peer_url():
    contract = dict(DEFAULT_CONTRACT)
    del contract["peer_url"]
    p = _make_provider(contract=contract)
    assert not p.should_federate(allow_federation=True)


def test_should_federate_never_compares_expires_at_to_local_clock():
    """The cross-process clock correctness point: should_federate's
    source must contain no reference to expires_at at all — it trusts
    the Federator's periodic refresh entirely, never independently
    judging expiry against its own time.monotonic()."""
    src = inspect.getsource(FederationConscriptionProvider.should_federate)
    assert "expires_at" not in src
    assert "monotonic" not in src


# ─── is_available ────────────────────────────────────────────────────

async def test_is_available_matches_should_federate():
    p = _make_provider(contract=DEFAULT_CONTRACT)
    assert await p.is_available() is True
    p2 = _make_provider(contract=None)
    assert await p2.is_available() is False


# ─── generate — wire behavior ────────────────────────────────────────

class _MockResp:
    def __init__(self, body, status=200):
        self._body = body
        self.status = status
    async def json(self):
        return self._body
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass


async def test_generate_routes_to_contract_peer_url_not_best_llm_peer():
    p = _make_provider(contract=DEFAULT_CONTRACT)
    p.state.best_llm_peer = "https://someone-else-entirely.example"

    captured = {}
    def mock_post(url, json=None, headers=None):
        captured["url"] = url
        captured["headers"] = headers
        return _MockResp({"answer": "hello from the donor"})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi", max_tokens=200)

    assert result == "hello from the donor"
    assert captured["url"] == "https://donor.example/api/ask"
    assert captured["headers"]["X-Federation-Conscripted"] == "1"
    assert captured["headers"]["X-Federation-Hops"] == "1"


async def test_generate_records_conscripted_usage():
    p = _make_provider(contract=DEFAULT_CONTRACT)
    def mock_post(url, json=None, headers=None):
        return _MockResp({"answer": "some answer text here"})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await p.generate("hi")
    assert p.last_usage["conscripted"] is True
    assert p.last_usage["federated_to"] == "https://donor.example"


async def test_generate_returns_none_on_non_200():
    p = _make_provider(contract=DEFAULT_CONTRACT)
    def mock_post(url, json=None, headers=None):
        return _MockResp({}, status=500)
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")
    assert result is None


async def test_generate_returns_none_on_empty_answer():
    p = _make_provider(contract=DEFAULT_CONTRACT)
    def mock_post(url, json=None, headers=None):
        return _MockResp({"answer": ""})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")
    assert result is None


async def test_generate_returns_none_when_should_federate_false():
    p = _make_provider(contract=None)
    result = await p.generate("hi")
    assert result is None


async def test_generate_falls_through_to_second_donor_on_first_failure():
    """The core multi-donor behavior: donor 1 times out/fails, donor 2
    in the list succeeds — must not give up after just the first."""
    contract1 = dict(DEFAULT_CONTRACT, peer_url="https://donor1.example")
    contract2 = dict(DEFAULT_CONTRACT, peer_url="https://donor2.example")
    p = _make_provider(contracts=[contract1, contract2])

    call_count = {"n": 0}
    def mock_post(url, json=None, headers=None):
        call_count["n"] += 1
        if "donor1" in url:
            return _MockResp({}, status=500)   # first donor fails
        return _MockResp({"answer": "answer from donor2"})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")

    assert result == "answer from donor2"
    assert call_count["n"] == 2   # tried both, in order


async def test_generate_returns_none_only_after_every_donor_fails():
    contract1 = dict(DEFAULT_CONTRACT, peer_url="https://donor1.example")
    contract2 = dict(DEFAULT_CONTRACT, peer_url="https://donor2.example")
    p = _make_provider(contracts=[contract1, contract2])

    def mock_post(url, json=None, headers=None):
        return _MockResp({}, status=500)   # everyone fails
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")

    assert result is None


async def test_generate_tries_donors_in_the_order_provided():
    contract1 = dict(DEFAULT_CONTRACT, peer_url="https://donor1.example")
    contract2 = dict(DEFAULT_CONTRACT, peer_url="https://donor2.example")
    p = _make_provider(contracts=[contract1, contract2])

    order = []
    def mock_post(url, json=None, headers=None):
        order.append(url)
        return _MockResp({"answer": "ok"})   # first one succeeds
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await p.generate("hi")

    assert order == ["https://donor1.example/api/ask"]   # stopped at first success


async def test_should_federate_true_with_multiple_contracts():
    contract1 = dict(DEFAULT_CONTRACT, peer_url="https://donor1.example")
    contract2 = dict(DEFAULT_CONTRACT, peer_url="https://donor2.example")
    p = _make_provider(contracts=[contract1, contract2])
    assert p.should_federate(allow_federation=True)


async def test_usable_contracts_filters_out_self_and_wrong_rank():
    self_contract = dict(DEFAULT_CONTRACT, peer_url="https://me.example")
    wrong_rank = dict(DEFAULT_CONTRACT, peer_url="https://donor2.example",
                      conscripted_as="vision")
    good = dict(DEFAULT_CONTRACT, peer_url="https://donor3.example")
    p = _make_provider(contracts=[self_contract, wrong_rank, good],
                       self_url="https://me.example")
    usable = p._usable_contracts()
    assert len(usable) == 1
    assert usable[0]["peer_url"] == "https://donor3.example"


async def test_generate_pre_flight_probe_prefers_local():
    """If the pre-flight probe finds local responding, we must NOT call
    the donor at all — return None so the chain re-walks to local."""
    p = _make_provider(contract=DEFAULT_CONTRACT)

    class _FakeLocalProvider:
        name = "GPT4All (local)"

    class _FakeChain:
        async def probe_local(self):
            return _FakeLocalProvider()

    recovered = []
    async def on_recovery(name):
        recovered.append(name)

    p.attach(_FakeChain(), on_recovery)

    called = {"post": False}
    def mock_post(*a, **kw):
        called["post"] = True
        return _MockResp({"answer": "should never get here"})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")

    assert result is None
    assert called["post"] is False
    assert recovered == ["GPT4All (local)"]


# ─── Donor-side visibility ───────────────────────────────────────────

from realm.federation import FederationMatrix, RANK_TO_CAPABILITY_KIND


def _matrix(**kw):
    defaults = dict(missed_after_s=60.0, conscription_enabled=True,
                    conscription_trigger_avg_s=10.0,
                    conscription_idle_avg_s=2.0,
                    default_conscription_max_minutes=15.0)
    defaults.update(kw)
    return FederationMatrix(**defaults)


async def test_get_donor_contract_none_when_no_contracts_exist():
    m = _matrix()
    result = await m.get_donor_contracts("https://anyone.example")
    assert result == []


async def test_get_donor_contract_finds_active_donor():
    m = _matrix()
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.1},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    result = await m.get_donor_contracts("https://vision-donor.example")
    assert len(result) == 1
    assert result[0]["conscripted_as"] == "chat"


async def test_get_donor_contract_none_for_non_donor_member():
    m = _matrix()
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.1},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    # A third, uninvolved member must get an empty list.
    result = await m.get_donor_contracts("https://uninvolved.example")
    assert result == []


# ─── Wire protocol — donor_contract over real HTTP ──────────────────

async def _boot_federator(tmp_path, ini_overrides: str = ""):
    import os
    os.environ["RENTAHAL_FAKE_ENGINES"] = "1"
    import app as app_module
    cfg = app_module.load_ini()
    fed_ini = tmp_path / "federator.ini"
    fed_ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n{ini_overrides}\n")
    cfg.read(fed_ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


async def test_checkin_endpoint_tells_donor_about_its_own_contract(tmp_path):
    import asyncio, uvicorn, aiohttp
    app = await _boot_federator(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9946, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            # Struggling chat node checks in first — this ASSIGNS the
            # contract (maybe_assign_conscription runs on ITS check-in,
            # since conscription is evaluated for the caller's own rank).
            await s.post("http://127.0.0.1:9946/api/federate/checkin", json={
                "member_url": "https://chat-struggling.example",
                "llm_avg_s": 25.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "chat"})
            # Donor was already registered? No — donor needs to exist in
            # the matrix BEFORE the contract can be assigned. Register it
            # first, then re-trigger assignment via a second chat check-in.
            await s.post("http://127.0.0.1:9946/api/federate/checkin", json={
                "member_url": "https://vision-donor.example",
                "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "vision", "capability_avg_s": {"vision": 0.1},
                "conscription_eligible_ranks": ["chat"]})
            await s.post("http://127.0.0.1:9946/api/federate/checkin", json={
                "member_url": "https://chat-struggling.example",
                "llm_avg_s": 25.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "chat"})
            # NOW the donor checks in again — it should learn it's an
            # active donor via donor_contract in its own response.
            async with s.post("http://127.0.0.1:9946/api/federate/checkin", json={
                "member_url": "https://vision-donor.example",
                "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "vision", "capability_avg_s": {"vision": 0.1},
                "conscription_eligible_ranks": ["chat"]}) as r:
                data = await r.json()
                assert data["donor_contract"] is not None
                assert data["donor_contract"]["conscripted_as"] == "chat"
                # And it should NOT see a "conscription" (that's only
                # for the struggling chat node asking for help).
                assert data["conscription"] is None
    finally:
        server.should_exit = True
        await task


# ─── FederationClient stores donor_contract ─────────────────────────

async def test_client_stores_donor_contract_from_response():
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    from realm.federation import FederationClient
    client = FederationClient(state)

    def mock_post(url, json=None):
        return _MockResp({
            "best_llm_peer": None, "best_tts_peer": None,
            "conscription": None,
            "donor_contract": {"peer_url": "https://me.example",
                               "conscripted_as": "chat"},
        })
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()
    assert state.donor_contract == {"peer_url": "https://me.example",
                                    "conscripted_as": "chat"}


async def test_client_donor_contract_none_when_absent():
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    from realm.federation import FederationClient
    client = FederationClient(state)

    def mock_post(url, json=None):
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()
    assert state.donor_contract is None


async def test_to_ui_dict_includes_both_conscription_and_donor_contract():
    cfg = FederationConfig(desire=True)
    state = FederationState(cfg, lambda: {})
    state.conscription = {"peer_url": "https://helper.example"}
    state.donor_contract = {"peer_url": "https://me.example"}
    d = state.to_ui_dict()
    assert d["conscription"] == {"peer_url": "https://helper.example"}
    assert d["donor_contract"] == {"peer_url": "https://me.example"}
