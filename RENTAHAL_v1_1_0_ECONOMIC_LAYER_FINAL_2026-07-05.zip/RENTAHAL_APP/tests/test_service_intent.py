"""
Regression tests for the service-finder realm — intent classification
and slot extraction for the "computer service finder X newline" pattern.

Architecture invariants this file LOCKS IN:
  - 'service finder X' triggers kind='service', captures X as a BizData
    OSM category in slots['category'] (mapped from natural English)
  - 'find a X', 'find me a X', 'find nearby X' also work
  - News/music/weather intents are NOT misclassified as service
  - 'service the printer' is NOT misclassified as service (it's an ask)
  - The full category map covers the 37 BizData categories
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.intent import (
    IntentClassifier,
    extract_service_slots,
    SERVICE_CATEGORY_MAP,
    PHRASE_INTENTS,
    SLOT_EXTRACTORS,
)


def _slots(text):
    import re
    tokens = re.findall(r"\w+", text.lower())
    return extract_service_slots(text, tokens)


def _classify(text):
    return IntentClassifier(bus=None).classify(text)


# ─── Registration ─────────────────────────────────────────────

def test_service_phrase_registered():
    assert PHRASE_INTENTS.get("service finder") == "service"


def test_find_phrases_registered():
    """Alternative triggers."""
    assert PHRASE_INTENTS.get("find a") == "service"
    assert PHRASE_INTENTS.get("find me") == "service"
    assert PHRASE_INTENTS.get("find nearby") == "service"


def test_service_has_slot_extractor():
    assert "service" in SLOT_EXTRACTORS


def test_category_map_has_core_categories():
    """The map must cover the categories users actually ask for."""
    required = ["haircut", "barber", "gas", "gasoline", "pharmacy",
                "coffee", "groceries", "bank", "atm", "restaurant",
                "hotel", "gym", "doctor", "dentist"]
    for word in required:
        assert word in SERVICE_CATEGORY_MAP, f"missing: {word}"


# ─── Basic slot extraction ────────────────────────────────────

def test_service_finder_haircut():
    s = _slots("service finder haircut")
    assert s["category"] == "hairdresser"
    assert s["category_label"] == "haircut"


def test_service_finder_pharmacy():
    s = _slots("service finder pharmacy")
    assert s["category"] == "pharmacy"


def test_service_finder_coffee():
    s = _slots("service finder coffee")
    assert s["category"] == "cafe"


def test_service_finder_bank():
    s = _slots("service finder bank")
    assert s["category"] == "bank"


# ─── Multi-word categories ────────────────────────────────────

def test_gas_station_two_words():
    """'gas station' should win over 'gas' alone (longer match)."""
    s = _slots("service finder gas station")
    assert s["category"] == "gas_station"
    assert s["category_label"] == "gas station"


def test_coffee_shop_two_words():
    s = _slots("service finder coffee shop")
    assert s["category"] == "cafe"
    assert s["category_label"] == "coffee shop"


def test_grocery_store_two_words():
    s = _slots("service finder grocery store")
    assert s["category"] == "supermarket"


def test_drug_store_two_words():
    s = _slots("service finder drug store")
    assert s["category"] == "pharmacy"


# ─── Alternative triggers ─────────────────────────────────────

def test_find_a_pharmacy():
    s = _slots("find a pharmacy")
    assert s["category"] == "pharmacy"


def test_find_me_a_barber():
    s = _slots("find me a barber")
    assert s["category"] == "hairdresser"


def test_find_nearby_coffee():
    s = _slots("find nearby coffee")
    assert s["category"] == "cafe"


# ─── Trailing politeness/proximity words stripped ─────────────

def test_trailing_please_stripped():
    s = _slots("service finder pharmacy please")
    assert s["category"] == "pharmacy"


def test_trailing_near_me_stripped():
    s = _slots("service finder gas station near me")
    assert s["category"] == "gas_station"


def test_trailing_nearby_stripped():
    s = _slots("service finder bank nearby")
    assert s["category"] == "bank"


def test_iOS_period_stripped():
    s = _slots("service finder haircut.")
    assert s["category"] == "hairdresser"


def test_iOS_exclamation_stripped():
    s = _slots("service finder coffee!")
    assert s["category"] == "cafe"


# ─── Edge cases ───────────────────────────────────────────────

def test_bare_trigger_returns_empty():
    """'service finder' alone — no category to extract."""
    assert _slots("service finder") == {}


def test_unmatched_category_preserved():
    """If user asks for something not in the map, we preserve the raw
    text so the handler can return a helpful 'I don't recognize X' error."""
    s = _slots("service finder unicorn fountain")
    assert "category" not in s
    assert "category_unmatched" in s


def test_capitalization_handled():
    """iOS may auto-capitalize."""
    s = _slots("Service Finder Haircut")
    assert s["category"] == "hairdresser"


# ─── Full classifier pipeline ─────────────────────────────────

def test_classifier_service_finder():
    intent = _classify("service finder haircut")
    assert intent.kind == "service"
    assert intent.slots.get("category") == "hairdresser"


def test_classifier_find_a():
    intent = _classify("find a pharmacy")
    assert intent.kind == "service"


def test_classifier_with_wake_word_prefix():
    """In production the wake word is stripped before classify, but the
    classifier should still tolerate it."""
    intent = _classify("computer service finder haircut")
    # 'computer' as first token isn't a service trigger, but the classifier
    # walks tokens[:3] for SINGLE_INTENTS. PHRASE check uses lower-string
    # prefix and doesn't match 'computer service finder'. So this falls to ask.
    # In production the browser strips 'computer' before sending.
    # If you want this to also work with the wake word, that's a separate
    # change — for now we verify the strip-then-classify pipeline.
    # The realistic case (post-strip) is tested by test_classifier_service_finder.
    assert intent.kind in ("ask", "service")


# ─── CRITICAL: other intents must NOT be misclassified ─────────

def test_weather_unaffected():
    intent = _classify("weather in boston")
    assert intent.kind == "weather"


def test_music_unaffected():
    intent = _classify("music london calling")
    assert intent.kind == "music"


def test_play_news_unaffected():
    intent = _classify("play news feed BBC")
    assert intent.kind == "news"


def test_ask_unaffected():
    """LLM questions don't accidentally route to service."""
    intent = _classify("tell me about the apollo missions")
    assert intent.kind == "ask"


def test_ambiguous_service_phrase_routes_to_ask():
    """'service the printer' is NOT a service-finder request — 'service'
    alone isn't a single-word intent (because that would be too broad)."""
    intent = _classify("service the printer")
    assert intent.kind == "ask"


def test_find_without_a_routes_to_ask():
    """'find the answer' is not a service search."""
    intent = _classify("find the answer to life")
    assert intent.kind == "ask"


# ─── Real-world category coverage ────────────────────────────

@pytest.mark.parametrize("phrase,expected_category", [
    ("service finder restaurant", "restaurant"),
    ("service finder hotel", "hotel"),
    ("service finder gym", "gym"),
    ("service finder dentist", "dentist"),
    ("service finder doctor", "doctor"),
    ("service finder pharmacy", "pharmacy"),
    ("service finder bank", "bank"),
    ("service finder atm", "bank"),
    ("service finder lawyer", "lawyer"),
    ("service finder bakery", "bakery"),
    ("service finder bar", "bar"),
    ("service finder car repair", "car_repair"),
    ("service finder mechanic", "car_repair"),
    ("service finder hospital", "hospital"),
    ("service finder parking", "parking"),
    ("service finder bookstore", "bookstore"),
    ("service finder florist", "florist"),
    ("service finder pet shop", "pet_shop"),
    ("service finder museum", "museum"),
    ("service finder cinema", "cinema"),
    ("service finder movies", "cinema"),
])
def test_real_world_categories(phrase, expected_category):
    intent = _classify(phrase)
    assert intent.kind == "service"
    assert intent.slots.get("category") == expected_category
