"""
Sprint 14 — end-to-end HTTP integration tests for:
  - Donor-side claim submission wired into /api/ask (fires when a
    request arrives with X-Federation-Conscripted + X-Federation-
    Requester-Url headers and is successfully answered)
  - The Federator-side claim endpoints:
    POST /api/federate/conscription-claim
    GET  /api/federate/conscription-claims/unmatched
    POST /api/federate/payout/link (mocked Stripe — real network
    unreachable from this sandbox, same restriction as every other
    external network dependency in this whole economic-layer arc)

Uses two REAL booted apps against the SAME Federator database — one
acting as the donor (answering /api/ask), one acting as the Federator
(reconciling claims) — to prove the full real round trip, not just
each half in isolation.
"""
import asyncio
import hashlib
import hmac
import json
import os
import sys
import time
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

asyncpg = pytest.importorskip("asyncpg")
stripe = pytest.importorskip("stripe")

os.environ["RENTAHAL_FAKE_ENGINES"] = "1"

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


async def _run_server(app, port):
    import uvicorn
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=port, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    return server, task


async def _drop_db(db_name):
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
        "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
    await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
    await admin_conn.close()


async def _boot_federator_app(tmp_path, db_name):
    """The Federator: [Federator] enabled, [Ledger] dsn, [Payout] configured."""
    dsn = BASE_DSN.rsplit("/", 1)[0] + f"/{db_name}"
    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "federator_config.ini"
    ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'fed_state.json'}\n"
        f"[Ledger]\ndsn = {dsn}\n"
        "[Payout]\nstripe_secret_key = sk_test_fake\n"
        "conscription_payout_rate_micros = 80\n"
        "claim_match_tolerance_s = 60.0\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


async def _boot_donor_app(tmp_path, federator_url):
    """The donor: an ordinary member realm, federated, pointed at the
    Federator above. AbuseGate disabled so repeated /api/ask calls in
    these tests don't trip PoW."""
    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "donor_config.ini"
    ini.write_text(
        "[AbuseGate]\nenabled = false\n"
        "[Federation]\ndesire = on\n"
        f"master_url = {federator_url}\n"
        "self_url = https://vision-donor.example\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


@pytest.mark.asyncio
async def test_donor_side_claim_submitted_after_conscripted_answer(tmp_path):
    """The real round trip: a simulated conscripted /api/ask call
    against a real donor realm results in a real claim landing in the
    real Federator's database."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_payout_e2e_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    fed_app = await _boot_federator_app(tmp_path, db_name)
    fed_server, fed_task = await _run_server(fed_app, 9970)

    donor_app = await _boot_donor_app(
        tmp_path, "http://127.0.0.1:9970/api/federate")
    donor_server, donor_task = await _run_server(donor_app, 9971)

    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            # Simulate FederationConscriptionProvider's own outgoing
            # call — same headers it actually sends.
            async with s.post("http://127.0.0.1:9971/api/ask",
                              json={"text": "what is the realm"},
                              headers={
                                  "X-Federation-Hops": "1",
                                  "X-Federation-Conscripted": "1",
                                  "X-Federation-Requester-Url":
                                      "https://chat-struggling.example",
                              }) as r:
                assert r.status == 200

            # Give the fire-and-forget claim submission a moment to land.
            await asyncio.sleep(0.5)

            # Confirm the donor's claim genuinely landed in the
            # Federator's database (still unmatched, since only one
            # side has claimed so far).
            async with s.get(
                    "http://127.0.0.1:9970/api/federate/conscription-claims/unmatched") as r:
                assert r.status == 200
                data = await r.json()
                donor_urls = [c["donor_url"] for c in data["unmatched_claims"]]
                assert "https://vision-donor.example" in donor_urls
    finally:
        donor_server.should_exit = True
        await donor_task
        fed_server.should_exit = True
        await fed_task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_full_bilateral_confirmation_over_real_http(tmp_path):
    """Both sides submit their claims directly to the Federator (this
    test isolates the Federator's own reconciliation endpoint rather
    than going through the donor's /api/ask wiring — that path is
    covered by the test above) — confirms a real HTTP round trip
    credits the donor correctly once both claims arrive."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_payout_bilateral_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    fed_app = await _boot_federator_app(tmp_path, db_name)
    server, task = await _run_server(fed_app, 9972)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            now = time.time()
            async with s.post(
                    "http://127.0.0.1:9972/api/federate/conscription-claim",
                    json={"role": "requester", "donor_url": "https://d.example",
                         "requester_url": "https://r.example", "rank": "chat",
                         "claimed_at": now}) as r:
                data1 = await r.json()
                assert data1["matched"] is False

            async with s.post(
                    "http://127.0.0.1:9972/api/federate/conscription-claim",
                    json={"role": "donor", "donor_url": "https://d.example",
                         "requester_url": "https://r.example", "rank": "chat",
                         "claimed_at": now + 3}) as r:
                data2 = await r.json()
                assert data2["matched"] is True
                assert data2["credited"] is True
                assert data2["credit_amount_micros"] == 80
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_claim_endpoints_absent_when_payout_not_configured(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_payout_absent_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()
    dsn = BASE_DSN.rsplit("/", 1)[0] + f"/{db_name}"

    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n"
        f"[Ledger]\ndsn = {dsn}\n")   # no [Payout] section at all
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)
    server, task = await _run_server(app, 9973)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.post(
                    "http://127.0.0.1:9973/api/federate/conscription-claim",
                    json={"role": "requester", "donor_url": "x",
                         "requester_url": "y", "rank": "chat"}) as r:
                assert r.status == 404
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_payout_link_endpoint_mocked_stripe(tmp_path):
    """MOCKED: api.stripe.com isn't reachable from this sandbox (see
    module docstring). Confirms the endpoint wires request -> account
    creation -> onboarding link creation -> response correctly."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_payout_link_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    fed_app = await _boot_federator_app(tmp_path, db_name)
    server, task = await _run_server(fed_app, 9974)
    try:
        import aiohttp
        fake_account = MagicMock(); fake_account.id = "acct_mocked"
        fake_link = MagicMock(); fake_link.url = "https://connect.stripe.com/setup/mocked"
        with patch("stripe.Account.create", return_value=fake_account), \
             patch("stripe.AccountLink.create", return_value=fake_link):
            async with aiohttp.ClientSession() as s:
                async with s.post(
                        "http://127.0.0.1:9974/api/federate/payout/link",
                        json={"donor_url": "https://vision-donor.example"}) as r:
                    assert r.status == 200
                    data = await r.json()
                    assert data["onboarding_url"] == "https://connect.stripe.com/setup/mocked"

                # A second link request for the SAME donor must reuse
                # the existing Stripe account, not create a new one.
                with patch("stripe.Account.create") as m_create:
                    async with s.post(
                            "http://127.0.0.1:9974/api/federate/payout/link",
                            json={"donor_url": "https://vision-donor.example"}) as r:
                        assert r.status == 200
                    assert m_create.call_count == 0   # reused, not re-created
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_unmatched_claim_endpoint_shows_the_lying_claim(tmp_path):
    """A donor's unpaired claim is genuinely visible for operator
    review via the observability endpoint — not silently hidden."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_payout_unmatched_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    fed_app = await _boot_federator_app(tmp_path, db_name)
    server, task = await _run_server(fed_app, 9975)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            await s.post(
                "http://127.0.0.1:9975/api/federate/conscription-claim",
                json={"role": "donor", "donor_url": "https://lying-donor.example",
                     "requester_url": "https://victim.example", "rank": "chat"})

            async with s.get(
                    "http://127.0.0.1:9975/api/federate/conscription-claims/unmatched") as r:
                data = await r.json()
                lying_claims = [c for c in data["unmatched_claims"]
                               if c["donor_url"] == "https://lying-donor.example"]
                assert len(lying_claims) == 1
                assert lying_claims[0]["credited"] is False
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)
