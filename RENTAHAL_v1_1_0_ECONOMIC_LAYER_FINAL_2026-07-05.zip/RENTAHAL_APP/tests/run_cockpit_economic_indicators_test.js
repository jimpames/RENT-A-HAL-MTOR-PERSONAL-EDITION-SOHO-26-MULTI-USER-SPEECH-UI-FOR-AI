// run_cockpit_economic_indicators_test.js — Sprint 15: confirms the
// persistent balance indicator and donor-earnings indicator markup
// exist, start hidden, and the polling functions are correctly wired
// (balance to this realm's own /api/billing/balance, donor earnings
// to the FEDERATOR's /payout/status via master_url/self_url piggy-
// backed onto the existing federation status poll).

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Markup ──────────────────────────────────────────────────────

assert(/id="balance-row"/.test(html), 'balance-row element present');
assert(/id="balance-row"[\s\S]{0,100}display:\s*none/.test(html),
       'balance-row starts hidden by default');
assert(/id="balance-indicator"/.test(html), 'balance-indicator element present');

assert(/id="donor-earnings-row"/.test(html), 'donor-earnings-row element present');
assert(/id="donor-earnings-row"[\s\S]{0,100}display:\s*none/.test(html),
       'donor-earnings-row starts hidden by default');
assert(/id="donor-earnings-indicator"/.test(html), 'donor-earnings-indicator element present');

// ─── pollBillingBalance ──────────────────────────────────────────

const balanceFnIdx = html.indexOf('async function pollBillingBalance');
assert(balanceFnIdx > 0, 'pollBillingBalance function defined');
const balanceFnEnd = html.indexOf('\nfunction ', balanceFnIdx + 1);
const balanceFnSrc = html.slice(balanceFnIdx, balanceFnEnd);
assert(/\/api\/billing\/balance\?account_id=/.test(balanceFnSrc),
       'pollBillingBalance calls the real /api/billing/balance endpoint');
assert(/encodeURIComponent\(userGuid\)/.test(balanceFnSrc),
       'pollBillingBalance uses the real client-side userGuid');
assert(/getElementById\('balance-row'\)/.test(balanceFnSrc),
       'pollBillingBalance targets the real balance-row element');
assert(/style\.display\s*=\s*'none'/.test(balanceFnSrc),
       'pollBillingBalance hides the row on 404 (billing not configured)');

// ─── pollDonorPayoutStatus ───────────────────────────────────────

const donorFnIdx = html.indexOf('async function pollDonorPayoutStatus');
assert(donorFnIdx > 0, 'pollDonorPayoutStatus function defined');
const donorFnEnd = html.indexOf('\n\n', donorFnIdx);
const donorFnSrc = html.slice(donorFnIdx, donorFnEnd);
assert(/\/payout\/status\?donor_url=/.test(donorFnSrc),
       'pollDonorPayoutStatus calls the real /payout/status endpoint');
assert(/masterUrl/.test(donorFnSrc) && /selfUrl/.test(donorFnSrc),
       'pollDonorPayoutStatus takes masterUrl/selfUrl as params (queries the Federator directly, not this realm)');
assert(/data\.linked/.test(donorFnSrc),
       'pollDonorPayoutStatus checks the linked flag before showing the row');

// ─── Wiring: renderFederationStatus triggers the donor poll ─────

const renderFedIdx = html.indexOf('function renderFederationStatus');
assert(renderFedIdx > 0, 'renderFederationStatus function found');
const renderFedNear = html.slice(renderFedIdx, renderFedIdx + 600);
assert(/pollDonorPayoutStatus\(s\.master_url,\s*s\.self_url\)/.test(renderFedNear),
       'renderFederationStatus triggers pollDonorPayoutStatus with the real federation status fields');

// ─── Auto-start ──────────────────────────────────────────────────

assert(/addEventListener\('DOMContentLoaded',\s*startBillingBalancePolling\)/.test(html),
       'startBillingBalancePolling is wired into the DOMContentLoaded auto-start, same as federation polling');

if (failCount > 0) {
  console.log(`\nFAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`\nOK: ${passCount} cockpit economic-indicator tests passed`);
}
