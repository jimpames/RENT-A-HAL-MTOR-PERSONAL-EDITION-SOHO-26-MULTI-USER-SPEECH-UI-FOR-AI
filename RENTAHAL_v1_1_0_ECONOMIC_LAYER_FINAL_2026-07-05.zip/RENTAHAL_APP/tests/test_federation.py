"""
Federation tests — matrix, check-in client, LLM provider, hop-limit.

These tests cover the entire federation layer:

  FederationMatrix — the Federator's phonebook
    - upsert creates/updates members
    - is_alive uses last_seen + missed_after_s correctly
    - effective_avg returns DEGRADED_AVG_S for stale members
    - best_peer_for returns argmin alive member, excluding self
    - best_peer_for returns None when no alive peer exists
    - peer_advice_bump rotates through equally-good peers
    - persistence round-trips through state_file
    - get_state returns HEALTHY/DEGRADED/UNKNOWN correctly

  FederationConfig — INI-driven knobs
    - from_cfg parses [Federation] correctly
    - missing keys use defaults
    - desire parses 'on'/'off'/'true'/'1'/'yes' correctly

  FederationClient — outbound check-in loop
    - start() is a no-op when desire=off
    - start() warns and stays OFF when self_url is empty
    - _do_checkin posts the right payload shape
    - successful response updates state.best_*_peer
    - failed response increments consecutive_failures
    - 4 consecutive failures → state.member_state == DEGRADED
    - successful checkin resets consecutive_failures

  FederationLLMProvider — overflow routing
    - should_federate returns False when desire=off
    - should_federate returns False when state != HEALTHY
    - should_federate returns False when local_avg < threshold
    - should_federate returns False when no best_llm_peer
    - should_federate returns False when best_llm_peer == self_url
    - should_federate returns False when allow_federation=False (hop limit)
    - is_available reads local stats correctly
    - generate sends X-Federation-Hops: 1 header
    - generate returns None on HTTP error (chain falls through)
    - generate returns None on timeout (chain falls through)
    - successful federation returns the peer's answer text

  Sentinel-based degraded handling
    - Missed-too-long member never wins best_peer_for
    - Sentinel decays back when member returns
"""
import asyncio
import json
import sys
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import (
    FederationMatrix, FederationConfig, FederationState, FederationClient,
    MemberRecord, DEGRADED_AVG_S, DEFAULTS,
)
from realm.federation_provider import FederationLLMProvider


# ─── MemberRecord ─────────────────────────────────────────────────────


def test_member_record_alive_false_for_never_seen():
    rec = MemberRecord(url="https://example.com")
    assert not rec.is_alive(now=time.monotonic(), missed_after_s=60.0)


def test_member_record_alive_within_window():
    now = time.monotonic()
    rec = MemberRecord(url="https://example.com", last_seen=now - 30)
    assert rec.is_alive(now=now, missed_after_s=60.0)


def test_member_record_alive_false_past_window():
    now = time.monotonic()
    rec = MemberRecord(url="https://example.com", last_seen=now - 120)
    assert not rec.is_alive(now=now, missed_after_s=60.0)


def test_member_record_effective_avg_sentinel_when_stale():
    now = time.monotonic()
    rec = MemberRecord(url="https://example.com", last_seen=now - 120,
                       llm_avg_s=2.0)
    assert rec.effective_avg("llm", now, 60.0) == DEGRADED_AVG_S
    assert rec.effective_avg("tts", now, 60.0) == DEGRADED_AVG_S


def test_member_record_effective_avg_real_when_alive():
    now = time.monotonic()
    rec = MemberRecord(url="https://example.com", last_seen=now,
                       llm_avg_s=2.5, tts_avg_s=1.7)
    assert rec.effective_avg("llm", now, 60.0) == 2.5
    assert rec.effective_avg("tts", now, 60.0) == 1.7


# ─── FederationMatrix ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_matrix_upsert_creates_new_member():
    m = FederationMatrix(missed_after_s=60.0)
    rec = await m.upsert("https://a.com", 2.0, 1.5, 100)
    assert rec.url == "https://a.com"
    assert rec.llm_avg_s == 2.0
    assert rec.tts_avg_s == 1.5
    assert rec.tokens_out == 100
    assert "https://a.com" in m.members


@pytest.mark.asyncio
async def test_matrix_upsert_updates_existing():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 2.0, 1.5, 100)
    rec = await m.upsert("https://a.com", 3.0, 2.0, 200)
    assert rec.llm_avg_s == 3.0
    assert len(m.members) == 1


@pytest.mark.asyncio
async def test_matrix_best_peer_returns_min_avg():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://fast.com", 1.5, 0.8, 0)
    await m.upsert("https://slow.com", 5.0, 3.0, 0)
    best = await m.best_peer_for("llm", exclude_url="https://other.com")
    assert best == "https://fast.com"


@pytest.mark.asyncio
async def test_matrix_best_peer_excludes_self():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://self.com", 1.0, 0.5, 0)   # would be best, but is self
    await m.upsert("https://other.com", 2.0, 1.0, 0)
    best = await m.best_peer_for("llm", exclude_url="https://self.com")
    assert best == "https://other.com"


@pytest.mark.asyncio
async def test_matrix_best_peer_none_when_empty():
    m = FederationMatrix(missed_after_s=60.0)
    best = await m.best_peer_for("llm", exclude_url="https://self.com")
    assert best is None


@pytest.mark.asyncio
async def test_matrix_best_peer_none_when_only_self():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://self.com", 1.0, 0.5, 0)
    best = await m.best_peer_for("llm", exclude_url="https://self.com")
    assert best is None


@pytest.mark.asyncio
async def test_matrix_stale_members_never_win():
    """Member with old last_seen must NOT be chosen even if their avg
    is smallest. The sentinel approach lets us skip the special branch."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://stale.com", 0.1, 0.1, 0)
    # Manually age it past the window
    m.members["https://stale.com"].last_seen = time.monotonic() - 120
    await m.upsert("https://fresh.com", 5.0, 5.0, 0)
    best = await m.best_peer_for("llm", exclude_url="https://other.com")
    assert best == "https://fresh.com"


@pytest.mark.asyncio
async def test_matrix_peer_advice_bump_rotates_consecutive_lookups():
    """Two peers with identical avg get rotated through. The recommended
    peer's avg is bumped slightly so the next consecutive lookup picks
    the other one."""
    m = FederationMatrix(missed_after_s=60.0, peer_advice_bump_s=0.1)
    await m.upsert("https://a.com", 2.0, 1.0, 0)
    await m.upsert("https://b.com", 2.0, 1.0, 0)
    # First lookup picks one (deterministic on dict ordering — Python 3.7+)
    first = await m.best_peer_for("llm", exclude_url="https://x.com")
    second = await m.best_peer_for("llm", exclude_url="https://x.com")
    # After the bump on `first`, `second` should be the OTHER peer
    assert first != second, \
        "peer_advice_bump did not rotate consecutive lookups"


@pytest.mark.asyncio
async def test_matrix_bump_decays_on_next_checkin():
    """The in-memory bump applied during recommendation should be
    overwritten by the peer's next genuine check-in."""
    m = FederationMatrix(missed_after_s=60.0, peer_advice_bump_s=0.5)
    await m.upsert("https://a.com", 2.0, 1.0, 0)
    await m.best_peer_for("llm", exclude_url="https://x.com")
    # After recommendation, a.com's llm_avg_s should be 2.0 + 0.5 = 2.5
    assert m.members["https://a.com"].llm_avg_s == pytest.approx(2.5)
    # New check-in overwrites the bumped value
    await m.upsert("https://a.com", 2.0, 1.0, 0)
    assert m.members["https://a.com"].llm_avg_s == 2.0


@pytest.mark.asyncio
async def test_matrix_persistence_round_trip(tmp_path):
    """Save → load round-trip preserves all member data."""
    state_file = tmp_path / "state.json"
    m1 = FederationMatrix(state_file=state_file, missed_after_s=60.0)
    await m1.upsert("https://a.com", 2.0, 1.0, 100)
    await m1.upsert("https://b.com", 3.0, 2.0, 200)
    # New matrix loads from same file
    m2 = FederationMatrix(state_file=state_file, missed_after_s=60.0)
    assert "https://a.com" in m2.members
    assert "https://b.com" in m2.members
    assert m2.members["https://a.com"].llm_avg_s == 2.0
    assert m2.members["https://b.com"].tokens_out == 200


@pytest.mark.asyncio
async def test_matrix_get_state_returns_healthy_degraded_unknown():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://fresh.com", 2.0, 1.0, 0)
    assert await m.get_state("https://fresh.com") == "HEALTHY"
    assert await m.get_state("https://unknown.com") == "UNKNOWN"
    # Age the fresh member
    m.members["https://fresh.com"].last_seen = time.monotonic() - 120
    assert await m.get_state("https://fresh.com") == "DEGRADED"


# ─── FederationConfig ─────────────────────────────────────────────────


def test_config_from_cfg_defaults_when_section_missing():
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read_string("[Other]\nfoo=bar\n")
    fc = FederationConfig.from_cfg(cfg)
    assert fc.desire is True   # default "on" → True
    assert fc.master_url == DEFAULTS["master_url"]
    assert fc.prefer_federation_for_llm_avg_s == 31.0


def test_config_from_cfg_reads_values():
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read_string("""
[Federation]
desire = on
master_url = https://my.federator/api
self_url = https://my.realm
prefer_federation_for_llm_avg_s = 45.5
checkin_interval_s = 30
""")
    fc = FederationConfig.from_cfg(cfg)
    assert fc.desire is True
    assert fc.master_url == "https://my.federator/api"
    assert fc.self_url == "https://my.realm"
    assert fc.prefer_federation_for_llm_avg_s == 45.5
    assert fc.checkin_interval_s == 30.0


@pytest.mark.parametrize("val,expected", [
    ("on", True), ("ON", True), ("true", True), ("True", True),
    ("1", True), ("yes", True), ("YES", True),
    ("off", False), ("false", False), ("0", False), ("no", False),
    ("", False),
])
def test_config_desire_parsing(val, expected):
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read_string(f"[Federation]\ndesire = {val}\n")
    fc = FederationConfig.from_cfg(cfg)
    assert fc.desire is expected, f"desire={val!r} should be {expected}"


# ─── FederationClient ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_client_start_noop_when_desire_off():
    """When desire=off, start() doesn't launch the task. No outbound
    HTTP. State stays OFF."""
    cfg = FederationConfig(desire=False, self_url="https://x")
    state = FederationState(cfg, lambda: {"llm_avg_s": 0, "tts_avg_s": 0,
                                          "tokens_out": 0})
    client = FederationClient(state)
    await client.start()
    assert client._task is None
    assert state.member_state == "OFF"


@pytest.mark.asyncio
async def test_client_start_warns_when_self_url_empty():
    cfg = FederationConfig(desire=True, self_url="")
    state = FederationState(cfg, lambda: {"llm_avg_s": 0, "tts_avg_s": 0,
                                          "tokens_out": 0})
    client = FederationClient(state)
    await client.start()
    assert client._task is None
    assert state.member_state == "OFF"


@pytest.mark.asyncio
async def test_client_do_checkin_posts_correct_payload():
    """Verify the wire shape of the check-in POST."""
    cfg = FederationConfig(
        desire=True, self_url="https://me.example",
        master_url="https://fed.example/api/federate", token="secret")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 4.2, "tts_avg_s": 1.8, "tokens_out": 1000})
    client = FederationClient(state)

    captured = {}

    class _MockResp:
        status = 200
        async def json(self):
            return {"best_llm_peer": "https://peer.example",
                    "best_tts_peer": None, "your_state": "HEALTHY"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    def mock_post(url, json=None):
        captured["url"] = url
        captured["payload"] = json
        return _MockResp()

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()

    assert captured["url"] == "https://fed.example/api/federate/checkin"
    p = captured["payload"]
    assert p["member_url"] == "https://me.example"
    assert p["llm_avg_s"] == 4.2
    assert p["tts_avg_s"] == 1.8
    assert p["tokens_out"] == 1000
    assert p["token"] == "secret"


@pytest.mark.asyncio
async def test_client_successful_checkin_updates_advice():
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {"llm_avg_s": 0, "tts_avg_s": 0,
                                          "tokens_out": 0})
    client = FederationClient(state)

    class _MockResp:
        status = 200
        async def json(self):
            return {"best_llm_peer": "https://peer.example",
                    "best_tts_peer": "https://tts.example",
                    "your_state": "HEALTHY"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        await client._do_checkin()

    assert state.best_llm_peer == "https://peer.example"
    assert state.best_tts_peer == "https://tts.example"
    assert state.member_state == "HEALTHY"
    assert state.consecutive_failures == 0


@pytest.mark.asyncio
async def test_client_failed_checkin_increments_counter():
    cfg = FederationConfig(desire=True, self_url="https://me",
                           master_url="https://nonexistent.example/api/federate",
                           degraded_after_missed_checkins=4)
    state = FederationState(cfg, lambda: {"llm_avg_s": 0, "tts_avg_s": 0,
                                          "tokens_out": 0})
    client = FederationClient(state)

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=Exception("network down")):
        await client._do_checkin()
        await client._do_checkin()
        await client._do_checkin()
        # Still HEALTHY at 3 failures (threshold is 4)
        assert state.consecutive_failures == 3
        assert state.member_state == "HEALTHY"
        await client._do_checkin()
        # Now DEGRADED
        assert state.consecutive_failures == 4
        assert state.member_state == "DEGRADED"


@pytest.mark.asyncio
async def test_client_recovery_resets_counter():
    """A successful check-in after failures resets the counter and
    returns to HEALTHY."""
    cfg = FederationConfig(desire=True, self_url="https://me",
                           master_url="https://fed/api/federate",
                           degraded_after_missed_checkins=4)
    state = FederationState(cfg, lambda: {"llm_avg_s": 0, "tts_avg_s": 0,
                                          "tokens_out": 0})
    state.consecutive_failures = 3
    state.member_state = "HEALTHY"
    client = FederationClient(state)

    class _MockResp:
        status = 200
        async def json(self):
            return {"best_llm_peer": None, "best_tts_peer": None,
                    "your_state": "HEALTHY"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        await client._do_checkin()
    assert state.consecutive_failures == 0
    assert state.member_state == "HEALTHY"


# ─── FederationLLMProvider — should_federate gate ────────────────────


def _make_provider(desire=True, state="HEALTHY", local_avg=50.0,
                   best_peer="https://peer.example",
                   self_url="https://me.example", threshold=31.0):
    cfg = FederationConfig(desire=desire, self_url=self_url,
                           prefer_federation_for_llm_avg_s=threshold)
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": local_avg, "tts_avg_s": 0, "tokens_out": 0})
    fed_state.member_state = state
    fed_state.best_llm_peer = best_peer
    return FederationLLMProvider(fed_state)


def test_provider_should_federate_happy_path():
    p = _make_provider(local_avg=50.0)
    assert p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_provider_should_federate_false_when_desire_off():
    p = _make_provider(desire=False)
    assert not p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_provider_should_federate_false_when_not_healthy():
    p = _make_provider(state="DEGRADED")
    assert not p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_provider_should_federate_false_when_local_avg_below_threshold():
    p = _make_provider(local_avg=10.0, threshold=31.0)
    assert not p.should_federate(local_llm_avg_s=10.0, allow_federation=True)


def test_provider_should_federate_false_when_no_best_peer():
    p = _make_provider(best_peer=None)
    assert not p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_provider_should_federate_false_when_peer_is_self():
    p = _make_provider(best_peer="https://me.example",
                       self_url="https://me.example")
    assert not p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_provider_should_federate_false_with_trailing_slash_self():
    """URL comparison should be slash-tolerant — these are the same realm."""
    p = _make_provider(best_peer="https://me.example/",
                       self_url="https://me.example")
    assert not p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_provider_should_federate_false_when_hops_exhausted():
    """The hop-limit check: when allow_federation=False, the provider
    must refuse to federate even if everything else looks good."""
    p = _make_provider(local_avg=50.0)
    assert not p.should_federate(local_llm_avg_s=50.0,
                                  allow_federation=False)


# ─── FederationLLMProvider — generate ────────────────────────────────


@pytest.mark.asyncio
async def test_provider_generate_sends_correct_payload_and_headers():
    captured = {}

    class _MockResp:
        status = 200
        async def json(self):
            return {"answer": "the federated reply"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    def mock_post(url, json=None, headers=None):
        captured["url"] = url
        captured["payload"] = json
        captured["headers"] = headers
        return _MockResp()

    p = _make_provider(local_avg=50.0, best_peer="https://peer.example")
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hello", allow_federation=True)

    assert result == "the federated reply"
    assert captured["url"] == "https://peer.example/api/ask"
    # Payload includes max_tokens forwarded to peer — without this, peer
    # would silently truncate every long federated answer at its chain
    # default. See test_provider_forwards_max_tokens_to_peer for the
    # invariant test.
    assert captured["payload"]["text"] == "hello"
    assert "max_tokens" in captured["payload"]
    assert captured["headers"]["X-Federation-Hops"] == "1"


@pytest.mark.asyncio
async def test_provider_generate_returns_none_on_hop_limit():
    """If allow_federation=False, generate returns None immediately —
    the chain falls through to the next provider (local LLM)."""
    p = _make_provider(local_avg=50.0)
    result = await p.generate("hello", allow_federation=False)
    assert result is None


@pytest.mark.asyncio
async def test_provider_generate_returns_none_on_http_error():
    class _ErrorResp:
        status = 500
        async def json(self):
            return {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    p = _make_provider(local_avg=50.0)
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _ErrorResp()):
        result = await p.generate("hello", allow_federation=True)
    assert result is None


@pytest.mark.asyncio
async def test_provider_generate_returns_none_on_timeout():
    p = _make_provider(local_avg=50.0)
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=asyncio.TimeoutError()):
        result = await p.generate("hello", allow_federation=True)
    assert result is None


@pytest.mark.asyncio
async def test_provider_generate_records_usage_with_federated_to():
    """last_usage must reflect that this was a federated call — so
    the cockpit / debug logs can tell."""
    class _MockResp:
        status = 200
        async def json(self):
            return {"answer": "result text"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    p = _make_provider(local_avg=50.0, best_peer="https://peer.example")
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        await p.generate("hello", allow_federation=True)

    assert p.last_usage is not None
    assert p.last_usage["federated_to"] == "https://peer.example"
    assert p.last_usage["tokens_out"] > 0


# ─── is_available reads stats correctly ──────────────────────────────


@pytest.mark.asyncio
async def test_provider_is_available_true_when_should_federate():
    p = _make_provider(local_avg=50.0)
    assert await p.is_available() is True


@pytest.mark.asyncio
async def test_provider_is_available_false_when_below_threshold():
    p = _make_provider(local_avg=10.0, threshold=31.0)
    assert await p.is_available() is False


# ─── FederationLLMFallbackProvider — RESCUE mode ────────────────────
#
# The fallback provider sits at the TAIL of the chain, between local
# providers and Echo. Different gate from the head provider: no
# threshold check. Fires when local LLM has died (chain reaches us).
# When local recovers, we never get a chance — chain returns to local
# automatically. Self-healing.


def _make_fallback_provider(desire=True, state="HEALTHY",
                             best_peer="https://peer.example",
                             self_url="https://me.example"):
    from realm.federation_provider import FederationLLMFallbackProvider
    cfg = FederationConfig(desire=desire, self_url=self_url)
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": 0, "tts_avg_s": 0, "tokens_out": 0})
    fed_state.member_state = state
    fed_state.best_llm_peer = best_peer
    return FederationLLMFallbackProvider(fed_state)


def test_fallback_should_federate_happy_path():
    """No threshold check — fallback fires whenever federation healthy
    and peer exists. The 'should fire' decision is the chain itself
    reaching us; we don't gate on local being slow."""
    p = _make_fallback_provider()
    assert p.should_federate(allow_federation=True)


def test_fallback_should_federate_false_when_desire_off():
    p = _make_fallback_provider(desire=False)
    assert not p.should_federate(allow_federation=True)


def test_fallback_should_federate_false_when_not_healthy():
    """If we can't reach the Federator, we have no peer advice we can
    trust. Better to fall through to Echo."""
    p = _make_fallback_provider(state="DEGRADED")
    assert not p.should_federate(allow_federation=True)


def test_fallback_should_federate_false_when_no_best_peer():
    p = _make_fallback_provider(best_peer=None)
    assert not p.should_federate(allow_federation=True)


def test_fallback_should_federate_false_when_peer_is_self():
    """Don't federate to ourselves — that's a hot loop."""
    p = _make_fallback_provider(best_peer="https://me.example",
                                 self_url="https://me.example")
    assert not p.should_federate(allow_federation=True)


def test_fallback_should_federate_false_with_trailing_slash_self():
    """rstrip('/') comparison catches the slash mismatch case."""
    p = _make_fallback_provider(best_peer="https://me.example/",
                                 self_url="https://me.example")
    assert not p.should_federate(allow_federation=True)


def test_fallback_should_federate_false_when_hops_exhausted():
    """Hop limit applies to the fallback provider too. A request that
    arrived via federation must NOT re-federate, even if the receiver's
    local LLM is also down — it'll fall through to Echo locally."""
    p = _make_fallback_provider()
    assert not p.should_federate(allow_federation=False)


def test_fallback_no_threshold_check_unlike_head_provider():
    """The KEY difference from FederationLLMProvider: no threshold.
    Even if local_avg is 0.1s (super fast), if the chain reaches us
    we still fire. Reaching us means earlier providers all failed."""
    from realm.federation_provider import FederationLLMFallbackProvider
    cfg = FederationConfig(
        desire=True, self_url="https://me.example",
        # Set threshold very high — head provider would never fire
        prefer_federation_for_llm_avg_s=999.0)
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": 0.1,   # very fast local; head would say "not needed"
        "tts_avg_s": 0, "tokens_out": 0})
    fed_state.member_state = "HEALTHY"
    fed_state.best_llm_peer = "https://peer.example"
    p = FederationLLMFallbackProvider(fed_state)
    # Despite local being super fast, fallback says yes — because the
    # chain only reaches us if local FAILED, not if local is slow.
    assert p.should_federate(allow_federation=True)


@pytest.mark.asyncio
async def test_fallback_is_available_when_federation_healthy():
    p = _make_fallback_provider()
    assert await p.is_available() is True


@pytest.mark.asyncio
async def test_fallback_is_available_false_when_no_peer():
    p = _make_fallback_provider(best_peer=None)
    assert await p.is_available() is False


@pytest.mark.asyncio
async def test_fallback_generate_sends_hops_header():
    """Fallback federated calls MUST include X-Federation-Hops: 1 so the
    receiver doesn't re-federate. Same hop-limit semantics as the head
    provider."""
    captured = {}

    class _MockResp:
        status = 200
        async def json(self): return {"answer": "from the peer"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    def mock_post(url, json=None, headers=None):
        captured["url"] = url
        captured["headers"] = headers
        return _MockResp()

    p = _make_fallback_provider(best_peer="https://peer.example")
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hello", allow_federation=True)
    assert result == "from the peer"
    assert captured["url"] == "https://peer.example/api/ask"
    assert captured["headers"]["X-Federation-Hops"] == "1"


@pytest.mark.asyncio
async def test_fallback_generate_returns_none_on_hop_limit():
    """If we received the request via federation (allow_federation=False),
    we MUST NOT re-federate. Return None so the chain falls to Echo."""
    p = _make_fallback_provider()
    result = await p.generate("hello", allow_federation=False)
    assert result is None


@pytest.mark.asyncio
async def test_fallback_generate_returns_none_on_http_error():
    class _ErrResp:
        status = 500
        async def json(self): return {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    p = _make_fallback_provider()
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _ErrResp()):
        result = await p.generate("hello", allow_federation=True)
    assert result is None


@pytest.mark.asyncio
async def test_fallback_generate_returns_none_on_timeout():
    """Peer didn't answer in time — return None so the chain falls to
    Echo. User gets the offline message rather than waiting forever."""
    p = _make_fallback_provider()
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=asyncio.TimeoutError()):
        result = await p.generate("hello", allow_federation=True)
    assert result is None


@pytest.mark.asyncio
async def test_fallback_records_usage_with_fallback_flag():
    """last_usage tells the operator HOW this answer came back:
    fallback=True distinguishes RESCUE (local died) from OVERFLOW (local
    slow). Useful for cockpit logs and post-mortem analysis."""
    class _MockResp:
        status = 200
        async def json(self): return {"answer": "rescued by peer"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    p = _make_fallback_provider(best_peer="https://peer.example")
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        await p.generate("hello", allow_federation=True)
    assert p.last_usage is not None
    assert p.last_usage["federated_to"] == "https://peer.example"
    assert p.last_usage["fallback"] is True


def test_fallback_provider_has_distinct_name_from_head():
    """The two federation providers must have distinct names so the
    cockpit can tell them apart in the LLM badge ('Federation (peer
    realms)' vs 'Federation Fallback (peer realms)')."""
    from realm.federation_provider import (
        FederationLLMProvider, FederationLLMFallbackProvider,
    )
    assert FederationLLMProvider.name != FederationLLMFallbackProvider.name
    assert "Fallback" in FederationLLMFallbackProvider.name


# ─── Local-LLM-Dead self-reporting (the "useless peer" bug fix) ─────
#
# When local LLM is dead but realm is answering via federation fallback,
# the rolling llm_avg_s reflects FEDERATED latency (e.g. 20s). That's
# "healthy enough" to be advertised as a peer in the matrix — but the
# realm can't actually serve federation traffic (receiver's federation
# is hop-blocked). Other realms federating to it would either get an
# Echo "no LLM" response or fail entirely.
#
# Fix: the realm self-reports llm_avg_s = DEGRADED_AVG_S (1000.0) when
# its local LLM is unavailable. Existing best_peer_for logic already
# excludes high-avg members, so no protocol change needed.


def test_metrics_local_llm_available_defaults_to_true():
    """Optimistic default — at boot, before detect() runs, assume our
    local LLM works. Better to mis-advertise once and self-correct than
    to refuse to participate at all."""
    from realm.orchestrator import Metrics
    m = Metrics()
    assert m.local_llm_available is True


def test_metrics_set_local_llm_available_is_idempotent():
    from realm.orchestrator import Metrics
    m = Metrics()
    m.set_local_llm_available(False)
    assert m.local_llm_available is False
    m.set_local_llm_available(False)   # same value, no side effects
    assert m.local_llm_available is False
    m.set_local_llm_available(True)
    assert m.local_llm_available is True


def test_metrics_set_local_llm_available_coerces_to_bool():
    """Defensive: caller might pass truthy non-bool (e.g. result of an
    'any()' generator). Coerce to bool so the flag never holds a weird
    type that confuses downstream code."""
    from realm.orchestrator import Metrics
    m = Metrics()
    m.set_local_llm_available(1)       # truthy int
    assert m.local_llm_available is True
    m.set_local_llm_available(0)       # falsy int
    assert m.local_llm_available is False
    m.set_local_llm_available("yes")   # truthy string
    assert m.local_llm_available is True


# ─── The actual stats adapter behavior (simulated) ──────────────────


class _MockMetrics:
    """Minimal stand-in for orchestrator.metrics in stats-adapter tests."""
    def __init__(self, llm_avg=0.0, tts_avg=0.0, tokens=0,
                 local_llm_available=True):
        self.ai_avg_service_s = llm_avg
        self.tts_avg_service_s = tts_avg
        self.total_tokens_out = tokens
        self.local_llm_available = local_llm_available


def _stats_adapter(metrics) -> dict:
    """Mirrors the _federation_stats closure in app.py. Kept in sync
    by the integration test in test_app_federation_stats_uses_metrics
    (which fails if these diverge)."""
    llm_avg = (float(metrics.ai_avg_service_s or 0.0)
               if metrics.local_llm_available
               else DEGRADED_AVG_S)
    return {
        "llm_avg_s": llm_avg,
        "tts_avg_s": float(metrics.tts_avg_service_s or 0.0),
        "tokens_out": int(metrics.total_tokens_out),
    }


def test_stats_adapter_reports_real_avg_when_local_alive():
    """The common case: local LLM working, report the real rolling avg."""
    metrics = _MockMetrics(llm_avg=3.5, local_llm_available=True)
    stats = _stats_adapter(metrics)
    assert stats["llm_avg_s"] == 3.5


def test_stats_adapter_reports_sentinel_when_local_dead():
    """The bug fix: when local LLM is dead, report DEGRADED_AVG_S so
    peers don't route to us. Even though rolling avg might LOOK
    reasonable (e.g. 20s because federated fallback is keeping it down)
    — we can't serve federation traffic."""
    metrics = _MockMetrics(llm_avg=20.5, local_llm_available=False)
    stats = _stats_adapter(metrics)
    assert stats["llm_avg_s"] == DEGRADED_AVG_S
    assert stats["llm_avg_s"] >= 1000.0   # sentinel must be at the floor


def test_stats_adapter_unaffected_tts_avg_regardless_of_llm_health():
    """TTS health is independent of LLM health. The bug fix changes only
    llm_avg_s; tts_avg_s passes through unchanged so realms can still
    serve TTS federation even when their local LLM is down."""
    metrics = _MockMetrics(llm_avg=20.5, tts_avg=1.2, local_llm_available=False)
    stats = _stats_adapter(metrics)
    assert stats["llm_avg_s"] == DEGRADED_AVG_S       # LLM sentinel
    assert stats["tts_avg_s"] == 1.2                   # TTS unaffected


def test_stats_adapter_tokens_pass_through_regardless_of_health():
    """Cumulative tokens-out is a count of work done, not a health
    signal. It passes through unchanged."""
    metrics = _MockMetrics(tokens=12345, local_llm_available=False)
    stats = _stats_adapter(metrics)
    assert stats["tokens_out"] == 12345


# ─── End-to-end: dead realm gets deprioritized in best_peer_for ─────


@pytest.mark.asyncio
async def test_dead_local_member_naturally_loses_in_best_peer_for():
    """The full bug-fix proof: a member self-reporting the sentinel
    (because their local LLM is dead) MUST NOT win best_peer_for over
    a healthy member. This is what makes the fix work end-to-end —
    we don't need a new protocol field; the sentinel + existing argmin
    do the job."""
    m = FederationMatrix(missed_after_s=60.0)
    # Healthy realm: alive, real-ish avg
    await m.upsert("https://healthy.example", llm_avg_s=3.2,
                   tts_avg_s=1.0, tokens_out=100)
    # Dead-local realm: alive (still checking in) but self-reports sentinel
    await m.upsert("https://dead-local.example", llm_avg_s=DEGRADED_AVG_S,
                   tts_avg_s=1.0, tokens_out=200)
    # Any third party asking for the best LLM peer gets healthy.example
    best = await m.best_peer_for("llm", exclude_url="https://asker.example")
    assert best == "https://healthy.example", \
        "Member self-reporting DEGRADED_AVG_S must lose to healthy peer"


@pytest.mark.asyncio
async def test_dead_local_member_can_still_consume_federation():
    """The other half of the fix: a member with dead local LLM can STILL
    receive peer advice from the Federator. They just can't be ADVISED
    to OTHERS. They borrow but can't lend."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://healthy.example", llm_avg_s=3.2,
                   tts_avg_s=1.0, tokens_out=100)
    await m.upsert("https://dead-local.example", llm_avg_s=DEGRADED_AVG_S,
                   tts_avg_s=1.0, tokens_out=200)
    # The dead realm asks: who can I borrow from?
    best = await m.best_peer_for("llm",
                                 exclude_url="https://dead-local.example")
    # They get the healthy peer (themselves excluded; sentinel doesn't
    # matter for the exclusion path).
    assert best == "https://healthy.example"


# ─── Pre-flight local probe (the "sanity check before federating" fix)
#
# Both federation providers gain a pre-flight probe: before firing the
# federated HTTP call, they probe local LLM via chain.probe_local().
# On probe success: call the recovery callback (clears stale rolling
# window, fires immediate Federator check-in, broadcasts cockpit flash)
# and return None so the chain falls through to local.
#
# Fixes the race where rolling avg stays elevated from recent federated
# calls even after local LLM recovers, causing federation to keep firing
# when local would have served the query.


@pytest.mark.asyncio
async def test_llm_head_probe_calls_recovery_when_local_alive():
    """The crucial fix: head provider's pre-flight probe finds local
    LLM responding → call recovery callback → return None (chain
    falls through to local). This is what makes peering rock solid."""
    from realm.federation_provider import FederationLLMProvider
    recovered_with = []

    async def recovery(provider_name):
        recovered_with.append(provider_name)

    p = _make_provider(local_avg=50.0)
    mock_local = MagicMock()
    mock_local.name = "GPT4All (Llama 3 8B Instruct)"
    mock_chain = MagicMock()
    mock_chain.probe_local = AsyncMock(return_value=mock_local)
    p.attach(mock_chain, recovery)

    result = await p.generate("hello", allow_federation=True)
    assert result is None, "Must return None so chain falls to local"
    assert recovered_with == ["GPT4All (Llama 3 8B Instruct)"]


@pytest.mark.asyncio
async def test_llm_head_probe_proceeds_with_federation_when_local_dead():
    """When the probe finds local LLM dead, proceed with federated call."""
    from realm.federation_provider import FederationLLMProvider
    recovered_with = []
    async def recovery(name):
        recovered_with.append(name)

    p = _make_provider(local_avg=50.0)
    mock_chain = MagicMock()
    mock_chain.probe_local = AsyncMock(return_value=None)
    p.attach(mock_chain, recovery)

    class _MockResp:
        status = 200
        async def json(self): return {"answer": "from peer"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await p.generate("hello", allow_federation=True)
    assert result == "from peer"
    assert recovered_with == []


@pytest.mark.asyncio
async def test_llm_head_probe_callback_failure_does_not_block_query():
    """Recovery callback raising must not break the query path."""
    from realm.federation_provider import FederationLLMProvider
    async def bad_recovery(name):
        raise RuntimeError("Federator unreachable")

    p = _make_provider(local_avg=50.0)
    mock_local = MagicMock()
    mock_local.name = "GPT4All"
    mock_chain = MagicMock()
    mock_chain.probe_local = AsyncMock(return_value=mock_local)
    p.attach(mock_chain, bad_recovery)

    # Should not raise — returns None for chain fallthrough
    result = await p.generate("hello", allow_federation=True)
    assert result is None


@pytest.mark.asyncio
async def test_llm_fallback_probe_calls_recovery_when_local_alive():
    """Tail provider's probe is belt-and-suspenders — one last probe
    before the rescue federated call. Same recovery side effects."""
    from realm.federation_provider import FederationLLMFallbackProvider
    recovered_with = []
    async def recovery(name):
        recovered_with.append(name)

    p = _make_fallback_provider()
    mock_local = MagicMock()
    mock_local.name = "GPT4All"
    mock_chain = MagicMock()
    mock_chain.probe_local = AsyncMock(return_value=mock_local)
    p.attach(mock_chain, recovery)

    result = await p.generate("hello", allow_federation=True)
    assert result is None
    assert recovered_with == ["GPT4All"]


@pytest.mark.asyncio
async def test_llm_head_no_probe_when_chain_not_attached():
    """Backward compat: provider works even if attach() never called."""
    from realm.federation_provider import FederationLLMProvider
    p = _make_provider(local_avg=50.0)
    # No attach()

    class _MockResp:
        status = 200
        async def json(self): return {"answer": "from peer"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await p.generate("hello", allow_federation=True)
    assert result == "from peer"


# ─── FederationClient.immediate_checkin ────────────────────────────


@pytest.mark.asyncio
async def test_immediate_checkin_fires_out_of_band():
    """The recovery callback uses immediate_checkin() to update the
    Federator's matrix BEFORE the next 15s scheduled check-in. Verify
    it actually posts."""
    posts = []

    class _MockResp:
        status = 200
        async def json(self):
            return {"best_llm_peer": None, "best_tts_peer": None,
                    "your_state": "HEALTHY"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    def mock_post(url, json=None):
        posts.append({"url": url, "body": json})
        return _MockResp()

    cfg = FederationConfig(desire=True, self_url="https://me",
                           master_url="https://fed/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 2.0, "tts_avg_s": 1.0, "tokens_out": 50})
    client = FederationClient(state)

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        ok = await client.immediate_checkin()

    assert ok is True
    assert len(posts) == 1
    assert posts[0]["url"] == "https://fed/api/federate/checkin"


@pytest.mark.asyncio
async def test_immediate_checkin_noop_when_desire_off():
    """If federation desire is off, immediate_checkin must not POST.
    The realm has opted out of federation entirely."""
    posts = []
    cfg = FederationConfig(desire=False, self_url="https://me",
                           master_url="https://fed/api/federate")
    state = FederationState(cfg, lambda: {"llm_avg_s": 0, "tts_avg_s": 0,
                                          "tokens_out": 0})
    client = FederationClient(state)

    import aiohttp
    def mock_post(*a, **kw):
        posts.append(a)
        raise AssertionError("should not have posted")
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        ok = await client.immediate_checkin()

    assert ok is False
    assert len(posts) == 0


@pytest.mark.asyncio
async def test_immediate_checkin_noop_when_self_url_empty():
    """self_url unset means we participate as consumer only — and even
    consumers don't push proactively. immediate_checkin must noop."""
    posts = []
    cfg = FederationConfig(desire=True, self_url="",
                           master_url="https://fed/api/federate")
    state = FederationState(cfg, lambda: {"llm_avg_s": 0, "tts_avg_s": 0,
                                          "tokens_out": 0})
    client = FederationClient(state)
    import aiohttp
    def mock_post(*a, **kw):
        posts.append(a)
        raise AssertionError("should not have posted")
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        ok = await client.immediate_checkin()
    assert ok is False


# ─── Stats adapter — TTS sentinel reporting ────────────────────────


def test_stats_adapter_reports_tts_sentinel_when_local_tts_dead():
    """Same fix as LLM, applied to TTS: when local TTS is dead, the
    rolling tts_avg_s reflects federated synth latency (round trip),
    which would otherwise look 'healthy' to other realms. Report
    DEGRADED_AVG_S so peers route TTS elsewhere."""
    class _M:
        ai_avg_service_s = 3.5
        tts_avg_service_s = 5.0
        total_tokens_out = 100
        local_llm_available = True
        local_tts_available = False
    metrics = _M()
    # Inline mirror of _federation_stats adapter (now with TTS sentinel)
    llm_avg = (float(metrics.ai_avg_service_s or 0.0)
               if metrics.local_llm_available
               else DEGRADED_AVG_S)
    tts_avg = (float(metrics.tts_avg_service_s or 0.0)
               if metrics.local_tts_available
               else DEGRADED_AVG_S)
    assert llm_avg == 3.5
    assert tts_avg == DEGRADED_AVG_S


def test_stats_adapter_reports_real_tts_avg_when_local_tts_alive():
    class _M:
        ai_avg_service_s = 3.5
        tts_avg_service_s = 1.2
        total_tokens_out = 100
        local_llm_available = True
        local_tts_available = True
    metrics = _M()
    tts_avg = (float(metrics.tts_avg_service_s or 0.0)
               if metrics.local_tts_available
               else DEGRADED_AVG_S)
    assert tts_avg == 1.2


def test_stats_adapter_llm_tts_independent_sentinels():
    """LLM dead doesn't poison TTS reporting and vice versa.
    Realms can serve as TTS peer while LLM is down, or vice versa."""
    class _M:
        ai_avg_service_s = 20.0
        tts_avg_service_s = 1.0
        total_tokens_out = 100
        local_llm_available = False    # LLM dead
        local_tts_available = True     # TTS fine
    metrics = _M()
    llm_avg = (float(metrics.ai_avg_service_s or 0.0)
               if metrics.local_llm_available
               else DEGRADED_AVG_S)
    tts_avg = (float(metrics.tts_avg_service_s or 0.0)
               if metrics.local_tts_available
               else DEGRADED_AVG_S)
    assert llm_avg == DEGRADED_AVG_S
    assert tts_avg == 1.0


# ─── max_tokens forwarding across federation (the I Love Lucy bug fix) ─


@pytest.mark.asyncio
async def test_provider_forwards_max_tokens_to_peer():
    """The fix for the silent truncation bug. Without max_tokens in the
    POST body, the receiving peer's /api/ask uses its chain default
    (400) and every long federated answer gets cut off mid-sentence
    (the I Love Lucy / Apollo program / etc. cases).

    Verifies the actual value, not just presence — a bug that sent
    a hardcoded number would also be wrong."""
    captured = {}
    class _MockResp:
        status = 200
        async def json(self): return {"answer": "full answer"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    def mock_post(url, json=None, headers=None):
        captured["payload"] = json
        return _MockResp()

    p = _make_provider(local_avg=50.0)
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await p.generate("tell me everything", max_tokens=1500,
                         allow_federation=True)

    assert captured["payload"]["max_tokens"] == 1500, (
        "max_tokens must be forwarded EXACTLY — peer uses this value as "
        "its chain's max_tokens. If the realm caller asked for 1500 and "
        "we send 400, every long federated answer truncates.")


@pytest.mark.asyncio
async def test_fallback_provider_forwards_max_tokens_to_peer():
    """Same bug, same fix, on the tail-end Fallback provider. The
    fallback path is what served the I Love Lucy query (RNL had its
    local LLM dead, so the fallback fired). Both providers must
    forward max_tokens."""
    captured = {}
    class _MockResp:
        status = 200
        async def json(self): return {"answer": "long answer"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    def mock_post(url, json=None, headers=None):
        captured["payload"] = json
        return _MockResp()

    p = _make_fallback_provider()
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await p.generate("tell me everything", max_tokens=1500,
                         allow_federation=True)

    assert captured["payload"]["max_tokens"] == 1500


@pytest.mark.asyncio
async def test_provider_forwards_caller_chosen_max_tokens():
    """Whatever the caller passes is what the peer receives. The
    federation provider doesn't override or cap — that's the peer's
    /api/ask job (so a Little Johnny caller can't bypass our ceiling)."""
    captured = {}
    class _MockResp:
        status = 200
        async def json(self): return {"answer": "x"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    def mock_post(url, json=None, headers=None):
        captured["payload"] = json
        return _MockResp()

    p = _make_provider(local_avg=50.0)
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        # Default chain value (400) should be forwarded if no override
        await p.generate("hi", allow_federation=True)
    assert captured["payload"]["max_tokens"] == 400


def test_orchestrator_passes_max_response_tokens_to_llm_generate():
    """Source-level wiring check: the orchestrator's LLM call MUST pass
    max_tokens=self.max_response_tokens. Without this, every query goes
    through the chain with the function default (400), regardless of
    what's configured."""
    import inspect
    import realm.orchestrator as orch_mod
    src = inspect.getsource(orch_mod)
    # The actual call site at the end of _execute (or similar)
    assert "self.llm.generate(text, max_tokens=self.max_response_tokens)" in src, (
        "Orchestrator must call llm.generate with max_tokens="
        "self.max_response_tokens. Without this, the chain's hardcoded "
        "400 default truncates every long answer.")


# ─── /api/ask caps inbound max_tokens at ceiling ─────────────────────


def test_api_ask_caps_inbound_max_tokens_at_ceiling():
    """Source-level invariant: /api/ask must cap payload.max_tokens
    at our configured ceiling. Without the cap, a Little Johnny caller
    could request 100,000 tokens and pin the GPU. With the cap, we
    serve at most max_response_tokens regardless of what's requested."""
    app_py = Path(__file__).resolve().parent.parent / "app.py"
    src = app_py.read_text()
    # The cap is the call to min() between requested and ceiling
    assert "min(requested, ceiling)" in src, (
        "/api/ask must cap requested max_tokens at the configured ceiling. "
        "Without this, federation callers can request unbounded tokens.")
    # The handler must read from the inbound payload
    assert 'payload.get("max_tokens"' in src, (
        "/api/ask must read max_tokens from the request body. Without "
        "this, federated calls fall back to the chain default and "
        "long answers truncate.")


def test_api_ask_reads_ceiling_from_config():
    """The ceiling itself must come from config.ini [LLMChain]
    max_response_tokens, not be hardcoded. Otherwise operators can't
    tune it without code changes."""
    app_py = Path(__file__).resolve().parent.parent / "app.py"
    src = app_py.read_text()
    assert 'cfg_get(cfg, "LLMChain",\n                                       "max_response_tokens"' in src \
           or 'cfg_get(cfg, "LLMChain", "max_response_tokens"' in src, (
        "Ceiling must be read from [LLMChain] max_response_tokens in "
        "config.ini.")


# ─── Degraded watchdog integration with federation providers ────────


def test_head_provider_refuses_to_federate_when_degraded():
    """The critical invariant: once the watchdog is degraded, the head
    federation provider returns False from should_federate, forcing the
    chain to fall through. Without this gate, a dead-local realm would
    federate forever and the operator would never know."""
    from realm.degraded_tracker import DegradedTracker
    p = _make_provider(local_avg=50.0)
    tracker = DegradedTracker(chain_label="LLM", degraded_after_s=10.0)
    # Force degraded state manually for the test
    tracker._is_degraded_cached = True
    p._degraded_tracker = tracker
    # All other conditions normally allow federation, but degraded gate trips
    assert not p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_head_provider_federates_normally_when_not_degraded():
    """Healthy tracker doesn't change behavior — federation works as
    designed when not degraded."""
    from realm.degraded_tracker import DegradedTracker
    p = _make_provider(local_avg=50.0)
    tracker = DegradedTracker(chain_label="LLM", degraded_after_s=300.0)
    p._degraded_tracker = tracker
    # Tracker is fresh, not degraded
    assert p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_head_provider_without_tracker_works_as_before():
    """Backward compat: providers constructed without a tracker behave
    exactly as before (no tracker check). This is important for
    existing tests that don't know about the watchdog."""
    p = _make_provider(local_avg=50.0)
    assert p._degraded_tracker is None
    assert p.should_federate(local_llm_avg_s=50.0, allow_federation=True)


def test_fallback_provider_refuses_to_federate_when_degraded():
    """Same gate semantics on the fallback path. Both providers must
    refuse so the chain falls through to Echo, not to peer→peer→peer."""
    from realm.degraded_tracker import DegradedTracker
    p = _make_fallback_provider()
    tracker = DegradedTracker(chain_label="LLM", degraded_after_s=10.0)
    tracker._is_degraded_cached = True
    p._degraded_tracker = tracker
    assert not p.should_federate(allow_federation=True)


def test_attach_with_tracker_wires_correctly():
    """The attach() method wires the tracker reference. Late binding
    is needed because the tracker is constructed alongside the chain
    in app.py, after the federation providers are instantiated."""
    from realm.degraded_tracker import DegradedTracker
    p = _make_provider(local_avg=50.0)
    tracker = DegradedTracker(chain_label="LLM", degraded_after_s=300.0)
    p.attach(chain=None, on_local_recovery=None, degraded_tracker=tracker)
    assert p._degraded_tracker is tracker
