// run_privacy_beacon_test.js — verifies the privacy beacon helpers
// and the wake-duration-default wiring in index.html.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else { console.log('FAIL: ' + label); failCount++; }
}

// ─── Privacy beacon: functions exist ───────────────────────────

assert(/function\s+startPrivacyBeacon\s*\(/.test(html),
       "startPrivacyBeacon() function defined");
assert(/function\s+stopPrivacyBeacon\s*\(/.test(html),
       "stopPrivacyBeacon() function defined");

// ─── Beacon is called from startWake / stopWake ────────────────

const startWakeIdx = html.indexOf('async function startWake');
const startWakeEnd = html.indexOf('\nfunction stopWake', startWakeIdx);
const startWakeBody = html.slice(startWakeIdx, startWakeEnd);
assert(/startPrivacyBeacon\(\)/.test(startWakeBody),
       "startWake() calls startPrivacyBeacon()");

const stopWakeIdx = html.indexOf('function stopWake');
const stopWakeEnd = html.indexOf('\n}\n', stopWakeIdx + 50);
const stopWakeBody = html.slice(stopWakeIdx, stopWakeEnd + 1);
assert(/stopPrivacyBeacon\(\)/.test(stopWakeBody),
       "stopWake() calls stopPrivacyBeacon()");

// ─── Beacon uses Web Speech Synthesis (browser, not server) ─────

const beaconIdx = html.indexOf('function startPrivacyBeacon');
const beaconBody = html.slice(beaconIdx, beaconIdx + 2000);
assert(/speechSynthesis/.test(beaconBody),
       "Beacon uses window.speechSynthesis (browser-native, zero cost)");
assert(/SpeechSynthesisUtterance/.test(beaconBody),
       "Beacon creates SpeechSynthesisUtterance");
assert(/Rent A Hal/.test(beaconBody),
       "Beacon utterance text is 'Rent A Hal'");
assert(/0\.25|\.25/.test(beaconBody),
       "Beacon volume is 0.25 (~25%) as specified");

// ─── Beacon honors config: on/off and interval ─────────────────

assert(/privacy_beacon/.test(beaconBody),
       "Beacon reads privacy_beacon flag from config");
assert(/privacy_beacon_seconds/.test(beaconBody),
       "Beacon reads privacy_beacon_seconds from config");
assert(/RENTAHAL_CONFIG/.test(beaconBody),
       "Beacon reads from window.RENTAHAL_CONFIG");

// ─── Beacon stops cleanly ──────────────────────────────────────

const stopBeaconIdx = html.indexOf('function stopPrivacyBeacon');
const stopBeaconBody = html.slice(stopBeaconIdx, stopBeaconIdx + 600);
assert(/clearInterval/.test(stopBeaconBody),
       "stopPrivacyBeacon clears the interval");
assert(/speechSynthesis.*cancel|cancel\(\)/.test(stopBeaconBody),
       "stopPrivacyBeacon cancels any pending utterance");

// ─── Wake duration: configured default applied on enable ───────

assert(/wake_word_duration/.test(startWakeBody),
       "startWake reads wake_word_duration from config");
assert(/setWakeTimer\s*\(/.test(startWakeBody),
       "startWake invokes setWakeTimer with the configured value");

// ─── window.RENTAHAL_CONFIG populated from /api/config ──────────

assert(/window\.RENTAHAL_CONFIG\s*=\s*CFG/.test(html),
       "window.RENTAHAL_CONFIG populated from /api/config response");

// ─── Tagline rendered from branding ────────────────────────────

assert(/{%\s*if\s+b\.tagline\s*%}.*beta-banner.*{{\s*b\.tagline\s*}}/s.test(html),
       "Tagline conditionally rendered from b.tagline");

// ─── Summary ────────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} privacy beacon / wake duration tests passed`);
  process.exit(0);
}
