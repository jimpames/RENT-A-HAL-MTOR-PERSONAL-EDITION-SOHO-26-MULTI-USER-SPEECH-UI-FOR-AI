// run_imagine_panel_test.js — verify the browser-side imagine panel and
// shared easter-egg video panel logic.
//
// Architecture invariants this test LOCKS IN:
//   - 'bus_imagine_result' opens the imagine panel with a real image
//   - 'bus_easter_egg_video' opens the SHARED easter-egg panel (Vision's
//     Magoo floor and Imagine's rickroll floor both route through it)
//   - Both panels participate in nukeAllCardPanels() mutual exclusion
//   - The easter-egg video ID is format-checked (11 chars) same as music
//   - stop_stop clears the easter-egg iframe too (it's YouTube, same
//     halt-by-removal mechanism as the music panel)
//   - imagine_result never gets treated as an easter egg and vice versa

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Panel HTML exists ─────────────────────────────────────────

assert(/<div id="imagine-panel"/.test(html), 'imagine panel div present');
assert(/id="imagine-image-container"/.test(html), 'imagine image container present');
assert(/id="imagine-status"/.test(html), 'imagine status line present');

assert(/<div id="easter-egg-panel"/.test(html), 'easter-egg panel div present');
assert(/id="easter-egg-video-container"/.test(html), 'easter-egg video container present');
assert(/id="easter-egg-label"/.test(html), 'easter-egg label present');

// ─── bus_imagine_result wiring ──────────────────────────────────

assert(/case 'bus_imagine_result'/.test(html),
       'WebSocket handler for bus_imagine_result exists');
assert(/openImaginePanel/.test(html), 'openImaginePanel referenced');

const imagineCaseMatch = html.match(
  /case 'bus_imagine_result'[\s\S]{0,500}break;/);
assert(imagineCaseMatch, 'bus_imagine_result case block found');
if (imagineCaseMatch) {
  assert(/nukeAllCardPanels/.test(imagineCaseMatch[0]),
         'bus_imagine_result clears other panels first (mutual exclusion)');
}

// ─── bus_easter_egg_video wiring ────────────────────────────────

assert(/case 'bus_easter_egg_video'/.test(html),
       'WebSocket handler for bus_easter_egg_video exists');
assert(/openEasterEggPanel/.test(html), 'openEasterEggPanel referenced');

const eggCaseMatch = html.match(
  /case 'bus_easter_egg_video'[\s\S]{0,800}break;/);
assert(eggCaseMatch, 'bus_easter_egg_video case block found');
if (eggCaseMatch) {
  assert(/nukeAllCardPanels/.test(eggCaseMatch[0]),
         'bus_easter_egg_video clears other panels first (mutual exclusion)');
}

// ─── openImaginePanel implementation ────────────────────────────

const imagineFnMatch = html.match(
  /function openImaginePanel[\s\S]{0,2200}?\n\}/);
assert(imagineFnMatch, 'openImaginePanel function exists');
if (imagineFnMatch) {
  const body = imagineFnMatch[0];
  assert(/destroyAndRecreate\('imagine-image-container'\)/.test(body),
         'openImaginePanel destroys BEFORE rendering (same discipline as music)');
  assert(/data:image\/png;base64,/.test(body),
         'renders a base64 PNG data URL');
  assert(/if \(!imageB64\)/.test(body),
         'handles missing image data gracefully');
}

// ─── openEasterEggPanel implementation ──────────────────────────

const eggFnMatch = html.match(
  /function openEasterEggPanel[\s\S]{0,2800}?\n\}/);
assert(eggFnMatch, 'openEasterEggPanel function exists');
if (eggFnMatch) {
  const body = eggFnMatch[0];
  assert(/destroyAndRecreate\('easter-egg-video-container'\)/.test(body),
         'openEasterEggPanel destroys BEFORE rendering');
  assert(/youtube\.com\/embed\//.test(body),
         'uses canonical youtube.com/embed/<id> path (same as music)');
  assert(/\^\[A-Za-z0-9_-\]\{11\}\$/.test(body),
         'validates video_id format (11 chars) same as music panel');
  assert(/source === 'vision'/.test(body),
         'label text branches on source: vision vs imagine');
}

// ─── Shared event, not two separate ones (the actual design goal) ──

assert(!/case 'bus_vision_easter_egg'/.test(html) &&
       !/case 'bus_imagine_easter_egg'/.test(html),
       'no separate per-realm easter-egg event exists — must be the ' +
       'single shared bus_easter_egg_video',
       'vision and imagine floors must share ONE client code path');

// ─── stop_stop halts the easter-egg iframe too ──────────────────

const stopCaseMatch = html.match(
  /case 'bus_intent_stop'[\s\S]{0,2000}break;/);
assert(stopCaseMatch, 'bus_intent_stop case exists');
if (stopCaseMatch) {
  assert(/easter-egg-video-container/.test(stopCaseMatch[0]),
         'STOP STOP clears the easter-egg iframe (it is YouTube too)');
}

// ─── nukeAllCardPanels covers the new panels ────────────────────

const nukeFnMatch = html.match(
  /function nukeAllCardPanels[\s\S]{0,3000}?\n\}/);
assert(nukeFnMatch, 'nukeAllCardPanels function found');
if (nukeFnMatch) {
  const body = nukeFnMatch[0];
  assert(/imagine-panel/.test(body),
         'nukeAllCardPanels closes the imagine panel');
  assert(/easter-egg-panel/.test(body),
         'nukeAllCardPanels closes the easter-egg panel');
}

// ─── hide/close buttons wired ───────────────────────────────────

assert(/onclick="hideImagine\(\)"/.test(html),
       'imagine panel close button wired');
assert(/onclick="hideEasterEgg\(\)"/.test(html),
       'easter-egg panel close button wired');

// ─── Summary ─────────────────────────────────────────────────

if (failCount > 0) {
  console.log(`\nFAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`\nOK: ${passCount} imagine/easter-egg panel tests passed`);
}
