"""
test_engine_chain_imagine.py — ImagineChain provider fall-through,
probe_local, and build_imagine_chain factory.

Same shape as test_engine_chain_vision.py / test_chain_probe.py.
"""
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.engine_chain import (
    ImagineChain, EchoImagineProvider, Automatic1111Provider,
    build_imagine_chain,
)


# ─── Helpers ───────────────────────────────────────────────────────

def _make_provider(name, available, generate_result=None, raises=None):
    p = MagicMock()
    p.name = name
    p.is_available = AsyncMock(return_value=available)
    if raises is not None:
        p.generate = AsyncMock(side_effect=raises)
    else:
        p.generate = AsyncMock(return_value=generate_result)
    return p


FAKE_PNG_B64 = "aWFtYWZha2Vwbmc="   # "iamafakepng"


# ─── EchoImagineProvider ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_echo_imagine_always_available():
    p = EchoImagineProvider()
    assert await p.is_available() is True


@pytest.mark.asyncio
async def test_echo_imagine_returns_decodable_stub():
    import base64
    p = EchoImagineProvider()
    result = await p.generate("a kitten")
    assert result is not None
    # Must be valid base64 that decodes to PNG magic bytes
    raw = base64.b64decode(result)
    assert raw[:8] == b"\x89PNG\r\n\x1a\n"


def test_echo_imagine_exposes_rickroll_easter_egg_id():
    """Sprint 4's orchestrator routes the imagine floor through the same
    YouTube-iframe mechanism the Music intent already uses. This constant
    is the contract between engine_chain.py and that future wiring —
    pin it so nobody accidentally breaks it as the codebase grows."""
    assert EchoImagineProvider.RICKROLL_YOUTUBE_ID == "dQw4w9WgXcQ"


# ─── ImagineChain.generate — fall-through ──────────────────────────

@pytest.mark.asyncio
async def test_generate_uses_first_available_provider():
    chain = ImagineChain([
        _make_provider("Automatic1111 (txt2img)", True, generate_result=FAKE_PNG_B64),
        _make_provider("Echo Imagine (offline fallback)", True, generate_result="never reached"),
    ])
    result = await chain.generate("a kitten wearing a hat")
    assert result == FAKE_PNG_B64
    assert chain.last_provider == "Automatic1111 (txt2img)"


@pytest.mark.asyncio
async def test_generate_falls_through_on_unavailable():
    chain = ImagineChain([
        _make_provider("Automatic1111 (txt2img)", False),
        _make_provider("Echo Imagine (offline fallback)", True, generate_result=FAKE_PNG_B64),
    ])
    result = await chain.generate("a kitten")
    assert result == FAKE_PNG_B64
    assert chain.last_provider == "Echo Imagine (offline fallback)"


@pytest.mark.asyncio
async def test_generate_falls_through_on_none_result():
    chain = ImagineChain([
        _make_provider("Automatic1111 (txt2img)", True, generate_result=None),
        _make_provider("Echo Imagine (offline fallback)", True, generate_result=FAKE_PNG_B64),
    ])
    result = await chain.generate("a kitten")
    assert result == FAKE_PNG_B64


@pytest.mark.asyncio
async def test_generate_falls_through_on_exception():
    chain = ImagineChain([
        _make_provider("Automatic1111 (txt2img)", True, raises=RuntimeError("VRAM OOM")),
        _make_provider("Echo Imagine (offline fallback)", True, generate_result=FAKE_PNG_B64),
    ])
    result = await chain.generate("a kitten")
    assert result == FAKE_PNG_B64


@pytest.mark.asyncio
async def test_generate_all_unavailable_returns_none():
    """Unlike Vision/LLM, Imagine has no text floor message to fall back
    to — if literally nothing is available (no providers configured at
    all), generate() returns None and the orchestrator handler is
    responsible for the spoken apology, same as TTSChain.synth()."""
    chain = ImagineChain([
        _make_provider("Automatic1111 (txt2img)", False),
    ])
    result = await chain.generate("a kitten")
    assert result is None
    assert chain.last_provider == "none"


@pytest.mark.asyncio
async def test_generate_passes_prompt_through():
    provider = _make_provider("Automatic1111 (txt2img)", True, generate_result=FAKE_PNG_B64)
    chain = ImagineChain([provider])
    await chain.generate("a watercolor mountain")
    provider.generate.assert_awaited_once_with("a watercolor mountain")


# ─── ImagineChain.probe_local ───────────────────────────────────────

@pytest.mark.asyncio
async def test_imagine_probe_returns_first_available_local():
    chain = ImagineChain([
        _make_provider("Automatic1111 (txt2img)", True),
        _make_provider("Echo Imagine (offline fallback)", True),
    ])
    result = await chain.probe_local()
    assert result is not None
    assert result.name == "Automatic1111 (txt2img)"


@pytest.mark.asyncio
async def test_imagine_probe_skips_echo():
    chain = ImagineChain([
        _make_provider("Echo Imagine (offline fallback)", True),
    ])
    result = await chain.probe_local()
    assert result is None


@pytest.mark.asyncio
async def test_imagine_probe_tolerates_exceptions():
    chain = ImagineChain([
        _make_provider("Broken Provider", True),
        _make_provider("Automatic1111 (txt2img)", True),
    ])
    chain.providers[0].is_available = AsyncMock(side_effect=RuntimeError("boom"))
    result = await chain.probe_local()
    assert result is not None
    assert result.name == "Automatic1111 (txt2img)"


# ─── Automatic1111Provider — availability probe shape ──────────────

@pytest.mark.asyncio
async def test_a1111_provider_unreachable_host_is_unavailable():
    p = Automatic1111Provider(host="localhost", port=1, timeout=1)
    assert await p.is_available() is False


@pytest.mark.asyncio
async def test_a1111_provider_generate_unreachable_returns_none():
    p = Automatic1111Provider(host="localhost", port=1, timeout=1)
    result = await p.generate("a kitten")
    assert result is None


def test_a1111_provider_defaults():
    p = Automatic1111Provider()
    assert p.steps == 20
    assert p.width == 512
    assert p.height == 512
    assert p.sampler == "Euler a"


# ─── build_imagine_chain — factory / config wiring ─────────────────

def test_build_imagine_chain_default_order():
    chain = build_imagine_chain({})
    names = [p.name for p in chain.providers]
    assert any("Automatic1111" in n for n in names)
    assert names[-1] == "Echo Imagine (offline fallback)"


def test_build_imagine_chain_respects_custom_order():
    chain = build_imagine_chain({"imagine_order": "echo"})
    assert len(chain.providers) == 1
    assert chain.providers[0].name == "Echo Imagine (offline fallback)"


def test_build_imagine_chain_always_has_echo_floor():
    chain = build_imagine_chain({"imagine_order": "nonexistent_provider"})
    assert len(chain.providers) == 1
    assert chain.providers[0].name == "Echo Imagine (offline fallback)"


def test_build_imagine_chain_reads_automatic1111_config():
    chain = build_imagine_chain({
        "imagine_order": "automatic1111",
        "automatic1111_host": "192.168.1.50",
        "automatic1111_port": "7861",
        "automatic1111_steps": "30",
        "automatic1111_width": "768",
        "automatic1111_height": "768",
        "automatic1111_sampler": "DPM++ 2M Karras",
    })
    a1111 = chain.providers[0]
    assert a1111.host == "192.168.1.50"
    assert a1111.port == 7861
    assert a1111.steps == 30
    assert a1111.width == 768
    assert a1111.height == 768
    assert a1111.sampler == "DPM++ 2M Karras"
