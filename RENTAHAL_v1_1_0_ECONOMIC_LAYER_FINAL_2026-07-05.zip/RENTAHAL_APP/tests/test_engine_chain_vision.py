"""
test_engine_chain_vision.py — VisionChain provider fall-through, probe_local,
and build_vision_chain factory.

Same shape as test_chain_probe.py / the LLMChain tests: a chain of mocked
providers, asserting probe order, fall-through-on-failure, and that the
Echo floor always answers when nothing real is online.
"""
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.engine_chain import (
    VisionChain, VisionProvider, EchoVisionProvider, LLaVAProvider,
    build_vision_chain,
)


# ─── Helpers ───────────────────────────────────────────────────────

def _make_provider(name, available, describe_result=None, raises=None):
    p = MagicMock()
    p.name = name
    p.is_available = AsyncMock(return_value=available)
    if raises is not None:
        p.describe = AsyncMock(side_effect=raises)
    else:
        p.describe = AsyncMock(return_value=describe_result)
    return p


FAKE_IMAGE_B64 = "ZmFrZWltYWdlYnl0ZXM="   # "fakeimagebytes"


# ─── EchoVisionProvider ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_echo_vision_always_available():
    p = EchoVisionProvider()
    assert await p.is_available() is True


@pytest.mark.asyncio
async def test_echo_vision_returns_offline_message():
    p = EchoVisionProvider()
    result = await p.describe(FAKE_IMAGE_B64, prompt="what do you see")
    assert result is not None
    assert "no vision model" in result.lower()


def test_echo_vision_exposes_easter_egg_id():
    """Sprint 4's orchestrator routes the vision floor through the same
    YouTube-iframe panel the Imagine floor's rickroll uses. This constant
    is the contract between engine_chain.py and that future wiring —
    pin it so nobody accidentally breaks it as the codebase grows."""
    assert EchoVisionProvider.EASTER_EGG_YOUTUBE_ID == "n3UKJq_lxcM"


# ─── VisionChain.describe — fall-through ───────────────────────────

@pytest.mark.asyncio
async def test_describe_uses_first_available_provider():
    chain = VisionChain([
        _make_provider("LLaVA (llava)", True, describe_result="A red ball on a table."),
        _make_provider("Echo Vision (offline fallback)", True, describe_result="never reached"),
    ])
    result = await chain.describe(FAKE_IMAGE_B64)
    assert result == "A red ball on a table."
    assert chain.last_provider == "LLaVA (llava)"


@pytest.mark.asyncio
async def test_describe_falls_through_on_unavailable():
    chain = VisionChain([
        _make_provider("LLaVA (llava)", False),    # not available, skipped
        _make_provider("Echo Vision (offline fallback)", True, describe_result="offline message"),
    ])
    result = await chain.describe(FAKE_IMAGE_B64)
    assert result == "offline message"
    assert chain.last_provider == "Echo Vision (offline fallback)"


@pytest.mark.asyncio
async def test_describe_falls_through_on_none_result():
    """Available but returns None (e.g. transient failure) — chain moves on."""
    chain = VisionChain([
        _make_provider("LLaVA (llava)", True, describe_result=None),
        _make_provider("Echo Vision (offline fallback)", True, describe_result="offline message"),
    ])
    result = await chain.describe(FAKE_IMAGE_B64)
    assert result == "offline message"


@pytest.mark.asyncio
async def test_describe_falls_through_on_exception():
    """A provider raising mid-call must not crash the chain."""
    chain = VisionChain([
        _make_provider("LLaVA (llava)", True, raises=RuntimeError("network blip")),
        _make_provider("Echo Vision (offline fallback)", True, describe_result="offline message"),
    ])
    result = await chain.describe(FAKE_IMAGE_B64)
    assert result == "offline message"


@pytest.mark.asyncio
async def test_describe_all_unavailable_returns_floor_message():
    chain = VisionChain([
        _make_provider("LLaVA (llava)", False),
    ])
    result = await chain.describe(FAKE_IMAGE_B64)
    assert "no vision model" in result.lower()
    assert chain.last_provider == "none"


@pytest.mark.asyncio
async def test_describe_passes_prompt_through():
    provider = _make_provider("LLaVA (llava)", True, describe_result="ok")
    chain = VisionChain([provider])
    await chain.describe(FAKE_IMAGE_B64, prompt="describe the scene")
    provider.describe.assert_awaited_once_with(FAKE_IMAGE_B64, prompt="describe the scene")


# ─── VisionChain.probe_local ────────────────────────────────────────

@pytest.mark.asyncio
async def test_vision_probe_returns_first_available_local():
    chain = VisionChain([
        _make_provider("LLaVA (llava)", True),
        _make_provider("Echo Vision (offline fallback)", True),
    ])
    result = await chain.probe_local()
    assert result is not None
    assert result.name == "LLaVA (llava)"


@pytest.mark.asyncio
async def test_vision_probe_skips_echo():
    chain = VisionChain([
        _make_provider("Echo Vision (offline fallback)", True),
    ])
    result = await chain.probe_local()
    assert result is None


@pytest.mark.asyncio
async def test_vision_probe_returns_none_when_nothing_local():
    chain = VisionChain([
        _make_provider("LLaVA (llava)", False),
        _make_provider("Echo Vision (offline fallback)", True),
    ])
    result = await chain.probe_local()
    assert result is None


@pytest.mark.asyncio
async def test_vision_probe_tolerates_exceptions():
    chain = VisionChain([
        _make_provider("Broken Provider", True, raises=RuntimeError("boom")),
        _make_provider("LLaVA (llava)", True),
    ])
    # _make_provider sets describe's side_effect, not is_available's — patch directly
    chain.providers[0].is_available = AsyncMock(side_effect=RuntimeError("boom"))
    result = await chain.probe_local()
    assert result is not None
    assert result.name == "LLaVA (llava)"


# ─── LLaVAProvider — availability probe shape ──────────────────────

@pytest.mark.asyncio
async def test_llava_provider_name_includes_model():
    p = LLaVAProvider(model="llava:13b")
    assert "llava:13b" in p.name


@pytest.mark.asyncio
async def test_llava_provider_unreachable_host_is_unavailable():
    """No real Ollama server on this port — must fail closed, not raise."""
    p = LLaVAProvider(host="localhost", port=1, timeout=1)
    assert await p.is_available() is False


@pytest.mark.asyncio
async def test_llava_provider_describe_unreachable_returns_none():
    p = LLaVAProvider(host="localhost", port=1, timeout=1)
    result = await p.describe(FAKE_IMAGE_B64)
    assert result is None


# ─── build_vision_chain — factory / config wiring ──────────────────

def test_build_vision_chain_default_order():
    chain = build_vision_chain({})
    names = [p.name for p in chain.providers]
    assert any("LLaVA" in n for n in names)
    assert names[-1] == "Echo Vision (offline fallback)"


def test_build_vision_chain_respects_custom_order():
    chain = build_vision_chain({"vision_order": "echo"})
    # Echo-only order still gets the floor appended exactly once (no dupe)
    assert len(chain.providers) == 1
    assert chain.providers[0].name == "Echo Vision (offline fallback)"


def test_build_vision_chain_always_has_echo_floor():
    """Even a malformed/empty order must end with the Echo floor so the
    realm never has zero vision providers."""
    chain = build_vision_chain({"vision_order": "nonexistent_provider"})
    assert len(chain.providers) == 1
    assert chain.providers[0].name == "Echo Vision (offline fallback)"


def test_build_vision_chain_reads_llava_config():
    chain = build_vision_chain({
        "vision_order": "llava",
        "llava_host": "192.168.1.50",
        "llava_port": "11500",
        "llava_model": "llava:34b",
    })
    llava = chain.providers[0]
    assert llava.host == "192.168.1.50"
    assert llava.port == 11500
    assert llava.model == "llava:34b"
