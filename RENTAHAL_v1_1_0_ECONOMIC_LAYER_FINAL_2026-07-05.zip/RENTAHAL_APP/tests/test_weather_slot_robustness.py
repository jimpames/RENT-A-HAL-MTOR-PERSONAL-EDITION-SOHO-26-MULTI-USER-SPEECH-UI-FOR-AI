"""
Regression tests for extract_weather_slots — all the edge cases we've hit.

History: Jim Ames reported on RENT-A-HAL — "weather always returns newburgh
no matter the city". Root cause was the regex capturing trailing words
("boston please", "london right now") that failed at geocoding, AND not
handling iOS punctuation. This file locks in fixes for every variant
we discovered.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.intent import extract_weather_slots


def slots(text):
    """Tokenize and run the extractor."""
    import re
    tokens = re.findall(r"\w+", text.lower())
    return extract_weather_slots(text, tokens)


# ─── Core cases ────────────────────────────────────────────────

def test_plain_in_preposition():
    assert slots("weather in boston") == {"location": "boston"}


def test_for_preposition():
    assert slots("weather for london") == {"location": "london"}


def test_at_preposition():
    assert slots("weather at chicago") == {"location": "chicago"}


def test_no_city_returns_empty():
    """Bare 'weather' = use server default (Newburgh)."""
    assert slots("weather") == {}


# ─── iOS punctuation ───────────────────────────────────────────

def test_ios_trailing_period():
    """iOS WebKit auto-adds period after dictation."""
    assert slots("weather in Boston.") == {"location": "boston"}


def test_ios_trailing_exclamation():
    """iOS adds ! to enthusiastic speech — old regex missed this."""
    assert slots("weather in Boston!") == {"location": "boston"}


def test_ios_trailing_question_mark():
    assert slots("weather in Boston?") == {"location": "boston"}


def test_ios_capitalization():
    """iOS capitalizes city names — extractor lowercases."""
    assert slots("Weather in Boston") == {"location": "boston"}


def test_ios_title_case_preposition():
    """iOS may title-case 'In' too."""
    assert slots("Weather In Boston.") == {"location": "boston"}


# ─── Trailing politeness words (the silent location killer) ───

def test_trailing_please_stripped():
    """OLD BUG: this returned 'boston please', which OpenWeatherMap
    couldn't geocode, defaulting back to Newburgh somehow."""
    assert slots("weather in Boston please") == {"location": "boston"}


def test_trailing_thanks_stripped():
    assert slots("weather in tokyo thanks") == {"location": "tokyo"}


def test_trailing_thank_you_stripped():
    assert slots("weather in london thank you") == {"location": "london"}


def test_multiple_trailing_words_stripped():
    """'please thanks' — both must go."""
    assert slots("weather in Boston please thanks") == {"location": "boston"}


def test_trailing_for_me_stripped():
    assert slots("weather in chicago for me") == {"location": "chicago"}


# ─── Trailing time words ──────────────────────────────────────

def test_trailing_today():
    """'today' should NOT be part of the city."""
    s = slots("weather in austin today")
    assert s.get("location") == "austin"
    assert s.get("when") == "today"


def test_trailing_tomorrow():
    s = slots("weather in tokyo tomorrow")
    assert s.get("location") == "tokyo"
    assert s.get("when") == "tomorrow"


def test_trailing_right_now():
    """'right now' is two words — longer phrase wins over 'now' alone."""
    s = slots("weather in london right now")
    assert s.get("location") == "london"
    assert s.get("when") == "right now"


def test_trailing_now():
    s = slots("weather in seattle now")
    assert s.get("location") == "seattle"


def test_combined_politeness_and_time():
    s = slots("weather in austin please today")
    assert s.get("location") == "austin"
    assert s.get("when") == "today"


# ─── Multi-word cities ────────────────────────────────────────

def test_two_word_city_new_york():
    assert slots("weather in new york") == {"location": "new york"}


def test_two_word_city_los_angeles():
    assert slots("weather in los angeles") == {"location": "los angeles"}


def test_two_word_city_san_francisco():
    assert slots("weather in san francisco") == {"location": "san francisco"}


def test_multi_word_city_with_trailing_word():
    """The really tricky one: 'los angeles thanks' must yield 'los angeles'."""
    assert slots("weather in los angeles thanks") == {"location": "los angeles"}


def test_three_word_location():
    """City + state combination."""
    s = slots("weather in newburgh new york")
    assert s.get("location") == "newburgh new york"


# ─── Sentence-form queries ────────────────────────────────────

def test_question_form():
    assert slots("what's the weather in chicago") == {"location": "chicago"}


def test_tell_me_form():
    assert slots("tell me the weather in tokyo") == {"location": "tokyo"}


def test_question_with_time():
    s = slots("what's the weather today in boston")
    assert s.get("location") == "boston"
    assert s.get("when") == "today"


# ─── iOS mishears of the preposition ──────────────────────────

def test_ios_mishear_in_as_and():
    """iOS sometimes hears 'in' as 'and'."""
    assert slots("weather and Boston") == {"location": "boston"}


def test_ios_mishear_in_as_of():
    """iOS sometimes hears 'in' as 'of'."""
    assert slots("weather of Tokyo") == {"location": "tokyo"}


def test_no_preposition_at_all():
    """User just says 'weather Boston' — fallback path kicks in."""
    assert slots("weather Boston") == {"location": "boston"}


def test_no_preposition_multi_word():
    assert slots("weather Los Angeles") == {"location": "los angeles"}


# ─── Negative cases — don't capture non-cities ────────────────

def test_weather_today_not_city():
    """'today' is a time word, not a city."""
    s = slots("weather today")
    assert "location" not in s
    assert s.get("when") == "today"


def test_weather_please_not_city():
    """Bare politeness is not a city."""
    assert slots("weather please") == {}


def test_weather_right_now_not_city():
    s = slots("weather right now")
    assert "location" not in s


def test_weather_tomorrow_not_city():
    s = slots("weather tomorrow")
    assert "location" not in s


# ─── Guard against catastrophic captures ──────────────────────

def test_does_not_capture_huge_strings():
    """Cap at ~40 chars; don't capture novel-length 'cities'."""
    huge = "weather in " + "a" * 200
    s = slots(huge)
    # Either no slot or capped to a small bound (regex {1,40} = max ~41 chars)
    if "location" in s:
        assert len(s["location"]) <= 50
