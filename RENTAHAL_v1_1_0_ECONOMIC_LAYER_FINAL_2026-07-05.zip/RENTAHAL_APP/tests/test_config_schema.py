"""
test_config_schema.py — load_schema() / Config metadata parsing.

Regression coverage for a bug found while adding the VisionChain/ImagineChain
config sections in Sprint 2: when a key's `; @label:/@type:/@scope:` line was
followed by a separate `; @help:` comment line (the common pattern for keys
with a longer explanation), load_schema() OVERWROTE pending_meta on the
second comment line instead of merging it — silently dropping label, type,
scope, min, and max for every key using that two-line style.

Concretely this meant Supporters.enabled (`@scope: frontend @type: bool`)
fell back to the defaults `scope: backend, type: str` and vanished from
frontend_config() entirely, regardless of the operator's setting in
config.ini. Hardware.require_cuda, VoiceLoop.privacy_beacon, and a dozen
other keys had the same silent type/scope loss.

These tests pin the merge behavior so it can't regress again.
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.config_schema import load_schema, Config


def _write_ini(text: str) -> Path:
    f = tempfile.NamedTemporaryFile(
        mode="w", suffix=".ini", delete=False, encoding="utf-8")
    f.write(text)
    f.close()
    return Path(f.name)


# ─── The core bug: metadata split across two comment lines ─────────

def test_label_type_scope_survive_a_following_help_line():
    """The exact shape that triggered the bug: @label/@type/@scope on one
    comment line, @help on the next. Both lines must contribute to the
    same key's metadata."""
    path = _write_ini(
        "[Section]\n"
        "; @label: Enabled @type: bool @scope: frontend\n"
        "; @help: When true, shows a thing in the footer.\n"
        "enabled = false\n"
    )
    schema = load_schema(path)
    entry = schema["Section"]["keys"]["enabled"]
    assert entry["label"] == "Enabled"
    assert entry["type"] == "bool"
    assert entry["scope"] == "frontend"
    assert entry["help"] == "When true, shows a thing in the footer."


def test_min_max_survive_a_following_help_line():
    path = _write_ini(
        "[Section]\n"
        "; @label: Window Size @type: int @min: 1 @max: 1000 @scope: backend\n"
        "; @help: Rolling window for averaging.\n"
        "window_size = 20\n"
    )
    schema = load_schema(path)
    entry = schema["Section"]["keys"]["window_size"]
    assert entry["type"] == "int"
    assert entry["min"] == "1"
    assert entry["max"] == "1000"


def test_three_line_metadata_all_merges():
    """Belt and suspenders: metadata spread across THREE comment lines
    (label+type, then scope alone, then help) must all merge — the fix
    is a general merge, not a special-case for exactly two lines."""
    path = _write_ini(
        "[Section]\n"
        "; @label: Require CUDA @type: bool\n"
        "; @scope: backend\n"
        "; @help: Refuses to launch without a GPU.\n"
        "require_cuda = true\n"
    )
    schema = load_schema(path)
    entry = schema["Section"]["keys"]["require_cuda"]
    assert entry["label"] == "Require CUDA"
    assert entry["type"] == "bool"
    assert entry["scope"] == "backend"
    assert entry["help"] == "Refuses to launch without a GPU."


# ─── frontend_config() actually surfaces the key now ───────────────

def test_frontend_scoped_bool_key_reaches_frontend_config():
    """The real-world symptom: a frontend-scoped bool key split across two
    comment lines must actually appear in frontend_config(), not silently
    vanish because its scope fell back to 'backend'."""
    path = _write_ini(
        "[Supporters]\n"
        "; @label: Enabled @type: bool @scope: frontend\n"
        "; @help: When true, shows a support link.\n"
        "enabled = false\n"
    )
    cfg = Config(path)
    out = cfg.frontend_config()
    assert "Supporters" in out
    assert out["Supporters"]["enabled"] is False   # coerced to real bool, not the string "false"


def test_backend_secret_key_excluded_from_frontend_config():
    """Sanity check the filter still works correctly post-fix — secrets
    and backend-scoped keys must NOT leak into frontend_config()."""
    path = _write_ini(
        "[Claude]\n"
        "; @label: API Key @type: secret @scope: backend\n"
        "; @help: sk-ant-... from console.anthropic.com\n"
        "api_key = sk-ant-totally-real-key\n"
    )
    cfg = Config(path)
    out = cfg.frontend_config()
    assert "Claude" not in out


# ─── Single-line metadata (the simple, already-working case) ───────

def test_single_line_metadata_still_works():
    """Backward-compat check: the common single-line style (no separate
    @help line) must keep working exactly as before."""
    path = _write_ini(
        "[Section]\n"
        "; @label: Port @type: int @min: 1 @max: 65535 @scope: backend\n"
        "port = 9999\n"
    )
    schema = load_schema(path)
    entry = schema["Section"]["keys"]["port"]
    assert entry["label"] == "Port"
    assert entry["type"] == "int"
    assert entry["min"] == "1"
    assert entry["max"] == "65535"


# ─── Real config.ini regression — every key resolves, none fall back ─

def test_real_config_ini_has_no_label_fallback_keys():
    """Run the fix against the actual shipped config.ini and confirm no
    key's label silently fell back to its own key name (the fingerprint
    of the bug — every previously-affected key showed this symptom)."""
    real_path = Path(__file__).resolve().parent.parent / "config.ini"
    schema = load_schema(real_path)
    fallen_back = [
        f"{section}.{key}"
        for section, body in schema.items()
        for key, entry in body["keys"].items()
        if entry.get("label") == key
    ]
    assert fallen_back == [], (
        f"These keys lost their @label metadata: {fallen_back}")


def test_real_config_ini_vision_and_imagine_sections_typed_correctly():
    """The actual Sprint 2 deliverable: VisionChain/LLaVA/ImagineChain/
    Automatic1111 sections parse with correct types, not just correct
    values."""
    real_path = Path(__file__).resolve().parent.parent / "config.ini"
    schema = load_schema(real_path)

    assert schema["LLaVA"]["keys"]["port"]["type"] == "int"
    assert schema["LLaVA"]["keys"]["timeout"]["type"] == "int"

    a1111 = schema["Automatic1111"]["keys"]
    assert a1111["port"]["type"] == "int"
    assert a1111["steps"]["type"] == "int"
    assert a1111["width"]["type"] == "int"
    assert a1111["height"]["type"] == "int"
    assert a1111["timeout"]["type"] == "int"
    assert a1111["sampler"]["type"] == "str"

    assert schema["VisionChain"]["keys"]["vision_order"]["label"] == "Provider Order"
    assert schema["ImagineChain"]["keys"]["imagine_order"]["label"] == "Provider Order"
