"""
Tests for the realm's KokoroHTTPProvider — the client side of the
dedicated Kokoro microservice.

These prove the chain integration: when the service is configured,
the realm tries it first; when it's down, the chain falls through
cleanly to the next provider (SAPI5/in-process Kokoro/online).

The actual HTTP wire protocol is exercised by tests in kokoro_service/
against the real service. Here we only verify the chain plumbing.
"""

import asyncio
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.engine_chain import (KokoroHTTPProvider, TTSChain, build_tts_chain,
                                EchoTTSProvider)

pytestmark = pytest.mark.asyncio


async def test_kokoro_service_unavailable_when_host_empty():
    """Empty host = disabled. Important: tts_order can include
    kokoro_service safely even when no service is running."""
    provider = KokoroHTTPProvider(host="", port=9998)
    assert await provider.is_available() is False


async def test_kokoro_service_unavailable_when_service_down():
    """Down service = chain falls through. Not a crash."""
    provider = KokoroHTTPProvider(host="127.0.0.1", port=1)
    assert await provider.is_available() is False


async def test_build_tts_chain_includes_kokoro_service_first_when_listed():
    """Factory order is honored; the service provider is at the head
    when listed first in tts_order."""
    cfg = {
        "tts_order": "kokoro_service,echo",
        "kokoro_service_host": "127.0.0.1",
        "kokoro_service_port": "9998",
    }
    chain = build_tts_chain(cfg)
    assert len(chain.providers) == 2
    assert isinstance(chain.providers[0], KokoroHTTPProvider)
    assert chain.providers[0].host == "127.0.0.1"
    assert chain.providers[0].port == 9998


async def test_chain_falls_through_when_service_unreachable():
    """The whole reason for the chain: if Kokoro service is down,
    the realm degrades gracefully through the next provider."""
    chain = TTSChain([
        KokoroHTTPProvider(host="127.0.0.1", port=1),   # nothing here
        EchoTTSProvider(),                               # always works
    ])
    audio = await chain.synth("fallback test")
    assert audio is not None
    assert chain.last_provider == "Echo TTS (test)"


async def test_deferred_mode_default_false():
    """Deferred mode is opt-in via config. Default is inline so the realm
    works for users who can autoplay."""
    cfg = {
        "tts_order": "kokoro_service",
        "kokoro_service_host": "localhost",
    }
    chain = build_tts_chain(cfg)
    assert chain.providers[0].deferred is False


async def test_deferred_mode_enabled_via_config():
    """Setting deferred = true (string from ini) flips the provider mode."""
    cfg = {
        "tts_order": "kokoro_service",
        "kokoro_service_host": "localhost",
        "kokoro_service_deferred": "true",
    }
    chain = build_tts_chain(cfg)
    assert chain.providers[0].deferred is True
