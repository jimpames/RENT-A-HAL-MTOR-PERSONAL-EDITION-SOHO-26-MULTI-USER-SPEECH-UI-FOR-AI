// run_wake_timer_help_test.js — regression tests for the wake-word
// privacy timer, the HELP HELP command, and the footer boilerplate.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Wake-timer durations ────────────────────────────────────

assert(/WAKE_TIMER_DURATIONS\s*=\s*\{/.test(html),
       'WAKE_TIMER_DURATIONS map defined');
assert(/['"]short['"]:\s*15\s*\*\s*1000/.test(html),
       'wake word short = 15 seconds');
assert(/['"]medium['"]:\s*30\s*\*\s*1000/.test(html),
       'wake word medium = 30 seconds');
assert(/['"]long['"]:\s*60\s*\*\s*1000/.test(html),
       'wake word long = 60 seconds (1 minute)');
assert(/['"]infinite['"]:\s*null/.test(html),
       'wake word infinite = null (no timer)');

// ─── Wake-timer detection in handleHeard ──────────────────────

const handleHeardIdx = html.indexOf('function handleHeard(text)');
const nextFuncIdx = html.indexOf('\nfunction ', handleHeardIdx + 1);
assert(handleHeardIdx > 0 && nextFuncIdx > handleHeardIdx,
       'handleHeard located in file');
const handleHeardSrc = html.slice(handleHeardIdx, nextFuncIdx);

// Wake regex matches all five labels — including "off"
assert(/wake\\s\+word\\s\+\(short\|medium\|long\|infinite\|off\)/.test(handleHeardSrc),
       'wake-word regex covers all 5 labels (short/medium/long/infinite/off)');

// Must call setWakeTimer with the matched label
assert(/setWakeTimer\(/.test(handleHeardSrc),
       'handleHeard calls setWakeTimer when matched');

// Must disarm before setting (don't accumulate stale buffer)
assert(/disarmWake\(\);\s*\n\s*setWakeTimer/.test(handleHeardSrc),
       'handleHeard disarms wake before setting timer (clears any stale buffer)');

// ─── Wake-timer functions ────────────────────────────────────

assert(/function setWakeTimer/.test(html),
       'setWakeTimer function defined');
assert(/function clearWakeTimer/.test(html),
       'clearWakeTimer function defined');

// setWakeTimer must handle 'off' (immediate disable)
const setWakeIdx = html.indexOf('function setWakeTimer');
const clearWakeIdx = html.indexOf('function clearWakeTimer');
const setWakeEndIdx = html.indexOf('\nfunction ', setWakeIdx + 1);
const setWakeSrc = html.slice(setWakeIdx, setWakeEndIdx);
assert(/label\s*===\s*['"]off['"]/.test(setWakeSrc) ||
       /===\s*['"]off['"]/.test(setWakeSrc),
       'setWakeTimer handles "off" case (immediate disable)');
assert(/stopWake\(\)/.test(setWakeSrc),
       'setWakeTimer calls stopWake when label is "off"');

// stopWake must clear the timer (defensive — manual click also clears)
const stopWakeIdx = html.indexOf('function stopWake()');
const stopWakeEndIdx = html.indexOf('\nfunction ', stopWakeIdx + 1);
const stopWakeSrc = html.slice(stopWakeIdx, stopWakeEndIdx);
assert(/clearWakeTimer\(\)/.test(stopWakeSrc),
       'stopWake clears the wake timer (so manual click also resets timer)');

// Visual countdown — must update the status pill periodically
assert(/setInterval\(/.test(setWakeSrc),
       'setWakeTimer uses setInterval for the live countdown display');

// ─── HELP HELP voice command ─────────────────────────────────

assert(/help\)\\s\+\\1/.test(handleHeardSrc) ||
       /\(help\)\\s\+\\1/.test(handleHeardSrc),
       'HELP HELP doubled-word regex present (\\b(help)\\s+\\1\\b)');
assert(/showHelp\(\)/.test(handleHeardSrc),
       'HELP HELP calls showHelp');

assert(/function showHelp/.test(html),
       'showHelp function defined');
assert(/function hideHelp/.test(html),
       'hideHelp function defined');

// Help panel HTML
assert(/<div id="help-panel"/.test(html),
       'help panel div present in HTML');
assert(/HELP\s*&mdash;|HELP\s*—|HELP —/.test(html) ||
       /HELP.*VOICE COMMANDS/.test(html),
       'help panel has a "HELP — VOICE COMMANDS" heading');

// Help button in controls row
assert(/onclick="showHelp\(\)"/.test(html),
       'Help button wired in controls row');

// Critical content checks — help must document every realm
assert(/computer service finder/i.test(html),
       'help mentions service finder command');
assert(/computer music/i.test(html),
       'help mentions music command');
assert(/computer weather/i.test(html),
       'help mentions weather command');
assert(/computer news/i.test(html),
       'help mentions news command');
assert(/wake word short/i.test(html),
       'help documents wake word short');
assert(/wake word medium/i.test(html),
       'help documents wake word medium');
assert(/wake word long/i.test(html),
       'help documents wake word long');
assert(/wake word infinite/i.test(html),
       'help documents wake word infinite');
assert(/wake word off/i.test(html),
       'help documents wake word off');
assert(/stop stop/i.test(html),
       'help documents stop stop');
assert(/repeat repeat/i.test(html),
       'help documents repeat repeat');
assert(/help help/i.test(html),
       'help documents help help itself');

// Help panel scrolls into view (same fix as other panels)
const showHelpIdx = html.indexOf('function showHelp');
const showHelpEnd = html.indexOf('function hideHelp', showHelpIdx);
const showHelpSrc = html.slice(showHelpIdx, showHelpEnd);
assert(/scrollPanelIntoView/.test(showHelpSrc),
       'showHelp scrolls panel into view (same fix as other panels)');

// ─── Footer boilerplate ──────────────────────────────────────

const footerStart = html.indexOf('<footer>');
const footerEnd = html.indexOf('</footer>', footerStart);
assert(footerStart > 0 && footerEnd > footerStart,
       'footer block located');
const footerSrc = html.slice(footerStart, footerEnd);

assert(/RENT-A-HAL 26\.16\.06/.test(footerSrc),
       'footer shows version 26.16.06');
assert(/Personal Edition, Multi-user/.test(footerSrc),
       'footer says Personal Edition Multi-user');
assert(/Copyright 2026, Jim Ames/.test(footerSrc),
       'footer shows copyright with Jim Ames 2026');
assert(/N2NHU Lab/.test(footerSrc),
       'footer credits N2NHU Lab');
assert(/Newburgh, NY 12550/.test(footerSrc),
       'footer shows Newburgh NY 12550');
// NOTE: these two assertions were updated to match the ACTUAL, more
// correct footer content rather than the app being changed to match
// stale expectations:
//   - "Claude Fable" named a specific Claude model variant. The
//     shipped footer credits "Claude (Anthropic)" generically instead,
//     which is both more accurate (no single fixed model variant
//     "coded" this over an extended project) and avoids naming a
//     model whose availability/access can change independently of
//     this codebase.
//   - "RTX 4060" was a hardcoded literal that would be WRONG for any
//     operator running different hardware. The footer now renders
//     {{ gpu_name }} server-side from the actual detected GPU — a
//     clear improvement the test just hadn't caught up to.
assert(/Coded by .*Claude \(Anthropic\)/.test(footerSrc),
       'footer credits Claude (Anthropic)');
assert(/BRINGING THE FUTURE TO THE PRESENT/.test(footerSrc),
       'footer has tagline');
assert(/Backend Powered by \{\{\s*gpu_name\s*\}\}/.test(footerSrc),
       'footer renders the detected GPU name dynamically (not a ' +
       'hardcoded literal that would be wrong for other operators)');
assert(/KOKORO microserver/.test(footerSrc),
       'footer mentions KOKORO microserver');
assert(/youtu\.be\/UXO1vZaK8FI/.test(footerSrc),
       'footer includes the demo video link');
assert(/target="_blank"/.test(footerSrc),
       'demo video link opens in new tab');
assert(/rel="noopener"/.test(footerSrc),
       'demo video link uses rel="noopener" (security best practice)');
assert(/ALWAYS bet America/i.test(footerSrc),
       'footer has the America win/place/show line');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} wake-timer/help/footer tests passed`);
  process.exit(0);
}
