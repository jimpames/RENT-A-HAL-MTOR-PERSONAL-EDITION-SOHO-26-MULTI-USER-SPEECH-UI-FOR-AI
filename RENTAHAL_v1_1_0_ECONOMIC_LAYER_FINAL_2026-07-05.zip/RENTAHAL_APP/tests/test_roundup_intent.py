"""
Tests for the ROUNDUP voice intent path:
  user says "computer roundup newline"
    → classifier matches kind=roundup
    → orchestrator routes to roundup_handler
    → handler fetches NPR+Guardian, publishes news_roundup_start bus event
    → returns brief spoken summary

These tests cover:
  - Classifier matches single-word "roundup"
  - Classifier matches multi-word "news roundup", "play roundup",
    "start roundup", "start the roundup", "play the roundup"
  - Classifier doesn't misclassify "roundup" buried in long question
  - News still wins for "news" without "roundup"
  - Orchestrator routes kind=roundup to roundup_handler
  - Handler publishes news_roundup_start with stories
  - Handler returns a brief spoken summary
  - Handler returns friendly message when no Kokoro service
  - Handler returns friendly message when no stories returned
  - bus_news_roundup_start is in ACK_TRACKED_EVENT_TYPES (both sides)
"""
import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.intent import IntentClassifier, SINGLE_INTENTS, PHRASE_INTENTS
from realm.realm_core import ConnectionManager


# ─── Classifier tests ──────────────────────────────────────────────


def _classify(text: str):
    """Helper: build a stub classifier and classify a phrase."""
    bus = MagicMock()
    bus.publish = AsyncMock()
    classifier = IntentClassifier(bus)
    return classifier.classify(text)


def test_single_word_roundup_classifies_as_roundup():
    assert "roundup" in SINGLE_INTENTS
    assert SINGLE_INTENTS["roundup"] == "roundup"
    intent = _classify("roundup")
    assert intent.kind == "roundup"


def test_phrase_news_roundup_classifies_as_roundup():
    """'news roundup' must beat just 'news' — PHRASE_INTENTS is checked
    before SINGLE_INTENTS, and 'news roundup' is the longer match."""
    assert PHRASE_INTENTS.get("news roundup") == "roundup"
    intent = _classify("news roundup")
    assert intent.kind == "roundup"


def test_phrase_play_roundup_classifies_as_roundup():
    intent = _classify("play roundup")
    assert intent.kind == "roundup"


def test_phrase_start_roundup_classifies_as_roundup():
    intent = _classify("start roundup")
    assert intent.kind == "roundup"


def test_phrase_start_the_roundup_classifies_as_roundup():
    intent = _classify("start the roundup")
    assert intent.kind == "roundup"


def test_phrase_play_the_roundup_classifies_as_roundup():
    intent = _classify("play the roundup")
    assert intent.kind == "roundup"


def test_news_without_roundup_still_classifies_as_news():
    """Adding the roundup intent must not break the existing news intent.
    Plain 'news' is still news."""
    intent = _classify("news")
    assert intent.kind == "news"


def test_news_left_still_classifies_as_news():
    """Verify the news slot extractor still works for category filtering."""
    intent = _classify("news left")
    assert intent.kind == "news"


def test_roundup_with_trailing_words_still_classifies():
    """'roundup please' or 'roundup news' should still trigger roundup —
    the first token is enough."""
    intent = _classify("roundup please")
    assert intent.kind == "roundup"


def test_roundup_buried_in_sentence_does_not_match():
    """If 'roundup' appears past the first 3 tokens, it should NOT trigger
    — that's the same rule as music/news/weather. Prevents false positives
    when the user asks an open-ended question that happens to contain
    the word 'roundup' later on."""
    intent = _classify("what is the latest cattle roundup news")
    # The current classifier checks the first 3 tokens of SINGLE_INTENTS
    # ['what', 'is', 'the'] — none match — so it falls through to "ask"
    assert intent.kind == "ask"


# ─── Orchestrator routing test ──────────────────────────────────────


@pytest.mark.asyncio
async def test_orchestrator_routes_roundup_to_handler():
    """When orchestrator gets kind=roundup, it must call roundup_handler.

    We don't need to spin up the full orchestrator — just verify the
    _route method dispatches correctly by mocking the handler."""
    from realm.orchestrator import Orchestrator
    from realm.event_bus import EventBus

    bus = EventBus()
    llm = MagicMock()
    tts = MagicMock()

    mock_handler = AsyncMock(return_value="Starting news roundup.")
    orch = Orchestrator(bus, llm, tts, roundup_handler=mock_handler)

    item = {
        "kind": "roundup",
        "text": "roundup",
        "slots": {},
        "user_guid": "test-guid",
        "nonce": "test-nonce",
    }
    result = await orch._route(item)
    assert result == "Starting news roundup."
    mock_handler.assert_called_once()
    # Handler is called with (slots, user_guid, bus)
    args = mock_handler.call_args
    assert args.args[0] == {}              # slots
    assert args.args[1] == "test-guid"     # user_guid
    assert args.args[2] is bus             # bus


@pytest.mark.asyncio
async def test_orchestrator_returns_friendly_message_when_no_roundup_handler():
    """If no roundup_handler was wired, the orchestrator returns a
    friendly message instead of crashing."""
    from realm.orchestrator import Orchestrator
    from realm.event_bus import EventBus

    bus = EventBus()
    orch = Orchestrator(bus, MagicMock(), MagicMock(), roundup_handler=None)
    item = {
        "kind": "roundup", "text": "roundup", "slots": {},
        "user_guid": "g", "nonce": "n",
    }
    result = await orch._route(item)
    assert "not configured" in result.lower()


# ─── Handler tests ────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_handler_returns_friendly_when_no_kokoro_service():
    """When [KokoroService] host is blank, the handler returns a
    friendly message — not a crash."""
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read_string("[KokoroService]\nhost =\nport = 9998\n[News]\n")
    from app import make_roundup_handler
    handler = make_roundup_handler(cfg)
    bus = MagicMock()
    bus.publish = AsyncMock()
    result = await handler({}, "guid", bus)
    assert "kokoro" in result.lower() or "service" in result.lower()
    bus.publish.assert_not_called()


@pytest.mark.asyncio
async def test_handler_publishes_news_roundup_start_event():
    """On the happy path, the handler must publish a news_roundup_start
    bus event with the shuffled stories. The browser handler depends on it."""
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read_string("[KokoroService]\nhost = localhost\nport = 9998\n[News]\n")
    from app import make_roundup_handler
    handler = make_roundup_handler(cfg)
    bus = MagicMock()
    bus.publish = AsyncMock()

    # Mock the parallel fetch to return real-looking stories
    fake_npr = [{"title": f"NPR {i}", "source": "NPR",
                 "audio_url": f"/audio/n{i}"} for i in range(3)]
    fake_guardian = [{"title": f"G {i}", "source": "The Guardian",
                      "audio_url": f"/audio/g{i}"} for i in range(3)]

    class _MockResp:
        def __init__(self, stories):
            self._stories = stories
            self.status = 200
        async def json(self):
            return {"enabled": True, "stories": self._stories}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    def mock_get(url, params=None):
        src = (params or {}).get("source", "")
        if src == "NPR":
            return _MockResp(fake_npr)
        return _MockResp(fake_guardian)

    import aiohttp
    with patch.object(aiohttp.ClientSession, "get", side_effect=mock_get):
        result = await handler({}, "test-guid", bus)

    # Spoken summary present and mentions roundup
    assert "roundup" in result.lower()
    # Bus event published
    bus.publish.assert_called_once()
    call = bus.publish.call_args
    assert call.args[0] == "news_roundup_start"
    assert call.kwargs["user_guid"] == "test-guid"
    assert len(call.kwargs["stories"]) == 6
    assert call.kwargs["total"] == 6


@pytest.mark.asyncio
async def test_handler_returns_friendly_when_no_stories_available():
    """If both sources return empty (no stories cached yet), the handler
    returns a friendly message and does NOT publish a roundup event."""
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read_string("[KokoroService]\nhost = localhost\nport = 9998\n[News]\n")
    from app import make_roundup_handler
    handler = make_roundup_handler(cfg)
    bus = MagicMock()
    bus.publish = AsyncMock()

    class _EmptyResp:
        status = 200
        async def json(self):
            return {"enabled": True, "stories": []}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _EmptyResp()):
        result = await handler({}, "guid", bus)

    # Friendly message, no crash
    assert any(word in result.lower() for word in
               ("no", "stories", "yet", "refresh"))
    bus.publish.assert_not_called()


@pytest.mark.asyncio
async def test_handler_continues_when_one_source_errors():
    """If NPR fetch raises but Guardian succeeds, we still get a
    roundup from Guardian. Single source outage doesn't kill the feature."""
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read_string("[KokoroService]\nhost = localhost\nport = 9998\n[News]\n")
    from app import make_roundup_handler
    handler = make_roundup_handler(cfg)
    bus = MagicMock()
    bus.publish = AsyncMock()

    fake_guardian = [{"title": "G 1", "source": "The Guardian",
                      "audio_url": "/audio/g1"}]

    class _GoodResp:
        status = 200
        async def json(self):
            return {"enabled": True, "stories": fake_guardian}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class _BadResp:
        status = 500
        async def json(self):
            return {"enabled": False}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    def mock_get(url, params=None):
        src = (params or {}).get("source", "")
        if src == "NPR":
            return _BadResp()
        return _GoodResp()

    import aiohttp
    with patch.object(aiohttp.ClientSession, "get", side_effect=mock_get):
        result = await handler({}, "guid", bus)

    # Bus event still published with Guardian-only content
    bus.publish.assert_called_once()
    call = bus.publish.call_args
    assert call.args[0] == "news_roundup_start"
    assert len(call.kwargs["stories"]) == 1
    assert call.kwargs["stories"][0]["source"] == "The Guardian"


# ─── ACK tracking is in sync ──────────────────────────────────────


def test_realm_ack_tracked_includes_roundup_start():
    """The realm-side ACK_TRACKED_EVENT_TYPES must include
    bus_news_roundup_start so the realm requires a browser ACK after
    starting the roundup. Without this, a lost roundup event would
    fail silently — exactly the 'ship and pray' bug we already fixed."""
    assert "bus_news_roundup_start" in ConnectionManager.ACK_TRACKED_EVENT_TYPES
