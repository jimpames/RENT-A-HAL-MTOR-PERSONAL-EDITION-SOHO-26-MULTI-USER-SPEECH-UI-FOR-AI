"""
Regression tests for the imagine realm — intent classification and slot
extraction for Automatic1111 txt2img prompts.

Architecture invariants this test file LOCKS IN:
  - 'imagine X' and 'draw X' both trigger kind='imagine', capturing X as
    the 'prompt' slot
  - Filler right after the trigger ('me', 'a picture of') is stripped
  - Trailing politeness words and iOS punctuation are stripped
  - Bare 'imagine'/'draw' with no subject yields no prompt slot (empty)
  - 'draw' is a known small-collision-risk trigger (accepted tradeoff,
    documented in intent.py) — this file locks in that it does NOT
    collide with anything currently in the vocabulary
"""
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.intent import (
    IntentClassifier,
    extract_imagine_slots,
    SINGLE_INTENTS,
    SLOT_EXTRACTORS,
)


def _slots(text):
    tokens = re.findall(r"\w+", text.lower())
    return extract_imagine_slots(text, tokens)


def _classify(text):
    return IntentClassifier(bus=None).classify(text)


# ─── Registration ─────────────────────────────────────────────

def test_imagine_is_a_single_intent():
    assert SINGLE_INTENTS.get("imagine") == "imagine"


def test_draw_is_a_single_intent():
    assert SINGLE_INTENTS.get("draw") == "imagine"


def test_imagine_has_slot_extractor():
    assert "imagine" in SLOT_EXTRACTORS
    assert SLOT_EXTRACTORS["imagine"] is extract_imagine_slots


# ─── Basic slot extraction ────────────────────────────────────

def test_imagine_with_simple_prompt():
    assert _slots("imagine a kitten wearing a hat") == {
        "prompt": "a kitten wearing a hat"}


def test_draw_with_simple_prompt():
    assert _slots("draw a sunset over the mountains") == {
        "prompt": "a sunset over the mountains"}


def test_imagine_strips_me_filler():
    assert _slots("imagine me a dragon") == {"prompt": "a dragon"}


def test_imagine_strips_a_picture_of_filler():
    assert _slots("imagine a picture of a castle") == {
        "prompt": "a castle"}


def test_imagine_strips_me_a_picture_of_filler():
    assert _slots("imagine me a picture of a castle") == {
        "prompt": "a castle"}


def test_imagine_strips_an_image_of_filler():
    assert _slots("imagine an image of outer space") == {
        "prompt": "outer space"}


# ─── Trailing politeness / punctuation ─────────────────────────

def test_imagine_strips_trailing_please():
    assert _slots("imagine a castle please") == {"prompt": "a castle"}


def test_imagine_strips_trailing_period():
    assert _slots("imagine a castle.") == {"prompt": "a castle"}


def test_imagine_strips_trailing_thanks():
    assert _slots("draw a robot thanks") == {"prompt": "a robot"}


# ─── Bare trigger, no subject ──────────────────────────────────

def test_bare_imagine_yields_no_prompt():
    assert _slots("imagine") == {}


def test_bare_draw_yields_no_prompt():
    assert _slots("draw") == {}


# ─── Full classifier round-trip ────────────────────────────────

def test_classify_imagine_a_kitten():
    intent = _classify("imagine a kitten wearing a hat")
    assert intent.kind == "imagine"
    assert intent.slots == {"prompt": "a kitten wearing a hat"}


def test_classify_draw_a_dragon():
    intent = _classify("draw a dragon breathing fire")
    assert intent.kind == "imagine"
    assert intent.slots == {"prompt": "a dragon breathing fire"}


# ─── False-positive guards ─────────────────────────────────────

def test_email_intent_unaffected_by_imagine_addition():
    """'email'/'mail' single-word intents must still work — no table
    collision from adding 'imagine'/'draw'."""
    intent = _classify("email")
    assert intent.kind == "gmail"


def test_weather_intent_unaffected_by_imagine_addition():
    intent = _classify("weather in Boston")
    assert intent.kind == "weather"


def test_drawer_does_not_trigger_imagine():
    """Tokenizer splits on non-alnum, so 'drawer' is one token, never
    equal to 'draw' — must NOT trigger the imagine intent."""
    intent = _classify("drawer is stuck")
    assert intent.kind != "imagine"


def test_withdraw_does_not_trigger_imagine():
    intent = _classify("I need to withdraw money")
    assert intent.kind != "imagine"
