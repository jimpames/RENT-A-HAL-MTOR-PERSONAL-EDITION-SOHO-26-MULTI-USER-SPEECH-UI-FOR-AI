"""
Natural next feature — manual conscription contract revocation.

A Federator operator previously had no way to end a contract early
without editing federation.ini and restarting the whole process (which
clears EVERY rank's contract, not just the one in question). This adds:

  FederationMatrix.get_all_contracts() / revoke_contract(rank)
    - pure data-layer methods, properly encapsulated (no reaching into
      the private lock from app.py)

  GET  /api/federate/contracts          — observability dump
  POST /api/federate/contracts/revoke   — force-expire one rank's contract

Same no-auth posture as the existing /api/federate/matrix endpoint —
documented as a deliberate, consistent choice, not an oversight.
"""
import asyncio
import os
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import FederationMatrix

pytestmark = pytest.mark.asyncio


def _matrix(**kw):
    defaults = dict(missed_after_s=60.0, conscription_enabled=True,
                    conscription_trigger_avg_s=10.0,
                    conscription_idle_avg_s=2.0,
                    default_conscription_max_minutes=15.0)
    defaults.update(kw)
    return FederationMatrix(**defaults)


# ─── FederationMatrix.get_all_contracts / revoke_contract ───────────

async def test_get_all_contracts_empty_when_none_active():
    m = _matrix()
    contracts = await m.get_all_contracts()
    assert contracts == {}


async def test_get_all_contracts_returns_active_contract():
    m = _matrix()
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.1},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    contracts = await m.get_all_contracts()
    assert "chat" in contracts
    assert len(contracts["chat"]) == 1
    assert contracts["chat"][0]["peer_url"] == "https://vision-donor.example"


async def test_get_all_contracts_returns_a_copy_not_the_live_dict():
    """Mutating the returned dict must not corrupt internal state."""
    m = _matrix()
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.1},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    contracts = await m.get_all_contracts()
    contracts["chat"] = "corrupted"
    contracts["imagine"] = "also corrupted"
    real = await m.get_all_contracts()
    assert real["chat"] != "corrupted"
    assert "imagine" not in real


async def test_get_all_contracts_inner_list_is_also_a_copy():
    """Mutating the INNER list (not just the outer dict) must not
    corrupt internal state either — multi-donor means each rank's
    value is itself a mutable list."""
    m = _matrix()
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.1},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    contracts = await m.get_all_contracts()
    contracts["chat"].append({"peer_url": "fake-injected-contract"})
    real = await m.get_all_contracts()
    assert len(real["chat"]) == 1   # the injected entry didn't leak in


async def test_revoke_contract_removes_and_returns_it():
    m = _matrix()
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.1},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")

    revoked = await m.revoke_contract("chat")
    assert len(revoked) == 1
    assert revoked[0]["peer_url"] == "https://vision-donor.example"

    contracts = await m.get_all_contracts()
    assert contracts.get("chat", []) == []


async def test_revoke_contract_returns_empty_list_when_nothing_active():
    m = _matrix()
    revoked = await m.revoke_contract("chat")
    assert revoked == []


async def test_revoke_specific_donor_leaves_other_donors_for_same_rank():
    """Fine-grained revocation: revoking ONE donor's contract must not
    disturb a DIFFERENT donor still helping the SAME rank."""
    m = _matrix(max_donors_per_rank=2)
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.05},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    await m.upsert("https://imagine-donor.example", 1.0, 1.0, 0,
                   node_type="imagine", capability_avg_s={"imagine": 0.05},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")

    contracts = await m.get_all_contracts()
    assert len(contracts["chat"]) == 2

    revoked = await m.revoke_contract("chat", donor_url="https://vision-donor.example")
    assert len(revoked) == 1
    assert revoked[0]["peer_url"] == "https://vision-donor.example"

    remaining = await m.get_all_contracts()
    assert len(remaining["chat"]) == 1
    assert remaining["chat"][0]["peer_url"] == "https://imagine-donor.example"


async def test_revoke_all_donors_for_rank_when_donor_url_omitted():
    m = _matrix(max_donors_per_rank=2)
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.05},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    await m.upsert("https://imagine-donor.example", 1.0, 1.0, 0,
                   node_type="imagine", capability_avg_s={"imagine": 0.05},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")

    revoked = await m.revoke_contract("chat")   # no donor_url — revoke all
    assert len(revoked) == 2

    remaining = await m.get_all_contracts()
    assert remaining.get("chat", []) == []


async def test_revoke_contract_only_affects_the_named_rank():
    """Revoking 'chat' must not touch an unrelated active 'imagine'
    contract."""
    m = _matrix()
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.1},
                   conscription_eligible_ranks=["chat"])
    await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")

    await m.upsert("https://imagine-slow.example", 20.0, 1.0, 0, node_type="imagine")
    await m.upsert("https://chat-donor2.example", 1.0, 1.0, 0,
                   node_type="chat", capability_avg_s={},
                   conscription_eligible_ranks=["imagine"])
    # chat-donor2 needs to actually be idle at ITS OWN native duty (llm)
    await m.upsert("https://chat-donor2.example", 0.1, 1.0, 0,
                   node_type="chat", conscription_eligible_ranks=["imagine"])
    await m.maybe_assign_conscription("imagine", requester_url="https://imagine-slow.example")

    await m.revoke_contract("chat")
    contracts = await m.get_all_contracts()
    assert contracts.get("chat", []) == []
    assert len(contracts.get("imagine", [])) == 1   # untouched


async def test_revoked_contract_allows_immediate_reassignment():
    """After revoking, the NEXT maybe_assign_conscription call must
    re-evaluate from scratch, not think the (now-gone) contract is
    still live."""
    m = _matrix()
    await m.upsert("https://chat-slow.example", 20.0, 1.0, 0, node_type="chat")
    await m.upsert("https://vision-donor.example", 1.0, 1.0, 0,
                   node_type="vision", capability_avg_s={"vision": 0.1},
                   conscription_eligible_ranks=["chat"])
    first = await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    assert len(first) == 1

    await m.revoke_contract("chat")

    # A different, better donor becomes available.
    await m.upsert("https://imagine-donor.example", 1.0, 1.0, 0,
                   node_type="imagine", capability_avg_s={"imagine": 0.01},
                   conscription_eligible_ranks=["chat"])
    second = await m.maybe_assign_conscription("chat", requester_url="https://chat-slow.example")
    assert len(second) == 1
    assert second[0]["peer_url"] == "https://imagine-donor.example"


# ─── Wire protocol — real HTTP ───────────────────────────────────────

async def _boot_federator(tmp_path):
    os.environ["RENTAHAL_FAKE_ENGINES"] = "1"
    import app as app_module
    cfg = app_module.load_ini()
    fed_ini = tmp_path / "federator.ini"
    fed_ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n")
    cfg.read(fed_ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


async def test_contracts_endpoints_over_real_http(tmp_path):
    import uvicorn, aiohttp
    app = await _boot_federator(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9951, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            # No contracts yet.
            async with s.get("http://127.0.0.1:9951/api/federate/contracts") as r:
                assert r.status == 200
                data = await r.json()
                assert data["contracts"] == {}

            # Set up a struggling chat node + idle vision donor.
            await s.post("http://127.0.0.1:9951/api/federate/checkin", json={
                "member_url": "https://chat-struggling.example",
                "llm_avg_s": 25.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "chat"})
            await s.post("http://127.0.0.1:9951/api/federate/checkin", json={
                "member_url": "https://vision-donor.example",
                "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "vision", "capability_avg_s": {"vision": 0.1},
                "conscription_eligible_ranks": ["chat"]})
            await s.post("http://127.0.0.1:9951/api/federate/checkin", json={
                "member_url": "https://chat-struggling.example",
                "llm_avg_s": 25.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "chat"})

            # Contract should now exist.
            async with s.get("http://127.0.0.1:9951/api/federate/contracts") as r:
                data = await r.json()
                assert "chat" in data["contracts"]
                assert len(data["contracts"]["chat"]) == 1
                assert data["contracts"]["chat"][0]["peer_url"] == "https://vision-donor.example"

            # Revoke it.
            async with s.post("http://127.0.0.1:9951/api/federate/contracts/revoke",
                              json={"rank": "chat"}) as r:
                assert r.status == 200
                data = await r.json()
                assert data["revoked"] is True
                assert len(data["contracts"]) == 1
                assert data["contracts"][0]["peer_url"] == "https://vision-donor.example"
                assert data["contract"]["peer_url"] == "https://vision-donor.example"

            # Confirm it's gone.
            async with s.get("http://127.0.0.1:9951/api/federate/contracts") as r:
                data = await r.json()
                assert data["contracts"] == {}

            # Revoking again returns revoked=False, no error.
            async with s.post("http://127.0.0.1:9951/api/federate/contracts/revoke",
                              json={"rank": "chat"}) as r:
                assert r.status == 200
                data = await r.json()
                assert data["revoked"] is False
                assert data["contracts"] == []
                assert data["contract"] is None
    finally:
        server.should_exit = True
        await task


async def test_revoke_specific_donor_over_real_http(tmp_path):
    """The donor_url-aware fine-grained revocation, over real HTTP."""
    import uvicorn, aiohttp
    app = await _boot_federator(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9953, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            await s.post("http://127.0.0.1:9953/api/federate/checkin", json={
                "member_url": "https://chat-struggling.example",
                "llm_avg_s": 25.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "chat"})
            await s.post("http://127.0.0.1:9953/api/federate/checkin", json={
                "member_url": "https://vision-donor.example",
                "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "vision", "capability_avg_s": {"vision": 0.05},
                "conscription_eligible_ranks": ["chat"]})
            await s.post("http://127.0.0.1:9953/api/federate/checkin", json={
                "member_url": "https://chat-struggling.example",
                "llm_avg_s": 25.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "chat"})
            await s.post("http://127.0.0.1:9953/api/federate/checkin", json={
                "member_url": "https://imagine-donor.example",
                "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "imagine", "capability_avg_s": {"imagine": 0.05},
                "conscription_eligible_ranks": ["chat"]})
            await s.post("http://127.0.0.1:9953/api/federate/checkin", json={
                "member_url": "https://chat-struggling.example",
                "llm_avg_s": 25.0, "tts_avg_s": 1.0, "tokens_out": 0,
                "node_type": "chat"})

            async with s.get("http://127.0.0.1:9953/api/federate/contracts") as r:
                data = await r.json()
                assert len(data["contracts"]["chat"]) == 2

            # Revoke ONLY the vision donor.
            async with s.post("http://127.0.0.1:9953/api/federate/contracts/revoke",
                              json={"rank": "chat",
                                   "donor_url": "https://vision-donor.example"}) as r:
                data = await r.json()
                assert len(data["contracts"]) == 1
                assert data["contracts"][0]["peer_url"] == "https://vision-donor.example"

            # The imagine donor's contract must survive, untouched.
            async with s.get("http://127.0.0.1:9953/api/federate/contracts") as r:
                data = await r.json()
                assert len(data["contracts"]["chat"]) == 1
                assert data["contracts"]["chat"][0]["peer_url"] == "https://imagine-donor.example"
    finally:
        server.should_exit = True
        await task


async def test_revoke_missing_rank_returns_400(tmp_path):
    import uvicorn, aiohttp
    app = await _boot_federator(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9952, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9952/api/federate/contracts/revoke",
                              json={}) as r:
                assert r.status == 400
    finally:
        server.should_exit = True
        await task
