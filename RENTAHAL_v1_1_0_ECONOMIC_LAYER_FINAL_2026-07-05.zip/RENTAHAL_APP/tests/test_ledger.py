"""
Sprint 11 — tests for realm/ledger.py, against a REAL Postgres instance.

Not mocked: the whole point of this module is a real database's
transactional/concurrency guarantees plus a hash chain verifiable
against real rows. A mock would test nothing meaningful here.

Isolation strategy: each test gets its OWN throwaway database (created
and dropped around the test), rather than sharing one growing table
across the whole file. The hash-chain/append-only design makes shared
mutable test state awkward on purpose — you can't "clean up" between
tests by deleting rows without corrupting the very chain you're trying
to test, and a tampering test that poisons verify_chain() for the rest
of the table would make every subsequent test's verify_chain() call
report the SAME pre-existing corruption, not what that test actually
introduced. Per-test databases sidestep all of this cleanly, at the
cost of a bit of per-test setup/teardown overhead (a few ms of
CREATE/DROP DATABASE against a local Postgres — acceptable).

If Postgres isn't reachable at all (RENTAHAL_LEDGER_TEST_DSN unset and
no local instance answering), every test in this file skips rather
than erroring — the ledger is opt-in infrastructure (not wired into
app.py's boot path until Sprint 13/14), so a machine without Postgres
must still show a clean `pytest tests/` run, not a hard failure.
"""
import asyncio
import os
import sys
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# asyncpg is an OPTIONAL dependency (see requirements.txt — the ledger
# isn't wired into app.py's boot path yet, so most deployments never
# need it installed at all). importorskip means a fresh install without
# it shows this whole file as SKIPPED, not a collection ERROR that
# would break the "pytest tests/ — zero regressions" promise for
# everyone who hasn't opted into the economic layer.
asyncpg = pytest.importorskip("asyncpg")

from realm.ledger import GENESIS_PREV_HASH, Ledger, _compute_row_hash

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


def _dsn_for_db(db_name: str) -> str:
    # Swap the database name in BASE_DSN for db_name, keeping host/creds.
    prefix = BASE_DSN.rsplit("/", 1)[0]
    return f"{prefix}/{db_name}"


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


@pytest.fixture
async def ledger():
    """Function-scoped: a fresh, uniquely-named database per test,
    dropped afterward regardless of pass/fail."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable at RENTAHAL_LEDGER_TEST_DSN "
                    f"({BASE_DSN}) — ledger tests require a real instance, "
                    "see ECONOMIC_LAYER_DESIGN.md Part B.1 for why.")
    db_name = f"rentahal_ledger_test_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    dsn = _dsn_for_db(db_name)
    led = await Ledger.connect(dsn)
    led.dsn = dsn   # test-only convenience attribute — see tests that
                     # need a second raw connection for tampering checks
    try:
        yield led
    finally:
        await led.close()
        admin_conn = await asyncpg.connect(BASE_DSN)
        # Terminate any lingering connections before dropping — Postgres
        # refuses DROP DATABASE while connections exist.
        await admin_conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
        await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
        await admin_conn.close()


# ─── _compute_row_hash — pure function, no database needed ─────────

def test_compute_row_hash_deterministic():
    h1 = _compute_row_hash("topup", "user-alice", 100, "ref", "{}", 12345, GENESIS_PREV_HASH)
    h2 = _compute_row_hash("topup", "user-alice", 100, "ref", "{}", 12345, GENESIS_PREV_HASH)
    assert h1 == h2


def test_compute_row_hash_changes_with_any_field():
    base = _compute_row_hash("topup", "user-alice", 100, "ref", "{}", 12345, GENESIS_PREV_HASH)
    assert _compute_row_hash("debit", "user-alice", 100, "ref", "{}", 12345, GENESIS_PREV_HASH) != base
    assert _compute_row_hash("topup", "user-bob", 100, "ref", "{}", 12345, GENESIS_PREV_HASH) != base
    assert _compute_row_hash("topup", "user-alice", 999, "ref", "{}", 12345, GENESIS_PREV_HASH) != base
    assert _compute_row_hash("topup", "user-alice", 100, "other", "{}", 12345, GENESIS_PREV_HASH) != base
    assert _compute_row_hash("topup", "user-alice", 100, "ref", "{}", 99999, GENESIS_PREV_HASH) != base
    assert _compute_row_hash("topup", "user-alice", 100, "ref", "{}", 12345, "f" * 64) != base


def test_compute_row_hash_is_sha256_hex():
    h = _compute_row_hash("topup", "a", 1, "", "{}", 1, GENESIS_PREV_HASH)
    assert len(h) == 64
    int(h, 16)   # raises if not valid hex


# ─── Ledger fixture tests ────────────────────────────────────────

pytestmark = pytest.mark.asyncio


# ─── Basic append + read ─────────────────────────────────────────────

async def test_append_entry_returns_populated_entry(ledger):
    entry = await ledger.append_entry("topup", "user-alice", 1_000_000,
                                      reference="stripe_ch_abc")
    assert entry.id == 1
    assert entry.entry_type == "topup"
    assert entry.account_id == "user-alice"
    assert entry.amount_micros == 1_000_000
    assert entry.reference == "stripe_ch_abc"
    assert entry.prev_hash == GENESIS_PREV_HASH
    assert len(entry.row_hash) == 64   # hex sha256


async def test_first_entry_chains_to_genesis(ledger):
    entry = await ledger.append_entry("topup", "user-alice", 100)
    assert entry.prev_hash == GENESIS_PREV_HASH


async def test_second_entry_chains_to_first(ledger):
    e1 = await ledger.append_entry("topup", "user-alice", 1_000_000)
    e2 = await ledger.append_entry("debit", "user-alice", -100)
    assert e2.prev_hash == e1.row_hash
    assert e2.id == e1.id + 1


async def test_metadata_round_trips(ledger):
    entry = await ledger.append_entry(
        "topup", "user-alice", 500, metadata={"stripe_session": "cs_123", "n": 5})
    assert entry.metadata == {"stripe_session": "cs_123", "n": 5}


async def test_metadata_defaults_to_empty_dict(ledger):
    entry = await ledger.append_entry("topup", "user-alice", 500)
    assert entry.metadata == {}


# ─── Balance ──────────────────────────────────────────────────────

async def test_balance_zero_for_unknown_account(ledger):
    balance = await ledger.get_balance("nobody")
    assert balance == 0


async def test_balance_sums_entries(ledger):
    await ledger.append_entry("topup", "user-alice", 1_000_000)
    await ledger.append_entry("debit", "user-alice", -100)
    await ledger.append_entry("debit", "user-alice", -100)
    balance = await ledger.get_balance("user-alice")
    assert balance == 999_800


async def test_balance_is_derived_not_cached(ledger):
    """The balance must be recomputed from scratch each call (SUM), not
    read from a cached/mutated running total. Proven concretely: a
    SECOND, independent Ledger instance pointed at the same database
    (which shares no in-memory state with the first) sees the exact
    same balance immediately after the first instance's write — there
    is nowhere for a stale cached value to hide."""
    await ledger.append_entry("topup", "user-alice", 1_000_000)
    second = await Ledger.connect(ledger.dsn, run_migrations=False)
    try:
        balance = await second.get_balance("user-alice")
        assert balance == 1_000_000
    finally:
        await second.close()


async def test_balance_scoped_per_account(ledger):
    await ledger.append_entry("topup", "user-alice", 1_000_000)
    await ledger.append_entry("topup", "user-bob", 500_000)
    assert await ledger.get_balance("user-alice") == 1_000_000
    assert await ledger.get_balance("user-bob") == 500_000


# ─── get_entries ──────────────────────────────────────────────────

async def test_get_entries_returns_newest_first(ledger):
    await ledger.append_entry("topup", "user-alice", 100, reference="first")
    await ledger.append_entry("topup", "user-alice", 200, reference="second")
    entries = await ledger.get_entries("user-alice")
    assert [e.reference for e in entries] == ["second", "first"]


async def test_get_entries_scoped_per_account(ledger):
    await ledger.append_entry("topup", "user-alice", 100)
    await ledger.append_entry("topup", "user-bob", 200)
    alice_entries = await ledger.get_entries("user-alice")
    assert len(alice_entries) == 1
    assert alice_entries[0].account_id == "user-alice"


async def test_get_entries_respects_limit(ledger):
    for i in range(5):
        await ledger.append_entry("topup", "user-alice", 100)
    entries = await ledger.get_entries("user-alice", limit=2)
    assert len(entries) == 2


# ─── verify_chain — the actual point of this whole module ─────────

async def test_verify_chain_valid_on_clean_ledger(ledger):
    for i in range(5):
        await ledger.append_entry("topup", f"user-{i}", 100)
    result = await ledger.verify_chain()
    assert result.valid is True
    assert result.checked_count == 5
    assert result.first_bad_id is None


async def test_verify_chain_valid_on_empty_ledger(ledger):
    result = await ledger.verify_chain()
    assert result.valid is True
    assert result.checked_count == 0


async def test_verify_chain_detects_amount_tampering(ledger):
    e1 = await ledger.append_entry("topup", "user-alice", 1_000_000)
    e2 = await ledger.append_entry("debit", "user-alice", -100)

    raw_conn = await asyncpg.connect(ledger.dsn)
    await raw_conn.execute(
        "UPDATE ledger_entries SET amount_micros = 999999999 WHERE id = $1",
        e2.id)
    await raw_conn.close()

    result = await ledger.verify_chain()
    assert result.valid is False
    assert result.first_bad_id == e2.id
    assert "row_hash does not match" in result.reason


async def test_verify_chain_detects_reference_tampering(ledger):
    e1 = await ledger.append_entry("topup", "user-alice", 1_000_000,
                                   reference="original")
    dsn = ledger.dsn
    raw_conn = await asyncpg.connect(dsn)
    await raw_conn.execute(
        "UPDATE ledger_entries SET reference = 'forged' WHERE id = $1", e1.id)
    await raw_conn.close()

    result = await ledger.verify_chain()
    assert result.valid is False
    assert result.first_bad_id == e1.id


async def test_verify_chain_detects_deleted_middle_row(ledger):
    """Deleting a row breaks the chain LINKAGE for the row after it —
    the next row's prev_hash no longer matches anything in the table."""
    e1 = await ledger.append_entry("topup", "user-alice", 100)
    e2 = await ledger.append_entry("debit", "user-alice", -10)
    e3 = await ledger.append_entry("debit", "user-alice", -10)

    dsn = ledger.dsn
    raw_conn = await asyncpg.connect(dsn)
    await raw_conn.execute("DELETE FROM ledger_entries WHERE id = $1", e2.id)
    await raw_conn.close()

    result = await ledger.verify_chain()
    assert result.valid is False
    assert result.first_bad_id == e3.id   # e3's prev_hash now points at nothing real


async def test_verify_chain_detects_prev_hash_edited_directly(ledger):
    e1 = await ledger.append_entry("topup", "user-alice", 100)
    e2 = await ledger.append_entry("debit", "user-alice", -10)

    dsn = ledger.dsn
    raw_conn = await asyncpg.connect(dsn)
    await raw_conn.execute(
        "UPDATE ledger_entries SET prev_hash = repeat('0', 64) WHERE id = $1",
        e2.id)
    await raw_conn.close()

    result = await ledger.verify_chain()
    assert result.valid is False
    assert result.first_bad_id == e2.id
    assert "chain broken" in result.reason


async def test_verify_chain_untampered_rows_before_tamper_point_dont_flag(ledger):
    """Rows written BEFORE the tampered one must not themselves be
    reported as bad — first_bad_id should point at the actual
    tampered row, not an earlier innocent one."""
    e1 = await ledger.append_entry("topup", "user-alice", 100)
    e2 = await ledger.append_entry("topup", "user-alice", 200)
    e3 = await ledger.append_entry("topup", "user-alice", 300)

    dsn = ledger.dsn
    raw_conn = await asyncpg.connect(dsn)
    await raw_conn.execute(
        "UPDATE ledger_entries SET amount_micros = 999 WHERE id = $1", e3.id)
    await raw_conn.close()

    result = await ledger.verify_chain()
    assert result.first_bad_id == e3.id   # not e1 or e2


# ─── Concurrency: the advisory lock actually serializes appends ────

async def test_concurrent_appends_produce_a_valid_chain(ledger):
    """The real test of the advisory-lock design: fire many concurrent
    append_entry calls and confirm the resulting chain is still fully
    valid — no two entries computed against the same stale tip."""
    await asyncio.gather(*[
        ledger.append_entry("topup", f"user-{i}", 100) for i in range(20)
    ])
    result = await ledger.verify_chain()
    assert result.valid is True
    assert result.checked_count == 20


# ─── Migration runner ────────────────────────────────────────────

async def test_migrations_are_idempotent(ledger):
    """Connecting again (which re-runs the migration check) must not
    error or duplicate anything — already-applied versions are skipped."""
    await ledger.append_entry("topup", "user-alice", 100)
    dsn = ledger.dsn
    second = await Ledger.connect(dsn)   # re-runs migration check
    balance = await second.get_balance("user-alice")
    assert balance == 100   # data untouched, no duplicate schema objects
    await second.close()


async def test_example_permissions_script_never_auto_applied(ledger):
    """The .sql.example hardening script must never be picked up by
    the migration runner — only real .sql files."""
    async with ledger._pool.acquire() as conn:
        exists = await conn.fetchval(
            "SELECT to_regclass('rentahal_ledger_app')")
    # to_regclass on a role name returns None either way (it's for
    # relations, not roles) -- the real check is that the CREATE ROLE
    # statement in the .example file was never executed at all, which
    # we confirm by checking the role doesn't exist via pg_roles.
    async with ledger._pool.acquire() as conn:
        role_exists = await conn.fetchval(
            "SELECT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = "
            "'rentahal_ledger_app')")
    assert role_exists is False


