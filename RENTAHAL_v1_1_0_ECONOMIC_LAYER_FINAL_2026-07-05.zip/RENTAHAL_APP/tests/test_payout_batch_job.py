"""
Sprint 14 — tests for payout_batch_job.py.

Mirrors the manual verification done during development: a donor with
sufficient confirmed balance gets paid, one below the minimum threshold
gets skipped, one with a balance but no completed onboarding is
entirely invisible to the job, and dry-run mode never calls Stripe at
all. Real Postgres throughout; Stripe Connect calls mocked (real
network unreachable from this sandbox, same restriction as everywhere
else in this arc).
"""
import asyncio
import os
import sys
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

asyncpg = pytest.importorskip("asyncpg")
stripe = pytest.importorskip("stripe")

import payout_batch_job
from realm.donor_payout import DonorAccountStore, PayoutConfig
from realm.ledger import DuplicateEntryError, Ledger

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")

pytestmark = pytest.mark.asyncio


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


@pytest.fixture
async def ledger():
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_payout_job_test_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()
    dsn = BASE_DSN.rsplit("/", 1)[0] + f"/{db_name}"

    led = await Ledger.connect(dsn)
    led.dsn = dsn
    try:
        yield led
    finally:
        await led.close()
        admin_conn = await asyncpg.connect(BASE_DSN)
        await admin_conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
        await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
        await admin_conn.close()


async def test_donor_above_minimum_gets_paid(ledger):
    store = DonorAccountStore(ledger)
    await store.link_account("https://donor-a.example", "acct_a")
    await store.mark_payouts_enabled("https://donor-a.example", True)
    await ledger.append_entry("conscription_credit", "https://donor-a.example",
                              6_000_000, reference="claim-match-1-2")

    cfg = PayoutConfig(stripe_secret_key="sk_test_fake",
                       minimum_payout_micros=5_000_000)
    fake_account = MagicMock(); fake_account.payouts_enabled = True
    fake_transfer = MagicMock(); fake_transfer.id = "tr_test_1"

    with patch("realm.donor_payout.stripe.Account.retrieve", return_value=fake_account), \
         patch("realm.donor_payout.stripe.Transfer.create",
              return_value=fake_transfer) as m_transfer:
        exit_code = await payout_batch_job.run(ledger.dsn, cfg, dry_run=False)

    assert exit_code == 0
    assert m_transfer.call_args.kwargs["amount"] == 600
    assert m_transfer.call_args.kwargs["destination"] == "acct_a"

    balance = await ledger.get_balance("https://donor-a.example")
    assert balance == 0


async def test_donor_below_minimum_not_paid(ledger):
    store = DonorAccountStore(ledger)
    await store.link_account("https://donor-b.example", "acct_b")
    await store.mark_payouts_enabled("https://donor-b.example", True)
    await ledger.append_entry("conscription_credit", "https://donor-b.example",
                              80, reference="claim-match-3-4")

    cfg = PayoutConfig(stripe_secret_key="sk_test_fake",
                       minimum_payout_micros=5_000_000)
    fake_account = MagicMock(); fake_account.payouts_enabled = True

    with patch("realm.donor_payout.stripe.Account.retrieve", return_value=fake_account), \
         patch("realm.donor_payout.stripe.Transfer.create") as m_transfer:
        await payout_batch_job.run(ledger.dsn, cfg, dry_run=False)

    assert m_transfer.call_count == 0
    balance = await ledger.get_balance("https://donor-b.example")
    assert balance == 80


async def test_donor_not_onboarded_entirely_invisible(ledger):
    """Has plenty of balance, but never linked/onboarded a Stripe
    account — get_payout_ready_accounts() must not return it at all."""
    await ledger.append_entry("conscription_credit", "https://donor-c.example",
                              10_000_000, reference="claim-match-5-6")

    cfg = PayoutConfig(stripe_secret_key="sk_test_fake")
    with patch("realm.donor_payout.stripe.Transfer.create") as m_transfer:
        await payout_batch_job.run(ledger.dsn, cfg, dry_run=False)

    assert m_transfer.call_count == 0
    balance = await ledger.get_balance("https://donor-c.example")
    assert balance == 10_000_000


async def test_dry_run_never_calls_stripe(ledger):
    store = DonorAccountStore(ledger)
    await store.link_account("https://donor-a.example", "acct_a")
    await store.mark_payouts_enabled("https://donor-a.example", True)
    await ledger.append_entry("conscription_credit", "https://donor-a.example",
                              6_000_000, reference="claim-match-1-2")

    cfg = PayoutConfig(stripe_secret_key="sk_test_fake",
                       minimum_payout_micros=5_000_000)
    with patch("realm.donor_payout.stripe.Account.retrieve") as m_retrieve, \
         patch("realm.donor_payout.stripe.Transfer.create") as m_transfer:
        await payout_batch_job.run(ledger.dsn, cfg, dry_run=True)

    assert m_retrieve.call_count == 0
    assert m_transfer.call_count == 0
    balance = await ledger.get_balance("https://donor-a.example")
    assert balance == 6_000_000


async def test_account_no_longer_enabled_at_stripe_gets_flagged_and_skipped(ledger):
    """Our own payouts_enabled flag can go stale — always re-verify
    with Stripe directly before attempting a transfer."""
    store = DonorAccountStore(ledger)
    await store.link_account("https://donor-a.example", "acct_a")
    await store.mark_payouts_enabled("https://donor-a.example", True)
    await ledger.append_entry("conscription_credit", "https://donor-a.example",
                              6_000_000, reference="claim-match-1-2")

    cfg = PayoutConfig(stripe_secret_key="sk_test_fake",
                       minimum_payout_micros=5_000_000)
    fake_account = MagicMock(); fake_account.payouts_enabled = False

    with patch("realm.donor_payout.stripe.Account.retrieve", return_value=fake_account), \
         patch("realm.donor_payout.stripe.Transfer.create") as m_transfer:
        await payout_batch_job.run(ledger.dsn, cfg, dry_run=False)

    assert m_transfer.call_count == 0
    account = await store.get_account("https://donor-a.example")
    assert account["payouts_enabled"] is False
    balance = await ledger.get_balance("https://donor-a.example")
    assert balance == 6_000_000


async def test_multiple_donors_paid_independently(ledger):
    store = DonorAccountStore(ledger)
    for name, acct in [("alice", "acct_alice"), ("bob", "acct_bob")]:
        url = f"https://donor-{name}.example"
        await store.link_account(url, acct)
        await store.mark_payouts_enabled(url, True)
        await ledger.append_entry("conscription_credit", url, 6_000_000,
                                  reference=f"claim-match-{name}")

    cfg = PayoutConfig(stripe_secret_key="sk_test_fake",
                       minimum_payout_micros=5_000_000)
    fake_account = MagicMock(); fake_account.payouts_enabled = True
    transfer_ids = iter(["tr_alice", "tr_bob"])
    def make_transfer(**kwargs):
        t = MagicMock()
        t.id = next(transfer_ids)
        return t

    with patch("realm.donor_payout.stripe.Account.retrieve", return_value=fake_account), \
         patch("realm.donor_payout.stripe.Transfer.create", side_effect=make_transfer):
        await payout_batch_job.run(ledger.dsn, cfg, dry_run=False)

    assert await ledger.get_balance("https://donor-alice.example") == 0
    assert await ledger.get_balance("https://donor-bob.example") == 0
