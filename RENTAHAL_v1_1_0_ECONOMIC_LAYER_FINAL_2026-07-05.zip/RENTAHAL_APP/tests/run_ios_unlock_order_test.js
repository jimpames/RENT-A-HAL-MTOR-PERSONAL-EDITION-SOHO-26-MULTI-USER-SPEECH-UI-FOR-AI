// run_ios_unlock_order_test.js — regression tests for iOS audio unlock
// ordering inside installStartupSound.
//
// Bug: iOS Safari grants "user gesture credit" to the FIRST .play() call
// inside a tap handler. The original code played /static/startup.mp3
// first (network fetch) and THEN ran the silent-WAV unlock on the
// `player` element. If startup.mp3 wasn't cached, the network fetch
// could close the gesture window before the silent-WAV unlock ran —
// the `player` element never got unlocked, TTS auto-play failed.
//
// Symptom: on iPhone, sometimes first tap doesn't unlock audio. Reloads
// don't always fix it. Once startup.mp3 is cached and plays fast enough,
// it works.
//
// Fix: do the silent-WAV unlock on `player` FIRST (data URL, instant,
// no network). Play startup.mp3 SECOND — its success/failure no longer
// affects whether `player` is unlocked.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Locate installStartupSound ────────────────────────────────

const installIdx = html.indexOf('function installStartupSound');
assert(installIdx > 0, 'installStartupSound function exists');

const installEnd = html.indexOf('\nfunction ', installIdx + 1);
const installSrc = html.slice(installIdx, installEnd);

// ─── The unlock (silent WAV → player) must come BEFORE startup.mp3 ──

const silentWavIdx = installSrc.indexOf('silentWav =');
const startupMp3Idx = installSrc.indexOf("'/static/startup.mp3'");

assert(silentWavIdx > 0, 'silent WAV unlock block present');
assert(startupMp3Idx > 0, 'startup.mp3 block present');
assert(silentWavIdx < startupMp3Idx,
       'silent WAV unlock runs BEFORE startup.mp3 ' +
       '(the iOS gesture-credit fix)');

// ─── player element is the unlock target (not a throwaway Audio) ──

// Find the FIRST .play() in the function — must be on player, not a new Audio
const playerPlayIdx = installSrc.indexOf('player.play()');
const newAudioPlayIdx = installSrc.indexOf('audio.play()');

assert(playerPlayIdx > 0, 'player.play() called inside installStartupSound');
assert(playerPlayIdx < newAudioPlayIdx,
       'player.play() (the unlock) runs BEFORE the throwaway Audio.play() ' +
       '(iOS gesture credit goes to the FIRST play() call)');

// ─── player.src must be set to silentWav, not the startup mp3 ──

assert(/player\.src\s*=\s*silentWav/.test(installSrc),
       'player.src is assigned the silent WAV data URL (not startup.mp3)');

// ─── The audible startup.mp3 plays via a throwaway Audio, NOT via player ──

assert(/new\s+Audio\s*\(\s*['"]\/static\/startup\.mp3['"]\s*\)/.test(installSrc),
       'startup.mp3 uses throwaway new Audio() ' +
       '(so it cannot accidentally take over the player element)');

// ─── Silent WAV is a data: URL (no network fetch) ──

assert(/silentWav\s*=[\s\S]*?data:audio\/wav;base64/.test(installSrc),
       'silent WAV is a data: URL (instant, no network)');

// ─── player.volume reset to 1 after unlock (in both then and catch) ──

const thenIdx = installSrc.indexOf('.then(');
const catchIdx = installSrc.indexOf('.catch(');
assert(thenIdx > 0 && catchIdx > 0,
       'unlock promise has both .then and .catch');

// Verify volume is reset in BOTH paths (idempotent failure mode)
const thenBlock = installSrc.slice(thenIdx, catchIdx);
const catchBlock = installSrc.slice(catchIdx, installSrc.indexOf('}', catchIdx + 50));
assert(/player\.volume\s*=\s*1/.test(thenBlock),
       'player.volume reset to 1 on unlock success');
assert(/player\.volume\s*=\s*1/.test(catchBlock),
       'player.volume reset to 1 on unlock failure (idempotent)');

// ─── Diagnostic logging present ──

assert(/console\.log\(['"`]\[audio\] player element unlocked/.test(installSrc),
       'logs [audio] when unlock succeeds (visible diagnostic)');
assert(/console\.log\(['"`]\[audio\] unlock failed/.test(installSrc),
       'logs [audio] when unlock fails (visible diagnostic)');

// ─── Both click and touchend handlers still attached ──

assert(/addEventListener\(['"]click['"]/.test(installSrc),
       'click listener still attached');
assert(/addEventListener\(['"]touchend['"]/.test(installSrc),
       'touchend listener still attached (iPhone-specific gesture)');

// ─── Handler removes itself after first run (one-shot) ──

assert(/removeEventListener\(['"]click['"]/.test(installSrc) &&
       /removeEventListener\(['"]touchend['"]/.test(installSrc),
       'handler removes itself after first gesture (one-shot pattern)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} iOS unlock order tests passed`);
  process.exit(0);
}
