"""
Regression tests for the Metrics class.

The orchestrator exposes operator cockpit gauges via a Metrics instance:
  - AI queue depth (from SafeQueue.depth())
  - TTS queue depth (in-flight Kokoro synth calls)
  - Rolling average AI query duration
  - Rolling average Kokoro synth duration
  - Cumulative tokens out since boot (LLM only, not non-LLM kinds)

These tests verify:
  - All counters increment correctly
  - Rolling window is bounded (memory safe under long uptime)
  - Tokens are only counted when tokens_out is non-None (so weather/news/
    music/service queries don't count toward "AI savings" — only real LLM)
  - Snapshots are JSON-serializable (so they fit through the bus → ws_relay)
  - Metrics class never raises, even on bad input (best-effort)
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.orchestrator import Metrics


def test_metrics_initial_state():
    m = Metrics()
    assert m.total_tokens_out == 0
    assert m.ai_queries_total == 0
    assert m.tts_calls_total == 0
    assert m.tts_queue_depth == 0
    assert m.ai_avg_service_s == 0.0
    assert m.tts_avg_service_s == 0.0


def test_record_ai_query_adds_duration_and_tokens():
    m = Metrics()
    m.record_ai_query(2.5, 150)
    assert m.ai_queries_total == 1
    assert m.total_tokens_out == 150
    assert m.ai_avg_service_s == 2.5


def test_record_ai_query_with_no_tokens_skips_token_count():
    """Weather/news/music/service queries have tokens_out=None — we still
    count the query toward avg duration, but NOT toward token savings."""
    m = Metrics()
    m.record_ai_query(0.3, None)  # service query, no LLM
    assert m.ai_queries_total == 1
    assert m.total_tokens_out == 0
    assert m.ai_avg_service_s == 0.3


def test_record_ai_query_with_zero_tokens_skips_token_count():
    m = Metrics()
    m.record_ai_query(1.0, 0)
    assert m.total_tokens_out == 0


def test_avg_uses_only_recent_window():
    """After window_size queries, oldest get dropped."""
    m = Metrics(window_size=3)
    m.record_ai_query(10.0, None)  # will be dropped
    m.record_ai_query(2.0, None)
    m.record_ai_query(2.0, None)
    m.record_ai_query(2.0, None)
    # Window holds last 3: 2, 2, 2 → avg 2.0
    assert m.ai_avg_service_s == 2.0


def test_avg_handles_zero_duration_gracefully():
    """Don't put zero into the window — it would skew the average down."""
    m = Metrics()
    m.record_ai_query(0.0, 100)   # zero/negative duration ignored
    m.record_ai_query(1.0, 100)
    assert m.ai_avg_service_s == 1.0


def test_tokens_accumulate_across_queries():
    m = Metrics()
    m.record_ai_query(1.0, 100)
    m.record_ai_query(2.0, 200)
    m.record_ai_query(3.0, 50)
    assert m.total_tokens_out == 350


def test_tts_start_increments_queue_depth():
    m = Metrics()
    m.tts_start()
    assert m.tts_queue_depth == 1
    m.tts_start()
    assert m.tts_queue_depth == 2


def test_tts_end_decrements_queue_depth():
    m = Metrics()
    m.tts_start()
    m.tts_start()
    m.tts_end(1.5)
    assert m.tts_queue_depth == 1
    m.tts_end(0.5)
    assert m.tts_queue_depth == 0


def test_tts_end_never_goes_negative():
    """If someone calls tts_end() more times than tts_start (e.g. via a
    crashed task that already decremented), don't let depth go negative."""
    m = Metrics()
    m.tts_end(1.0)  # extra end call
    assert m.tts_queue_depth == 0


def test_tts_avg_tracks_recent_durations():
    m = Metrics(window_size=10)
    m.tts_start(); m.tts_end(0.5)
    m.tts_start(); m.tts_end(1.5)
    assert m.tts_avg_service_s == 1.0


def test_record_ai_query_never_raises_on_bad_input():
    """Best-effort: bad input is dropped silently, never crashes."""
    m = Metrics()
    # These should NOT raise. The hot path can't risk a metrics crash.
    m.record_ai_query("not a number", None)
    m.record_ai_query(1.0, "not a number")
    # Counter still increments (we got the call)
    assert m.ai_queries_total >= 1


def test_snapshot_has_all_fields():
    """Snapshot dict has every documented field."""
    m = Metrics()
    m.record_ai_query(1.0, 100)
    m.tts_start(); m.tts_end(0.5)
    snap = m.snapshot(ai_queue_depth=3)
    required = ["ai_queue_depth", "tts_queue_depth",
                "ai_avg_service_s", "tts_avg_service_s",
                "total_tokens_out", "ai_queries_total",
                "tts_calls_total", "window_size", "uptime_s"]
    for field in required:
        assert field in snap, f"snapshot missing field: {field}"
    assert snap["ai_queue_depth"] == 3
    assert snap["tts_queue_depth"] == 0
    assert snap["total_tokens_out"] == 100


def test_snapshot_is_json_serializable():
    """Snapshot must marshal through the bus → ws_relay → WebSocket."""
    import json
    m = Metrics()
    m.record_ai_query(1.0, 100)
    snap = m.snapshot(ai_queue_depth=0)
    # Should not raise
    json.dumps(snap)


def test_snapshot_avgs_are_rounded():
    """Avoid floating-point noise in the UI."""
    m = Metrics()
    m.record_ai_query(1.0, None)
    m.record_ai_query(1.0001, None)
    snap = m.snapshot(ai_queue_depth=0)
    # 3-decimal precision
    assert isinstance(snap["ai_avg_service_s"], float)
    assert abs(snap["ai_avg_service_s"] - 1.00005) < 0.001


def test_window_size_bounded_under_load():
    """Even with 10000 queries, window holds only window_size items."""
    m = Metrics(window_size=20)
    for i in range(10000):
        m.record_ai_query(1.0, 10)
    snap = m.snapshot(ai_queue_depth=0)
    assert snap["window_size"] == 20
    assert snap["ai_queries_total"] == 10000
    assert snap["total_tokens_out"] == 100000
    # The deque caps at 20; we can't introspect its length from the
    # snapshot, but the avg should still be computed from <=20 items
    assert 0 < snap["ai_avg_service_s"] <= 1.0


def test_uptime_present_and_increasing():
    """uptime_s should be present and positive."""
    import time
    m = Metrics()
    time.sleep(0.05)
    snap = m.snapshot(ai_queue_depth=0)
    assert snap["uptime_s"] > 0


# ─── Orchestrator integration ────────────────────────────────
# Source-level check: verify the orchestrator actually calls Metrics.
# Without this, someone could refactor _handle and silently lose the
# metrics-recording call — class-level tests would still pass.

def test_orchestrator_calls_record_ai_query_in_handle():
    """The orchestrator's _handle method must call self.metrics.record_ai_query
    so AI query metrics actually flow into the Metrics instance."""
    import pathlib, re
    orch_path = pathlib.Path(__file__).resolve().parent.parent \
        / "realm" / "orchestrator.py"
    src = orch_path.read_text(encoding="utf-8")
    # Find the _handle method
    handle_idx = src.find("async def _handle")
    assert handle_idx > 0, "_handle method not found"
    next_idx = src.find("\n    async def ", handle_idx + 1)
    handle_src = src[handle_idx:next_idx] if next_idx > handle_idx else src[handle_idx:]
    # Look for an UNCOMMENTED call to record_ai_query.
    # Each non-empty line should be inspected: it counts only if it's
    # not a comment line.
    found_active_call = False
    for line in handle_src.split("\n"):
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue    # comment-only line
        if "self.metrics.record_ai_query" in stripped:
            found_active_call = True
            break
    assert found_active_call, \
        "_handle must call self.metrics.record_ai_query(elapsed, tokens_out) " \
        "in a non-comment line"


def test_orchestrator_calls_tts_start_and_end_in_speak():
    """The orchestrator's _speak method must wrap synth with tts_start/end
    so TTS queue depth + service time are tracked."""
    import pathlib
    orch_path = pathlib.Path(__file__).resolve().parent.parent \
        / "realm" / "orchestrator.py"
    src = orch_path.read_text(encoding="utf-8")
    speak_idx = src.find("async def _speak")
    assert speak_idx > 0, "_speak method not found"
    speak_src = src[speak_idx:]
    # Strip comment lines so commenting-out the call doesn't pass
    active_lines = [l for l in speak_src.split("\n")
                    if not l.lstrip().startswith("#")]
    active_src = "\n".join(active_lines)
    assert "self.metrics.tts_start" in active_src, \
        "_speak must call self.metrics.tts_start() before synth (uncommented)"
    assert "self.metrics.tts_end" in active_src, \
        "_speak must call self.metrics.tts_end(duration) after synth (uncommented)"
    # The end call must be in a finally block
    finally_idx = active_src.find("finally:")
    tts_end_idx = active_src.find("self.metrics.tts_end")
    assert finally_idx > 0 and finally_idx < tts_end_idx, \
        "tts_end must be in a finally block (gauge can't get stuck up)"


def test_orchestrator_starts_metrics_broadcast_loop():
    """The orchestrator's attach() must start the metrics broadcast task."""
    import pathlib
    orch_path = pathlib.Path(__file__).resolve().parent.parent \
        / "realm" / "orchestrator.py"
    src = orch_path.read_text(encoding="utf-8")
    attach_idx = src.find("async def attach")
    next_idx = src.find("\n    async def ", attach_idx + 1)
    attach_src = src[attach_idx:next_idx]
    assert "_metrics_broadcast_loop" in attach_src, \
        "attach() must start the metrics broadcast loop"


def test_metrics_broadcast_publishes_correct_event_type():
    """The broadcast loop must publish 'metrics_snapshot' (which the
    browser listens for as 'bus_metrics_snapshot')."""
    import pathlib
    orch_path = pathlib.Path(__file__).resolve().parent.parent \
        / "realm" / "orchestrator.py"
    src = orch_path.read_text(encoding="utf-8")
    assert '"metrics_snapshot"' in src, \
        "Must publish 'metrics_snapshot' bus event"


# ─── local_llm_available flag for federation health reporting ───────


def test_metrics_local_llm_available_default_true():
    """Optimistic default — boot before detect() runs. Better to
    mis-advertise once than refuse to participate at boot."""
    from realm.orchestrator import Metrics
    m = Metrics()
    assert m.local_llm_available is True


def test_metrics_set_local_llm_available_flips_flag():
    """Single setter, idempotent, coerces to bool."""
    from realm.orchestrator import Metrics
    m = Metrics()
    m.set_local_llm_available(False)
    assert m.local_llm_available is False
    m.set_local_llm_available(True)
    assert m.local_llm_available is True


def test_metrics_local_llm_independent_of_durations():
    """The health flag does NOT affect duration recording. Even when
    local is marked dead, query durations still flow into the rolling
    avg (we still want to know how long things took)."""
    from realm.orchestrator import Metrics
    m = Metrics()
    m.set_local_llm_available(False)
    m.record_ai_query(2.5, 100)
    # Avg recorded as normal — the flag affects only federation reporting
    assert m._ai_durations[-1] == 2.5
    assert m.total_tokens_out == 100


# ─── is_local_llm_provider classifier ───────────────────────────────


@pytest.mark.parametrize("name,expected", [
    # Local LLM providers — return True
    ("GPT4All (Llama 3 8B Instruct)", True),
    ("Claude (claude-haiku-4-5-20251001)", True),
    ("HuggingFace (meta-llama/Meta-Llama-3-8B-Instruct)", True),
    ("SomeCustomLocalModel v2", True),
    # Federation providers — return False (forward to peers)
    ("Federation (peer realms)", False),
    ("Federation Fallback (peer realms)", False),
    # Echo offline fallback — return False
    ("Echo (offline fallback)", False),
    # Empty/sentinel values — return False
    ("", False),
    ("none", False),
    (None, False),
    # Whitespace handling
    ("   ", False),
    ("  GPT4All  ", True),
])
def test_is_local_llm_provider_classification(name, expected):
    """The federation health classification: which providers prove that
    THIS realm has a working local LLM?"""
    from realm.orchestrator import is_local_llm_provider
    assert is_local_llm_provider(name) is expected


def test_is_local_llm_provider_orchestrator_uses_it():
    """The orchestrator MUST call is_local_llm_provider to update the
    metrics flag. Without this wiring, the flag stays at its default
    forever and dead realms never report as degraded.

    We verify via source inspection that the orchestrator both:
    1. Calls is_local_llm_provider() to classify the answering provider
    2. Calls self.metrics.set_local_llm_available(...) to store the result

    The 'self.metrics.' prefix distinguishes the orchestrator CALL site
    from the Metrics method DEFINITION (which uses 'def set_local_llm_
    available'). Catches the sabotage case where someone removes the
    orchestrator call but leaves the method intact."""
    import inspect
    import realm.orchestrator as orch_mod
    src = inspect.getsource(orch_mod)
    assert "is_local_llm_provider(" in src, \
        "Orchestrator module must reference is_local_llm_provider"
    assert "self.metrics.set_local_llm_available(" in src, (
        "Orchestrator must call self.metrics.set_local_llm_available "
        "after each query. Without this wiring, dead-local realms keep "
        "advertising as healthy peers in the federation matrix."
    )


# ─── Recovery actions on Metrics (clear rolling window + flip flag) ───


def test_reset_ai_window_clears_durations_and_flips_flag():
    """The recovery action when local LLM probe succeeds: clear the
    rolling window (stale federated timings drop out immediately) and
    flip the flag to True (next check-in reports as healthy peer).
    Both effects happen atomically — one or the other alone would
    leave federation in an inconsistent state for ~15 seconds."""
    from realm.orchestrator import Metrics
    m = Metrics()
    # Simulate the state we'd be in after federation rescue: rolling
    # window full of long federated calls, flag flipped to False.
    for _ in range(20):
        m.record_ai_query(20.0, 100)
    m.set_local_llm_available(False)
    assert m.local_llm_available is False
    assert len(m._ai_durations) == 20
    assert m.ai_avg_service_s == 20.0
    # Recovery action
    m.reset_ai_window_to_local_recovery()
    # Both effects: empty window AND flag flipped
    assert len(m._ai_durations) == 0
    assert m.local_llm_available is True
    # Next query rebuilds the window with fresh timings
    m.record_ai_query(2.5, 100)
    assert m.ai_avg_service_s == 2.5


def test_reset_tts_window_clears_durations_and_flips_flag():
    """TTS analogue of reset_ai_window. Same semantics."""
    from realm.orchestrator import Metrics
    m = Metrics()
    for _ in range(20):
        m.tts_start()
        m.tts_end(5.0)
    m.set_local_tts_available(False)
    assert m.local_tts_available is False
    assert m.tts_avg_service_s == 5.0
    m.reset_tts_window_to_local_recovery()
    assert len(m._tts_durations) == 0
    assert m.local_tts_available is True


def test_reset_ai_window_is_idempotent():
    """Calling reset on already-clean state has no side effects."""
    from realm.orchestrator import Metrics
    m = Metrics()
    m.reset_ai_window_to_local_recovery()
    assert m.local_llm_available is True
    m.reset_ai_window_to_local_recovery()
    assert m.local_llm_available is True


# ─── is_local_tts_provider classifier ─────────────────────────────


@pytest.mark.parametrize("name,expected", [
    # Local TTS providers — return True
    ("Kokoro Service (localhost:9998)", True),
    ("Kokoro (RTX 4060)", True),
    ("ElevenLabs", True),
    ("OpenAI TTS", True),
    ("SAPI5", True),
    ("pyttsx3", True),
    # Federation TTS providers — return False
    ("Federation TTS (peer realms)", False),
    ("Federation TTS Fallback (peer realms)", False),
    # Empty/sentinel values
    ("", False),
    ("none", False),
    (None, False),
])
def test_is_local_tts_provider_classification(name, expected):
    from realm.orchestrator import is_local_tts_provider
    assert is_local_tts_provider(name) is expected


def test_is_local_tts_provider_orchestrator_uses_it():
    """The orchestrator's _speak method MUST call is_local_tts_provider
    to update the metrics flag. Same wiring discipline as LLM."""
    import inspect
    import realm.orchestrator as orch_mod
    src = inspect.getsource(orch_mod)
    assert "is_local_tts_provider(" in src, \
        "Orchestrator must call is_local_tts_provider"
    assert "self.metrics.set_local_tts_available(" in src, (
        "Orchestrator must call self.metrics.set_local_tts_available "
        "after each TTS call. Without this, dead-TTS realms keep "
        "advertising as healthy TTS peers."
    )


def test_metrics_local_tts_available_default_true():
    from realm.orchestrator import Metrics
    m = Metrics()
    assert m.local_tts_available is True


def test_metrics_set_local_tts_available_idempotent():
    from realm.orchestrator import Metrics
    m = Metrics()
    m.set_local_tts_available(False)
    assert m.local_tts_available is False
    m.set_local_tts_available(False)
    assert m.local_tts_available is False
    m.set_local_tts_available(True)
    assert m.local_tts_available is True
