// ──────────────────────────────────────────────────────────────────────────
//  Buffered-dictation state machine self-test
// ──────────────────────────────────────────────────────────────────────────
// Paste into the browser DevTools Console (F12) on your RENT-A-HAL page.
// Exercises: COMPUTER → armed → multi-utterance buffer → "newline" submits;
// 10s silence reprompts; "stop stop" mid-buffer cancels.
// ──────────────────────────────────────────────────────────────────────────

(function () {
  const sent = [];
  const origSend = send;
  send = (msg) => { sent.push(msg); };

  function reset() {
    sent.length = 0;
    wakeState = 'idle';
    armedBuffer = '';
    if (silenceTimer) { clearTimeout(silenceTimer); silenceTimer = null; }
  }

  function check(name, ok, detail) {
    const tag = ok ? '%cPASS' : '%cFAIL';
    const col = ok ? 'color:#0a0' : 'color:#c00;font-weight:bold';
    console.log(`${tag}%c — ${name}${detail ? '  (' + detail + ')' : ''}`, col, '');
    return ok;
  }

  let pass = 0, total = 0;
  function run(name, fn) {
    total++;
    try { if (fn()) pass++; }
    catch (e) { check(name, false, 'threw: ' + e.message); }
  }

  console.log('\n=== buffered-dictation state machine self-test ===\n');

  run('1. "computer" alone arms (no send yet)', () => {
    reset();
    handleHeard('computer');
    return check('arm without send',
      wakeState === 'armed' && sent.length === 0,
      'state=' + wakeState + ' sent=' + sent.length);
  });

  run('2. armed buffer accumulates across multiple utterances', () => {
    reset();
    handleHeard('computer');
    handleHeard('how far');
    handleHeard('is the sun');
    handleHeard('from earth');
    const expected = 'how far is the sun from earth';
    return check('buffer accumulates',
      armedBuffer === expected && sent.length === 0,
      'buffer="' + armedBuffer + '"');
  });

  run('3. "newline" submits the accumulated buffer', () => {
    reset();
    handleHeard('computer');
    handleHeard('how far is the sun from earth');
    handleHeard('newline');
    return check('newline submits',
      sent.length === 1 &&
      sent[0].text === 'how far is the sun from earth' &&
      wakeState === 'idle',
      'sent=' + JSON.stringify(sent));
  });

  run('4. "newline" at end of same utterance submits buffer + trailing text', () => {
    reset();
    handleHeard('computer');
    handleHeard('what is two plus two');
    handleHeard('please newline');
    return check('inline newline trims correctly',
      sent.length === 1 && sent[0].text === 'what is two plus two please',
      'sent=' + JSON.stringify(sent));
  });

  run('5. one-shot: "computer X newline" sends X', () => {
    reset();
    handleHeard('computer how far is the sun from earth newline');
    return check('one-shot wake+question+submit',
      sent.length === 1 &&
      sent[0].text === 'how far is the sun from earth' &&
      wakeState === 'idle',
      'sent=' + JSON.stringify(sent));
  });

  run('6. "submit" / "done" / "end" also work as submit words', () => {
    reset();
    handleHeard('computer');
    handleHeard('hello world');
    handleHeard('submit');
    const a = sent.length === 1 && sent[0].text === 'hello world';

    reset();
    handleHeard('computer');
    handleHeard('hello again');
    handleHeard('done');
    const b = sent.length === 1 && sent[0].text === 'hello again';

    return check('alternate submit words',
      a && b,
      'submit-result=' + a + ' done-result=' + b);
  });

  run('7. doubled STOP mid-buffer cancels without sending the buffer', () => {
    reset();
    handleHeard('computer');
    handleHeard('this is a partial question that');
    handleHeard('stop stop');
    const stopWasSent = sent.length === 1 && sent[0].text === 'stop stop';
    const bufferWasNotSent = !sent.some(m =>
      m.text.includes('partial question'));
    return check('STOP STOP cancels buffer',
      stopWasSent && bufferWasNotSent && wakeState === 'idle',
      'sent=' + JSON.stringify(sent));
  });

  run('8. non-wake utterance in idle does NOT send anything', () => {
    reset();
    handleHeard('hello there friend');
    return check('idle ignores non-wake',
      sent.length === 0 && wakeState === 'idle');
  });

  run('9. silence timer resets on every armed utterance', () => {
    reset();
    handleHeard('computer');
    const t1 = silenceTimer;
    handleHeard('first chunk');
    const t2 = silenceTimer;
    handleHeard('second chunk');
    const t3 = silenceTimer;
    return check('timer reset each utterance',
      t1 !== t2 && t2 !== t3,
      'timer ids: ' + t1 + ',' + t2 + ',' + t3);
  });

  run('10. empty buffer + "newline" does NOT submit empty query', () => {
    reset();
    handleHeard('computer');
    handleHeard('newline');
    return check('empty + newline rejects',
      sent.length === 0 && wakeState === 'idle');
  });

  // ─── iOS WebKit speech-recognition quirks ───────────────────────────
  // Apple's WebKit speech recognition (used by Chrome/Safari/Firefox/etc.
  // on iOS — Apple forbids non-WebKit browser engines) has different
  // behavior than desktop Chrome. These tests cover the cases Jim Ames
  // reported: "newline" rarely or never works on iPhone.

  run('11. iOS: literal \\n character in transcribed text triggers submit', () => {
    reset();
    handleHeard('computer');
    handleHeard('weather in newburgh');
    // iOS often inserts an actual LF when user says "newline"
    handleHeard('\n');
    return check('literal \\n submits',
      sent.length === 1 && /newburgh/i.test(sent[0].text || ''),
      'sent=' + JSON.stringify(sent));
  });

  run('12. iOS: literal \\n bundled with question text submits', () => {
    reset();
    // iOS may emit: "computer weather in newburgh\n"
    handleHeard('computer weather in newburgh\n');
    return check('bundled \\n submits',
      sent.length === 1 && /weather in newburgh/i.test(sent[0].text || ''),
      'sent=' + JSON.stringify(sent));
  });

  run('13. iOS: "go" triggers submit (shorter trigger more iOS-friendly)', () => {
    reset();
    handleHeard('computer');
    handleHeard('what time is it');
    handleHeard('go');
    return check('"go" submits buffered query',
      sent.length === 1 && /what time is it/i.test(sent[0].text || ''),
      'sent=' + JSON.stringify(sent));
  });

  run('14. iOS: "send" triggers submit', () => {
    reset();
    handleHeard('computer');
    handleHeard('weather in boston');
    handleHeard('send');
    return check('"send" submits',
      sent.length === 1 && /weather in boston/i.test(sent[0].text || ''),
      'sent=' + JSON.stringify(sent));
  });

  run('15. iOS: "new-line" with hyphen triggers submit', () => {
    reset();
    handleHeard('computer');
    handleHeard('hello');
    handleHeard('new-line');
    return check('hyphenated new-line submits',
      sent.length === 1, 'sent=' + JSON.stringify(sent));
  });

  run('16. iOS: capitalization & trailing period like "Newline." triggers', () => {
    reset();
    handleHeard('computer');
    handleHeard('hello world');
    handleHeard('Newline.');  // iOS auto-capitalizes after a pause + adds period
    return check('"Newline." submits',
      sent.length === 1 && /hello world/i.test(sent[0].text || ''),
      'sent=' + JSON.stringify(sent));
  });

  run('17. iOS: text after newline char gets included in buffer before submit', () => {
    reset();
    handleHeard('computer');
    handleHeard('what is the weather\nin tokyo');
    // The \n triggers submit; both halves of the utterance get joined
    return check('text both sides of \\n included',
      sent.length === 1 &&
      /weather/i.test(sent[0].text || '') &&
      /tokyo/i.test(sent[0].text || ''),
      'sent=' + JSON.stringify(sent));
  });

  send = origSend;
  console.log(`\n=== ${pass}/${total} passed ===\n`);
})();
