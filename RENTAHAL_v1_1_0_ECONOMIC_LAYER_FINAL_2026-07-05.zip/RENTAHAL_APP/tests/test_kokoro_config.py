"""
Kokoro misconfiguration paths must fail gracefully with clear log messages,
not with cryptic ONNX errors and not by silently falling back to the working
directory.

Reproduces Jim's bug:
  Load model from C:\\Users\\jimpames\\...\\RENTAHAL_APP failed:
  system error number 13

Root cause was empty model_path → ONNX tried to load the working directory.
Fix: KokoroTTSProvider now validates the path is a real file before loading.
"""

import asyncio
import os
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.engine_chain import KokoroTTSProvider

pytestmark = pytest.mark.asyncio


async def test_empty_model_path_disables_provider_cleanly(caplog):
    """The original Jim-bug: empty model_path made ONNX load the CWD."""
    provider = KokoroTTSProvider(model_path="", voice="af_sarah")
    available = await provider.is_available()
    assert available is False
    audio = await provider.synth("hello")
    assert audio is None


async def test_path_to_directory_fails_with_clear_message(caplog):
    """If user points model_path at a directory instead of the .onnx file."""
    with tempfile.TemporaryDirectory() as tmp:
        provider = KokoroTTSProvider(model_path=tmp, voice="af_sarah")
        with caplog.at_level("WARNING"):
            available = await provider.is_available()
        assert available is False
        # Log must explain WHY, not just "failed"
        log_text = " ".join(r.message for r in caplog.records)
        assert "directory" in log_text.lower(), \
            f"directory-path error should mention 'directory'; logs: {log_text}"


async def test_nonexistent_file_fails_with_clear_message(caplog):
    """If user typos the path or hasn't downloaded the model yet."""
    bogus = os.path.join(tempfile.gettempdir(), "no-such-kokoro-model.onnx")
    provider = KokoroTTSProvider(model_path=bogus, voice="af_sarah")
    with caplog.at_level("WARNING"):
        available = await provider.is_available()
    assert available is False
    log_text = " ".join(r.message for r in caplog.records)
    assert "not found" in log_text.lower(), \
        f"missing-file error should say 'not found'; logs: {log_text}"


async def test_missing_voices_file_fails_with_clear_message(caplog):
    """If user has the .onnx but voices.bin is missing."""
    with tempfile.TemporaryDirectory() as tmp:
        onnx_path = os.path.join(tmp, "kokoro-v0_19.onnx")
        # Create a fake onnx file so the model_path check passes
        with open(onnx_path, "wb") as f:
            f.write(b"\x00" * 100)
        # Don't create voices.bin
        provider = KokoroTTSProvider(model_path=onnx_path, voice="af_sarah")
        with caplog.at_level("WARNING"):
            available = await provider.is_available()
        assert available is False
        log_text = " ".join(r.message for r in caplog.records)
        assert "voices" in log_text.lower(), \
            f"missing-voices error should mention voices; logs: {log_text}"


async def test_voices_path_override_is_respected(caplog):
    """User can put voices.bin somewhere else and configure it explicitly."""
    with tempfile.TemporaryDirectory() as tmp:
        onnx_path = os.path.join(tmp, "model.onnx")
        # Put voices in a sibling directory
        voices_dir = os.path.join(tmp, "elsewhere")
        os.makedirs(voices_dir)
        voices_path = os.path.join(voices_dir, "voices.bin")
        # Create both files; they're not real but pass exists() checks
        with open(onnx_path, "wb") as f:
            f.write(b"\x00" * 100)
        with open(voices_path, "wb") as f:
            f.write(b"\x00" * 100)
        provider = KokoroTTSProvider(model_path=onnx_path,
                                     voices_path=voices_path,
                                     voice="af_sarah")
        # Will fail in Kokoro() since the bytes are bogus, but it should
        # reach that point WITHOUT complaining about missing voices.bin.
        with caplog.at_level("WARNING"):
            await provider.is_available()
        log_text = " ".join(r.message for r in caplog.records)
        # The voices path should NOT have triggered a "not found" — only the
        # downstream Kokoro library load can complain about bad ONNX bytes.
        voices_complaints = [r for r in caplog.records
                             if "voices" in r.message.lower()
                             and "not found" in r.message.lower()]
        assert not voices_complaints, \
            f"voices_path override was ignored: {[r.message for r in voices_complaints]}"
