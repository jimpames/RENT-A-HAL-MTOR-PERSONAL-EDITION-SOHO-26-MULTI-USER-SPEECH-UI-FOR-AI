"""
Sprint 7 tests — conscription policy & config.

Pure plumbing: config parsing, the two policy pure-functions
(permits_rank / eligible_conscription_ranks), and wire-format storage.
NO decision-making is tested here because none exists yet — Sprint 8's
Federator-side decision engine is the first consumer of any of this
data. Every test in this file is either a pure function or inert
storage/round-trip.

  FederationConfig — [FederationConscription] parsing
    - defaults: allow=on, ranks=empty (opt-in required), minutes=15
    - permitted_conscription_ranks parses comma lists, case/whitespace
      tolerant
    - "none" and "" both parse to the empty frozenset
    - "any" is kept as a literal set member, not expanded at parse time

  FederationConfig.permits_rank — pure policy check
    - False when allow_federation_conscription = off, regardless of ranks
    - False when ranks is empty (opt-in required)
    - True only for explicitly listed ranks
    - "any" permits every rank

  FederationConfig.eligible_conscription_ranks — the acceptance-bar test
    - a node with permitted_conscription_ranks=chat but NO real chat
      provider configured must never appear eligible for chat
    - "any" resolves against whatever's actually configured
    - intersection is genuinely bidirectional (permission alone isn't
      enough; configuration alone isn't enough)

  MemberRecord.conscription_eligible_ranks — inert storage
    - defaults empty list; to_dict omits when empty (backward compat)
    - round-trips through to_dict/from_dict
    - old-format records (key absent) load fine

  FederationMatrix.upsert — wire storage
    - conscription_eligible_ranks stored and REPLACED (not merged) each
      check-in
    - omitted entirely when caller doesn't pass it (old client code)

  FederationClient._do_checkin — sending side
    - conscription_eligible_ranks computed from configured_ranks ∩
      config's own eligible_conscription_ranks()
    - omitted when configured_ranks isn't in stats (old-style stats
      callable — matches Sprint 6's backward-compat pattern)
    - omitted when eligible set is empty (nothing to report)
"""
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import (
    FederationMatrix, FederationConfig, FederationState, FederationClient,
    MemberRecord, CONSCRIPTION_DEFAULTS, CONSCRIPTION_RANKS,
)

pytestmark = pytest.mark.asyncio


def _cfg_from_ini(text: str) -> FederationConfig:
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read_string(text)
    return FederationConfig.from_cfg(cfg)


# ─── [FederationConscription] parsing ───────────────────────────────

def test_conscription_defaults_with_no_section_at_all():
    fc = _cfg_from_ini("[Federation]\ndesire = on\n")
    assert fc.allow_federation_conscription is True
    assert fc.permitted_conscription_ranks == frozenset()
    assert fc.max_conscription_minutes == 15


def test_conscription_defaults_match_CONSCRIPTION_DEFAULTS():
    assert CONSCRIPTION_DEFAULTS["allow_federation_conscription"] == "on"
    assert CONSCRIPTION_DEFAULTS["permitted_conscription_ranks"] == ""
    assert CONSCRIPTION_DEFAULTS["max_conscription_minutes"] == "15"


def test_allow_federation_conscription_parses_off():
    fc = _cfg_from_ini(
        "[FederationConscription]\nallow_federation_conscription = off\n")
    assert fc.allow_federation_conscription is False


def test_permitted_ranks_parses_comma_list():
    fc = _cfg_from_ini(
        "[FederationConscription]\npermitted_conscription_ranks = chat,imagine\n")
    assert fc.permitted_conscription_ranks == frozenset({"chat", "imagine"})


def test_permitted_ranks_tolerates_whitespace_and_case():
    fc = _cfg_from_ini(
        "[FederationConscription]\n"
        "permitted_conscription_ranks =  Chat , VISION ,  imagine  \n")
    assert fc.permitted_conscription_ranks == frozenset({"chat", "vision", "imagine"})


def test_permitted_ranks_empty_string_is_empty_set():
    fc = _cfg_from_ini(
        "[FederationConscription]\npermitted_conscription_ranks = \n")
    assert fc.permitted_conscription_ranks == frozenset()


def test_permitted_ranks_none_synonym_is_empty_set():
    fc = _cfg_from_ini(
        "[FederationConscription]\npermitted_conscription_ranks = none\n")
    assert fc.permitted_conscription_ranks == frozenset()


def test_permitted_ranks_none_synonym_case_insensitive():
    fc = _cfg_from_ini(
        "[FederationConscription]\npermitted_conscription_ranks = NONE\n")
    assert fc.permitted_conscription_ranks == frozenset()


def test_permitted_ranks_any_kept_as_literal_member():
    """'any' is NOT expanded at parse time — expansion requires knowing
    the node's configured capabilities, which the parser doesn't have."""
    fc = _cfg_from_ini(
        "[FederationConscription]\npermitted_conscription_ranks = any\n")
    assert fc.permitted_conscription_ranks == frozenset({"any"})


def test_max_conscription_minutes_parses_custom_value():
    fc = _cfg_from_ini(
        "[FederationConscription]\nmax_conscription_minutes = 30\n")
    assert fc.max_conscription_minutes == 30


def test_conscription_ranks_vocabulary_is_exactly_three():
    assert set(CONSCRIPTION_RANKS) == {"chat", "vision", "imagine"}


# ─── permits_rank ────────────────────────────────────────────────────

def test_permits_rank_false_when_master_switch_off():
    fc = FederationConfig(allow_federation_conscription=False,
                          permitted_conscription_ranks=frozenset({"chat"}))
    assert fc.permits_rank("chat") is False


def test_permits_rank_false_when_ranks_empty():
    fc = FederationConfig(allow_federation_conscription=True,
                          permitted_conscription_ranks=frozenset())
    assert fc.permits_rank("chat") is False


def test_permits_rank_true_for_explicitly_listed_rank():
    fc = FederationConfig(allow_federation_conscription=True,
                          permitted_conscription_ranks=frozenset({"chat"}))
    assert fc.permits_rank("chat") is True
    assert fc.permits_rank("vision") is False


def test_permits_rank_any_permits_everything():
    fc = FederationConfig(allow_federation_conscription=True,
                          permitted_conscription_ranks=frozenset({"any"}))
    assert fc.permits_rank("chat") is True
    assert fc.permits_rank("vision") is True
    assert fc.permits_rank("imagine") is True
    assert fc.permits_rank("something_not_even_a_real_rank") is True


# ─── eligible_conscription_ranks — the acceptance-bar tests ─────────

def test_eligible_ranks_empty_when_master_switch_off():
    fc = FederationConfig(allow_federation_conscription=False,
                          permitted_conscription_ranks=frozenset({"any"}))
    assert fc.eligible_conscription_ranks({"chat", "vision"}) == set()


def test_permitted_but_not_configured_is_never_eligible():
    """THE acceptance-bar test from the Sprint 7 plan: a node with
    permitted_conscription_ranks=chat but no real LLM provider
    configured must never appear as a conscription candidate."""
    fc = FederationConfig(allow_federation_conscription=True,
                          permitted_conscription_ranks=frozenset({"chat"}))
    # This node only has vision configured — chat is PERMITTED but not
    # CONFIGURED, so it must not appear as eligible.
    assert fc.eligible_conscription_ranks({"vision"}) == set()


def test_configured_but_not_permitted_is_never_eligible():
    """The mirror case: a real provider alone isn't consent."""
    fc = FederationConfig(allow_federation_conscription=True,
                          permitted_conscription_ranks=frozenset({"vision"}))
    # Node has chat AND vision configured, but only vision is permitted.
    assert fc.eligible_conscription_ranks({"chat", "vision"}) == {"vision"}


def test_eligible_ranks_is_genuine_intersection():
    fc = FederationConfig(allow_federation_conscription=True,
                          permitted_conscription_ranks=frozenset({"chat", "imagine"}))
    assert fc.eligible_conscription_ranks({"chat", "vision"}) == {"chat"}


def test_eligible_ranks_any_resolves_against_configured():
    fc = FederationConfig(allow_federation_conscription=True,
                          permitted_conscription_ranks=frozenset({"any"}))
    assert fc.eligible_conscription_ranks({"vision", "imagine"}) == {"vision", "imagine"}
    assert fc.eligible_conscription_ranks(set()) == set()


def test_eligible_ranks_empty_configured_is_empty_result():
    fc = FederationConfig(allow_federation_conscription=True,
                          permitted_conscription_ranks=frozenset({"chat"}))
    assert fc.eligible_conscription_ranks(set()) == set()


# ─── MemberRecord.conscription_eligible_ranks — inert storage ──────

def test_conscription_eligible_ranks_defaults_empty():
    rec = MemberRecord(url="https://a.com")
    assert rec.conscription_eligible_ranks == []


def test_to_dict_omits_conscription_eligible_ranks_when_empty():
    rec = MemberRecord(url="https://a.com")
    d = rec.to_dict()
    assert "conscription_eligible_ranks" not in d


def test_to_dict_includes_conscription_eligible_ranks_when_present():
    rec = MemberRecord(url="https://a.com",
                       conscription_eligible_ranks=["chat", "vision"])
    d = rec.to_dict()
    assert d["conscription_eligible_ranks"] == ["chat", "vision"]


def test_from_dict_round_trips_conscription_eligible_ranks():
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 0, "last_seen": 1.0,
         "conscription_eligible_ranks": ["imagine"]}
    rec = MemberRecord.from_dict(d)
    assert rec.conscription_eligible_ranks == ["imagine"]


def test_from_dict_missing_conscription_eligible_ranks_defaults_empty():
    """Old-format record — no such key at all."""
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 0, "last_seen": 1.0}
    rec = MemberRecord.from_dict(d)
    assert rec.conscription_eligible_ranks == []


def test_from_dict_ignores_non_string_entries():
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 0, "last_seen": 1.0,
         "conscription_eligible_ranks": ["chat", 42, None, "vision"]}
    rec = MemberRecord.from_dict(d)
    assert rec.conscription_eligible_ranks == ["chat", "vision"]


# ─── FederationMatrix.upsert — wire storage ─────────────────────────

async def test_upsert_stores_conscription_eligible_ranks():
    m = FederationMatrix(missed_after_s=60.0)
    rec = await m.upsert("https://a.com", 2.0, 1.0, 0,
                         conscription_eligible_ranks=["chat"])
    assert rec.conscription_eligible_ranks == ["chat"]


async def test_upsert_replaces_not_merges_conscription_eligible_ranks():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 2.0, 1.0, 0,
                   conscription_eligible_ranks=["chat", "vision"])
    rec = await m.upsert("https://a.com", 2.0, 1.0, 0,
                         conscription_eligible_ranks=["imagine"])
    assert rec.conscription_eligible_ranks == ["imagine"]


async def test_upsert_without_conscription_eligible_ranks_leaves_unchanged():
    """None (not passed) must NOT clear a previously-reported list —
    only an explicit new list replaces it. Simulates an old client
    that doesn't know about this field at all."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 2.0, 1.0, 0,
                   conscription_eligible_ranks=["chat"])
    rec = await m.upsert("https://a.com", 3.0, 1.0, 0)   # no ranks arg at all
    assert rec.conscription_eligible_ranks == ["chat"]


async def test_upsert_empty_list_explicitly_clears():
    """An explicit empty list (operator revoked consent) DOES clear —
    distinct from not passing the argument at all."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 2.0, 1.0, 0,
                   conscription_eligible_ranks=["chat"])
    rec = await m.upsert("https://a.com", 2.0, 1.0, 0,
                         conscription_eligible_ranks=[])
    assert rec.conscription_eligible_ranks == []


# ─── FederationClient._do_checkin — sending side ────────────────────

class _MockResp:
    def __init__(self, body, status=200):
        self._body = body
        self.status = status
    async def json(self):
        return self._body
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass


async def _capture_checkin_payload(cfg, stats):
    state = FederationState(cfg, lambda: stats)
    client = FederationClient(state)
    captured = {}
    def mock_post(url, json=None):
        captured["payload"] = json
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()
    return captured["payload"]


async def test_checkin_sends_eligible_ranks_when_configured_and_permitted():
    cfg = FederationConfig(
        desire=True, self_url="https://me.example",
        master_url="https://fed.example/api/federate",
        allow_federation_conscription=True,
        permitted_conscription_ranks=frozenset({"chat"}))
    payload = await _capture_checkin_payload(cfg, {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
        "configured_ranks": ["chat", "vision"]})
    assert payload["conscription_eligible_ranks"] == ["chat"]


async def test_checkin_omits_eligible_ranks_when_stats_has_no_configured_ranks():
    """Backward compat: an old-style stats callable that doesn't know
    about configured_ranks at all — matches Sprint 6's precedent for
    capability_avg_s."""
    cfg = FederationConfig(
        desire=True, self_url="https://me.example",
        master_url="https://fed.example/api/federate",
        allow_federation_conscription=True,
        permitted_conscription_ranks=frozenset({"any"}))
    payload = await _capture_checkin_payload(cfg, {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    assert "conscription_eligible_ranks" not in payload


async def test_checkin_omits_eligible_ranks_when_nothing_permitted():
    cfg = FederationConfig(
        desire=True, self_url="https://me.example",
        master_url="https://fed.example/api/federate",
        allow_federation_conscription=True,
        permitted_conscription_ranks=frozenset())   # opt-out
    payload = await _capture_checkin_payload(cfg, {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
        "configured_ranks": ["chat", "vision", "imagine"]})
    assert "conscription_eligible_ranks" not in payload


async def test_checkin_eligible_ranks_sorted_for_determinism():
    cfg = FederationConfig(
        desire=True, self_url="https://me.example",
        master_url="https://fed.example/api/federate",
        allow_federation_conscription=True,
        permitted_conscription_ranks=frozenset({"any"}))
    payload = await _capture_checkin_payload(cfg, {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
        "configured_ranks": ["imagine", "chat", "vision"]})
    assert payload["conscription_eligible_ranks"] == ["chat", "imagine", "vision"]
