"""
engines.py — engine implementations for the harness.

FakeEngines     : instant/configurable-latency async fakes (correct pattern).
BlockingEngines : reproduces webgui.py's ORIGINAL sin — synchronous sleeps on
                  the event loop, exactly like os.system(ffmpeg) + whisper +
                  BARK did. Used by the harness to PROVE the loop-stall
                  failure mode, so the fix is demonstrated, not asserted.
ExecutorEngines : the fixed pattern — same work, pushed off-loop. This is the
                  shape TorchEngines in webgui.py must take (see PATCHES doc).
"""

import asyncio
import time
from concurrent.futures import ThreadPoolExecutor


class FakeEngines:
    def __init__(self, infer_latency=0.0, stt_latency=0.0, tts_latency=0.0,
                 fail_on_prompt=None):
        self.infer_latency = infer_latency
        self.stt_latency = stt_latency
        self.tts_latency = tts_latency
        self.fail_on_prompt = fail_on_prompt
        self.calls = {"stt": 0, "tts": 0, "infer": 0}

    async def stt(self, audio_b64):
        self.calls["stt"] += 1
        await asyncio.sleep(self.stt_latency)
        return f"transcribed:{audio_b64[:16]}"

    async def tts(self, text):
        self.calls["tts"] += 1
        await asyncio.sleep(self.tts_latency)
        return "QkFTRTY0QVVESU8="  # "BASE64AUDIO"

    async def infer(self, query):
        self.calls["infer"] += 1
        if self.fail_on_prompt and self.fail_on_prompt in query.get("prompt", ""):
            raise RuntimeError("synthetic inference failure")
        await asyncio.sleep(self.infer_latency)
        return f"echo:{query.get('prompt', '')}"


class BlockingEngines(FakeEngines):
    """The original webgui.py behavior: heavy work runs ON the event loop."""

    def __init__(self, block_seconds=1.0):
        super().__init__()
        self.block_seconds = block_seconds

    async def stt(self, audio_b64):
        self.calls["stt"] += 1
        time.sleep(self.block_seconds)        # <- os.system(ffmpeg) + whisper.decode
        return "transcribed:blocking"

    async def tts(self, text):
        self.calls["tts"] += 1
        time.sleep(self.block_seconds)        # <- bark.generate_audio
        return "QkFTRTY0QVVESU8="


class ExecutorEngines(FakeEngines):
    """The fix: identical heavy work, run off-loop. Pattern for TorchEngines."""

    def __init__(self, block_seconds=1.0, workers=4):
        super().__init__()
        self.block_seconds = block_seconds
        self.pool = ThreadPoolExecutor(max_workers=workers)

    async def stt(self, audio_b64):
        self.calls["stt"] += 1
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(self.pool, time.sleep, self.block_seconds)
        return "transcribed:executor"

    async def tts(self, text):
        self.calls["tts"] += 1
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(self.pool, time.sleep, self.block_seconds)
        return "QkFTRTY0QVVESU8="
