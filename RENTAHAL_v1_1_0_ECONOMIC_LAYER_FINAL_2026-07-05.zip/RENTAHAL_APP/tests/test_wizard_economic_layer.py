"""
Sprint 15 — tests for wizard.py's economic-layer probes and config
wiring (probe_ledger, probe_stripe_key, get_state()/save() extensions).

Same testability split as the rest of this economic-layer arc:
probe_ledger is tested against REAL Postgres (no network restriction —
it's the same local test instance every other Postgres-backed test in
this suite uses). probe_stripe_key needs a real call to api.stripe.com,
unreachable from this sandbox, so it's tested via mocking the SDK call,
clearly labeled.
"""
import asyncio
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import wizard

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


async def _postgres_reachable() -> bool:
    try:
        import asyncpg
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


# ─── probe_ledger ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_probe_ledger_not_configured():
    result = await wizard.probe_ledger("")
    assert result["up"] is False
    assert result["error"] == "not configured"


@pytest.mark.asyncio
async def test_probe_ledger_real_connection():
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    result = await wizard.probe_ledger(BASE_DSN)
    assert result["up"] is True
    assert result["error"] is None


@pytest.mark.asyncio
async def test_probe_ledger_wrong_credentials():
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    bad_dsn = "postgresql://nobody:wrongpassword@localhost:5432/postgres"
    result = await wizard.probe_ledger(bad_dsn)
    assert result["up"] is False
    assert result["error"] is not None


@pytest.mark.asyncio
async def test_probe_ledger_unreachable_host():
    result = await wizard.probe_ledger(
        "postgresql://user:pass@127.0.0.1:1/nonexistent")
    assert result["up"] is False


# ─── probe_stripe_key — mocked SDK call, clearly labeled ─────────

@pytest.mark.asyncio
async def test_probe_stripe_key_not_configured():
    result = await wizard.probe_stripe_key("")
    assert result["valid"] is False
    assert result["error"] == "not configured"


@pytest.mark.asyncio
async def test_probe_stripe_key_valid():
    """MOCKED: api.stripe.com isn't reachable from this sandbox (see
    module docstring in realm/billing.py and realm/donor_payout.py for
    the same documented restriction)."""
    fake_account = MagicMock()
    fake_account.id = "acct_platform123"
    with patch("stripe.Account.retrieve", return_value=fake_account):
        result = await wizard.probe_stripe_key("sk_test_valid")
    assert result["valid"] is True
    assert result["account_id"] == "acct_platform123"


@pytest.mark.asyncio
async def test_probe_stripe_key_invalid():
    with patch("stripe.Account.retrieve",
              side_effect=Exception("Invalid API Key provided")):
        result = await wizard.probe_stripe_key("sk_test_bad")
    assert result["valid"] is False
    assert "Invalid API Key" in result["error"]


# ─── get_state() integration — real end-to-end via TestClient ────

def test_get_state_includes_economic_layer_fields(tmp_path, monkeypatch):
    ini = tmp_path / "config.ini"
    ini.write_text("[Server]\nhost = 0.0.0.0\n")
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)

    from fastapi.testclient import TestClient
    app = wizard.build_app()
    client = TestClient(app)
    r = client.get("/api/wizard/state")
    data = r.json()

    assert "ledger" in data
    assert "billing" in data
    assert "payout" in data
    assert "abuse_gate_tiers" in data
    assert len(data["abuse_gate_tiers"]) == 4   # free, pi-100, pi-1000, pi-10000
    assert data["abuse_gate_tiers"][0]["label"] == "free"
    assert "ledger_dsn" in data["config"]
    assert "has_billing_stripe_secret_key" in data["config"]
    assert "has_payout_stripe_secret_key" in data["config"]


def test_get_state_economic_layer_never_gates_go(tmp_path, monkeypatch):
    """THE point of this whole panel set: fully-configured-looking
    (but actually broken) economic layer settings must never affect
    the gate — only GPT4All/Vision/Imagine (per node_type) and CUDA do."""
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[Ledger]\ndsn = postgresql://totally:broken@nowhere/nothing\n"
        "[Billing]\nstripe_secret_key = sk_test_totally_fake_and_invalid\n")
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)

    import inspect
    sig = inspect.signature(wizard.is_go_allowed)
    param_names = set(sig.parameters.keys())
    assert "ledger_probe" not in param_names
    assert "billing_probe" not in param_names
    assert "payout_probe" not in param_names


def test_secrets_never_echoed_back_in_get_state(tmp_path, monkeypatch):
    """Same discipline as weather_api_key/ngrok_authtoken — has-value
    bools only, never the actual secret."""
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[Billing]\nstripe_secret_key = sk_test_super_secret_value\n")
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)

    from fastapi.testclient import TestClient
    app = wizard.build_app()
    client = TestClient(app)
    r = client.get("/api/wizard/state")
    body_text = r.text
    assert "sk_test_super_secret_value" not in body_text
    assert r.json()["config"]["has_billing_stripe_secret_key"] is True


# ─── save() — economic layer field round trip ────────────────────

def test_save_writes_ledger_dsn(tmp_path, monkeypatch):
    # Matches the REAL shipped config.ini's shape: [Ledger]/[Billing]/
    # [Payout] sections already exist with empty-string defaults (from
    # Sprints 11-14) — save_value() does an IN-PLACE line rewrite, so
    # the section+key must already be present in the file for it to
    # find and replace. A genuinely bare-minimum config.ini missing
    # these sections entirely would silently no-op here, same as it
    # would for any other schema-driven field this codebase manages
    # this way — not a Sprint 15-specific gap.
    config_ini = tmp_path / "config.ini"
    config_ini.write_text(
        "[GPT4All]\nmodel = \n"
        "[Ledger]\ndsn = \n"
        "[Billing]\nstripe_secret_key = \n"
        "stripe_webhook_secret = \n"
        "price_per_submit_micros = 100\n"
        "low_balance_threshold_micros = 10000\n")
    monkeypatch.setattr(wizard, "CONFIG_INI", config_ini)
    federation_ini = tmp_path / "federation.ini"
    federation_ini.write_text("[Federation]\ndesire = off\n")
    monkeypatch.setattr(wizard, "FEDERATION_INI", federation_ini)

    from fastapi.testclient import TestClient
    app = wizard.build_app()
    client = TestClient(app)
    resp = client.post("/api/wizard/save", json={
        "realm_name": "Test Realm", "tagline": "", "desire": False,
        "master_url": "https://rentahal.com/api/federate", "self_url": "",
        "ledger_dsn": "postgresql://user:pass@127.0.0.1:5432/mydb",
        "billing_stripe_secret_key": "sk_test_new_key",
        "billing_price_per_submit_micros": "150",
    })
    assert resp.status_code == 200
    written = config_ini.read_text()
    assert "postgresql://user:pass@127.0.0.1:5432/mydb" in written
    assert "sk_test_new_key" in written
    assert "150" in written


def test_save_empty_secret_preserves_existing_value(tmp_path, monkeypatch):
    """The 'empty field means keep existing' discipline — a blank
    billing_stripe_secret_key in the save payload must NOT erase an
    already-configured key."""
    config_ini = tmp_path / "config.ini"
    config_ini.write_text(
        "[GPT4All]\nmodel = \n"
        "[Billing]\nstripe_secret_key = sk_test_already_here\n")
    monkeypatch.setattr(wizard, "CONFIG_INI", config_ini)
    federation_ini = tmp_path / "federation.ini"
    federation_ini.write_text("[Federation]\ndesire = off\n")
    monkeypatch.setattr(wizard, "FEDERATION_INI", federation_ini)

    from fastapi.testclient import TestClient
    app = wizard.build_app()
    client = TestClient(app)
    client.post("/api/wizard/save", json={
        "realm_name": "X", "tagline": "", "desire": False,
        "master_url": "https://rentahal.com/api/federate", "self_url": "",
        "billing_stripe_secret_key": "",   # blank — must preserve existing
    })
    written = config_ini.read_text()
    assert "sk_test_already_here" in written
