// run_echo_silence_test.js — regression tests for the SILENCE button
// and the echo-guard hardening around bus_tts_complete/bus_tts_aborted.
//
// HISTORY NOTE: this file originally also asserted two further changes
// — nukeAllCardPanels() firing on every bus_query_processing, and
// playAudio's onended NOT releasing isSpeaking (deferring release
// solely to bus_tts_complete). Both were tried and found to cause a
// real regression: nukeAllCardPanels() ends by pausing the audio
// player, and firing that on EVERY query start (not just panel-opening
// ones) could cut off still-playing audio from a prior turn. Both
// changes were reverted; see run_silence_button_test.js, which
// explicitly pins the reverted (known-good) behavior for those two
// specific items. This file no longer asserts either — see that file
// for the authoritative version of "what bus_query_processing and
// playAudio's onended should do."
//
// What DID ship correctly and stays covered here:
//   1. New silenceAll() function + big visible 🔇 SILENCE button.
//      Single click kills all audio: player.pause, src='', stops
//      thinking sound, removes YouTube iframe, sends "stop stop"
//      to realm so realm halts further chunks.
//   2. bus_tts_complete is now handled (the server has always
//      published it; the browser used to ignore it) — ADDITIVE to
//      playAudio's own onended release, extending the echo guard a
//      bit longer (2s) to cover trailing reverb after the final chunk.
//   3. bus_tts_aborted also extends the echo guard (previously it set
//      isSpeaking=false but never extended the guard at all).

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── SILENCE button + silenceAll function ──────────────

// Button in controls row
assert(/id="silence-btn"/.test(html),
       'silence-btn exists in DOM');
assert(/onclick="silenceAll\(\)"/.test(html),
       'silence button wired to silenceAll()');
assert(/🔇 SILENCE/.test(html),
       'silence button shows clear "🔇 SILENCE" label');
// Big and red so users find it in panic
assert(/silence-btn[\s\S]{0,200}#cc1f1f|background:#cc1f1f/.test(html) ||
       /silenceAll[\s\S]{0,200}background:#cc1f1f/.test(html),
       'silence button is visually distinct (red background)');

// silenceAll function
assert(/function silenceAll/.test(html),
       'silenceAll function defined');

const silIdx = html.indexOf('function silenceAll');
const silEnd = html.indexOf('\nfunction ', silIdx + 1);
const silSrc = html.slice(silIdx, silEnd);

// Pauses the audio player
assert(/player\.pause\(\)/.test(silSrc),
       'silenceAll pauses the audio player');
// Clears src so queued chunks can't keep playing
assert(/player\.src\s*=\s*['"]['"]/.test(silSrc),
       'silenceAll clears player.src (drops queued audio chunks)');
// Stops thinking sound
assert(/stopThinkingSound\(\)/.test(silSrc),
       'silenceAll stops thinking sound');
// Releases speaking lock + extends echo guard
assert(/isSpeaking\s*=\s*false/.test(silSrc),
       'silenceAll releases speaking lock');
assert(/echoGuardUntil/.test(silSrc),
       'silenceAll extends echo guard (silences mic briefly)');
// Kills YouTube iframe so video audio stops too
assert(/music-player-container[\s\S]*?innerHTML\s*=\s*['"]['"]/.test(silSrc),
       'silenceAll removes YouTube iframe (kills music audio too)');
// Sends "stop stop" to realm so realm halts further chunks
assert(/['"]stop stop['"]/.test(silSrc) ||
       /sendPrompt\(['"]stop stop['"]\)/.test(silSrc),
       'silenceAll sends "stop stop" to realm (realm halts further TTS)');
// Visual feedback so user knows the click registered
assert(/SILENCED/.test(silSrc),
       'silence button shows "SILENCED" visual feedback');

// ─── Echo guard hardening ──────────────────────────────────────

// bus_tts_complete handler releases isSpeaking and extends the guard.
// ADDITIVE to playAudio's own onended release (run_silence_button_test.js
// pins that onended must still release isSpeaking on every chunk —
// this handler doesn't replace that, it adds a longer guard extension
// once the server confirms every chunk has actually been dispatched).
const completeIdx = html.indexOf("case 'bus_tts_complete'");
assert(completeIdx > 0,
       "bus_tts_complete handler added (was missing — realm published " +
       'this event but browser ignored it)');

const completeEnd = html.indexOf('break;', completeIdx);
const completeSrc = html.slice(completeIdx, completeEnd);
assert(/isSpeaking\s*=\s*false/.test(completeSrc),
       'bus_tts_complete releases speaking lock');
assert(/echoGuardUntil\s*=\s*Date\.now\(\)\s*\+\s*\d{4}/.test(completeSrc),
       'bus_tts_complete extends echo guard >=1000ms (covers reverb)');

// playAudio's onended must STILL release isSpeaking on every chunk —
// see run_silence_button_test.js, which pins this as the deliberately-
// kept known-good behavior (the alternative was tried and reverted).
const playAudioIdx = html.indexOf('function playAudio');
const playAudioEnd = html.indexOf('\nfunction ', playAudioIdx + 1);
const playAudioSrc = html.slice(playAudioIdx, playAudioEnd);
const onendedIdx = playAudioSrc.indexOf('player.onended');
const onendedEnd = playAudioSrc.indexOf('};', onendedIdx);
const onendedSrc = playAudioSrc.slice(onendedIdx, onendedEnd);
assert(/isSpeaking\s*=\s*false/.test(onendedSrc),
       'playAudio onended still releases isSpeaking (known-good behavior)');
assert(/echoGuardUntil/.test(onendedSrc),
       'playAudio onended still extends echo guard');

// bus_tts_aborted should also extend echo guard (cancellation case)
const abortedIdx = html.indexOf("case 'bus_tts_aborted'");
const abortedEnd = html.indexOf('break;', abortedIdx);
const abortedSrc = html.slice(abortedIdx, abortedEnd);
assert(/echoGuardUntil/.test(abortedSrc),
       'bus_tts_aborted extends echo guard (no mic burst after cancel)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} echo-silence tests passed`);
  process.exit(0);
}
