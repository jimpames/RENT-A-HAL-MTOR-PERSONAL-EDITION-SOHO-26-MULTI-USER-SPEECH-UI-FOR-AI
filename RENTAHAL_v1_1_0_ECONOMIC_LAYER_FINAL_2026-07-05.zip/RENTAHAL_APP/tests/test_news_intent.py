"""
Tests for the news intent slot extractor.

The classifier already routes the word "news" to kind=news; this checks
the SLOT extraction layered on top: 'news feed AP News' → {feed: 'ap news'},
'news left' → {category: 'left'}, etc.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.intent import extract_news_slots


def test_bare_news_no_slots():
    """Plain 'news' = latest from all sources, no filtering."""
    assert extract_news_slots("news", ["news"]) == {}
    assert extract_news_slots("computer news", ["computer", "news"]) == {}


def test_news_feed_simple_name():
    """'news feed bbc' → feed: bbc"""
    result = extract_news_slots("news feed bbc", ["news", "feed", "bbc"])
    assert result == {"feed": "bbc"}


def test_news_feed_multi_word_name():
    """'play news feed AP News' → feed: 'ap news'. The classifier
    lowercases, the service matches case-insensitively against 'AP News'."""
    result = extract_news_slots("play news feed ap news",
                                ["play", "news", "feed", "ap", "news"])
    assert result == {"feed": "ap news"}


def test_news_from_alias():
    """'news from npr' uses 'from' marker."""
    result = extract_news_slots("news from npr", ["news", "from", "npr"])
    assert result == {"feed": "npr"}


def test_news_source_alias():
    """'news source the guardian' uses 'source' marker."""
    result = extract_news_slots("news source the guardian",
                                ["news", "source", "the", "guardian"])
    assert result == {"feed": "the guardian"}


def test_category_left():
    """'news left' → category: left, no feed."""
    result = extract_news_slots("news left", ["news", "left"])
    assert result == {"category": "left"}


def test_category_right():
    result = extract_news_slots("news right", ["news", "right"])
    assert result == {"category": "right"}


def test_category_center():
    result = extract_news_slots("news center please",
                                ["news", "center", "please"])
    assert result == {"category": "center"}


def test_category_takes_priority_over_feed():
    """If 'left' appears AND 'feed X' appears, category wins (it's
    more specific and unambiguous). User can specify either, not both."""
    result = extract_news_slots("news left feed bbc",
                                ["news", "left", "feed", "bbc"])
    assert result == {"category": "left"}


def test_feed_with_trailing_please_stripped():
    """'news feed bbc please' → feed: bbc (not 'bbc please')."""
    result = extract_news_slots("news feed bbc please",
                                ["news", "feed", "bbc", "please"])
    assert result == {"feed": "bbc"}


def test_feed_with_punctuation_stops():
    """The regex stops at sentence enders so 'news feed bbc.' works."""
    result = extract_news_slots("news feed bbc.",
                                ["news", "feed", "bbc"])
    assert result == {"feed": "bbc"}


def test_feed_handles_hyphenated_names():
    """'news feed pbs newshour' or names with hyphens."""
    result = extract_news_slots("news feed pbs newshour",
                                ["news", "feed", "pbs", "newshour"])
    assert result == {"feed": "pbs newshour"}
