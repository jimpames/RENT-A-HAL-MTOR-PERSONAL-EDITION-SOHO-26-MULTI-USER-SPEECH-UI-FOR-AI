"""
Regression test for a real bug found while reviewing the Nuitka
compile command (not hypothetical — found by reading the actual shipped
code): app.py's compiled-mode INI directory resolved as "next to the
exe" (`Path(sys.executable).resolve().parent`), while wizard.py's
resolved as `%LOCALAPPDATA%\\RentAHalSOHO\\<version>`. Two entry points,
two different answers to "where do config.ini/federation.ini live" —
meaning a wizard edit could be completely invisible to the realm (or
vice versa), depending on which exe's directory happened to contain a
stray config.ini.

Fixed by extracting the resolution logic into realm/ini_location.py,
one shared implementation both app.py and wizard.py import — this test
locks in that they now agree, and that the module's other real
behaviors (first-run bootstrap, idempotency, non-destructiveness) work
correctly.
"""
import importlib
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm import ini_location


def test_source_mode_returns_source_dir(monkeypatch):
    monkeypatch.delenv("NUITKA_ONEFILE_PARENT", raising=False)
    monkeypatch.setattr(sys, "frozen", False, raising=False)
    source_dir = Path("/some/source/dir")
    assert ini_location.resolve_ini_dir(source_dir) == source_dir


def test_compiled_mode_uses_localappdata(monkeypatch, tmp_path):
    monkeypatch.setenv("NUITKA_ONEFILE_PARENT", "12345")
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    result = ini_location.resolve_ini_dir(Path("/irrelevant/in/compiled/mode"))
    assert result == (tmp_path / ini_location.APP_SUBFOLDER
                      / ini_location.PRODUCT_VERSION)


def test_settings_folder_never_collides_with_onefile_tempdir_names():
    """THE actual collision found while reviewing the real compile
    commands: --onefile-tempdir-spec="{CACHE_DIR}\\RentAHalSOHO\\{VERSION}"
    resolves under %LOCALAPPDATA% on Windows (Nuitka's {CACHE_DIR}
    placeholder), which would have been the EXACT same path this
    module used for persistent settings before this fix — meaning
    Nuitka's own onefile extraction could land directly on top of a
    real, operator-edited config.ini. APP_SUBFOLDER must never match
    either exe's onefile-tempdir-spec folder name."""
    known_onefile_tempdir_names = {"RentAHalSOHO", "RentAHalWizard"}
    assert ini_location.APP_SUBFOLDER not in known_onefile_tempdir_names


def test_compiled_mode_without_localappdata_falls_back_to_exe_dir(monkeypatch):
    monkeypatch.setenv("NUITKA_ONEFILE_PARENT", "12345")
    monkeypatch.delenv("LOCALAPPDATA", raising=False)
    result = ini_location.resolve_ini_dir(Path("/irrelevant"))
    assert result == Path(sys.executable).resolve().parent


def test_pyinstaller_frozen_marker_also_detected(monkeypatch):
    monkeypatch.delenv("NUITKA_ONEFILE_PARENT", raising=False)
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    assert ini_location.is_compiled() is True


def test_app_and_wizard_resolve_to_the_identical_directory(monkeypatch, tmp_path):
    """THE regression check — the actual bug. Both entry points must
    compute the exact same INI_DIR when compiled, not just similar-
    looking ones. Reloads both modules under simulated compiled-mode
    env vars to force their module-level INI_DIR computation to
    re-run, matching exactly what happens at real process startup."""
    monkeypatch.setenv("NUITKA_ONEFILE_PARENT", "12345")
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    monkeypatch.setenv("RENTAHAL_FAKE_ENGINES", "1")

    import app as app_module
    import wizard as wizard_module
    importlib.reload(app_module)
    importlib.reload(wizard_module)
    try:
        assert app_module.INI_DIR == wizard_module.INI_DIR
        assert app_module.CONFIG_PATH == wizard_module.CONFIG_INI
        assert app_module.FEDERATION_CONFIG_PATH == wizard_module.FEDERATION_INI
    finally:
        # Leave both modules in their normal (source-mode) state for
        # any test that runs after this one in the same session.
        monkeypatch.undo()
        importlib.reload(app_module)
        importlib.reload(wizard_module)


def test_ensure_default_ini_files_populates_a_fresh_directory(tmp_path):
    ini_dir = tmp_path / "fresh_appdata"
    template_dir = tmp_path / "templates"
    template_dir.mkdir()
    (template_dir / "config.ini").write_text("[Branding]\nrealm_name = Test\n")
    (template_dir / "federation.ini").write_text("[Federation]\ndesire = off\n")

    ini_location.ensure_default_ini_files(ini_dir, template_dir)

    assert (ini_dir / "config.ini").exists()
    assert (ini_dir / "federation.ini").exists()
    assert "Test" in (ini_dir / "config.ini").read_text()


def test_ensure_default_ini_files_never_overwrites_existing_edits(tmp_path):
    ini_dir = tmp_path / "appdata"
    ini_dir.mkdir()
    (ini_dir / "config.ini").write_text("[Branding]\nrealm_name = MyCustomEdit\n")
    template_dir = tmp_path / "templates"
    template_dir.mkdir()
    (template_dir / "config.ini").write_text("[Branding]\nrealm_name = DefaultTemplate\n")

    ini_location.ensure_default_ini_files(ini_dir, template_dir)

    content = (ini_dir / "config.ini").read_text()
    assert "MyCustomEdit" in content
    assert "DefaultTemplate" not in content


def test_ensure_default_ini_files_is_a_no_op_when_no_template_exists(tmp_path):
    """A source-mode dev run, or a compile that forgot to bundle the
    templates — must not crash, just leave the directory without that
    file rather than erroring."""
    ini_dir = tmp_path / "appdata"
    template_dir = tmp_path / "empty_templates"
    template_dir.mkdir()

    ini_location.ensure_default_ini_files(ini_dir, template_dir)

    assert not (ini_dir / "config.ini").exists()
    assert ini_dir.exists()   # directory itself still gets created
