"""
Test the metrics pipeline end-to-end:
  provider's last_usage → LLMChain.last_usage → Orchestrator query_result event

Three regimes:
  1. Real usage from a provider that returns a usage block (Claude/GPT4All)
  2. Approximated usage when the provider doesn't return one (Echo, HF)
  3. No usage at all when the LLM wasn't called (weather/gmail intents)

Plus: elapsed_s is positive, started_at < ended_at, tokens_per_sec computed.
"""

import asyncio
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.event_bus import EventBus
from realm.intent import IntentClassifier
from realm.engine_chain import (LLMChain, TTSChain, LLMProvider, EchoLLMProvider,
                                EchoTTSProvider, _approximate_tokens)
from realm.orchestrator import Orchestrator

pytestmark = pytest.mark.asyncio


class RealUsageProvider(LLMProvider):
    """Simulates GPT4All/Claude: returns text AND a usage block."""
    name = "Test (real usage)"
    def __init__(self, latency=0.05, tokens=42):
        self.latency = latency
        self.tokens = tokens
        self.last_usage = None
    async def is_available(self): return True
    async def generate(self, prompt, max_tokens=400):
        await asyncio.sleep(self.latency)
        self.last_usage = {"tokens_out": self.tokens, "tokens_in": 8, "approx": False}
        return "answered: " + prompt


@pytest.fixture
async def realm():
    bus = EventBus()
    llm = LLMChain([RealUsageProvider(tokens=42)])
    tts = TTSChain([EchoTTSProvider()])
    orch = Orchestrator(bus, llm, tts)
    clf = IntentClassifier(bus)
    await clf.attach()
    await orch.attach()
    log = []
    async def trace(ev): log.append((ev.type, dict(ev.payload)))
    await bus.subscribe_all(trace)
    yield bus, orch, log, llm
    await orch.detach()


async def _await_event(log, name, timeout=5):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for t, p in log:
            if t == name:
                return p
        await asyncio.sleep(0.01)
    raise TimeoutError(f"no {name}; saw {[t for t, _ in log]}")


async def test_real_usage_flows_through_to_query_result(realm):
    bus, orch, log, llm = realm
    await bus.publish("prompt_text", text="what is the realm",
                      nonce="n1", user_guid="u1")
    payload = await _await_event(log, "query_result")
    assert payload["tokens_out"] == 42, \
        f"real tokens_out should be 42, got {payload.get('tokens_out')}"
    assert payload["tokens_approx"] is False
    assert payload["tokens_per_sec"] is not None and payload["tokens_per_sec"] > 0
    assert payload["elapsed_s"] > 0
    assert payload["started_at"] < payload["ended_at"]
    assert payload["prompt"] == "what is the realm"
    assert payload["llm_provider"] == "Test (real usage)"


async def test_approximated_usage_marked_as_approx():
    """Echo provider doesn't return usage; chain approximates from word count."""
    bus = EventBus()
    llm = LLMChain([EchoLLMProvider()])
    tts = TTSChain([EchoTTSProvider()])
    orch = Orchestrator(bus, llm, tts)
    clf = IntentClassifier(bus)
    await clf.attach()
    await orch.attach()
    log = []
    await bus.subscribe_all(
        lambda ev: log.append((ev.type, dict(ev.payload))) or asyncio.sleep(0))

    try:
        await bus.publish("prompt_text", text="hello realm",
                          nonce="n2", user_guid="u2")
        payload = await _await_event(log, "query_result")
        assert payload["tokens_approx"] is True, \
            "echo provider's tokens must be marked approximate"
        assert payload["tokens_out"] > 0
        # Echo's response starts with "I heard you ask:" — word count should
        # be reasonable
        echo_response = payload["text"]
        expected_approx = _approximate_tokens(echo_response)
        assert payload["tokens_out"] == expected_approx
    finally:
        await orch.detach()


async def test_weather_intent_has_no_token_fields(realm):
    """When intent.kind != 'ask', no LLM ran — token fields should be None."""
    bus, orch, log, _ = realm
    orch.weather_handler = lambda slots, guid: asyncio.sleep(0.01) or "It's 72."

    async def weather_h(slots, guid):
        await asyncio.sleep(0.01)
        return "It's 72 degrees in your area."
    orch.weather_handler = weather_h

    await bus.publish("prompt_text", text="weather in Newburgh",
                      nonce="n3", user_guid="u3")
    payload = await _await_event(log, "query_result")
    assert payload["kind"] == "weather"
    assert payload["tokens_out"] is None, \
        "weather queries didn't use the LLM; tokens must be None"
    assert payload["tokens_per_sec"] is None
    # Elapsed should still be recorded
    assert payload["elapsed_s"] > 0


async def test_query_processing_event_carries_prompt_and_start(realm):
    """The processing event needs the prompt+start_time so the UI can show
    'thinking…' with the prompt visible from the very first frame."""
    bus, orch, log, _ = realm
    await bus.publish("prompt_text", text="quick question",
                      nonce="n4", user_guid="u4")
    proc = await _await_event(log, "query_processing")
    assert proc["prompt"] == "quick question"
    assert "started_at" in proc and proc["started_at"] > 0


async def test_tokens_per_second_is_reasonable(realm):
    """tokens_per_sec must roughly equal tokens_out / elapsed_s.
    Both values are rounded separately by the orchestrator (3dp for elapsed,
    2dp for tok/s), so divergence up to a few tok/s is expected."""
    bus, orch, log, _ = realm
    await bus.publish("prompt_text", text="speed test",
                      nonce="n5", user_guid="u5")
    payload = await _await_event(log, "query_result")
    computed = payload["tokens_out"] / payload["elapsed_s"]
    # Generous bound: rounding can shift things by a few tok/s at high rates.
    # The point is to catch "math is fundamentally wrong" not rounding noise.
    rel_err = abs(payload["tokens_per_sec"] - computed) / max(computed, 1)
    assert rel_err < 0.01, \
        f"tok/s math wrong: {payload['tokens_per_sec']} vs {computed} (rel_err={rel_err:.4f})"
    assert payload["tokens_per_sec"] > 0
