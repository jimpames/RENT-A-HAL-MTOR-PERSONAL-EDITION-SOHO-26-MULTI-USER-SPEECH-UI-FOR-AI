# Test fixtures — provenance

`hello-world.txt` and `hello-world.txt.ots` are copied verbatim from
the OpenTimestamps client's own repository:

    https://github.com/opentimestamps/opentimestamps-client/tree/master/examples

`hello-world.txt.ots` is a genuine, publicly-known, already-complete
OpenTimestamps proof — it embeds a real attestation to Bitcoin block
358391 (mined 2015-05-28). It's used here to test LOCAL/STRUCTURAL
verification (realm/ots_anchor.py's local_verify) against real data,
without needing live network access to OpenTimestamps calendar
servers or a Bitcoin node.

Copied into this repo (rather than fetched at test time) so the test
suite has no hidden network dependency on GitHub being reachable —
same reasoning as every other fixture in this test suite.
