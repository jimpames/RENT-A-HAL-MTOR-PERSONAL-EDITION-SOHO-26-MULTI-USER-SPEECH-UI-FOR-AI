"""Unit tests: SafeQueue and ConnectionManager under concurrency abuse."""

import asyncio
import random

import pytest

import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from realm.realm_core import SafeQueue, ConnectionManager, CancellableQuery

pytestmark = pytest.mark.asyncio


# ---------------------------------------------------------------------------
# SafeQueue
# ---------------------------------------------------------------------------

def make_item(guid, n):
    return {"query": {"prompt": f"q{n}"}, "user_guid": guid,
            "websocket": None, "timestamp": 0}


async def test_no_item_loss_under_consumer(monkeypatch=None):
    """Every item put is either processed or explicitly tombstoned — never lost.
    The OLD code lost items when asyncio.wait_for cancelled get() post-dequeue."""
    q = SafeQueue()
    produced, processed = 300, []

    async def consumer():
        while len(processed) + tombstoned[0] < produced:
            try:
                cq = await asyncio.wait_for(q.get(), timeout=0.5)
            except asyncio.TimeoutError:
                break
            processed.append(cq.item["_seq"])
            await q.clear_inflight(cq.item["user_guid"])

    tombstoned = [0]
    guids = [f"g{i}" for i in range(10)]

    async def producer():
        for n in range(produced):
            await q.put(make_item(random.choice(guids), n))
            if n % 7 == 0:
                await asyncio.sleep(0)

    await asyncio.gather(producer(), consumer(), consumer(), consumer())
    assert len(processed) == produced, "items were lost in the queue"
    assert len(set(processed)) == produced, "an item was processed twice"


async def test_put_does_not_block_behind_waiting_get():
    """OLD BUG: get() held the lock while awaiting, serializing put() behind it.
    Now a put while a consumer is parked must complete instantly."""
    q = SafeQueue()
    getter = asyncio.create_task(q.get())
    await asyncio.sleep(0.05)          # consumer is parked inside get()
    ok = await asyncio.wait_for(q.put(make_item("u1", 0)), timeout=0.1)
    assert ok
    cq = await asyncio.wait_for(getter, timeout=0.5)
    assert cq.item["user_guid"] == "u1"


async def test_remove_by_guid_tombstones_queued_items():
    q = SafeQueue()
    for n in range(5):
        await q.put(make_item("victim", n))
    await q.put(make_item("bystander", 99))
    await q.remove_by_guid("victim")
    cq = await asyncio.wait_for(q.get(), timeout=0.5)
    assert cq.item["user_guid"] == "bystander", "tombstoned item leaked through"
    # later queries from the same guid must still work
    await q.put(make_item("victim", 100))
    await q.clear_inflight("bystander")
    cq2 = await asyncio.wait_for(q.get(), timeout=0.5)
    assert cq2.item["user_guid"] == "victim"


async def test_remove_by_guid_cancels_inflight():
    q = SafeQueue()
    await q.put(make_item("u1", 0))
    cq = await q.get()
    started = asyncio.Event()

    async def slow(item):
        started.set()
        await asyncio.sleep(30)

    run_task = asyncio.create_task(cq.run(slow))
    await started.wait()
    await asyncio.wait_for(q.remove_by_guid("u1"), timeout=1.0)
    with pytest.raises(asyncio.CancelledError):
        await run_task
    assert q.inflight() == 0


async def test_cancel_before_start_is_effective():
    """OLD BUG: cancel() on a not-yet-started CancellableQuery was a no-op."""
    cq = CancellableQuery(make_item("u1", 0))
    await cq.cancel()

    async def should_never_run(item):
        raise AssertionError("query ran after cancellation")

    with pytest.raises(asyncio.CancelledError):
        await cq.run(should_never_run)


async def test_full_queue_rejects():
    q = SafeQueue(maxsize=2)
    assert await q.put(make_item("a", 0))
    assert await q.put(make_item("b", 1))
    assert not await q.put(make_item("c", 2))


async def test_depth_accounting():
    q = SafeQueue()
    await q.put(make_item("a", 0))
    await q.put(make_item("b", 1))
    assert (q.pending(), q.inflight(), q.depth()) == (2, 0, 2)
    await q.get()
    assert (q.pending(), q.inflight(), q.depth()) == (1, 1, 2)
    await q.clear_inflight("a")
    assert q.depth() == 1


# ---------------------------------------------------------------------------
# ConnectionManager
# ---------------------------------------------------------------------------

class FakeWS:
    def __init__(self, dies=False):
        self.dies = dies
        self.sent = []
        self.closed = False

    async def send_json(self, payload):
        if self.dies:
            raise ConnectionResetError("peer gone")
        self.sent.append(payload)

    async def close(self):
        self.closed = True


async def test_broadcast_survives_dead_sockets_and_evicts():
    """One dead socket must NOT abort the broadcast.

    With the queue-based design: broadcast enqueues to every connection.
    The drain tasks then process each queue independently. Dying sockets
    cause their drain task to trigger disconnect; live sockets get the
    message. We must wait for the drain tasks to process before asserting.
    """
    m = ConnectionManager()
    live = {f"live{i}": FakeWS() for i in range(20)}
    dead = {f"dead{i}": FakeWS(dies=True) for i in range(5)}
    for g, ws in {**live, **dead}.items():
        await m.connect(ws, g)

    await m.broadcast({"type": "queue_update", "depth": 1})   # must not raise

    # Let drain tasks process: live ones send, dead ones fail and trigger
    # disconnect. A few yields are enough at the test scale.
    for _ in range(20):
        await asyncio.sleep(0.01)
        if m.count() == 20:
            break

    for ws in live.values():
        assert len(ws.sent) == 1, "a live client missed the broadcast"
    assert m.count() == 20, "dead sockets were not evicted"
    assert all(g.startswith("live") for g in m.active_guids())


async def test_safe_send_evicts_on_failure():
    """safe_send returns True on successful ENQUEUE. The actual send happens
    later in the drain task; if send_json raises, the drain task triggers
    disconnect. Wait for that to happen before asserting eviction."""
    m = ConnectionManager()
    ws = FakeWS(dies=True)
    await m.connect(ws, "u1")
    # safe_send returns True — the payload was enqueued successfully.
    # The dying socket is discovered when the drain task tries to write.
    assert await m.safe_send("u1", {"type": "x"})
    # Let the drain task process the queue and trigger disconnect
    for _ in range(20):
        await asyncio.sleep(0.01)
        if m.count() == 0:
            break
    assert m.count() == 0, "dying socket was not evicted by drain task"


async def test_safe_send_to_unknown_guid_is_false_not_raise():
    m = ConnectionManager()
    assert not await m.safe_send("ghost", {"type": "x"})


async def test_concurrent_mutation_during_broadcast_storm():
    """Fuzz: connects/disconnects racing many broadcasts. The OLD dict
    iteration could hit RuntimeError(dict changed size) or send to a
    just-removed socket and explode."""
    m = ConnectionManager()
    stop = asyncio.Event()

    async def churn():
        i = 0
        while not stop.is_set():
            ws = FakeWS(dies=(i % 3 == 0))
            await m.connect(ws, f"churn{i % 15}")
            if i % 2:
                await m.disconnect(f"churn{(i - 1) % 15}")
            i += 1
            await asyncio.sleep(0)

    async def storm():
        for _ in range(300):
            await m.broadcast({"type": "tick"})
            await asyncio.sleep(0)

    churner = asyncio.create_task(churn())
    await asyncio.wait_for(storm(), timeout=10)
    stop.set()
    await churner          # no exception = pass


async def test_reconnect_replaces_and_closes_old_socket():
    """A fresh connect on the same guid replaces the old socket and
    allocates a fresh queue + drain task. The old socket is closed."""
    m = ConnectionManager()
    old, new = FakeWS(), FakeWS()
    await m.connect(old, "u1")
    await m.connect(new, "u1")
    assert old.closed and m.count() == 1
    assert await m.safe_send("u1", {"type": "x"})
    # Let drain task process
    for _ in range(20):
        await asyncio.sleep(0.01)
        if new.sent:
            break
    assert new.sent and not old.sent
