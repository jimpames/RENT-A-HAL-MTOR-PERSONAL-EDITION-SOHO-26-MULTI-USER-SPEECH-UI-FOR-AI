"""
Tests for the application-level ACK tracking in ConnectionManager.

The "ship and pray" problem: the realm publishes bus events but has no
idea whether the browser actually processed them. service_results could
hit a browser handler that throws, or could get lost between TCP receive
and onmessage delivery, and the realm would never know. Symptom: cards
intermittently fail to render while TTS plays fine (different events
have different fate, no diagnostic surface).

The fix: for a curated set of user-visible state-changing event types
(service_results, music_search_request, news_bundle, news_stories,
query_result), the realm:
  1. Stamps each outgoing payload with a conn_token + monotonic seq
  2. Registers a timeout warning timer (default 3.0s)
  3. The browser ACKs after the handler ran successfully
  4. On ACK, the timer is cancelled and we record the round-trip time
  5. On timeout, the timer fires and logs WARNING with event_type + guid

Why conn_token: a naive seq would collide across reconnects. With
conn_token rotating on every connect(), an ACK that arrives bearing an
old conn_token (from a page that was reloaded) is silently rejected,
so the realm cannot accidentally credit a new event with an old session's
ACK. This is the "don't cross ourselves up" guarantee.

Coverage:
  - Events of tracked types get stamped with conn_token + seq
  - Events of untracked types do NOT get an ACK timer
  - ACK with current conn_token cancels the pending timer
  - ACK with stale conn_token is silently rejected
  - ACK for unknown seq returns False without crashing
  - Timeout warning fires after ACK_TIMEOUT_S when no ACK arrives
  - Reconnect cancels all pending ACK timers from old connection
  - Disconnect cancels all pending ACK timers
  - Reconnect issues a fresh conn_token (different from old)
  - seq monotonically increases per connection
  - seq resets to 0 on reconnect
"""
import asyncio
import time

import pytest

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.realm_core import ConnectionManager


class _FakeWebSocket:
    def __init__(self):
        self.sent = []

    async def send_json(self, payload):
        # Capture a deep-enough copy that test assertions can read
        # the stamped fields without races
        self.sent.append(dict(payload))

    async def close(self):
        pass


async def _wait_until(predicate, timeout=2.0):
    deadline = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < deadline:
        if predicate():
            return True
        await asyncio.sleep(0.01)
    return False


# ─── Identity stamping ────────────────────────────────────────


@pytest.mark.asyncio
async def test_tracked_event_gets_conn_token_and_seq():
    mgr = ConnectionManager()
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    token_after_connect = mgr.get_conn_token("alice")
    assert token_after_connect is not None
    assert len(token_after_connect) == 12  # token_hex(6) gives 12 chars

    await mgr.safe_send("alice", {"type": "bus_service_results", "results": []})
    assert await _wait_until(lambda: len(ws.sent) == 1)
    sent = ws.sent[0]
    assert sent["_conn_token"] == token_after_connect
    assert sent["_seq"] == 0
    assert sent["type"] == "bus_service_results"


@pytest.mark.asyncio
async def test_seq_increments_monotonically_within_connection():
    mgr = ConnectionManager()
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    for i in range(5):
        await mgr.safe_send("alice", {"type": "bus_service_results", "n": i})
    assert await _wait_until(lambda: len(ws.sent) == 5)
    seqs = [s["_seq"] for s in ws.sent]
    assert seqs == [0, 1, 2, 3, 4]


@pytest.mark.asyncio
async def test_reconnect_rotates_conn_token_and_resets_seq():
    mgr = ConnectionManager()
    ws1 = _FakeWebSocket()
    await mgr.connect(ws1, "alice")
    token1 = mgr.get_conn_token("alice")
    await mgr.safe_send("alice", {"type": "bus_service_results"})
    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws1.sent) == 2)
    # Reconnect
    ws2 = _FakeWebSocket()
    await mgr.connect(ws2, "alice")
    token2 = mgr.get_conn_token("alice")
    assert token2 != token1, "reconnect must rotate conn_token"
    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws2.sent) == 1)
    # seq reset
    assert ws2.sent[0]["_seq"] == 0
    assert ws2.sent[0]["_conn_token"] == token2


# ─── ACK round-trip ───────────────────────────────────────────


@pytest.mark.asyncio
async def test_ack_with_current_token_cancels_pending():
    mgr = ConnectionManager()
    mgr.ACK_TIMEOUT_S = 10.0  # plenty of time so no flakes
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    token = mgr.get_conn_token("alice")
    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws.sent) == 1)
    # The pending registry should have this seq
    assert 0 in mgr._pending_acks["alice"]
    # ACK it
    result = await mgr.ack_received("alice", token, 0)
    assert result is True
    # Pending registry now empty
    assert 0 not in mgr._pending_acks.get("alice", {})


@pytest.mark.asyncio
async def test_ack_with_stale_token_is_rejected_silently():
    mgr = ConnectionManager()
    mgr.ACK_TIMEOUT_S = 10.0
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws.sent) == 1)
    # ACK with a wrong token — simulates ACK arriving after reconnect
    result = await mgr.ack_received("alice", "deadbeefcafe", 0)
    assert result is False
    # Pending registry still has the entry — the stale ACK didn't credit
    assert 0 in mgr._pending_acks["alice"]


@pytest.mark.asyncio
async def test_ack_for_unknown_seq_returns_false():
    mgr = ConnectionManager()
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    token = mgr.get_conn_token("alice")
    # Never sent anything; ACK for seq=42 should harmlessly return False
    result = await mgr.ack_received("alice", token, 42)
    assert result is False


@pytest.mark.asyncio
async def test_ack_for_unknown_guid_returns_false():
    mgr = ConnectionManager()
    result = await mgr.ack_received("ghost", "anytoken", 0)
    assert result is False


# ─── Timeout warning ──────────────────────────────────────────


@pytest.mark.asyncio
async def test_timeout_fires_when_no_ack_arrives(caplog):
    mgr = ConnectionManager()
    mgr.ACK_TIMEOUT_S = 0.05  # fast timeout for tests
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")

    import logging
    caplog.set_level(logging.WARNING)

    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws.sent) == 1)
    # Wait long enough for the timeout to fire
    await asyncio.sleep(0.15)
    # Pending registry should be empty (timer fired and removed entry)
    assert 0 not in mgr._pending_acks.get("alice", {})
    # And there should be a warning log line
    warnings = [r.message for r in caplog.records
                if r.levelno >= logging.WARNING]
    assert any("ACK MISSING" in m and "bus_service_results" in m
               for m in warnings), \
        f"expected ACK MISSING warning, got: {warnings}"


@pytest.mark.asyncio
async def test_no_warning_when_ack_arrives_before_timeout(caplog):
    mgr = ConnectionManager()
    mgr.ACK_TIMEOUT_S = 0.5  # longer timeout
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    token = mgr.get_conn_token("alice")

    import logging
    caplog.set_level(logging.WARNING)

    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws.sent) == 1)
    # ACK immediately
    await mgr.ack_received("alice", token, 0)
    # Wait past the timeout window
    await asyncio.sleep(0.55)
    # No warning should have fired
    warnings = [r.message for r in caplog.records
                if "ACK MISSING" in r.message]
    assert warnings == [], f"unexpected warnings: {warnings}"


# ─── Untracked event types don't get tracked ──────────────────


@pytest.mark.asyncio
async def test_untracked_event_does_not_register_pending_ack():
    mgr = ConnectionManager()
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    # bus_tts_chunk is NOT in ACK_TRACKED_EVENT_TYPES
    await mgr.safe_send("alice", {"type": "bus_tts_chunk", "seq": 0, "audio_b64": ""})
    assert await _wait_until(lambda: len(ws.sent) == 1)
    # No pending ACK registered
    assert mgr._pending_acks.get("alice", {}) == {}
    # Payload still stamped with conn_token + _seq (for diagnostic use)
    assert "_conn_token" in ws.sent[0]
    assert "_seq" in ws.sent[0]


@pytest.mark.asyncio
async def test_mixed_event_types_only_tracked_ones_are_acked():
    mgr = ConnectionManager()
    mgr.ACK_TIMEOUT_S = 10.0
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    # Send a mix of tracked and untracked
    await mgr.safe_send("alice", {"type": "bus_query_processing"})  # untracked
    await mgr.safe_send("alice", {"type": "bus_service_results"})   # tracked
    await mgr.safe_send("alice", {"type": "bus_tts_chunk"})         # untracked
    await mgr.safe_send("alice", {"type": "bus_query_result"})      # tracked
    await mgr.safe_send("alice", {"type": "bus_tts_complete"})      # untracked
    assert await _wait_until(lambda: len(ws.sent) == 5)
    # Only the tracked events should have pending ACKs registered.
    # Their seqs are 1 (service_results) and 3 (query_result).
    pending = mgr._pending_acks["alice"]
    assert set(pending.keys()) == {1, 3}, \
        f"expected pending acks for seq 1 and 3, got {set(pending.keys())}"


# ─── Cleanup on lifecycle events ──────────────────────────────


@pytest.mark.asyncio
async def test_disconnect_cancels_pending_ack_timers(caplog):
    mgr = ConnectionManager()
    mgr.ACK_TIMEOUT_S = 0.05
    ws = _FakeWebSocket()
    await mgr.connect(ws, "alice")
    import logging
    caplog.set_level(logging.WARNING)

    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws.sent) == 1)
    # Disconnect BEFORE the timeout would fire
    await mgr.disconnect("alice")
    # Wait past the timeout window
    await asyncio.sleep(0.15)
    # No warning should have fired (timer was cancelled)
    warnings = [r.message for r in caplog.records
                if "ACK MISSING" in r.message]
    assert warnings == [], \
        f"disconnect should have cancelled timer; got warnings: {warnings}"


@pytest.mark.asyncio
async def test_reconnect_cancels_old_pending_ack_timers(caplog):
    mgr = ConnectionManager()
    mgr.ACK_TIMEOUT_S = 0.05
    ws1 = _FakeWebSocket()
    await mgr.connect(ws1, "alice")
    import logging
    caplog.set_level(logging.WARNING)

    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws1.sent) == 1)
    # Reconnect before timeout
    ws2 = _FakeWebSocket()
    await mgr.connect(ws2, "alice")
    # Wait past the timeout window
    await asyncio.sleep(0.15)
    # Old pending ACK was for the previous connection. We CANCEL its
    # timer on reconnect so we don't emit a misleading warning about
    # an event whose connection no longer exists.
    warnings = [r.message for r in caplog.records
                if "ACK MISSING" in r.message]
    assert warnings == [], \
        f"reconnect should have cancelled old timer; got: {warnings}"


# ─── Cross-up resistance — the "don't cross ourselves up" guarantee ──


@pytest.mark.asyncio
async def test_old_ack_after_reconnect_does_not_credit_new_event():
    """The critical test for the 'don't cross ourselves up' guarantee.

    Scenario: Alice's old page sends an ACK for seq=0 with the OLD
    conn_token, but the realm receives it AFTER Alice has reconnected
    with a NEW conn_token. The realm must NOT credit this ACK to the
    new connection's seq=0 (a freshly sent service_results that's
    waiting for its own ACK)."""
    mgr = ConnectionManager()
    mgr.ACK_TIMEOUT_S = 10.0
    # Initial connection
    ws1 = _FakeWebSocket()
    await mgr.connect(ws1, "alice")
    old_token = mgr.get_conn_token("alice")
    # Reconnect (Alice reloaded)
    ws2 = _FakeWebSocket()
    await mgr.connect(ws2, "alice")
    new_token = mgr.get_conn_token("alice")
    assert old_token != new_token
    # New connection sends service_results — seq=0
    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws2.sent) == 1)
    # NEW pending ACK exists for seq=0
    assert 0 in mgr._pending_acks["alice"]
    # OLD page's ACK arrives, bearing the OLD token, for seq=0
    result = await mgr.ack_received("alice", old_token, 0)
    assert result is False, \
        "old-token ACK must NOT credit a new event (cross-up bug)"
    # NEW pending ACK still exists — the stale ACK didn't suppress it
    assert 0 in mgr._pending_acks["alice"], \
        "new event's pending ACK should still be tracked"


@pytest.mark.asyncio
async def test_two_simultaneous_users_have_distinct_conn_tokens():
    """Multi-user defense: Alice's token and Bob's token are unrelated,
    and an ACK from one cannot affect the other's pending events."""
    mgr = ConnectionManager()
    ws_alice = _FakeWebSocket()
    ws_bob = _FakeWebSocket()
    await mgr.connect(ws_alice, "alice")
    await mgr.connect(ws_bob, "bob")
    alice_token = mgr.get_conn_token("alice")
    bob_token = mgr.get_conn_token("bob")
    assert alice_token != bob_token
    # Alice sends a tracked event
    await mgr.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws_alice.sent) == 1)
    # Bob's "ACK" arrives, with HIS token but Alice's seq — clearly wrong.
    # ack_received looks up the guid first, so bob's token wouldn't match
    # alice's token even for the same seq. But more importantly the call
    # is for ack_received("bob", bob_token, 0) — Bob has no pending acks,
    # so it just returns False.
    result = await mgr.ack_received("bob", bob_token, 0)
    assert result is False
    # Alice's pending ACK still exists
    assert 0 in mgr._pending_acks["alice"]


@pytest.mark.asyncio
async def test_realm_restart_simulation_orphans_all_acks():
    """If we simulate a realm restart by re-instantiating the manager,
    any ACK arriving with a token from the old instance is naturally
    orphaned because the new instance has zero pending state.

    This isn't a defended invariant — it's a property that falls out
    of the design. We test it so a regression would be obvious."""
    mgr_old = ConnectionManager()
    ws = _FakeWebSocket()
    await mgr_old.connect(ws, "alice")
    old_token = mgr_old.get_conn_token("alice")
    await mgr_old.safe_send("alice", {"type": "bus_service_results"})
    assert await _wait_until(lambda: len(ws.sent) == 1)
    # "Restart" — fresh manager. Even if Alice's old browser sent an ACK
    # with old_token for seq=0, the new manager has no record of Alice.
    mgr_new = ConnectionManager()
    result = await mgr_new.ack_received("alice", old_token, 0)
    assert result is False
