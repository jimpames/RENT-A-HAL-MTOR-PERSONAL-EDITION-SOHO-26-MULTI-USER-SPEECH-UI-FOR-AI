"""
Regression tests for make_service_handler.

Architecture being tested:
  1. Handler reads user's location from get_user_location callback
  2. Reverse-geocodes lat/lon → city name via Nominatim
  3. Calls BizData with city + OSM category
  4. Computes haversine distance from user to each result
  5. Sorts by distance, takes top N, publishes bus event
  6. Returns brief spoken summary for TTS

Tests stub aiohttp so we can verify:
  - Correct URLs are called (Nominatim + BizData, NOT Google or Yelp)
  - Results are sorted by distance
  - Top result speaks correct distance and bearing
  - "No location" case is handled
  - "No results" case is handled
  - Disabled-via-config short-circuits without any HTTP
"""

import asyncio
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

pytestmark = pytest.mark.asyncio


class FakeResponse:
    def __init__(self, body, json_data=None, status=200):
        self._body = body
        self._json = json_data
        self.status = status

    async def text(self):
        return self._body

    async def json(self):
        return self._json

    async def __aenter__(self): return self
    async def __aexit__(self, *args): pass


class FakeSession:
    """Captures GET calls. Returns different responses based on URL."""
    nominatim_response = None
    bizdata_response = None
    raise_exc = None
    calls = []

    def __init__(self, *args, **kwargs):
        pass

    async def __aenter__(self): return self
    async def __aexit__(self, *args): pass

    def get(self, url, params=None, timeout=None):
        FakeSession.calls.append({"url": url, "params": params or {}})
        if FakeSession.raise_exc:
            raise FakeSession.raise_exc
        if "nominatim" in url:
            return FakeSession.nominatim_response or FakeResponse(
                "", json_data={"address": {"city": "Newburgh"}})
        if "bizdata" in url or "businesses" in url:
            return FakeSession.bizdata_response or FakeResponse(
                "", json_data={"businesses": []})
        return FakeResponse("", json_data={})


@pytest.fixture(autouse=True)
def reset_session():
    FakeSession.calls = []
    FakeSession.nominatim_response = None
    FakeSession.bizdata_response = None
    FakeSession.raise_exc = None
    yield


class FakeBus:
    def __init__(self):
        self.events = []

    async def publish(self, event_type, **payload):
        self.events.append({"type": event_type, "payload": payload})


def _cfg(enabled=True, radius=5, max_results=3):
    return {
        "Service": {
            "enabled": str(enabled).lower(),
            "bizdata_url": "https://bizdata-web.vercel.app/api/businesses",
            "nominatim_url": "https://nominatim.openstreetmap.org/reverse",
            "radius_km": str(radius),
            "max_results": str(max_results),
            "timeout_s": "12",
        }
    }


def _cfg_get(cfg, section, key, default=""):
    return cfg.get(section, {}).get(key, default)


def _user_loc(lat=41.5, lon=-74.0):
    return lambda guid: {"lat": lat, "lon": lon, "ts": 0}


# Sample businesses near user at (41.5, -74.0)
SAMPLE_BUSINESSES = {
    "businesses": [
        {  # ~0.5 mi north
            "name": "Joe's Barber",
            "category": "hairdresser",
            "address": "123 Main St, Newburgh",
            "phone": "+1 845-555-0123",
            "website": "https://joesbarber.example",
            "lat": 41.507,
            "lon": -74.0,
            "opening_hours": "Mo-Sa 09:00-18:00",
        },
        {  # ~2 mi east — should rank LAST
            "name": "Far Cuts",
            "category": "hairdresser",
            "address": "999 Far Ave, Newburgh",
            "phone": "+1 845-555-9999",
            "website": "",
            "lat": 41.5,
            "lon": -73.972,
            "opening_hours": "",
        },
        {  # ~1 mi south
            "name": "Buzz Salon",
            "category": "hairdresser",
            "address": "456 Oak Rd, Newburgh",
            "phone": "+1 845-555-0456",
            "website": "https://buzzsalon.example",
            "lat": 41.486,
            "lon": -74.0,
            "opening_hours": "Tu-Su 10:00-19:00",
        },
    ]
}


# ─── Happy path ────────────────────────────────────────────────

async def test_finds_haircut_sorts_by_distance():
    """Three results returned; top 3 sorted by haversine distance."""
    FakeSession.nominatim_response = FakeResponse(
        "", json_data={"address": {"city": "Newburgh"}})
    FakeSession.bizdata_response = FakeResponse(
        "", json_data=SAMPLE_BUSINESSES)
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        result = await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    # Spoken summary mentions the CLOSEST result, not the furthest
    assert "Joe's Barber" in result, f"closest result missing: {result!r}"
    # Bus event published with top 3 in distance order
    assert len(bus.events) == 1
    ev = bus.events[0]
    assert ev["type"] == "service_results"
    results = ev["payload"]["results"]
    assert len(results) == 3
    assert results[0]["name"] == "Joe's Barber"
    assert results[1]["name"] == "Buzz Salon"
    assert results[2]["name"] == "Far Cuts"
    # Distances are computed
    assert results[0]["distance_mi"] < results[1]["distance_mi"]
    assert results[1]["distance_mi"] < results[2]["distance_mi"]
    # Bearings are sensible compass directions
    assert results[0]["bearing"] in {"north", "northeast", "northwest"}
    assert results[2]["bearing"] in {"east", "northeast", "southeast"}


async def test_max_results_caps_at_config():
    """max_results = 2 should give 2 results, not 3."""
    FakeSession.nominatim_response = FakeResponse(
        "", json_data={"address": {"city": "Newburgh"}})
    FakeSession.bizdata_response = FakeResponse(
        "", json_data=SAMPLE_BUSINESSES)
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(max_results=2), _user_loc())
        await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    results = bus.events[0]["payload"]["results"]
    assert len(results) == 2


async def test_spoken_summary_includes_distance_and_bearing():
    """Top result summary should be informative."""
    FakeSession.nominatim_response = FakeResponse(
        "", json_data={"address": {"city": "Newburgh"}})
    FakeSession.bizdata_response = FakeResponse(
        "", json_data=SAMPLE_BUSINESSES)
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        result = await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    assert "miles" in result.lower()
    # Some compass direction should be mentioned
    assert any(d in result.lower() for d in
               ["north", "south", "east", "west"])


# ─── Negative paths ────────────────────────────────────────────

async def test_no_location_returns_helpful_message():
    """User hasn't sent location → friendly error, NO HTTP call."""
    bus = FakeBus()
    no_location = lambda guid: None
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), no_location)
        result = await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    assert "location" in result.lower()
    assert len(FakeSession.calls) == 0
    assert len(bus.events) == 0


async def test_no_category_returns_helpful_message():
    """Empty slots → friendly prompt, no HTTP."""
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        result = await handler({}, "test-user", bus)
    assert "category" in result.lower() or "service finder" in result.lower()
    assert len(FakeSession.calls) == 0
    assert len(bus.events) == 0


async def test_unmatched_category_returns_helpful_message():
    """Category like 'unicorn fountain' (not in map) → friendly explanation."""
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        result = await handler(
            {"category_unmatched": "unicorn fountain"},
            "test-user", bus)
    assert "recognize" in result.lower() or "unicorn" in result.lower()
    assert len(bus.events) == 0


async def test_bizdata_returns_no_results():
    """BizData returns empty list → friendly message, no bus event."""
    FakeSession.nominatim_response = FakeResponse(
        "", json_data={"address": {"city": "Nowheresville"}})
    FakeSession.bizdata_response = FakeResponse(
        "", json_data={"businesses": []})
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        result = await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    assert "couldn't" in result.lower() or "no " in result.lower()
    assert len(bus.events) == 0


async def test_nominatim_failure():
    """Reverse-geocoding fails → friendly error."""
    FakeSession.nominatim_response = FakeResponse(
        "", json_data={}, status=500)
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        result = await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    assert "city" in result.lower() or "couldn't" in result.lower()


async def test_bizdata_network_error():
    """BizData unreachable → graceful error message."""
    FakeSession.nominatim_response = FakeResponse(
        "", json_data={"address": {"city": "Newburgh"}})
    # First call (Nominatim) succeeds; we'll raise on the next session
    # Actually the easier sabotage: raise on every get
    FakeSession.raise_exc = asyncio.TimeoutError()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        result = await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    # We should get some kind of friendly error, not a crash
    assert isinstance(result, str)
    assert len(result) > 0


async def test_disabled_via_config():
    """[Service] enabled=false → no HTTP, returns disabled message."""
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(enabled=False), _user_loc())
        result = await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    assert "disabled" in result.lower()
    assert len(FakeSession.calls) == 0
    assert len(bus.events) == 0


# ─── Architecture invariants ─────────────────────────────────

async def test_calls_only_osm_endpoints():
    """The handler must hit Nominatim + BizData only — NOT Google,
    NOT Yelp, NOT Apple Maps."""
    FakeSession.nominatim_response = FakeResponse(
        "", json_data={"address": {"city": "Newburgh"}})
    FakeSession.bizdata_response = FakeResponse(
        "", json_data=SAMPLE_BUSINESSES)
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "test-user", bus)
    for call in FakeSession.calls:
        url = call["url"].lower()
        assert "googleapis" not in url
        assert "yelp" not in url
        assert "places-api" not in url
        # Should hit either nominatim or bizdata
        assert ("nominatim" in url or "bizdata" in url or
                "openstreetmap" in url or "businesses" in url)


async def test_bus_event_isolated_to_user():
    """Service results should be tagged with the requesting user's guid."""
    FakeSession.nominatim_response = FakeResponse(
        "", json_data={"address": {"city": "Newburgh"}})
    FakeSession.bizdata_response = FakeResponse(
        "", json_data=SAMPLE_BUSINESSES)
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeSession):
        from app import make_service_handler
        handler = make_service_handler(_cfg(), _user_loc())
        await handler(
            {"category": "hairdresser", "category_label": "haircut"},
            "alice-guid-xxx", bus)
    assert bus.events[0]["payload"]["user_guid"] == "alice-guid-xxx"


# ─── Compliance: realm has no proprietary-mapping references ────

def test_realm_does_not_call_google_or_yelp():
    """The realm code must never reference Google Places, Yelp, or
    Apple Maps APIs. Only OSM-backed services (BizData, Nominatim,
    Overpass) are allowed."""
    import pathlib
    realm_dir = pathlib.Path(__file__).resolve().parent.parent
    suspect_files = [
        realm_dir / "app.py",
        realm_dir / "realm" / "orchestrator.py",
        realm_dir / "realm" / "intent.py",
    ]
    BANNED = [
        "googleapis.com/places",
        "maps.googleapis.com",
        "places.googleapis.com",
        "yelp_api_key",
        "YELP_API_KEY",
        "api.yelp.com",
        "mapquestapi.com",
        "google_places_api_key",
    ]
    for f in suspect_files:
        if not f.exists():
            continue
        content = f.read_text(encoding="utf-8")
        for banned in BANNED:
            assert banned not in content, (
                f"{f.name} contains '{banned}' — but the service finder "
                "MUST use OpenStreetMap-backed services only "
                "(BizData / Nominatim / Overpass)."
            )
