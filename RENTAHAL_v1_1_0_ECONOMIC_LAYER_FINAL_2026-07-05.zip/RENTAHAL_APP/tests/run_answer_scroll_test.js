// run_answer_scroll_test.js — regression tests for:
//   1. Bug: After help (or any tall panel) is shown, an AI chat query
//      arrives, the answer text is set but the user can't see it
//      because they're scrolled down. Fix: scroll answer back into view
//      on bus_query_result for ask/weather kinds (not service/music/news
//      which have their own panel scroll).
//   2. Watchdog dropped from 30s → 15s per user feedback ("30 sec is
//      too much drop it to 15").

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Watchdog timing ──────────────────────────────────────────

assert(/const\s+THINKING_MAX_MS\s*=\s*15000/.test(html),
       'THINKING_MAX_MS is 15000 (15 seconds, was 30000)');
// Make sure the old value isn't still lurking somewhere
assert(!/THINKING_MAX_MS\s*=\s*30000/.test(html),
       'no stale 30000ms reference for THINKING_MAX_MS');

// ─── scrollAnswerIntoView helper exists ───────────────────────

assert(/function scrollAnswerIntoView/.test(html),
       'scrollAnswerIntoView helper function exists');

const scrollAnswerIdx = html.indexOf('function scrollAnswerIntoView');
const nextFnIdx = html.indexOf('\nfunction ', scrollAnswerIdx + 1);
assert(scrollAnswerIdx > 0 && nextFnIdx > scrollAnswerIdx,
       'scrollAnswerIntoView extractable');
const scrollAnswerSrc = html.slice(scrollAnswerIdx, nextFnIdx);

assert(/requestAnimationFrame/.test(scrollAnswerSrc),
       'scrollAnswerIntoView uses requestAnimationFrame');
assert(/scrollIntoView/.test(scrollAnswerSrc),
       'scrollAnswerIntoView uses scrollIntoView API');
assert(/block:\s*['"]nearest['"]/.test(scrollAnswerSrc),
       'scrollAnswerIntoView uses block:nearest (no jitter if already visible)');
assert(/catch/.test(scrollAnswerSrc),
       'scrollAnswerIntoView has fallback for older browsers');

// ─── bus_query_result calls scrollAnswerIntoView selectively ──

const qResultIdx = html.indexOf("case 'bus_query_result':");
const qResultEnd = html.indexOf('break;', qResultIdx);
const qResultSrc = html.slice(qResultIdx, qResultEnd);

assert(/scrollAnswerIntoView/.test(qResultSrc),
       'bus_query_result calls scrollAnswerIntoView (fixes "answer hidden after help" bug)');

// Critical: must NOT scroll the answer when this is a service/music/news
// kind, because those have their own panel scroll that should win.
assert(/msg\.kind\s*!==\s*['"]service['"]/.test(qResultSrc),
       'bus_query_result skips answer-scroll for service kind (panel scroll wins)');
assert(/msg\.kind\s*!==\s*['"]music['"]/.test(qResultSrc),
       'bus_query_result skips answer-scroll for music kind (panel scroll wins)');
assert(/msg\.kind\s*!==\s*['"]news['"]/.test(qResultSrc),
       'bus_query_result skips answer-scroll for news kind (panel scroll wins)');

// Order: must set textContent BEFORE scrolling (otherwise we scroll to
// stale content)
const textBeforeScroll =
  qResultSrc.indexOf('answerEl.textContent') <
  qResultSrc.indexOf('scrollAnswerIntoView');
assert(textBeforeScroll,
       'answer text is set BEFORE scrolling (so we scroll to the new content)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} answer-scroll/watchdog tests passed`);
  process.exit(0);
}
