// run_metrics_layout_shift_test.js — regression test for the
// "video freezes momentarily during YouTube playback, audio stays
// perfect" bug.
//
// Root cause: #metrics-row and #federation-row use flex-wrap with no
// reserved height. Their variable-length text (tokens-out counter
// growing digits, avg-time fields flipping between "—" and "1.23s")
// occasionally crosses the wrap threshold and flips the row between
// one line and two — a HEIGHT change that pushes every panel below it
// (including the music panel's YouTube <iframe>) down by that many
// pixels. Repositioning a playing iframe forces the browser to
// reflow + repaint it, which can freeze the video for a frame or two
// while its audio (already scheduled ahead) keeps playing.
//
// Fix: min-height on both rows so their box size never changes
// regardless of wrap state, plus tabular-nums so digit width jitter
// doesn't even get a chance to cross the threshold in the first place.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// Pull just the <style> block so we're checking CSS, not JS/markup.
const styleMatch = html.match(/<style>([\s\S]*?)<\/style>/);
assert(!!styleMatch, 'index.html has a <style> block');
const css = styleMatch ? styleMatch[1] : '';

// ─── The actual fix ─────────────────────────────────────────────

assert(/#metrics-row\s*,\s*#federation-row\s*\{[^}]*min-height/.test(css),
       '#metrics-row and #federation-row have a reserved min-height',
       'height must be pinned so wrap-state changes never move panels below');

assert(/#metrics-row\s*,\s*#federation-row\s*\{[^}]*font-variant-numeric:\s*tabular-nums/.test(css),
       '#metrics-row and #federation-row use tabular-nums',
       'stabilizes digit width so avg-time/token-count updates jitter less');

// ─── Structural invariant that made this bug possible in the first
//     place — locking it in so a future refactor doesn't silently
//     reintroduce the freeze by deleting the min-height fix while
//     leaving flex-wrap in place. ───────────────────────────────

assert(/\.status\s*\{[^}]*flex-wrap:\s*wrap/.test(css),
       '.status still uses flex-wrap (confirms the fix is still needed, '
       + 'not just coincidentally passing)');

// ─── Document-flow invariant: the music panel must still be a normal
//     flow sibling below the status panel (not position:fixed / a
//     modal overlay) — that's WHY a height change above it matters.
//     If this ever changes, the layout-shift mechanism no longer
//     applies and this whole fix (and test) should be revisited. ──

assert(/id="music-panel"/.test(html),
       'music-panel exists (sanity check the element this bug affects is still present)');

if (failCount > 0) {
  console.log(`\nFAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`\nOK: ${passCount} metrics layout-shift tests passed`);
}
