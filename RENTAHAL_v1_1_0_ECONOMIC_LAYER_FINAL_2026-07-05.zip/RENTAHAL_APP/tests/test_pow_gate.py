"""
Sprint 10 — tests for realm/pow_gate.py.

Deliberately runs at LOW difficulty (bits <= 4, a handful of
milliseconds each) so the routine test suite stays fast — this file
tests CORRECTNESS of the mechanism, not real wall-clock tier costs.
The actual difficulty ladder's wall-clock timing is verified
separately in pow_benchmark.py (a standalone script, not collected by
pytest, since solving even the pi-1000 tier honestly takes real
seconds and has no place slowing down a suite that otherwise runs in
~20 seconds).

Covers:
  - tier_for_count: pure function, the difficulty ladder math
  - count_leading_zero_bits: the difficulty measure itself
  - generate_challenge / verify_solution: the signed round trip
  - Tampering: difficulty_bits, expiry, challenge, nonce, wrong secret
  - Expiry enforcement
  - RateLimitTracker: sliding window count/prune behavior
  - SubmissionThrottle: the cheap gate in front of the expensive one
  - PowGate.check: the full endpoint-facing flow — free tier, paid
    tier issuing a challenge, solving and resubmitting, tampered
    resubmission, throttled resubmission flood, enabled=False bypass
"""
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.pow_gate import (
    PowGate, RateLimitTracker, SubmissionThrottle,
    count_leading_zero_bits, generate_challenge, solve_challenge,
    tier_for_count, verify_solution,
)

SECRET = b"test-secret-at-least-16-bytes!!"


# ─── tier_for_count ──────────────────────────────────────────────────

def test_tier_free_below_threshold():
    assert tier_for_count(0) == ("free", 0)
    assert tier_for_count(9) == ("free", 0)


def test_tier_boundaries_are_inclusive_at_threshold():
    assert tier_for_count(10) == ("pi-100", 4)
    assert tier_for_count(50) == ("pi-1000", 8)
    assert tier_for_count(200) == ("pi-10000", 12)


def test_tier_just_below_boundary_is_previous_tier():
    assert tier_for_count(49) == ("pi-1000", 8) or tier_for_count(49)[1] == 4
    # 49 is between the pi-100 (10) and pi-1000 (50) thresholds -> pi-100
    assert tier_for_count(49) == ("pi-100", 4)


def test_tier_escalates_beyond_last_threshold():
    label, bits = tier_for_count(200)
    assert bits == 12
    label2, bits2 = tier_for_count(400)
    assert bits2 == 14   # +1 escalation step (200 calls past 200)
    label3, bits3 = tier_for_count(600)
    assert bits3 == 16   # +2 escalation steps


def test_tier_escalation_caps_at_max_difficulty():
    label, bits = tier_for_count(1_000_000)
    assert bits == 32   # MAX_DIFFICULTY_BITS, never exceeds it


# ─── count_leading_zero_bits ─────────────────────────────────────────

def test_leading_zero_bits_all_zero():
    assert count_leading_zero_bits(b"\x00\x00\x00\x00") == 32


def test_leading_zero_bits_none():
    assert count_leading_zero_bits(b"\xff\x00") == 0


def test_leading_zero_bits_partial_byte():
    assert count_leading_zero_bits(b"\x0f") == 4   # 0000 1111
    assert count_leading_zero_bits(b"\x01") == 7   # 0000 0001


def test_leading_zero_bits_stops_at_first_nonzero_byte():
    assert count_leading_zero_bits(b"\x00\x0f\xff") == 12


# ─── generate_challenge / verify_solution round trip ────────────────

def test_valid_solution_verifies():
    challenge = generate_challenge(SECRET, difficulty_bits=2, tier_label="test")
    sol = solve_challenge(challenge)
    assert sol is not None
    ok, reason = verify_solution(SECRET, sol)
    assert ok is True
    assert reason == "ok"


def test_tampered_difficulty_bits_rejected():
    """THE core security property: a client can't solve an easy
    puzzle and then claim it solved a harder one — the signature
    covers difficulty_bits, not just challenge+expiry."""
    challenge = generate_challenge(SECRET, difficulty_bits=2, tier_label="test")
    sol = solve_challenge(challenge)
    tampered = dict(sol)
    tampered["difficulty_bits"] = 0
    ok, reason = verify_solution(SECRET, tampered)
    assert ok is False
    assert reason == "invalid signature"


def test_tampered_expiry_rejected():
    challenge = generate_challenge(SECRET, difficulty_bits=2, tier_label="test")
    sol = solve_challenge(challenge)
    tampered = dict(sol)
    tampered["expiry"] = time.time() + 99999
    ok, reason = verify_solution(SECRET, tampered)
    assert ok is False
    assert reason == "invalid signature"


def test_tampered_challenge_rejected():
    challenge = generate_challenge(SECRET, difficulty_bits=2, tier_label="test")
    sol = solve_challenge(challenge)
    other_challenge = generate_challenge(SECRET, difficulty_bits=2, tier_label="test")
    tampered = dict(sol)
    tampered["challenge"] = other_challenge["challenge"]
    ok, reason = verify_solution(SECRET, tampered)
    assert ok is False
    assert reason == "invalid signature"


def test_wrong_nonce_rejected():
    """A syntactically valid, correctly-signed challenge, but the
    nonce doesn't actually satisfy the difficulty requirement."""
    challenge = generate_challenge(SECRET, difficulty_bits=8, tier_label="test")
    import base64
    fake_sol = {
        "challenge": challenge["challenge"],
        "expiry": challenge["expiry"],
        "difficulty_bits": challenge["difficulty_bits"],
        "signature": challenge["signature"],
        "nonce": base64.urlsafe_b64encode((0).to_bytes(8, "big")).decode(),
    }
    ok, reason = verify_solution(SECRET, fake_sol)
    # Overwhelmingly likely nonce=0 doesn't satisfy an 8-bit
    # requirement (1/256 chance it would) — assert the failure mode
    # is specifically "insufficient difficulty", not something else.
    if not ok:
        assert reason == "insufficient difficulty"


def test_expired_challenge_rejected():
    challenge = generate_challenge(SECRET, difficulty_bits=2, tier_label="test",
                                   ttl_s=-1.0)   # already expired
    sol = solve_challenge(challenge)
    ok, reason = verify_solution(SECRET, sol)
    assert ok is False
    assert reason == "challenge expired"


def test_wrong_server_secret_rejected():
    challenge = generate_challenge(SECRET, difficulty_bits=2, tier_label="test")
    sol = solve_challenge(challenge)
    ok, reason = verify_solution(b"a-completely-different-secret!!", sol)
    assert ok is False
    assert reason == "invalid signature"


def test_malformed_solution_rejected_gracefully():
    ok, reason = verify_solution(SECRET, {"garbage": True})
    assert ok is False
    assert reason == "malformed solution"


def test_malformed_base64_rejected_gracefully():
    challenge = generate_challenge(SECRET, difficulty_bits=2, tier_label="test")
    sol = solve_challenge(challenge)
    tampered = dict(sol)
    tampered["nonce"] = "not valid base64!!!"
    ok, reason = verify_solution(SECRET, tampered)
    assert ok is False
    assert reason == "malformed encoding"


# ─── RateLimitTracker ────────────────────────────────────────────────

def test_rate_tracker_counts_zero_initially():
    t = RateLimitTracker(window_s=60.0)
    assert t.count("key1") == 0


def test_rate_tracker_counts_recorded_calls():
    t = RateLimitTracker(window_s=60.0)
    for _ in range(5):
        t.record("key1")
    assert t.count("key1") == 5


def test_rate_tracker_prunes_old_entries():
    t = RateLimitTracker(window_s=10.0)
    now = 1000.0
    t.record("key1", now=now - 20.0)   # outside window
    t.record("key1", now=now - 5.0)    # inside window
    assert t.count("key1", now=now) == 1


def test_rate_tracker_keys_are_independent():
    t = RateLimitTracker(window_s=60.0)
    t.record("key1")
    t.record("key1")
    t.record("key2")
    assert t.count("key1") == 2
    assert t.count("key2") == 1


# ─── SubmissionThrottle ──────────────────────────────────────────────

def test_submission_throttle_allows_under_limit():
    th = SubmissionThrottle(max_per_window=3, window_s=10.0)
    assert th.allow("key1") is True
    assert th.allow("key1") is True
    assert th.allow("key1") is True


def test_submission_throttle_blocks_over_limit():
    th = SubmissionThrottle(max_per_window=3, window_s=10.0)
    for _ in range(3):
        th.allow("key1")
    assert th.allow("key1") is False


def test_submission_throttle_resets_after_window():
    th = SubmissionThrottle(max_per_window=2, window_s=10.0)
    now = 1000.0
    th.allow("key1", now=now)
    th.allow("key1", now=now)
    assert th.allow("key1", now=now) is False
    assert th.allow("key1", now=now + 11.0) is True   # window passed


# ─── PowGate — the full endpoint-facing flow ─────────────────────────

def test_gate_free_tier_allowed_without_solution():
    gate = PowGate(secret=SECRET)
    result = gate.check("1.2.3.4", None)
    assert result.allowed is True


def test_gate_disabled_always_allows():
    gate = PowGate(secret=b"", enabled=False)
    for _ in range(500):   # would be well into escalating tiers if enabled
        result = gate.check("1.2.3.4", None)
        assert result.allowed is True


def test_gate_rejects_short_secret_when_enabled():
    with pytest.raises(ValueError):
        PowGate(secret=b"short", enabled=True)


def test_gate_issues_challenge_past_free_tier():
    gate = PowGate(secret=SECRET, tiers=[(0, "free", 0), (3, "pi-100", 2)])
    for _ in range(3):
        gate.check("1.2.3.4", None)
    result = gate.check("1.2.3.4", None)
    assert result.allowed is False
    assert result.status_code == 402
    assert result.response_body["error"] == "proof_of_work_required"
    assert result.response_body["tier"] == "pi-100"
    assert result.response_body["difficulty_bits"] == 2


def test_gate_accepts_valid_solved_challenge():
    gate = PowGate(secret=SECRET, tiers=[(0, "free", 0), (3, "pi-100", 2)])
    for _ in range(3):
        gate.check("1.2.3.4", None)
    challenge_result = gate.check("1.2.3.4", None)
    solution = solve_challenge(challenge_result.response_body)
    final = gate.check("1.2.3.4", solution)
    assert final.allowed is True


def test_gate_rejects_tampered_resubmission():
    gate = PowGate(secret=SECRET, tiers=[(0, "free", 0), (3, "pi-100", 2)])
    for _ in range(3):
        gate.check("1.2.3.4", None)
    challenge_result = gate.check("1.2.3.4", None)
    solution = solve_challenge(challenge_result.response_body)
    solution["difficulty_bits"] = 0   # attempt to downgrade
    final = gate.check("1.2.3.4", solution)
    assert final.allowed is False
    assert "invalid_proof_of_work" in final.response_body["error"]


def test_gate_different_keys_tracked_independently():
    gate = PowGate(secret=SECRET, tiers=[(0, "free", 0), (2, "pi-100", 2)])
    gate.check("alice", None)
    gate.check("alice", None)
    # alice is now past the free threshold
    alice_result = gate.check("alice", None)
    assert alice_result.allowed is False
    # bob has made zero calls — still free
    bob_result = gate.check("bob", None)
    assert bob_result.allowed is True


def test_gate_flood_of_wrong_solutions_gets_throttled():
    """The cheap gate in front of the expensive gate: repeated invalid
    submissions against the same key eventually get a 429, not endless
    Argon2id verification attempts."""
    gate = PowGate(secret=SECRET, tiers=[(0, "free", 0), (1, "pi-100", 4)],
                   submission_max_per_window=3, submission_window_s=10.0)
    gate.check("flooder", None)   # consume the free call
    challenge_result = gate.check("flooder", None)
    bogus_solution = {
        "challenge": challenge_result.response_body["challenge"],
        "expiry": challenge_result.response_body["expiry"],
        "difficulty_bits": challenge_result.response_body["difficulty_bits"],
        "signature": challenge_result.response_body["signature"],
        "nonce": "AAAAAAAAAAA=",   # almost certainly wrong
    }
    results = [gate.check("flooder", bogus_solution) for _ in range(6)]
    status_codes = [r.status_code for r in results]
    assert 429 in status_codes   # throttle kicked in before all 6 ran full Argon2id
