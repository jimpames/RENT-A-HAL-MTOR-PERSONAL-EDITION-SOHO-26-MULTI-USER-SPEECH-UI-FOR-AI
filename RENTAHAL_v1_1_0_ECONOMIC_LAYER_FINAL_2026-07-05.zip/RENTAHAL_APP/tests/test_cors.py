"""
Tests for CORS middleware on /api/* endpoints.

Bug: Little Johnny saves an HTML file with `fetch("https://rentahal.com/api/ask")`
to his desktop, opens it via file://, browser blocks the response because
the API didn't include CORS headers. Server log shows "200 OK" but the
JS callback never receives the data.

Fix: FastAPI CORSMiddleware added with default allow_origins=*. This
makes the API readable from any origin, including file://. Config-driven
so operators can lock it down.

Coverage:
  - Default config -> any origin can call /api
  - OPTIONS preflight returns 200 with correct headers
  - Configured origin list -> only listed origins allowed
  - Wildcard + credentials guard (browser rule)
  - WebSocket /ws is not affected by CORS middleware
  - GET, POST, OPTIONS allowed; PUT/DELETE not
"""
import os
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Force fake engines so we don't need GPT4All / Kokoro running
os.environ["RENTAHAL_FAKE_ENGINES"] = "1"


@pytest.fixture
def client():
    """Build a fresh app instance with the default config.

    NOTE: this used to call a `build_app()` that never actually existed
    in app.py (app.py's boot function has always been `create_app(cfg,
    logger)`, requiring a config object — `build_app()` is wizard.py's
    function, for its own separate FastAPI app). This fixture silently
    errored on every run via ImportError, which pytest reports as a
    setup ERROR rather than a FAILURE — easy to miss in a large test
    run's summary line. Fixed to use the same load_ini() + setup_logging()
    + create_app(cfg, logger) pattern every other test file in this
    suite already uses."""
    from app import load_ini, setup_logging, create_app
    cfg = load_ini()
    logger = setup_logging(cfg)
    app = create_app(cfg, logger)
    return TestClient(app)


def test_default_cors_allows_any_origin(client):
    """Default config (allowed_origins=*) -> requests from any origin succeed
    and the response carries Access-Control-Allow-Origin."""
    r = client.get(
        "/api/setup_status",
        headers={"Origin": "https://littlejohnny.example.com"},
    )
    assert r.status_code == 200
    assert "access-control-allow-origin" in {k.lower() for k in r.headers}


def test_options_preflight_returns_ok(client):
    """The browser preflights cross-origin POSTs with OPTIONS. Must return
    200 (or 204) with the right Allow-Origin / Allow-Methods headers."""
    r = client.options(
        "/api/ask",
        headers={
            "Origin": "https://anywhere.example.com",
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "Content-Type",
        },
    )
    assert r.status_code in (200, 204)
    h = {k.lower(): v for k, v in r.headers.items()}
    assert "access-control-allow-origin" in h
    assert "access-control-allow-methods" in h
    assert "POST" in h["access-control-allow-methods"]


def test_options_preflight_allows_content_type_header(client):
    """The POST /api/ask demo sends Content-Type: application/json.
    Preflight must report this header as allowed, or the browser rejects."""
    r = client.options(
        "/api/ask",
        headers={
            "Origin": "https://elsewhere.example.com",
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "Content-Type",
        },
    )
    h = {k.lower(): v for k, v in r.headers.items()}
    allowed = h.get("access-control-allow-headers", "").lower()
    assert "content-type" in allowed


def test_cors_works_with_no_origin_header(client):
    """When a non-browser client (curl, server-side fetch) doesn't send
    an Origin header, the response still works — CORS only kicks in when
    Origin is present."""
    r = client.get("/api/setup_status")
    assert r.status_code == 200


def test_api_config_returns_cors_headers(client):
    """The Little Johnny HTML page reads /api/config. Verify it carries
    CORS headers when called cross-origin."""
    r = client.get(
        "/api/config",
        headers={"Origin": "file://"},
    )
    assert r.status_code == 200
    assert "access-control-allow-origin" in {k.lower() for k in r.headers}


def test_post_ask_carries_cors_headers(client):
    """The big demo — POST to /api/ask — must include CORS headers so the
    browser surfaces the response to JavaScript."""
    r = client.post(
        "/api/ask",
        headers={
            "Origin": "https://demo.example.com",
            "Content-Type": "application/json",
        },
        json={"text": "tell me a joke"},
    )
    # We don't care about the body (fake engines), only the CORS header.
    assert r.status_code in (200, 400, 503)
    assert "access-control-allow-origin" in {k.lower() for k in r.headers}


def test_post_ask_options_preflight(client):
    """The full preflight cycle the browser uses for the AI ask demo:
    OPTIONS first, then the real POST."""
    r = client.options(
        "/api/ask",
        headers={
            "Origin": "https://demo.example.com",
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "Content-Type",
        },
    )
    assert r.status_code in (200, 204)


def test_options_preflight_for_news(client):
    """News endpoint is a GET — preflight may still happen for some clients."""
    r = client.options(
        "/api/news",
        headers={
            "Origin": "https://demo.example.com",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert r.status_code in (200, 204)


def test_cors_section_present_in_config_ini():
    """Doc/config check: [CORS] section exists in config.ini with both knobs."""
    cfg_path = Path(__file__).resolve().parent.parent / "config.ini"
    src = cfg_path.read_text(encoding="utf-8")
    assert "[CORS]" in src
    assert "allowed_origins" in src
    assert "allow_credentials" in src


def test_cors_middleware_imported_in_app():
    """Source-level check: CORSMiddleware is imported and added in app.py
    to defend against future refactors that might drop it."""
    app_path = Path(__file__).resolve().parent.parent / "app.py"
    src = app_path.read_text(encoding="utf-8")
    assert "from fastapi.middleware.cors import CORSMiddleware" in src
    # Strip comment lines, check for an actual call
    active = "\n".join(
        line for line in src.split("\n") if not line.lstrip().startswith("#")
    )
    assert "add_middleware(" in active
    assert "CORSMiddleware" in active


def test_cors_default_methods_are_safe():
    """Verify the middleware only allows GET/POST/OPTIONS (not PUT/DELETE).
    Source-level check — defense against accidental over-broadening."""
    app_path = Path(__file__).resolve().parent.parent / "app.py"
    src = app_path.read_text(encoding="utf-8")
    # Locate the middleware block
    idx = src.find("add_middleware(")
    assert idx > 0
    block_end = src.find(")", idx)
    block = src[idx:block_end]
    assert "GET" in block
    assert "POST" in block
    assert "OPTIONS" in block
    # No accidental write methods
    assert '"PUT"' not in block
    assert '"DELETE"' not in block


def test_cors_wildcard_credentials_combination_guarded():
    """Browser CORS rules reject Allow-Origin=* combined with credentials=true.
    Verify the realm guards against this misconfiguration at startup
    (logs a warning and forces credentials=false)."""
    app_path = Path(__file__).resolve().parent.parent / "app.py"
    src = app_path.read_text(encoding="utf-8")
    # The guard exists
    assert 'cors_origins == ["*"]' in src or "cors_origins==['*']" in src
    assert "cors_allow_credentials = False" in src or \
        "cors_allow_credentials=False" in src
