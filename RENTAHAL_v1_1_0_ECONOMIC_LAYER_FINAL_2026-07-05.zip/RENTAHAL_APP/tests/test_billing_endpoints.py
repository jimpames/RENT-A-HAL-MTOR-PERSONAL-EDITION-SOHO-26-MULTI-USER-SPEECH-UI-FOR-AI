"""
Sprint 13 — end-to-end HTTP integration tests for /api/billing/checkout,
/api/billing/webhook, /api/billing/balance, against a REALLY booted app
with a real Postgres-backed Ledger connected via lifespan startup.

/api/billing/webhook needs NO mocking at all — signature verification
is pure local cryptography, so these tests use genuinely valid signed
payloads throughout, constructed with the exact real Stripe algorithm.

/api/billing/checkout DOES need the underlying stripe.checkout.Session.
create call mocked (api.stripe.com isn't reachable from this sandbox —
same restriction as every other external network dependency in this
whole economic-layer arc), clearly labeled as such.
"""
import asyncio
import hashlib
import hmac
import json
import os
import sys
import time
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

asyncpg = pytest.importorskip("asyncpg")
stripe = pytest.importorskip("stripe")

os.environ["RENTAHAL_FAKE_ENGINES"] = "1"

WEBHOOK_SECRET = "whsec_integration_test_secret"

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


def _sign(payload_bytes: bytes, secret: str, timestamp: int = None) -> str:
    ts = timestamp if timestamp is not None else int(time.time())
    signed_payload = f"{ts}.{payload_bytes.decode()}"
    sig = hmac.new(secret.encode(), signed_payload.encode(), hashlib.sha256).hexdigest()
    return f"t={ts},v1={sig}"


def _checkout_completed_payload(event_id, account_id, amount_cents=1000):
    return json.dumps({
        "id": event_id, "object": "event", "api_version": "2024-06-20",
        "created": int(time.time()), "type": "checkout.session.completed",
        "data": {"object": {
            "id": f"cs_{event_id}", "object": "checkout.session",
            "client_reference_id": account_id, "amount_total": amount_cents,
            "currency": "usd", "payment_intent": f"pi_{event_id}",
            "metadata": {}}},
    }).encode()


async def _boot_billing_app(tmp_path):
    db_name = f"rentahal_billing_endpoint_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()
    dsn = BASE_DSN.rsplit("/", 1)[0] + f"/{db_name}"

    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(
        f"[Ledger]\ndsn = {dsn}\n"
        "[Billing]\nstripe_secret_key = sk_test_fake\n"
        f"stripe_webhook_secret = {WEBHOOK_SECRET}\n"
        "price_per_submit_micros = 100\n"
        "low_balance_threshold_micros = 10000\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)
    return app, db_name


async def _run_server(app, port):
    import uvicorn
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=port, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    return server, task


async def _drop_db(db_name):
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
        "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
    await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
    await admin_conn.close()


@pytest.mark.asyncio
async def test_billing_endpoints_absent_when_not_configured(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    import app as app_module
    cfg = app_module.load_ini()   # no [Billing] section at all
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)
    server, task = await _run_server(app, 9960)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9960/api/billing/checkout",
                              json={"account_id": "x", "amount_micros": 5_000_000}) as r:
                assert r.status == 404
            async with s.get("http://127.0.0.1:9960/api/billing/balance",
                             params={"account_id": "x"}) as r:
                assert r.status == 404
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_webhook_valid_signature_credits_balance(tmp_path):
    """No mocking here at all — genuinely valid signature, real
    Postgres credit, real balance readback."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    app, db_name = await _boot_billing_app(tmp_path)
    server, task = await _run_server(app, 9961)
    try:
        import aiohttp
        payload = _checkout_completed_payload("evt_http_test", "user-http-alice", 1000)
        sig = _sign(payload, WEBHOOK_SECRET)
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9961/api/billing/webhook",
                              data=payload,
                              headers={"Stripe-Signature": sig,
                                      "Content-Type": "application/json"}) as r:
                assert r.status == 200
                body = await r.json()
                assert body["handled"] is True
                assert body["credited"] is True

            async with s.get("http://127.0.0.1:9961/api/billing/balance",
                             params={"account_id": "user-http-alice"}) as r:
                assert r.status == 200
                balance_data = await r.json()
                assert balance_data["balance_micros"] == 10_000_000
                assert balance_data["balance_usd"] == 10.0
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_webhook_forged_signature_rejected_over_http(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    app, db_name = await _boot_billing_app(tmp_path)
    server, task = await _run_server(app, 9962)
    try:
        import aiohttp
        payload = _checkout_completed_payload("evt_forged", "user-mallory", 1000)
        forged_sig = _sign(payload, "wrong-secret-entirely")
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9962/api/billing/webhook",
                              data=payload,
                              headers={"Stripe-Signature": forged_sig,
                                      "Content-Type": "application/json"}) as r:
                assert r.status == 400   # NOT 200 — forged signatures must not look "processed"

            async with s.get("http://127.0.0.1:9962/api/billing/balance",
                             params={"account_id": "user-mallory"}) as r:
                balance_data = await r.json()
                assert balance_data["balance_micros"] == 0   # nothing credited
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_webhook_redelivery_over_http_does_not_double_credit(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    app, db_name = await _boot_billing_app(tmp_path)
    server, task = await _run_server(app, 9963)
    try:
        import aiohttp
        payload = _checkout_completed_payload("evt_redeliver_http", "user-http-bob", 500)
        sig = _sign(payload, WEBHOOK_SECRET)
        async with aiohttp.ClientSession() as s:
            for _ in range(3):   # simulate Stripe retrying 3 times
                async with s.post("http://127.0.0.1:9963/api/billing/webhook",
                                  data=payload,
                                  headers={"Stripe-Signature": sig,
                                          "Content-Type": "application/json"}) as r:
                    assert r.status == 200   # every delivery gets 200, even redeliveries

            async with s.get("http://127.0.0.1:9963/api/billing/balance",
                             params={"account_id": "user-http-bob"}) as r:
                balance_data = await r.json()
                assert balance_data["balance_micros"] == 5_000_000   # only ONE credit
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_checkout_endpoint_returns_url_from_mocked_stripe(tmp_path):
    """MOCKED: api.stripe.com isn't reachable from this sandbox (see
    module docstring). Confirms the endpoint wires request -> SDK call
    -> response correctly around whatever the SDK returns."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    app, db_name = await _boot_billing_app(tmp_path)
    server, task = await _run_server(app, 9964)
    try:
        import aiohttp
        fake_session = MagicMock()
        fake_session.url = "https://checkout.stripe.com/pay/cs_mocked_integration"
        with patch("stripe.checkout.Session.create", return_value=fake_session):
            async with aiohttp.ClientSession() as s:
                async with s.post("http://127.0.0.1:9964/api/billing/checkout",
                                  json={"account_id": "user-checkout",
                                       "amount_micros": 5_000_000}) as r:
                    assert r.status == 200
                    data = await r.json()
                    assert data["checkout_url"] == "https://checkout.stripe.com/pay/cs_mocked_integration"
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_checkout_endpoint_missing_account_id_400(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    app, db_name = await _boot_billing_app(tmp_path)
    server, task = await _run_server(app, 9965)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.post("http://127.0.0.1:9965/api/billing/checkout",
                              json={"amount_micros": 5_000_000}) as r:
                assert r.status == 400
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_balance_endpoint_zero_for_unknown_account(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    app, db_name = await _boot_billing_app(tmp_path)
    server, task = await _run_server(app, 9966)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:9966/api/billing/balance",
                             params={"account_id": "never-seen-before"}) as r:
                assert r.status == 200
                data = await r.json()
                assert data["balance_micros"] == 0
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)
