// run_wizard_syntax_test.js — same idea as run_syntax_test.js, but for
// templates/wizard.html. No prior test covered this file at all —
// added while extending it with Vision/Imagine panels (Sprint 9's
// wizard glue-up) so a future edit that breaks the script block gets
// caught immediately instead of silently shipping a blank wizard page.

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const htmlPath = path.join(__dirname, '..', 'templates', 'wizard.html');
const html = fs.readFileSync(htmlPath, 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

const scriptMatches = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
assert(scriptMatches.length === 1,
       'wizard.html has exactly one <script> block',
       `found ${scriptMatches.length}`);

const scriptBody = scriptMatches.length > 0 ? scriptMatches[0][1] : '';

let parseError = null;
try {
  new vm.Script(scriptBody, { filename: 'wizard.html-inline-script' });
} catch (e) {
  parseError = e;
}
assert(parseError === null, 'script block parses as valid JavaScript',
       parseError ? parseError.message : undefined);

// Sanity checks that the Sprint 9 additions are actually present —
// catches an incomplete edit (e.g. markup added but JS wiring forgotten,
// or vice versa) rather than just "the file happens to still parse."
assert(/id="vision-status"/.test(html), 'vision-status element present');
assert(/id="imagine-status"/.test(html), 'imagine-status element present');
assert(/id="llava-host"/.test(html) && /id="llava-port"/.test(html)
       && /id="llava-model"/.test(html),
       'LLaVA host/port/model fields present');
assert(/id="a1111-host"/.test(html) && /id="a1111-port"/.test(html),
       'AUTOMATIC1111 host/port fields present');
assert(/llava_host:\s*document\.getElementById\('llava-host'\)/.test(scriptBody),
       'onGo() payload includes llava_host');
assert(/automatic1111_host:\s*document\.getElementById\('a1111-host'\)/.test(scriptBody),
       'onGo() payload includes automatic1111_host');
assert(/setIfUnfocused\('llava-host'/.test(scriptBody),
       'renderState syncs llava-host via sticky-edit pattern');

// Sprint 15: economic layer panels
assert(/id="ledger-status"/.test(html), 'ledger-status element present');
assert(/id="billing-status"/.test(html), 'billing-status element present');
assert(/id="payout-status"/.test(html), 'payout-status element present');
assert(/id="abuse-gate-tiers-body"/.test(html), 'abuse-gate-tiers-body element present');
assert(/id="ledger-dsn"/.test(html), 'ledger-dsn input present');
assert(/id="billing-stripe-secret-key"/.test(html), 'billing-stripe-secret-key input present');
assert(/id="payout-stripe-secret-key"/.test(html), 'payout-stripe-secret-key input present');
assert(/ledger_dsn:\s*document\.getElementById\('ledger-dsn'\)/.test(scriptBody),
       "onGo() payload includes ledger_dsn");
assert(/billing_stripe_secret_key:\s*document\.getElementById/.test(scriptBody),
       "onGo() payload includes billing_stripe_secret_key");
assert(/payout_stripe_secret_key:\s*document\.getElementById/.test(scriptBody),
       "onGo() payload includes payout_stripe_secret_key");
assert(/abuse_gate_tiers/.test(scriptBody),
       'renderState renders the abuse-gate tier table');
assert(/setIfUnfocused\('ledger-dsn'/.test(scriptBody),
       'renderState syncs ledger-dsn via sticky-edit pattern');

if (failCount > 0) {
  console.log(`\nFAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`\nOK: ${passCount} wizard.html syntax tests passed`);
}
