// run_stt_normalize_test.js — regression tests for the browser-side
// STT punctuation normalizer.
//
// Bug: Chrome's SpeechRecognition injects sentence-end punctuation
// at silence boundaries. "music london calling" → "music. london
// calling". Downstream parsers that match against word boundaries
// with whitespace separators fail.
//
// Fix: normalizeSttText() strips end-of-word punctuation but
// preserves apostrophes, hyphens, and in-token punctuation in
// numbers. Applied in recognition.onresult BEFORE handleHeard
// receives the text.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Helper function exists and is exported correctly ─────────

assert(/function normalizeSttText/.test(html),
       'normalizeSttText helper function defined');

const normIdx = html.indexOf('function normalizeSttText');
const normEnd = html.indexOf('\nfunction ', normIdx + 1);
const normSrc = html.slice(normIdx, normEnd);

// Three sequential transforms: word-end punct, standalone punct,
// whitespace collapse.
assert(/replace\(\/\(\[a-z0-9\]\)\\s\*\(\[\.,;:!\?\]\+\)\(\?=\\s\|\$\)\/gi/.test(normSrc),
       'word-end punctuation regex present (with lookahead for word boundary)');
assert(/replace\(\/\(\^\|\\s\)\[\.,;:!\?\]\+\(\?=\\s\|\$\)\/g/.test(normSrc),
       'standalone punctuation regex present');
assert(/replace\(\/\\s\+\/g,\s*['"] ['"]\)/.test(normSrc),
       'whitespace collapse regex present');

// Defensive: handles empty/null input
assert(/if\s*\(\s*!raw\s*\)/.test(normSrc),
       'normalizeSttText guards against empty/null input');

// ─── Applied in recognition.onresult BEFORE handleHeard ───────

const onresultIdx = html.indexOf('recognition.onresult');
const onresultEnd = html.indexOf('recognition.onerror', onresultIdx);
const onresultSrc = html.slice(onresultIdx, onresultEnd);

assert(/normalizeSttText\(/.test(onresultSrc),
       'recognition.onresult calls normalizeSttText');

// Order matters: normalize must happen BEFORE handleHeard sees the text.
// Otherwise downstream parsing gets the raw punctuated version.
const normCallIdx = onresultSrc.indexOf('normalizeSttText');
const handleCallIdx = onresultSrc.indexOf('handleHeard');
assert(normCallIdx > 0 && handleCallIdx > normCallIdx,
       'normalizeSttText runs BEFORE handleHeard (downstream gets clean text)');

// And BEFORE the echo guard check — we want the normalized text to be
// what gets logged either way.
assert(/normalizeSttText\(/.test(onresultSrc) &&
       onresultSrc.indexOf('normalizeSttText') <
       onresultSrc.indexOf('echoGuardUntil'),
       'normalize runs before echo guard check (consistent logging)');

// ─── Diagnostic logging when normalization changes the text ──

assert(/normalized/.test(onresultSrc) || /\[recognition\] normalized/.test(html),
       'logs [recognition] normalized when input changed (visible diagnostic)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} STT normalize tests passed`);
  process.exit(0);
}
