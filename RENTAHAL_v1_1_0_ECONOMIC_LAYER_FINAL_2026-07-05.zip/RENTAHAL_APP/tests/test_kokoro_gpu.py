"""
Tests for the Kokoro GPU activation path (ported from news_reader.py).

These tests stub onnxruntime + kokoro_onnx with fake modules so they run
on Linux CI where there's no actual ONNX install. They prove the
ARCHITECTURE works: provider config flows through, the custom-session
path is taken when CUDA is requested AND available, the fallback path
runs when CUDA isn't available, and verification of active providers
correctly warns when GPU was requested but didn't engage.
"""

import asyncio
import os
import sys
import tempfile
import types
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.engine_chain import KokoroTTSProvider

pytestmark = pytest.mark.asyncio


# ---------------------------------------------------------------------------
# Fake ONNX Runtime / kokoro_onnx so we can drive the loader on Linux
# ---------------------------------------------------------------------------

class _FakeSession:
    def __init__(self, providers):
        self._providers = providers
    def get_providers(self):
        return self._providers


class _FakeKokoro:
    def __init__(self, sess):
        self.sess = sess
    def create(self, text, voice="af_sarah", speed=1.0, lang="en-us"):
        import numpy as np
        return np.zeros(100), 22050


def install_fake_onnx_stack(monkeypatch, available_providers,
                             cuda_session_explodes=False):
    """Install fake onnxruntime + kokoro_onnx modules.

    Args:
      available_providers: what ort.get_available_providers() returns
      cuda_session_explodes: simulate cuDNN failure on InferenceSession ctor
    """
    fake_ort = types.ModuleType("onnxruntime")

    class SessionOptions:
        def __init__(self):
            self.log_severity_level = 0

    class InferenceSession:
        def __init__(self, model_path, sess_options=None, providers=None):
            # Reproduce real ORT behavior: if CUDA was requested in providers
            # and we said it's available, it's used; otherwise fall back.
            if cuda_session_explodes:
                raise RuntimeError("simulated cuDNN failure")
            self._wanted = providers or []
            # Find providers actually usable from `available_providers`
            self.active = []
            for p in self._wanted:
                name = p[0] if isinstance(p, tuple) else p
                if name in available_providers:
                    self.active.append(name)
            # ORT always falls back to CPU if everything else fails
            if not self.active:
                self.active = ["CPUExecutionProvider"]

        def get_providers(self):
            return self.active

    fake_ort.SessionOptions = SessionOptions
    fake_ort.InferenceSession = InferenceSession
    fake_ort.get_available_providers = lambda: available_providers
    monkeypatch.setitem(sys.modules, "onnxruntime", fake_ort)

    # Fake kokoro_onnx
    fake_kokoro = types.ModuleType("kokoro_onnx")
    class Kokoro:
        def __init__(self, model_path, voices_path):
            # Plain constructor — pretends to use whatever ONNX_PROVIDER says
            provider = os.environ.get("ONNX_PROVIDER", "CPUExecutionProvider")
            actual = provider if provider in available_providers else "CPUExecutionProvider"
            self.sess = _FakeSession([actual])
        @classmethod
        def from_session(cls, sess, voices_path):
            inst = cls.__new__(cls)
            inst.sess = sess
            return inst
        def create(self, text, voice="af_sarah", speed=1.0, lang="en-us"):
            import numpy as np
            return np.zeros(100), 22050
    fake_kokoro.Kokoro = Kokoro
    monkeypatch.setitem(sys.modules, "kokoro_onnx", fake_kokoro)


def _make_kokoro_files():
    """Create empty model + voices files; return (model_path, voices_path)."""
    tmp = tempfile.mkdtemp()
    onnx_path = os.path.join(tmp, "kokoro-v1.0.onnx")
    voices_path = os.path.join(tmp, "voices-v1.0.bin")
    open(onnx_path, "wb").write(b"\x00" * 100)
    open(voices_path, "wb").write(b"\x00" * 100)
    return onnx_path, voices_path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

async def test_cuda_requested_and_available_uses_custom_session(monkeypatch, caplog):
    """The whole point: when CUDA is available, build a custom session with
    cudnn_conv1d_pad_to_nc1d so Kokoro's 1-D convs don't fail."""
    install_fake_onnx_stack(monkeypatch,
        available_providers=["CUDAExecutionProvider", "CPUExecutionProvider"])
    model, voices = _make_kokoro_files()
    provider = KokoroTTSProvider(model_path=model, voices_path=voices,
                                 onnx_provider="CUDAExecutionProvider")
    with caplog.at_level("INFO"):
        ok = await provider.is_available()
    assert ok is True
    # ACTIVE providers should include CUDA (from the custom session)
    assert "CUDAExecutionProvider" in provider._active_providers, \
        f"CUDA should be active; got {provider._active_providers}"
    log_text = " ".join(r.message for r in caplog.records)
    assert "ACTIVE providers" in log_text, \
        "boot log must include ACTIVE providers line for transparency"


async def test_cuda_requested_but_not_available_warns_and_uses_cpu(monkeypatch, caplog):
    """The bug we want to catch: CUDA was asked for but isn't actually
    installed. User should get a clear warning with the EXACT fix command,
    not silent CPU fallback. Verified by Jim Ames on Win11 — most common
    cause is the dual onnxruntime-install pattern."""
    install_fake_onnx_stack(monkeypatch,
        available_providers=["CPUExecutionProvider"])  # No CUDA
    model, voices = _make_kokoro_files()
    provider = KokoroTTSProvider(model_path=model, voices_path=voices,
                                 onnx_provider="CUDAExecutionProvider")
    with caplog.at_level("WARNING"):
        await provider.is_available()
    log_text = " ".join(r.message for r in caplog.records)
    # Must explain WHAT went wrong
    assert "not registered" in log_text or "not active" in log_text, \
        f"missing-CUDA warning required; logs: {log_text}"
    # Must tell the user EXACTLY how to fix it — the verified pip sequence
    assert "pip uninstall" in log_text and "pip install onnxruntime-gpu" in log_text, \
        f"warning must include the verified fix command; logs: {log_text}"


async def test_cuda_session_explodes_falls_back_gracefully(monkeypatch, caplog):
    """If ORT chokes on the custom session (rare but happens with bad
    cuDNN versions), we fall back to the plain Kokoro() constructor."""
    install_fake_onnx_stack(monkeypatch,
        available_providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
        cuda_session_explodes=True)
    model, voices = _make_kokoro_files()
    provider = KokoroTTSProvider(model_path=model, voices_path=voices,
                                 onnx_provider="CUDAExecutionProvider")
    with caplog.at_level("WARNING"):
        ok = await provider.is_available()
    assert ok is True, "must still load via fallback even when CUDA session fails"
    log_text = " ".join(r.message for r in caplog.records)
    assert "CUDA session build failed" in log_text, \
        "should explain why CUDA session was abandoned"


async def test_cpu_only_provider_skips_custom_session(monkeypatch, caplog):
    """User who explicitly chose CPU shouldn't see CUDA session attempts."""
    install_fake_onnx_stack(monkeypatch,
        available_providers=["CUDAExecutionProvider", "CPUExecutionProvider"])
    model, voices = _make_kokoro_files()
    provider = KokoroTTSProvider(model_path=model, voices_path=voices,
                                 onnx_provider="CPUExecutionProvider")
    with caplog.at_level("INFO"):
        ok = await provider.is_available()
    assert ok is True
    log_text = " ".join(r.message for r in caplog.records)
    # No CUDA-not-active warning when user didn't ask for CUDA
    assert "CUDA requested but not active" not in log_text


async def test_voices_path_resolution_prefers_v1_then_plain(monkeypatch):
    """Empty voices_path → look for voices-v1.0.bin first, then voices.bin."""
    install_fake_onnx_stack(monkeypatch,
        available_providers=["CPUExecutionProvider"])
    # Case A: only voices-v1.0.bin exists
    tmp = tempfile.mkdtemp()
    model = os.path.join(tmp, "model.onnx")
    voices_v1 = os.path.join(tmp, "voices-v1.0.bin")
    open(model, "wb").write(b"\x00" * 100)
    open(voices_v1, "wb").write(b"\x00" * 100)
    provider = KokoroTTSProvider(model_path=model,
                                 onnx_provider="CPUExecutionProvider")
    assert await provider.is_available()

    # Case B: only plain voices.bin exists (older bundles)
    tmp2 = tempfile.mkdtemp()
    model2 = os.path.join(tmp2, "model.onnx")
    plain = os.path.join(tmp2, "voices.bin")
    open(model2, "wb").write(b"\x00" * 100)
    open(plain, "wb").write(b"\x00" * 100)
    provider2 = KokoroTTSProvider(model_path=model2,
                                  onnx_provider="CPUExecutionProvider")
    assert await provider2.is_available()


async def test_kokoro_onnx_not_installed_fails_clean(monkeypatch, caplog):
    """If user hasn't pip-installed kokoro-onnx, fail with a clear pip hint."""
    # Don't install fakes — but DO ensure kokoro_onnx is missing
    sys.modules.pop("kokoro_onnx", None)
    # Inject onnxruntime so the import order doesn't matter
    fake_ort = types.ModuleType("onnxruntime")
    fake_ort.get_available_providers = lambda: ["CPUExecutionProvider"]
    monkeypatch.setitem(sys.modules, "onnxruntime", fake_ort)

    # Block kokoro_onnx import even if it happened to be installed
    real_import = __builtins__["__import__"] if isinstance(__builtins__, dict) \
                  else __builtins__.__import__
    def blocker(name, *args, **kwargs):
        if name == "kokoro_onnx":
            raise ImportError("simulated missing package")
        return real_import(name, *args, **kwargs)
    monkeypatch.setattr("builtins.__import__", blocker)

    model, voices = _make_kokoro_files()
    provider = KokoroTTSProvider(model_path=model, voices_path=voices)
    with caplog.at_level("WARNING"):
        ok = await provider.is_available()
    assert ok is False
    log_text = " ".join(r.message for r in caplog.records)
    assert "pip install" in log_text.lower(), \
        f"should suggest pip install; logs: {log_text}"
