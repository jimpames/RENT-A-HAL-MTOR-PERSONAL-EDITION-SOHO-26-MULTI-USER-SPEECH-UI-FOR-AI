"""
Sprint 14 — requester-side claim submission wiring.

Confirms FederationConscriptionProvider._try_one_donor() submits a
claim to the Federator (role='requester') after a SUCCESSFUL
conscripted answer, and does NOT submit one on failure — a claim
should only ever represent work that genuinely happened. Also confirms
the new X-Federation-Requester-Url header (found to be a real gap
while wiring the donor side — the donor had no way to know who to
attribute a claim to without it) is sent correctly.

Claim submission itself is HTTP to the Federator — mocked here
(aiohttp's ClientSession, same technique used throughout this test
suite), since the point of these tests is confirming the WIRING
(when does a claim get submitted, with what fields), not re-testing
realm/donor_payout.py's own reconciliation logic (covered thoroughly,
against real Postgres, in test_donor_payout.py).
"""
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import FederationConfig, FederationState
from realm.federation_provider import FederationConscriptionProvider

pytestmark = pytest.mark.asyncio


def _make_provider(self_url="https://chat-struggling.example", token=""):
    cfg = FederationConfig(desire=True, self_url=self_url,
                           master_url="https://federator.example/api/federate",
                           token=token)
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": 0, "tts_avg_s": 0, "tokens_out": 0})
    fed_state.member_state = "HEALTHY"
    fed_state.conscriptions = [{
        "peer_url": "https://vision-donor.example",
        "native_role": "vision",
        "conscripted_as": "chat",
        "assigned_at": 0.0,
        "expires_at": 99999999.0,
    }]
    return FederationConscriptionProvider(fed_state)


class _MockAskResp:
    def __init__(self, body, status=200):
        self._body = body
        self.status = status
    async def json(self):
        return self._body
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass


class _MockClaimResp:
    def __init__(self, status=200):
        self.status = status
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass


async def test_successful_answer_includes_requester_url_header():
    """The header the donor side actually needs to attribute a claim
    correctly — found to be missing during Sprint 14 development, now
    verified present."""
    p = _make_provider(self_url="https://chat-struggling.example")
    captured = {}

    def mock_post(url, json=None, headers=None):
        if url.endswith("/api/ask"):
            captured["ask_headers"] = headers
            return _MockAskResp({"answer": "here's your answer"})
        return _MockClaimResp()

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")

    assert result == "here's your answer"
    assert captured["ask_headers"]["X-Federation-Requester-Url"] == \
        "https://chat-struggling.example"


async def test_successful_answer_submits_requester_claim():
    p = _make_provider(self_url="https://chat-struggling.example")
    captured = {}

    def mock_post(url, json=None, headers=None):
        if url.endswith("/api/ask"):
            return _MockAskResp({"answer": "answer text"})
        elif url.endswith("/conscription-claim"):
            captured["claim_body"] = json
            captured["claim_headers"] = headers
            return _MockClaimResp()
        return _MockAskResp({}, status=404)

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await p.generate("hi")

    assert captured["claim_body"]["role"] == "requester"
    assert captured["claim_body"]["donor_url"] == "https://vision-donor.example"
    assert captured["claim_body"]["requester_url"] == "https://chat-struggling.example"
    assert captured["claim_body"]["rank"] == "chat"


async def test_claim_includes_token_when_configured():
    p = _make_provider(token="my-shared-secret")
    captured = {}

    def mock_post(url, json=None, headers=None):
        if url.endswith("/api/ask"):
            return _MockAskResp({"answer": "answer text"})
        elif url.endswith("/conscription-claim"):
            captured["claim_headers"] = headers
            return _MockClaimResp()
        return _MockAskResp({}, status=404)

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await p.generate("hi")

    assert captured["claim_headers"]["X-Federation-Token"] == "my-shared-secret"


async def test_failed_answer_does_not_submit_a_claim():
    """No answer was actually produced — a claim would represent work
    that never happened. Must not be submitted at all."""
    p = _make_provider()
    claim_calls = []

    def mock_post(url, json=None, headers=None):
        if url.endswith("/api/ask"):
            return _MockAskResp({}, status=500)   # donor fails
        elif url.endswith("/conscription-claim"):
            claim_calls.append(json)
            return _MockClaimResp()
        return _MockAskResp({}, status=404)

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")

    assert result is None
    assert claim_calls == []


async def test_claim_submission_failure_does_not_break_the_returned_answer():
    """THE resilience property: even if the Federator is completely
    unreachable for claim submission, the user must still get their
    already-successful answer — fire-and-forget, never blocking."""
    p = _make_provider()

    def mock_post(url, json=None, headers=None):
        if url.endswith("/api/ask"):
            return _MockAskResp({"answer": "the real answer"})
        raise ConnectionError("Federator is completely down")

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")

    assert result == "the real answer"   # NOT None — the claim failure didn't propagate


async def test_no_claim_submitted_when_master_url_missing():
    cfg = FederationConfig(desire=True, self_url="https://x.example",
                           master_url="")   # no Federator configured
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": 0, "tts_avg_s": 0, "tokens_out": 0})
    fed_state.member_state = "HEALTHY"
    fed_state.conscriptions = [{
        "peer_url": "https://vision-donor.example",
        "native_role": "vision", "conscripted_as": "chat",
        "assigned_at": 0.0, "expires_at": 99999999.0,
    }]
    p = FederationConscriptionProvider(fed_state)
    claim_calls = []

    def mock_post(url, json=None, headers=None):
        if url.endswith("/api/ask"):
            return _MockAskResp({"answer": "answer"})
        claim_calls.append(url)
        return _MockClaimResp()

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.generate("hi")

    assert result == "answer"
    assert claim_calls == []   # no attempt at all, cfg.master_url is empty
