"""
Tests for realm/gate.py — the optional payment gate.

Coverage:
  - Session token signing / verification round-trip
  - Tampered tokens are rejected (modified payload, modified sig)
  - Expired tokens are rejected
  - Bad-secret tokens are rejected
  - ReplayCache TTL behavior + eviction + max size
  - GateConfig validation when enabled
  - extract_spl_transfer handles real Solana transaction shapes
  - GateVerifier full path: replay → fetch → extract → validate → issue
  - Failure paths: replay seen, tx not found, wrong wallet, wrong dest,
    insufficient amount, stale tx, RPC error
  - GateVerifier never raises
  - Off-by-default: enabled=false short-circuits with no RPC calls
"""
import asyncio
import time
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock

import pytest

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.gate import (
    GateConfig,
    GateConfigError,
    GateRpcError,
    GateVerifier,
    ReplayCache,
    SessionToken,
    SolanaRpcClient,
    TokenTransferDetails,
    extract_spl_transfer,
    generate_session_secret,
    sign_session_token,
    verify_session_token,
)


# ─────────────────────── Session tokens ───────────────────────


def _make_token(wallet="A" * 44, exp_in=3600, secret="testsecret"):
    now = int(time.time())
    tok = SessionToken(
        wallet=wallet,
        issued_at=now,
        expires_at=now + exp_in,
        operator_wallet="B" * 44,
    )
    return tok, sign_session_token(tok, secret), secret


def test_session_token_roundtrip():
    """Sign then verify — should get the same data back."""
    tok, signed, secret = _make_token()
    verified = verify_session_token(signed, secret)
    assert verified is not None
    assert verified.wallet == tok.wallet
    assert verified.issued_at == tok.issued_at
    assert verified.expires_at == tok.expires_at
    assert verified.operator_wallet == tok.operator_wallet


def test_session_token_wrong_secret_rejected():
    _, signed, _ = _make_token(secret="goodsecret")
    assert verify_session_token(signed, "differentsecret") is None


def test_session_token_tampered_payload_rejected():
    """Modify a single byte of the payload — signature check fails."""
    _, signed, secret = _make_token()
    parts = signed.split(".")
    # Flip a byte in the payload
    payload = parts[0]
    tampered = payload[:5] + ("Z" if payload[5] != "Z" else "Y") + payload[6:]
    bad = tampered + "." + parts[1]
    assert verify_session_token(bad, secret) is None


def test_session_token_tampered_signature_rejected():
    _, signed, secret = _make_token()
    parts = signed.split(".")
    tampered_sig = parts[1][:-2] + "ZZ"
    bad = parts[0] + "." + tampered_sig
    assert verify_session_token(bad, secret) is None


def test_session_token_expired_rejected():
    """A token whose exp is in the past returns None."""
    tok = SessionToken(
        wallet="A" * 44,
        issued_at=int(time.time()) - 7200,
        expires_at=int(time.time()) - 3600,
        operator_wallet="B" * 44,
    )
    secret = "x"
    signed = sign_session_token(tok, secret)
    assert verify_session_token(signed, secret) is None


def test_session_token_malformed_string_safe():
    """Garbage input never raises."""
    assert verify_session_token("garbage", "secret") is None
    assert verify_session_token("", "secret") is None
    assert verify_session_token("a.b.c", "secret") is None
    assert verify_session_token(None, "secret") is None


def test_session_token_empty_secret_safe():
    """Empty secret on verify side returns None, never raises."""
    _, signed, _ = _make_token()
    assert verify_session_token(signed, "") is None


def test_sign_with_empty_secret_raises():
    """Empty secret on SIGN side is a config error — refuse to sign."""
    tok, _, _ = _make_token()
    with pytest.raises(GateConfigError):
        sign_session_token(tok, "")


def test_generate_session_secret_is_long_enough():
    """Auto-generated secret should be a real urlsafe string."""
    s = generate_session_secret()
    assert isinstance(s, str)
    assert len(s) >= 40
    # Different calls produce different secrets
    assert generate_session_secret() != s


def test_session_token_timing_safe_compare():
    """Two tokens that differ only in signature bytes are both rejected
    in similar time (no early-exit timing leak). This is a smoke test —
    we just confirm hmac.compare_digest is used."""
    import realm.gate
    src = Path(realm.gate.__file__).read_text()
    assert "hmac.compare_digest" in src, \
        "Session token verification must use hmac.compare_digest"


# ─────────────────────── Replay cache ───────────────────────


def test_replay_cache_basic():
    c = ReplayCache(ttl_seconds=60)
    assert not c.has_seen("sig1")
    c.mark_seen("sig1")
    assert c.has_seen("sig1")


def test_replay_cache_two_signatures_independent():
    c = ReplayCache(ttl_seconds=60)
    c.mark_seen("sig1")
    assert c.has_seen("sig1")
    assert not c.has_seen("sig2")


def test_replay_cache_expires_after_ttl():
    """Entries older than TTL are evicted."""
    c = ReplayCache(ttl_seconds=0)  # zero TTL — immediate expiry
    c.mark_seen("sig1")
    # has_seen calls _evict_expired first; with TTL=0, entry is already expired
    time.sleep(0.001)
    assert not c.has_seen("sig1")


def test_replay_cache_max_size_does_not_grow_unbounded():
    """When the cache hits max_size, oldest entries are dropped."""
    c = ReplayCache(ttl_seconds=10000, max_size=100)
    for i in range(500):
        c.mark_seen(f"sig_{i}")
    # Cache should be bounded
    assert c.size() <= 100
    # The most recent signatures should still be in there
    assert c.has_seen("sig_499")


def test_replay_cache_mark_then_mark_same_is_idempotent():
    c = ReplayCache(ttl_seconds=60)
    c.mark_seen("sig1")
    c.mark_seen("sig1")     # second call should not raise
    assert c.has_seen("sig1")


# ─────────────────────── Config validation ───────────────────────


def test_config_disabled_passes_validation_trivially():
    """When enabled=false, nothing else matters."""
    cfg = GateConfig(enabled=False)
    cfg.validate()   # should not raise


def test_config_enabled_requires_mint():
    cfg = GateConfig(enabled=True, operator_wallet="W", session_secret="s")
    with pytest.raises(GateConfigError, match="token_mint"):
        cfg.validate()


def test_config_enabled_requires_operator_wallet():
    cfg = GateConfig(enabled=True, token_mint="M", session_secret="s")
    with pytest.raises(GateConfigError, match="operator_wallet"):
        cfg.validate()


def test_config_enabled_requires_session_secret():
    cfg = GateConfig(enabled=True, token_mint="M", operator_wallet="W")
    with pytest.raises(GateConfigError, match="session_secret"):
        cfg.validate()


def test_config_enabled_required_payment_must_be_positive():
    cfg = GateConfig(
        enabled=True, token_mint="M", operator_wallet="W",
        session_secret="s", required_payment=0,
    )
    with pytest.raises(GateConfigError, match="required_payment"):
        cfg.validate()


def test_config_enabled_session_duration_must_be_positive():
    cfg = GateConfig(
        enabled=True, token_mint="M", operator_wallet="W",
        session_secret="s", session_duration_hours=0,
    )
    with pytest.raises(GateConfigError, match="session_duration_hours"):
        cfg.validate()


def test_config_enabled_full_valid_passes():
    cfg = GateConfig(
        enabled=True,
        token_mint="9000PuMpfunMintAddressHere",
        operator_wallet="OPERATOR" + "W" * 36,
        session_secret=generate_session_secret(),
        required_payment=10.0,
        session_duration_hours=24,
    )
    cfg.validate()   # should not raise


# ───────────── extract_spl_transfer with realistic shapes ─────────────


def _fake_tx_transfer_checked(
    from_wallet="A" * 44,
    destination="DEST" + "T" * 40,
    mint="9000" + "M" * 40,
    ui_amount=10.0,
    block_time=None,
) -> Dict[str, Any]:
    """Build a transaction matching Solana's parsed transferChecked shape."""
    if block_time is None:
        block_time = int(time.time())
    return {
        "blockTime": block_time,
        "transaction": {
            "signatures": ["SIG" + "X" * 80],
            "message": {
                "instructions": [
                    {
                        "program": "spl-token",
                        "parsed": {
                            "type": "transferChecked",
                            "info": {
                                "source": "SRC" + "S" * 41,
                                "destination": destination,
                                "mint": mint,
                                "tokenAmount": {
                                    "uiAmount": ui_amount,
                                    "decimals": 6,
                                    "amount": str(int(ui_amount * 1_000_000)),
                                },
                                "authority": from_wallet,
                            },
                        },
                    }
                ]
            },
        },
        "meta": {
            "innerInstructions": [],
            "postTokenBalances": [
                {"owner": destination, "mint": mint},
            ],
        },
    }


def test_extract_spl_transfer_basic():
    mint = "9000" + "M" * 40
    tx = _fake_tx_transfer_checked(mint=mint)
    result = extract_spl_transfer(tx, mint)
    assert result is not None
    assert result.amount_ui == 10.0
    assert result.mint == mint


def test_extract_spl_transfer_wrong_mint_returns_none():
    """A transaction with a different mint is not a payment for OUR token."""
    tx = _fake_tx_transfer_checked(mint="OTHER" + "X" * 39)
    result = extract_spl_transfer(tx, "9000" + "M" * 40)
    assert result is None


def test_extract_spl_transfer_handles_none_tx():
    assert extract_spl_transfer(None, "anything") is None
    assert extract_spl_transfer({}, "anything") is None


def test_extract_spl_transfer_skips_non_spl_instructions():
    """A tx with only compute-budget instructions returns None."""
    tx = {
        "blockTime": int(time.time()),
        "transaction": {
            "signatures": ["S"],
            "message": {
                "instructions": [
                    {"program": "compute-budget", "parsed": {}},
                    {"program": "system", "parsed": {}},
                ],
            },
        },
        "meta": {},
    }
    assert extract_spl_transfer(tx, "anything") is None


def test_extract_spl_transfer_finds_inside_inner_instructions():
    """Some wallets nest the transfer in innerInstructions."""
    mint = "9000" + "M" * 40
    tx = {
        "blockTime": int(time.time()),
        "transaction": {
            "signatures": ["S"],
            "message": {"instructions": [{"program": "compute-budget", "parsed": {}}]},
        },
        "meta": {
            "innerInstructions": [
                {
                    "index": 0,
                    "instructions": [
                        {
                            "program": "spl-token",
                            "parsed": {
                                "type": "transferChecked",
                                "info": {
                                    "source": "SRC",
                                    "destination": "DEST" + "T" * 40,
                                    "mint": mint,
                                    "tokenAmount": {"uiAmount": 50.0},
                                    "authority": "A" * 44,
                                },
                            },
                        },
                    ],
                },
            ]
        },
    }
    result = extract_spl_transfer(tx, mint)
    assert result is not None
    assert result.amount_ui == 50.0


# ─────────────────── GateVerifier (with mocked RPC) ───────────────────


def _verifier_config():
    return GateConfig(
        enabled=True,
        token_mint="9000" + "M" * 40,
        operator_wallet="DEST" + "T" * 40,
        session_secret="testsecret-must-be-long-enough-to-pass",
        required_payment=10.0,
        session_duration_hours=24,
        replay_window_minutes=10,
    )


class _MockRpc:
    """In-memory mock SolanaRpcClient. Lets tests script the response."""
    def __init__(self):
        self._txs: Dict[str, Optional[Dict[str, Any]]] = {}
        self._raise_on: Dict[str, Exception] = {}
        self.calls: List[str] = []

    def script_tx(self, sig: str, tx: Optional[Dict[str, Any]]):
        self._txs[sig] = tx

    def script_error(self, sig: str, exc: Exception):
        self._raise_on[sig] = exc

    async def get_transaction(self, signature: str):
        self.calls.append(signature)
        if signature in self._raise_on:
            raise self._raise_on[signature]
        return self._txs.get(signature)

    async def get_mint_decimals(self, mint: str) -> int:
        return 6


def _make_verifier(cfg=None, now: int = None) -> tuple[GateVerifier, _MockRpc]:
    cfg = cfg or _verifier_config()
    rpc = _MockRpc()
    clock = (lambda: now) if now is not None else None
    v = GateVerifier(config=cfg, rpc_client=rpc, clock=clock)
    return v, rpc


@pytest.mark.asyncio
async def test_verify_disabled_short_circuits():
    """When gate is disabled, verify never even calls RPC."""
    cfg = GateConfig(enabled=False)
    v = GateVerifier(config=cfg, rpc_client=_MockRpc())
    result = await v.verify_payment("any-wallet", "any-sig")
    assert not result.ok
    assert "not enabled" in result.reason


@pytest.mark.asyncio
async def test_verify_empty_wallet_or_signature():
    v, _ = _make_verifier()
    r1 = await v.verify_payment("", "sig")
    r2 = await v.verify_payment("wallet", "")
    assert not r1.ok and not r2.ok


@pytest.mark.asyncio
async def test_verify_replay_seen_rejected():
    """Same signature used twice is rejected the second time."""
    v, rpc = _make_verifier(now=int(time.time()))
    sig = "REPLAY" + "X" * 78
    tx = _fake_tx_transfer_checked(
        from_wallet="A" * 44,
        destination="DEST" + "T" * 40,
        mint="9000" + "M" * 40,
        ui_amount=10.0,
        block_time=v._now(),
    )
    rpc.script_tx(sig, tx)
    # First call succeeds
    r1 = await v.verify_payment("A" * 44, sig)
    assert r1.ok, f"first call should succeed: {r1.reason}"
    # Second call with same sig is rejected (replay)
    r2 = await v.verify_payment("A" * 44, sig)
    assert not r2.ok
    assert "already been used" in r2.reason


@pytest.mark.asyncio
async def test_verify_tx_not_found():
    """RPC returns None → caller gets a friendly message."""
    v, rpc = _make_verifier()
    rpc.script_tx("missing-sig", None)
    result = await v.verify_payment("wallet", "missing-sig")
    assert not result.ok
    assert "not found" in result.reason


@pytest.mark.asyncio
async def test_verify_rpc_error_returns_friendly_failure():
    """RPC raises → verify returns ok=False, not an exception."""
    v, rpc = _make_verifier()
    rpc.script_error("err-sig", GateRpcError("network down"))
    result = await v.verify_payment("wallet", "err-sig")
    assert not result.ok
    # Friendly message, no raw exception text
    assert "try again" in result.reason.lower()


@pytest.mark.asyncio
async def test_verify_wrong_from_wallet_rejected():
    """Signature exists but the connected wallet isn't the one who paid."""
    v, rpc = _make_verifier(now=int(time.time()))
    tx = _fake_tx_transfer_checked(
        from_wallet="REAL" + "S" * 40,    # tx is FROM this wallet
        destination="DEST" + "T" * 40,
        mint="9000" + "M" * 40,
        ui_amount=10.0,
        block_time=v._now(),
    )
    rpc.script_tx("sig", tx)
    # But user says they're a DIFFERENT wallet
    result = await v.verify_payment("FAKE" + "F" * 40, "sig")
    assert not result.ok
    assert "wallet" in result.reason.lower()


@pytest.mark.asyncio
async def test_verify_wrong_destination_rejected():
    """Payment was sent somewhere other than the operator's wallet."""
    v, rpc = _make_verifier(now=int(time.time()))
    tx = _fake_tx_transfer_checked(
        from_wallet="A" * 44,
        destination="WRONG" + "X" * 39,    # not the operator's address
        mint="9000" + "M" * 40,
        ui_amount=10.0,
        block_time=v._now(),
    )
    # postTokenBalances also doesn't match
    tx["meta"]["postTokenBalances"] = [
        {"owner": "WRONG" + "X" * 39, "mint": "9000" + "M" * 40},
    ]
    rpc.script_tx("sig", tx)
    result = await v.verify_payment("A" * 44, "sig")
    assert not result.ok
    assert "operator" in result.reason.lower()


@pytest.mark.asyncio
async def test_verify_insufficient_amount_rejected():
    """Paid only 5 when 10 was required."""
    v, rpc = _make_verifier(now=int(time.time()))
    tx = _fake_tx_transfer_checked(
        from_wallet="A" * 44,
        destination="DEST" + "T" * 40,
        mint="9000" + "M" * 40,
        ui_amount=5.0,                      # less than required 10
        block_time=v._now(),
    )
    rpc.script_tx("sig", tx)
    result = await v.verify_payment("A" * 44, "sig")
    assert not result.ok
    assert "less than" in result.reason or "5" in result.reason


@pytest.mark.asyncio
async def test_verify_stale_transaction_rejected():
    """Transaction is older than the replay window."""
    now = int(time.time())
    v, rpc = _make_verifier(now=now)
    # Transaction from 2 hours ago
    tx = _fake_tx_transfer_checked(
        from_wallet="A" * 44,
        destination="DEST" + "T" * 40,
        mint="9000" + "M" * 40,
        ui_amount=10.0,
        block_time=now - 7200,
    )
    rpc.script_tx("sig", tx)
    result = await v.verify_payment("A" * 44, "sig")
    assert not result.ok
    assert "too old" in result.reason.lower()


@pytest.mark.asyncio
async def test_verify_happy_path_issues_session():
    """Everything aligns → session token issued."""
    now = int(time.time())
    v, rpc = _make_verifier(now=now)
    tx = _fake_tx_transfer_checked(
        from_wallet="A" * 44,
        destination="DEST" + "T" * 40,
        mint="9000" + "M" * 40,
        ui_amount=10.0,
        block_time=now,
    )
    rpc.script_tx("happy-sig", tx)
    result = await v.verify_payment("A" * 44, "happy-sig")
    assert result.ok, f"expected success, got: {result.reason}"
    assert result.session_token
    assert result.expires_at > now
    # The token round-trips
    verified = v.check_session(result.session_token)
    assert verified is not None
    assert verified.wallet == "A" * 44


@pytest.mark.asyncio
async def test_verify_happy_path_pays_more_than_required_ok():
    """Overpayment is fine — we accept >= required."""
    now = int(time.time())
    v, rpc = _make_verifier(now=now)
    tx = _fake_tx_transfer_checked(
        from_wallet="A" * 44,
        destination="DEST" + "T" * 40,
        mint="9000" + "M" * 40,
        ui_amount=100.0,                    # generous tip
        block_time=now,
    )
    rpc.script_tx("sig", tx)
    result = await v.verify_payment("A" * 44, "sig")
    assert result.ok


@pytest.mark.asyncio
async def test_verify_never_raises_on_garbage_input():
    """Whatever weird input comes in, we always return VerifyResult."""
    v, rpc = _make_verifier()
    rpc.script_tx("garbage", {"weird": "shape"})    # malformed tx
    result = await v.verify_payment("wallet", "garbage")
    # We don't care if ok or not — we care that NO EXCEPTION
    assert not result.ok


@pytest.mark.asyncio
async def test_check_session_validates_cookie():
    """check_session is the cookie-validating side."""
    now = int(time.time())
    v, rpc = _make_verifier(now=now)
    tx = _fake_tx_transfer_checked(
        from_wallet="A" * 44,
        destination="DEST" + "T" * 40,
        mint="9000" + "M" * 40,
        ui_amount=10.0,
        block_time=now,
    )
    rpc.script_tx("sig", tx)
    result = await v.verify_payment("A" * 44, "sig")
    assert result.ok

    # Now use check_session to validate the issued cookie
    session = v.check_session(result.session_token)
    assert session is not None
    assert session.wallet == "A" * 44


def test_check_session_rejects_garbage():
    """Random strings as cookies return None."""
    cfg = GateConfig(enabled=False)
    v = GateVerifier(config=cfg, rpc_client=_MockRpc())
    assert v.check_session("garbage") is None
    assert v.check_session("") is None


# ─────────────────── Integration helpers ───────────────────


def test_gate_module_publicly_exports():
    """The module API surface stays stable."""
    import realm.gate as g
    for name in [
        "GateConfig", "GateVerifier", "GateError", "GateConfigError",
        "GateRpcError", "GateInvalidPayment", "ReplayCache",
        "SessionToken", "SolanaRpcClient", "TokenTransferDetails",
        "extract_spl_transfer", "generate_session_secret",
        "sign_session_token", "verify_session_token", "VerifyResult",
    ]:
        assert hasattr(g, name), f"realm.gate missing public name: {name}"
