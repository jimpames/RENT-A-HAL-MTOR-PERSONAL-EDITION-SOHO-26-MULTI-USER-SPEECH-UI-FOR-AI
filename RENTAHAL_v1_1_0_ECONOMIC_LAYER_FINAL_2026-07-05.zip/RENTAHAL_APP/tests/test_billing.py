"""
Sprint 13 — tests for realm/billing.py.

Two tiers, matching what's genuinely testable from this environment
(same honesty discipline as Sprint 12's OpenTimestamps notes):

  1. WEBHOOK SIGNATURE VERIFICATION: fully real, zero network. Every
     test in this section constructs genuinely valid Stripe-format
     signatures using the EXACT algorithm the real SDK implements
     (verified against stripe.WebhookSignature.verify_header's actual
     source before writing a single test — sig = HMAC-SHA256 of
     "{timestamp}.{payload}", header format "t=...,v1=..."), then
     confirms real forgery/tampering/replay attempts are genuinely
     rejected. This is the single most security-critical piece of the
     whole sprint, and it gets the most thorough testing, not the
     least, precisely because it's the one piece that doesn't need any
     network access to test for real.

  2. CHECKOUT SESSION CREATION: needs a real network call to
     api.stripe.com, which this sandbox cannot reach (confirmed
     directly in Sprint 12's notes for OpenTimestamps' calendar
     servers — same restriction applies here). Tested by mocking the
     SDK's own HTTP call, clearly labeled as such below rather than
     silently.

  3. THE IDEMPOTENCY + LEDGER INTEGRATION: real Postgres, same
     per-test-database isolation pattern as test_ledger.py and
     test_ots_anchor.py.
"""
import asyncio
import hashlib
import hmac
import json
import os
import sys
import time
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

stripe = pytest.importorskip("stripe")
asyncpg = pytest.importorskip("asyncpg")

from realm.ledger import DuplicateEntryError, Ledger
from realm.billing import (
    BillingConfig, WebhookResult, WebhookVerificationError,
    cents_to_micros, create_checkout_session,
    handle_checkout_completed_event, micros_to_cents, verify_webhook,
)

WEBHOOK_SECRET = "whsec_test_secret_for_pytest_only"

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


def _dsn_for_db(db_name: str) -> str:
    prefix = BASE_DSN.rsplit("/", 1)[0]
    return f"{prefix}/{db_name}"


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


def _sign(payload_bytes: bytes, secret: str, timestamp: int = None) -> str:
    """Constructs a genuinely valid Stripe-format signature header,
    using the exact real algorithm (verified against the installed
    SDK's own WebhookSignature.verify_header implementation)."""
    ts = timestamp if timestamp is not None else int(time.time())
    signed_payload = f"{ts}.{payload_bytes.decode()}"
    sig = hmac.new(secret.encode(), signed_payload.encode(), hashlib.sha256).hexdigest()
    return f"t={ts},v1={sig}"


def _make_checkout_completed_payload(event_id="evt_test", session_id="cs_test",
                                     account_id="user-alice", amount_cents=500,
                                     metadata=None) -> bytes:
    """A genuine, correctly-shaped Stripe webhook payload — matches
    the real shape (object: 'event' at top level is REQUIRED by the
    real SDK, found the hard way during development when a payload
    missing it raised AttributeError deep inside stripe's own
    construct_event)."""
    return json.dumps({
        "id": event_id,
        "object": "event",
        "api_version": "2024-06-20",
        "created": int(time.time()),
        "type": "checkout.session.completed",
        "data": {"object": {
            "id": session_id,
            "object": "checkout.session",
            "client_reference_id": account_id,
            "amount_total": amount_cents,
            "currency": "usd",
            "payment_intent": "pi_test",
            "metadata": metadata or {},
        }},
    }).encode()


# ─── Unit conversions ────────────────────────────────────────────────

def test_micros_to_cents():
    assert micros_to_cents(1_000_000) == 100    # $1.00 -> 100 cents
    assert micros_to_cents(10_000) == 1          # 1 cent
    assert micros_to_cents(500_000) == 50        # $0.50 -> 50 cents


def test_cents_to_micros():
    assert cents_to_micros(100) == 1_000_000     # 100 cents -> $1.00
    assert cents_to_micros(1) == 10_000
    assert cents_to_micros(1000) == 10_000_000   # $10.00


def test_conversion_round_trips():
    for cents in [50, 100, 500, 999, 12345]:
        assert micros_to_cents(cents_to_micros(cents)) == cents


def test_billing_config_enabled_requires_both_keys():
    assert BillingConfig().enabled is False
    assert BillingConfig(stripe_secret_key="sk_x").enabled is False
    assert BillingConfig(stripe_webhook_secret="whsec_x").enabled is False
    assert BillingConfig(stripe_secret_key="sk_x",
                         stripe_webhook_secret="whsec_x").enabled is True


# ─── Webhook signature verification — REAL cryptography ─────────────

def test_valid_signature_accepted():
    payload = _make_checkout_completed_payload()
    sig = _sign(payload, WEBHOOK_SECRET)
    event = verify_webhook(payload, sig, WEBHOOK_SECRET)
    assert event["type"] == "checkout.session.completed"
    assert event["id"] == "evt_test"


def test_forged_signature_wrong_secret_rejected():
    """THE core security property: someone who doesn't know the
    webhook secret cannot forge a valid-looking signature."""
    payload = _make_checkout_completed_payload()
    forged_sig = _sign(payload, "attacker-does-not-know-the-real-secret")
    with pytest.raises(WebhookVerificationError):
        verify_webhook(payload, forged_sig, WEBHOOK_SECRET)


def test_tampered_payload_rejected():
    """A valid signature for ONE payload must not verify against a
    DIFFERENT (tampered) payload — e.g. an attacker intercepting a
    real webhook and modifying the account_id or amount."""
    payload = _make_checkout_completed_payload(account_id="user-alice")
    valid_sig = _sign(payload, WEBHOOK_SECRET)
    tampered_payload = payload.replace(b"user-alice", b"user-mallory")
    with pytest.raises(WebhookVerificationError):
        verify_webhook(tampered_payload, valid_sig, WEBHOOK_SECRET)


def test_expired_timestamp_rejected():
    """Replay protection: a genuinely valid signature for an OLD
    timestamp (outside the tolerance window) must be rejected — stops
    an attacker replaying a captured, previously-valid webhook."""
    payload = _make_checkout_completed_payload()
    old_sig = _sign(payload, WEBHOOK_SECRET, timestamp=int(time.time()) - 99999)
    with pytest.raises(WebhookVerificationError):
        verify_webhook(payload, old_sig, WEBHOOK_SECRET)


def test_malformed_signature_header_rejected():
    payload = _make_checkout_completed_payload()
    with pytest.raises(WebhookVerificationError):
        verify_webhook(payload, "not-a-valid-signature-header-at-all",
                       WEBHOOK_SECRET)


def test_missing_signature_header_rejected():
    payload = _make_checkout_completed_payload()
    with pytest.raises(WebhookVerificationError):
        verify_webhook(payload, "", WEBHOOK_SECRET)


def test_signature_valid_for_different_webhook_secret_rejected():
    """A signature that's genuinely valid for the WRONG secret (e.g. a
    different Stripe account's webhook secret, or a stale rotated
    secret) must not verify against THIS realm's configured secret."""
    payload = _make_checkout_completed_payload()
    sig_for_other_secret = _sign(payload, "whsec_a_completely_different_account")
    with pytest.raises(WebhookVerificationError):
        verify_webhook(payload, sig_for_other_secret, WEBHOOK_SECRET)


# ─── Checkout session creation — mocked SDK call, clearly labeled ───

def test_create_checkout_session_calls_real_sdk_with_correct_params():
    """MOCKED: the actual HTTP call to api.stripe.com cannot be made
    from this sandbox (see module docstring). This confirms our code
    calls the real SDK method with the CORRECT parameters — verified
    against the SDK's actual type definitions before writing this
    module — not that the network round trip itself succeeds."""
    cfg = BillingConfig(stripe_secret_key="sk_test_fake",
                        stripe_webhook_secret="whsec_fake")
    fake_session = MagicMock()
    fake_session.url = "https://checkout.stripe.com/pay/cs_fake123"

    with patch("stripe.checkout.Session.create", return_value=fake_session) as mock_create:
        url = create_checkout_session(cfg, "user-alice", 5_000_000)

    assert url == "https://checkout.stripe.com/pay/cs_fake123"
    call_kwargs = mock_create.call_args.kwargs
    assert call_kwargs["mode"] == "payment"
    assert call_kwargs["client_reference_id"] == "user-alice"
    assert call_kwargs["metadata"]["account_id"] == "user-alice"
    assert call_kwargs["line_items"][0]["price_data"]["unit_amount"] == 500
    assert call_kwargs["line_items"][0]["price_data"]["currency"] == "usd"


def test_create_checkout_session_rejects_non_positive_amount():
    cfg = BillingConfig(stripe_secret_key="sk_x", stripe_webhook_secret="whsec_x")
    with pytest.raises(ValueError):
        create_checkout_session(cfg, "user-alice", 0)
    with pytest.raises(ValueError):
        create_checkout_session(cfg, "user-alice", -100)


def test_create_checkout_session_rejects_below_stripe_minimum():
    cfg = BillingConfig(stripe_secret_key="sk_x", stripe_webhook_secret="whsec_x")
    with pytest.raises(ValueError):
        create_checkout_session(cfg, "user-alice", 1000)


# ─── Idempotent credit flow — real Postgres ──────────────────────────

pytestmark = pytest.mark.asyncio


@pytest.fixture
async def ledger():
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable — see test_ledger.py's fixture "
                    "for the same pattern and reasoning.")
    db_name = f"rentahal_billing_test_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    dsn = _dsn_for_db(db_name)
    led = await Ledger.connect(dsn)
    led.dsn = dsn
    try:
        yield led
    finally:
        await led.close()
        admin_conn = await asyncpg.connect(BASE_DSN)
        await admin_conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
        await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
        await admin_conn.close()


async def test_checkout_completed_credits_the_account(ledger):
    payload = _make_checkout_completed_payload(
        event_id="evt_credit_test", account_id="user-alice", amount_cents=1000)
    event = verify_webhook(payload, _sign(payload, WEBHOOK_SECRET), WEBHOOK_SECRET)

    result = await handle_checkout_completed_event(event, ledger)

    assert result.handled is True
    assert result.credited is True
    assert result.duplicate is False
    assert result.account_id == "user-alice"
    assert result.amount_micros == 10_000_000

    balance = await ledger.get_balance("user-alice")
    assert balance == 10_000_000


async def test_redelivered_event_does_not_double_credit(ledger):
    """THE acceptance-critical property: Stripe redelivering the SAME
    event (network hiccup, timeout, Stripe's own retry policy) must
    NOT result in the account being credited twice."""
    payload = _make_checkout_completed_payload(
        event_id="evt_redelivery_test", account_id="user-bob", amount_cents=500)
    sig = _sign(payload, WEBHOOK_SECRET)

    event1 = verify_webhook(payload, sig, WEBHOOK_SECRET)
    result1 = await handle_checkout_completed_event(event1, ledger)
    assert result1.credited is True

    event2 = verify_webhook(payload, sig, WEBHOOK_SECRET)
    result2 = await handle_checkout_completed_event(event2, ledger)
    assert result2.credited is False
    assert result2.duplicate is True

    balance = await ledger.get_balance("user-bob")
    assert balance == 5_000_000


async def test_different_events_for_same_account_both_credit(ledger):
    """Two GENUINELY DIFFERENT top-ups for the same account (different
    event IDs) must both credit — the idempotency guard is keyed on
    the event ID, not the account."""
    payload1 = _make_checkout_completed_payload(
        event_id="evt_first", account_id="user-carol", amount_cents=500)
    payload2 = _make_checkout_completed_payload(
        event_id="evt_second", account_id="user-carol", amount_cents=500)

    event1 = verify_webhook(payload1, _sign(payload1, WEBHOOK_SECRET), WEBHOOK_SECRET)
    event2 = verify_webhook(payload2, _sign(payload2, WEBHOOK_SECRET), WEBHOOK_SECRET)

    result1 = await handle_checkout_completed_event(event1, ledger)
    result2 = await handle_checkout_completed_event(event2, ledger)
    assert result1.credited is True
    assert result2.credited is True

    balance = await ledger.get_balance("user-carol")
    assert balance == 10_000_000


async def test_non_checkout_completed_event_ignored(ledger):
    """An event type we don't act on (e.g. checkout.session.expired)
    must be a clean no-op, not an error."""
    payload = json.dumps({
        "id": "evt_other", "object": "event", "api_version": "2024-06-20",
        "created": int(time.time()), "type": "checkout.session.expired",
        "data": {"object": {"id": "cs_expired"}},
    }).encode()
    event = verify_webhook(payload, _sign(payload, WEBHOOK_SECRET), WEBHOOK_SECRET)
    result = await handle_checkout_completed_event(event, ledger)
    assert result.handled is False
    assert result.credited is False


async def test_missing_account_id_raises(ledger):
    payload = json.dumps({
        "id": "evt_no_account", "object": "event", "api_version": "2024-06-20",
        "created": int(time.time()), "type": "checkout.session.completed",
        "data": {"object": {"id": "cs_x", "amount_total": 500,
                           "currency": "usd", "metadata": {}}},
    }).encode()
    event = verify_webhook(payload, _sign(payload, WEBHOOK_SECRET), WEBHOOK_SECRET)
    with pytest.raises(ValueError):
        await handle_checkout_completed_event(event, ledger)


async def test_account_id_from_metadata_when_no_client_reference_id(ledger):
    """Belt-and-suspenders: account_id can come from metadata.account_id
    instead of client_reference_id."""
    payload = json.dumps({
        "id": "evt_via_metadata", "object": "event", "api_version": "2024-06-20",
        "created": int(time.time()), "type": "checkout.session.completed",
        "data": {"object": {"id": "cs_x", "amount_total": 500, "currency": "usd",
                           "metadata": {"account_id": "user-dave"}}},
    }).encode()
    event = verify_webhook(payload, _sign(payload, WEBHOOK_SECRET), WEBHOOK_SECRET)
    result = await handle_checkout_completed_event(event, ledger)
    assert result.account_id == "user-dave"
    assert result.credited is True
