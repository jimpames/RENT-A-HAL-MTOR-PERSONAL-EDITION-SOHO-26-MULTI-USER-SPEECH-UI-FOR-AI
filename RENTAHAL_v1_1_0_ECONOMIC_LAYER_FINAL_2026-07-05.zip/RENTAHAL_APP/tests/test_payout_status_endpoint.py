"""
Sprint 15 — tests for GET /api/federate/payout/status, the cockpit
visibility endpoint for donor earnings.
"""
import asyncio
import os
import sys
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

asyncpg = pytest.importorskip("asyncpg")
stripe = pytest.importorskip("stripe")

os.environ["RENTAHAL_FAKE_ENGINES"] = "1"

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


async def _run_server(app, port):
    import uvicorn
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=port, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    return server, task


async def _drop_db(db_name):
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
        "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
    await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
    await admin_conn.close()


async def _boot_federator_app(tmp_path, db_name):
    dsn = BASE_DSN.rsplit("/", 1)[0] + f"/{db_name}"
    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n"
        f"[Ledger]\ndsn = {dsn}\n"
        "[Payout]\nstripe_secret_key = sk_test_fake\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


@pytest.mark.asyncio
async def test_payout_status_unknown_donor(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_payout_status_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    app = await _boot_federator_app(tmp_path, db_name)
    server, task = await _run_server(app, 9980)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.get(
                    "http://127.0.0.1:9980/api/federate/payout/status",
                    params={"donor_url": "https://never-linked.example"}) as r:
                assert r.status == 200
                data = await r.json()
                assert data["linked"] is False
                assert data["payouts_enabled"] is False
                assert data["balance_micros"] == 0
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_payout_status_linked_with_confirmed_balance(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_payout_status_linked_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    app = await _boot_federator_app(tmp_path, db_name)
    server, task = await _run_server(app, 9981)
    try:
        import aiohttp
        now = __import__("time").time()
        async with aiohttp.ClientSession() as s:
            # Confirm a real matched claim (requester + donor) so the
            # donor genuinely has a confirmed ledger balance, exactly
            # the same path a real conscripted request would create.
            await s.post("http://127.0.0.1:9981/api/federate/conscription-claim",
                        json={"role": "requester", "donor_url": "https://vision-donor.example",
                             "requester_url": "https://r.example", "rank": "chat",
                             "claimed_at": now})
            await s.post("http://127.0.0.1:9981/api/federate/conscription-claim",
                        json={"role": "donor", "donor_url": "https://vision-donor.example",
                             "requester_url": "https://r.example", "rank": "chat",
                             "claimed_at": now + 2})

            # Link a payout account for that same donor.
            from unittest.mock import patch, MagicMock
            fake_account = MagicMock(); fake_account.id = "acct_status_test"
            fake_link = MagicMock(); fake_link.url = "https://connect.stripe.com/setup/fake"
            with patch("stripe.Account.create", return_value=fake_account), \
                 patch("stripe.AccountLink.create", return_value=fake_link):
                await s.post("http://127.0.0.1:9981/api/federate/payout/link",
                            json={"donor_url": "https://vision-donor.example"})

            async with s.get(
                    "http://127.0.0.1:9981/api/federate/payout/status",
                    params={"donor_url": "https://vision-donor.example"}) as r:
                assert r.status == 200
                data = await r.json()
                assert data["linked"] is True
                assert data["balance_micros"] == 80   # the confirmed conscription credit
                assert data["balance_usd"] == round(80 / 1_000_000, 6)
    finally:
        server.should_exit = True
        await task
        await _drop_db(db_name)


@pytest.mark.asyncio
async def test_payout_status_absent_when_not_configured(tmp_path):
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    import app as app_module
    cfg = app_module.load_ini()
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)
    server, task = await _run_server(app, 9982)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.get(
                    "http://127.0.0.1:9982/api/federate/payout/status",
                    params={"donor_url": "https://x.example"}) as r:
                assert r.status == 404
    finally:
        server.should_exit = True
        await task
