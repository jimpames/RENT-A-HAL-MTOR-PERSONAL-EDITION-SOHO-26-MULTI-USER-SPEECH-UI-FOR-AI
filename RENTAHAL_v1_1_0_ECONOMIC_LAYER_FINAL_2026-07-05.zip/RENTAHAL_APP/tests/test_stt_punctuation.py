"""
Regression tests for STT punctuation handling.

Bug: Chrome's SpeechRecognition can inject sentence-end punctuation
at silence boundaries between words. For example, saying "music
london calling" can be transcribed as "music. london calling" with a
spurious period. This breaks the music intent classifier's regex
which requires whitespace between the trigger word and the query.

Fixes:
  1. sanitize_speech_text() in intent.py — strips end-of-word
     punctuation but preserves apostrophes, hyphens, and numbers
  2. classify() calls sanitize at entry — every code path is covered
  3. The music regex itself is now punctuation-tolerant — defense
     in depth in case a future caller bypasses sanitize
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.intent import (
    sanitize_speech_text, tokenize,
    extract_music_slots, IntentClassifier,
)


# ─── sanitize_speech_text — strip injected punctuation ──────

def test_sanitize_strips_period_after_word_at_boundary():
    """The specific user-reported case: music. london calling."""
    assert sanitize_speech_text("music. london calling") == "music london calling"


def test_sanitize_strips_period_at_end_of_text():
    assert sanitize_speech_text("hello world.") == "hello world"


def test_sanitize_strips_question_mark():
    assert sanitize_speech_text("what's the weather?") == "what's the weather"


def test_sanitize_strips_comma_at_boundary():
    assert sanitize_speech_text("service finder, haircut") == "service finder haircut"


def test_sanitize_strips_multiple_consecutive_punct():
    assert sanitize_speech_text("stop... stop...") == "stop stop"


def test_sanitize_strips_exclamation_and_question():
    assert sanitize_speech_text("what?! really!") == "what really"


def test_sanitize_strips_semicolon_and_colon():
    assert sanitize_speech_text("first thing; second thing: third") \
        == "first thing second thing third"


# ─── sanitize PRESERVES legitimate punctuation ─────────────

def test_sanitize_preserves_apostrophe_in_contractions():
    """Don't break "what's", "let's", "i'm", etc."""
    assert sanitize_speech_text("what's the weather") == "what's the weather"
    assert sanitize_speech_text("let's go") == "let's go"
    assert sanitize_speech_text("i'm asking") == "i'm asking"


def test_sanitize_preserves_decimal_numbers():
    """3.14 must stay 3.14 — the period is in-token, not boundary."""
    assert sanitize_speech_text("pi is 3.14") == "pi is 3.14"


def test_sanitize_preserves_comma_in_numbers():
    """1,000,000 must stay intact."""
    assert sanitize_speech_text("a million is 1,000,000") \
        == "a million is 1,000,000"


def test_sanitize_preserves_hyphens():
    """drive-through, well-known — hyphens carry meaning."""
    assert sanitize_speech_text("drive-through window") \
        == "drive-through window"
    assert sanitize_speech_text("well-known fact") == "well-known fact"


def test_sanitize_collapses_whitespace():
    """Multiple spaces from punctuation removal collapse to single space."""
    assert sanitize_speech_text("hello  ,   world") == "hello world"


def test_sanitize_handles_empty_input():
    assert sanitize_speech_text("") == ""
    assert sanitize_speech_text(None) == ""


def test_sanitize_handles_punctuation_only():
    """All-punctuation input becomes empty after sanitization."""
    assert sanitize_speech_text("...") == ""
    # With spaces:
    assert sanitize_speech_text(" . . . ") == ""


# ─── Classifier integration — punctuated input parses correctly ──

def test_classifier_handles_music_with_period():
    """User-reported bug: 'music. london calling' must classify as music
    intent with query='london calling'."""
    cls = IntentClassifier(bus=None)
    intent = cls.classify("music. london calling")
    assert intent.kind == "music", f"expected music, got {intent.kind}"
    assert intent.slots.get("query") == "london calling", \
        f"expected query=london calling, got {intent.slots.get('query')}"


def test_classifier_handles_music_with_comma():
    cls = IntentClassifier(bus=None)
    intent = cls.classify("music, london calling")
    assert intent.kind == "music"
    assert intent.slots.get("query") == "london calling"


def test_classifier_handles_music_player_with_period():
    cls = IntentClassifier(bus=None)
    intent = cls.classify("music player. london calling")
    assert intent.kind == "music"
    assert intent.slots.get("query") == "london calling"


def test_classifier_handles_weather_with_period():
    """Weather is one of the SINGLE_INTENTS — punctuation must not break it."""
    cls = IntentClassifier(bus=None)
    intent = cls.classify("weather. tokyo")
    assert intent.kind == "weather"


def test_classifier_handles_service_finder_with_period():
    """Service finder is a PHRASE_INTENT — must work with injected punct."""
    cls = IntentClassifier(bus=None)
    intent = cls.classify("service finder. haircut")
    assert intent.kind == "service"


def test_classifier_handles_doubled_stop_with_period():
    """STOP. STOP. — doubled action word with injected periods."""
    cls = IntentClassifier(bus=None)
    intent = cls.classify("stop. stop.")
    assert intent.kind == "stop"


def test_classifier_preserves_raw_text_for_display():
    """sanitize is for matching only — raw_text stays unchanged so the
    user sees what they actually said (with punctuation)."""
    cls = IntentClassifier(bus=None)
    raw = "music. london calling"
    intent = cls.classify(raw)
    assert intent.raw_text == raw


# ─── Punctuation-free baseline must still work (no regression) ──

def test_classifier_music_without_punct_still_works():
    cls = IntentClassifier(bus=None)
    intent = cls.classify("music london calling")
    assert intent.kind == "music"
    assert intent.slots.get("query") == "london calling"


def test_classifier_clean_weather_query_still_works():
    cls = IntentClassifier(bus=None)
    intent = cls.classify("weather in tokyo")
    assert intent.kind == "weather"


def test_classifier_clean_doubled_stop_still_works():
    cls = IntentClassifier(bus=None)
    intent = cls.classify("stop stop")
    assert intent.kind == "stop"


# ─── Music extractor regex is punctuation-tolerant ───────────

def test_music_extractor_works_with_period_after_trigger():
    """Defense in depth: even if sanitize is bypassed, the music regex
    itself handles punctuation between the trigger and the query."""
    slots = extract_music_slots("music. london calling",
                                tokenize("music london calling"))
    assert slots.get("query") == "london calling"


def test_music_extractor_works_with_multiple_punct():
    slots = extract_music_slots("music!! london calling",
                                tokenize("music london calling"))
    assert slots.get("query") == "london calling"
