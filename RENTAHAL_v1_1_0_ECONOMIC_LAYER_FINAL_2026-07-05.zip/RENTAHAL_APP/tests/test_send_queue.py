"""
Tests for ConnectionManager per-connection outbound queue + drain task.

Bug being protected against:
  When multiple bus events were published for the same user in rapid
  succession (e.g. service_results, query_result, tts_started, tts_chunk,
  tts_complete during a service query), each one created an independent
  asyncio task that raced to call ws.send_json. Even with a per-connection
  send lock, the ORDER OF LOCK ACQUISITION depended on event-loop
  scheduling, not on publish order. Under load, tasks could reach
  acquire() out of order — events arrived at the browser in the wrong
  sequence. Symptom: bus_query_result would land before bus_service_results,
  the answer text would update but the card panel never opened.

Fix:
  Per-connection asyncio.Queue (bounded) + single drain task per
  connection. safe_send becomes a synchronous-in-spirit ENQUEUE
  (publishers never block on I/O). The drain task is the SINGLE writer
  for that connection. Order is captured at the enqueue point, which is
  synchronous with bus.publish(). Multi-user parallelism is preserved —
  each user has their own queue and drain task.

Coverage:
  - Order is preserved across 100 concurrent enqueues to one user
  - Two users send in parallel (cross-user is NOT serialized)
  - Disconnect cancels the drain task and removes the queue
  - Reconnect allocates a FRESH queue + FRESH drain task
  - Drain task triggers disconnect on send_json failure
  - Bounded queue rejects when full (slow consumer alarm)
  - safe_send returns False for unknown guid
  - broadcast goes through the queue model — no race with per-user events
  - The exact 5-event service-query race the bug is about
"""
import asyncio
import time

import pytest

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.realm_core import ConnectionManager


class _FakeWebSocket:
    """A mock websocket that records send order with optional delay/failure."""
    def __init__(self, delay: float = 0.0, dies: bool = False):
        self.delay = delay
        self.dies = dies
        self.sent = []          # ordered list as sends complete
        self.in_flight = 0
        self.high_water = 0     # max concurrency observed

    async def send_json(self, payload):
        self.in_flight += 1
        if self.in_flight > self.high_water:
            self.high_water = self.in_flight
        try:
            if self.delay:
                await asyncio.sleep(self.delay)
            if self.dies:
                raise ConnectionResetError("peer gone")
            self.sent.append(payload)
        finally:
            self.in_flight -= 1

    async def close(self):
        pass


async def _wait_until(predicate, timeout: float = 1.0):
    """Poll predicate every 10ms until True or timeout."""
    deadline = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < deadline:
        if predicate():
            return True
        await asyncio.sleep(0.01)
    return False


# ─── Order preservation under concurrent enqueue ─────────────


@pytest.mark.asyncio
async def test_order_preserved_under_100_concurrent_enqueues():
    """100 concurrent safe_send calls to the same user must arrive at
    the WebSocket in the order they were enqueued.

    This is the actual bug-prevention test. With the OLD lock-based
    design, this could fail because asyncio task scheduling could
    reorder acquire() calls. With the queue, order is captured at
    enqueue time and can't be reordered."""
    mgr = ConnectionManager()
    ws = _FakeWebSocket(delay=0.001)
    await mgr.connect(ws, "user")

    # Fire 100 enqueues from many tasks in parallel — these tasks are
    # scheduled by the event loop, but the ORDER of safe_send completion
    # is the order we care about. The queue captures order on put,
    # not on send.
    results = await asyncio.gather(
        *[mgr.safe_send("user", {"seq": i}) for i in range(100)]
    )
    assert all(results), "some enqueues were rejected"

    # Wait for the drain task to process everything
    assert await _wait_until(lambda: len(ws.sent) == 100, timeout=3.0), \
        f"drain task did not process all messages (got {len(ws.sent)})"

    # ORDER must match enqueue order — the bug we're preventing
    received_seqs = [m["seq"] for m in ws.sent]
    assert received_seqs == list(range(100)), \
        f"messages arrived out of order: {received_seqs[:10]}..."


@pytest.mark.asyncio
async def test_drain_task_is_single_writer_no_overlap():
    """The drain task is the only thing calling ws.send_json for a
    connection — no concurrent sends, ever. high_water must stay at 1."""
    mgr = ConnectionManager()
    ws = _FakeWebSocket(delay=0.005)
    await mgr.connect(ws, "user")

    # Enqueue many items
    for i in range(20):
        await mgr.safe_send("user", {"n": i})

    assert await _wait_until(lambda: len(ws.sent) == 20)
    assert ws.high_water == 1, \
        f"drain task had concurrent sends (high water = {ws.high_water})"


# ─── Cross-user parallelism preserved ──────────────────────────


@pytest.mark.asyncio
async def test_two_users_send_in_parallel_not_serialized():
    """Alice and Bob each have their own queue + drain task. Their
    sends must NOT serialize against each other — that's the whole
    point of per-connection queues vs a global mutex."""
    mgr = ConnectionManager()
    ws_alice = _FakeWebSocket(delay=0.05)
    ws_bob = _FakeWebSocket(delay=0.05)
    await mgr.connect(ws_alice, "alice")
    await mgr.connect(ws_bob, "bob")

    start = time.monotonic()
    await mgr.safe_send("alice", {"type": "x"})
    await mgr.safe_send("bob", {"type": "y"})
    # Wait for both to land
    assert await _wait_until(
        lambda: ws_alice.sent and ws_bob.sent, timeout=1.0)
    elapsed = time.monotonic() - start
    # Two parallel 50ms sends should land in well under 100ms
    assert elapsed < 0.09, \
        f"cross-user sends serialized (took {elapsed:.3f}s)"


# ─── Disconnect cleanup ────────────────────────────────────────


@pytest.mark.asyncio
async def test_disconnect_cancels_drain_task_and_removes_queue():
    """After disconnect, the drain task is cancelled and the queue is
    removed. No leaks."""
    mgr = ConnectionManager()
    ws = _FakeWebSocket()
    await mgr.connect(ws, "user")
    # Internal state check
    assert "user" in mgr._send_queues
    assert "user" in mgr._drain_tasks
    drain_task = mgr._drain_tasks["user"]

    await mgr.disconnect("user")

    # Let cancellation propagate
    await asyncio.sleep(0.01)
    assert "user" not in mgr._send_queues
    assert "user" not in mgr._drain_tasks
    assert drain_task.done() or drain_task.cancelled()


@pytest.mark.asyncio
async def test_reconnect_allocates_fresh_queue_and_drain_task():
    """A reconnect on the same guid must give us NEW queue + NEW drain
    task. Old ones are cancelled. Any pending items in the old queue
    are NOT delivered to the new socket."""
    mgr = ConnectionManager()
    ws_old = _FakeWebSocket(delay=0.05)
    await mgr.connect(ws_old, "user")
    old_queue = mgr._send_queues["user"]
    old_drain = mgr._drain_tasks["user"]

    # Enqueue something to old queue, but don't wait for drain
    await mgr.safe_send("user", {"old": True})

    # Reconnect immediately
    ws_new = _FakeWebSocket()
    await mgr.connect(ws_new, "user")

    new_queue = mgr._send_queues["user"]
    new_drain = mgr._drain_tasks["user"]
    assert new_queue is not old_queue, "reconnect did not replace queue"
    assert new_drain is not old_drain, "reconnect did not replace drain"

    # Send via new connection
    await mgr.safe_send("user", {"new": True})
    assert await _wait_until(lambda: ws_new.sent, timeout=0.5)
    # New socket got the new payload; should NOT have received the
    # "old: True" item — that went to the cancelled drain's queue.
    assert any(p.get("new") for p in ws_new.sent)
    assert not any(p.get("old") for p in ws_new.sent)


# ─── Drain task error handling ─────────────────────────────────


@pytest.mark.asyncio
async def test_drain_task_triggers_disconnect_on_send_failure():
    """When ws.send_json raises, the drain task triggers disconnect()
    instead of crashing. Subsequent enqueues to that guid return False."""
    mgr = ConnectionManager()
    ws = _FakeWebSocket(dies=True)
    await mgr.connect(ws, "user")
    # First enqueue succeeds (queue exists). Drain task picks up,
    # send_json raises, drain triggers disconnect.
    assert await mgr.safe_send("user", {"type": "x"})

    assert await _wait_until(lambda: mgr.count() == 0, timeout=1.0)
    # Second send after disconnect returns False
    assert not await mgr.safe_send("user", {"type": "y"})


# ─── Bounded queue ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_full_queue_rejects_safely():
    """A slow consumer can stall the drain task. The queue is bounded;
    once full, safe_send returns False without blocking publishers.

    This is the alarm condition: in production it means a connection
    is stuck and we're shedding load to avoid memory growth."""
    mgr = ConnectionManager()
    # Use a websocket that NEVER completes (huge delay)
    ws = _FakeWebSocket(delay=100.0)
    await mgr.connect(ws, "stuck")

    # Verify the bound is reasonable (not infinity from a misconfigured manager)
    assert mgr.MAX_OUTBOUND_QUEUE <= 10000, \
        "queue bound must be sized for memory safety, not unbounded"

    # Fill the queue past its capacity. Push 2× the bound.
    rejected = 0
    accepted = 0
    push_count = mgr.MAX_OUTBOUND_QUEUE * 2
    for i in range(push_count):
        if await mgr.safe_send("stuck", {"n": i}):
            accepted += 1
        else:
            rejected += 1
        # Yield occasionally so the drain has a chance (it won't drain
        # though, because send_json is sleeping)
        if i % 50 == 0:
            await asyncio.sleep(0)

    # We should have accepted up to MAX_OUTBOUND_QUEUE and rejected the rest.
    # (One may have been in-flight in the drain task at the time we hit cap.)
    assert accepted <= mgr.MAX_OUTBOUND_QUEUE + 1, \
        f"accepted {accepted} which is above the configured bound " \
        f"of {mgr.MAX_OUTBOUND_QUEUE} — queue is unbounded!"
    assert rejected >= push_count - mgr.MAX_OUTBOUND_QUEUE - 1, \
        f"only rejected {rejected} of {push_count}; queue did not enforce bound"


# ─── Unknown guid ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_safe_send_unknown_guid_returns_false():
    """A send to a guid we don't know about must return False, never raise."""
    mgr = ConnectionManager()
    assert not await mgr.safe_send("ghost", {"type": "x"})


# ─── Broadcast respects per-user queue ─────────────────────────


@pytest.mark.asyncio
async def test_broadcast_enqueues_to_every_user():
    """Broadcast must reach every connected user, going through their
    per-user queue (so it serializes against per-user events for that
    same connection, but parallels across users)."""
    mgr = ConnectionManager()
    websockets = {f"u{i}": _FakeWebSocket() for i in range(10)}
    for guid, ws in websockets.items():
        await mgr.connect(ws, guid)

    await mgr.broadcast({"type": "tick"})

    assert await _wait_until(
        lambda: all(len(ws.sent) >= 1 for ws in websockets.values()),
        timeout=1.0)
    for guid, ws in websockets.items():
        assert any(p["type"] == "tick" for p in ws.sent), \
            f"user {guid} didn't get the broadcast"


@pytest.mark.asyncio
async def test_broadcast_does_not_block_on_slow_users():
    """If one user has a slow socket, broadcast still delivers to fast
    users promptly. Each connection's drain task is independent."""
    mgr = ConnectionManager()
    fast = _FakeWebSocket()
    slow = _FakeWebSocket(delay=0.5)
    await mgr.connect(fast, "fast")
    await mgr.connect(slow, "slow")

    start = time.monotonic()
    await mgr.broadcast({"type": "tick"})
    # Fast user should receive the broadcast in well under 100ms,
    # even though slow user is taking 500ms.
    assert await _wait_until(lambda: fast.sent, timeout=0.2)
    elapsed = time.monotonic() - start
    assert elapsed < 0.15, \
        f"broadcast was blocked by slow consumer (took {elapsed:.3f}s)"


# ─── The actual bug scenario ───────────────────────────────────


@pytest.mark.asyncio
async def test_service_query_5_event_burst_arrives_in_order():
    """The exact scenario that caused 'cards sometimes don't display':
    a service query fires 5 bus events in rapid succession via
    asyncio.create_task. With the queue, they must arrive at the
    WebSocket in the exact order they were enqueued."""
    mgr = ConnectionManager()
    ws = _FakeWebSocket(delay=0.001)
    await mgr.connect(ws, "alice")

    # Mimic what bus.publish does for a service query: fire-and-forget
    # tasks that call safe_send. Each task is independent.
    tasks = [
        asyncio.create_task(
            mgr.safe_send("alice", {"type": "bus_service_results"})),
        asyncio.create_task(
            mgr.safe_send("alice", {"type": "bus_query_result"})),
        asyncio.create_task(
            mgr.safe_send("alice", {"type": "bus_tts_started"})),
        asyncio.create_task(
            mgr.safe_send("alice", {"type": "bus_tts_chunk", "seq": 0})),
        asyncio.create_task(
            mgr.safe_send("alice", {"type": "bus_tts_complete"})),
    ]
    results = await asyncio.gather(*tasks)
    assert all(results), "some events were rejected at enqueue"

    assert await _wait_until(lambda: len(ws.sent) == 5)
    # Critically: order matches the order the tasks were CREATED in
    # gather, because gather drives them in that order; the queue then
    # preserves order through drain.
    expected = [
        "bus_service_results",
        "bus_query_result",
        "bus_tts_started",
        "bus_tts_chunk",
        "bus_tts_complete",
    ]
    actual = [p["type"] for p in ws.sent]
    assert actual == expected, \
        f"events arrived out of order: {actual}"
