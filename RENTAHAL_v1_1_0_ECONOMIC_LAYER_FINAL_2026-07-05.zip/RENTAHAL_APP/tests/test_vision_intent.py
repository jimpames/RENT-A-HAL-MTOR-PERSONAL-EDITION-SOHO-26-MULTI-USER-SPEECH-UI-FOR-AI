"""
Regression tests for the vision realm — intent classification for the
"what do you see" family of phrases.

Architecture invariants this test file LOCKS IN:
  - Full vision phrases ("what do you see", "take a look", etc.) trigger
    kind='vision'
  - Deliberately NOT a bare "look" trigger — that would false-positive on
    "look up the weather", "look for a pharmacy", etc. This file locks
    in that those must NOT be misclassified as vision.
  - Vision has no slot extractor — it's a trigger-only intent, the actual
    payload (the webcam frame) travels out of band, not as a text slot.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.intent import IntentClassifier, PHRASE_INTENTS, SLOT_EXTRACTORS


def _classify(text):
    return IntentClassifier(bus=None).classify(text)


# ─── Registration ─────────────────────────────────────────────

def test_vision_phrases_are_registered():
    for phrase in ("what do you see", "what can you see", "can you see",
                    "take a look", "look at this", "look at that"):
        assert PHRASE_INTENTS.get(phrase) == "vision"


def test_vision_has_no_dedicated_slot_extractor():
    """Vision is trigger-only — the image travels out of band (webcam
    capture), not as a parsed text slot. Falls through to the default
    empty-slots lambda, same as 'roundup'."""
    assert "vision" not in SLOT_EXTRACTORS


# ─── Basic classification ──────────────────────────────────────

def test_what_do_you_see():
    intent = _classify("what do you see")
    assert intent.kind == "vision"


def test_what_can_you_see():
    intent = _classify("what can you see")
    assert intent.kind == "vision"


def test_can_you_see():
    intent = _classify("can you see")
    assert intent.kind == "vision"


def test_take_a_look():
    intent = _classify("take a look")
    assert intent.kind == "vision"


def test_look_at_this():
    intent = _classify("look at this")
    assert intent.kind == "vision"


def test_look_at_that():
    intent = _classify("look at that")
    assert intent.kind == "vision"


def test_vision_phrase_with_trailing_words():
    """The trigger phrase must win even with trailing content, same as
    'service finder haircut please' works for service."""
    intent = _classify("what do you see right now")
    assert intent.kind == "vision"


def test_vision_confidence_is_high():
    intent = _classify("what do you see")
    assert intent.confidence >= 0.9


# ─── iOS/STT punctuation robustness (same pattern as other intents) ──

def test_vision_with_injected_punctuation():
    intent = _classify("what do you see?")
    assert intent.kind == "vision"


def test_vision_with_trailing_period():
    intent = _classify("take a look.")
    assert intent.kind == "vision"


# ─── False-positive guards — the real point of this file ──────────

def test_look_up_the_weather_is_not_vision():
    """'look' alone is NOT a trigger. This must classify as weather (or
    at minimum NOT vision) — the whole reason bare 'look' was excluded."""
    intent = _classify("look up the weather")
    assert intent.kind != "vision"


def test_look_for_a_pharmacy_is_not_vision():
    intent = _classify("look for a pharmacy")
    assert intent.kind != "vision"


def test_looking_forward_to_the_weekend_is_not_vision():
    """'look' as a substring of 'looking' must not match at all — the
    classifier tokenizes, so this is really testing that 'looking' !=
    'look' at the token level."""
    intent = _classify("looking forward to the weekend")
    assert intent.kind != "vision"


def test_weather_intent_unaffected_by_vision_phrases():
    """Sanity check the existing weather intent still works after these
    additions — no accidental phrase-table collision."""
    intent = _classify("weather in Boston")
    assert intent.kind == "weather"


def test_service_intent_unaffected_by_vision_phrases():
    intent = _classify("find a pharmacy")
    assert intent.kind == "service"


def test_music_intent_unaffected_by_vision_phrases():
    intent = _classify("music london calling")
    assert intent.kind == "music"
