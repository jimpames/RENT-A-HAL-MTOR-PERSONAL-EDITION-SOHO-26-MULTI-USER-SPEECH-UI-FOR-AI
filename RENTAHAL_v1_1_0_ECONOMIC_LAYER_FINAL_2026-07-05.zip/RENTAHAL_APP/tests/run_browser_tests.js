// run_browser_tests.js — headless verification of the wake state machine.
//
// Pulls the relevant functions out of templates/index.html, stubs the DOM
// just enough to let them run, and executes browser_wake_test.js against
// them. If this passes, we have evidence (not just hope) that the new
// state machine behaves correctly.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

// Extract the <script> block(s) — there's just one in this app
const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
if (!scriptMatch) {
  console.error('no <script> block found in index.html');
  process.exit(1);
}
let js = scriptMatch[1];

// Strip the IIFE that runs on DOMContentLoaded — it calls fetch/connectWS
// which we don't want in this sandbox
js = js.replace(/^\(async \(\) => \{[\s\S]*?\}\)\(\);?/m, '');

// Strip top-level declarations that we're going to stub instead
// (let CFG = null;, let socket = null;, etc. — anything we pre-declare)
const stubbed = ['CFG', 'socket', 'userGuid', 'wakeOn', 'recognition',
                 'audioCtx', 'analyser', 'micStream', 'isSpeaking',
                 'echoGuardUntil', 'recognitionRunning', 'restartGeneration'];
for (const name of stubbed) {
  // Match: let NAME = ...; or let NAME;
  const re = new RegExp('^let\\s+' + name + '\\s*(=\\s*[^;]*)?;\\s*$', 'm');
  js = js.replace(re, '');
}

// Also strip the DOM lookups (document.getElementById(...))
js = js.replace(/^const\s+player\s*=\s*document\.getElementById[^;]+;\s*$/m, '');
js = js.replace(/^const\s+transcriptEl\s*=\s*document\.getElementById[^;]+;\s*$/m, '');
js = js.replace(/^const\s+answerEl\s*=\s*document\.getElementById[^;]+;\s*$/m, '');
js = js.replace(/^const\s+wakeBtn\s*=\s*document\.getElementById[^;]+;\s*$/m, '');

// Convert top-level `let` to `var` so test code can mutate the state.
// In a browser, top-level `let` is still in the global lexical environment
// and accessible via direct name lookup; in Node's eval, it's hidden.
js = js.replace(/^let\s+(\w+)/gm, 'var $1');

// Make window a true global up front
global.window = global;

const stubs = `
  const CFG = { VoiceLoop: { wake_word: 'computer' } };
  const transcriptEl = { textContent: '', innerHTML: '' };
  const answerEl = { textContent: '', innerHTML: '' };
  const wakeBtn = { textContent: '' };
  const player = { pause(){}, currentTime: 0, src: '', onerror: null, onended: null,
                   play() { return { catch() {} }; } };
  var socket = null, userGuid = null;
  var isSpeaking = false, echoGuardUntil = 0;
  var wakeOn = false, recognition = null, audioCtx = null, micStream = null;
  var recognitionRunning = false, restartGeneration = 0, analyser = null;

  // Stubs for functions handleHeard calls
  function startThinkingSound() {}
  function stopThinkingSound() {}
  function setStatus(){}

  // crypto polyfill
  if (typeof crypto === 'undefined') {
    global.crypto = { randomUUID: () => 'test-' + Math.random().toString(36).slice(2) };
  }

  // Audio stubs so startThinkingSound() doesn't throw
  function Audio() {
    return { loop: false, volume: 0, play() { return Promise.reject(); }, pause() {} };
  }
  function AudioContext() {
    return {
      currentTime: 0,
      destination: {},
      createOscillator() { return { type:'', frequency:{value:0}, connect(g){return g;}, start(){}, stop(){} }; },
      createGain()      { return { gain:{value:0,cancelScheduledValues(){},setValueAtTime(){},linearRampToValueAtTime(){}}, connect(d){return d;} }; },
      close() {}
    };
  }
`;

// Wrap and execute
const code = stubs + js;

try {
  eval(code);
} catch (e) {
  console.error('Failed to load state machine:', e.message);
  process.exit(1);
}

// Now run the test file — it expects window.send, handleHeard, etc.
const testJs = fs.readFileSync(
  path.join(__dirname, 'browser_wake_test.js'), 'utf8');

// The test wraps everything in an IIFE; we patch console.log to count
let passCount = 0, failCount = 0;
const origLog = console.log;
console.log = function(...args) {
  const joined = args.map(String).join(' ');
  if (joined.includes('PASS')) passCount++;
  if (joined.includes('FAIL')) failCount++;
  origLog.apply(console, args);
};

try {
  eval(testJs);
} catch (e) {
  console.error('Test execution failed:', e.message, e.stack);
  process.exit(1);
}

console.log = origLog;

if (failCount > 0) {
  console.log(`\nFAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`\nOK: ${passCount} tests passed`);
  process.exit(0);
}
