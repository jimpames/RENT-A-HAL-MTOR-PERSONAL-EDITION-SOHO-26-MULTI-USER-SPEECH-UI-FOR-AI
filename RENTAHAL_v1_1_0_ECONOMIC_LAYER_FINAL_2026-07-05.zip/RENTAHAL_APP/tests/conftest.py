"""conftest.py — shared harness machinery."""

import asyncio
import contextlib
import json
import socket
import time

import pytest
import uvicorn
import websockets


# ---------------------------------------------------------------------------
# Event-loop lag probe: the instrument that catches BUG-1.
# ---------------------------------------------------------------------------

class LoopLagProbe:
    """Samples scheduling lag every `tick`s. max_lag ~= longest loop stall."""

    def __init__(self, tick=0.01):
        self.tick = tick
        self.max_lag = 0.0
        self.samples = []
        self._task = None

    async def _run(self):
        loop = asyncio.get_running_loop()
        last = loop.time()
        while True:
            await asyncio.sleep(self.tick)
            now = loop.time()
            lag = max(0.0, (now - last) - self.tick)
            self.samples.append(lag)
            self.max_lag = max(self.max_lag, lag)
            last = now

    def start(self):
        self._task = asyncio.ensure_future(self._run())
        return self

    async def stop(self):
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task


@pytest.fixture
def lag_probe():
    return LoopLagProbe()


# ---------------------------------------------------------------------------
# In-process uvicorn server on a free port
# ---------------------------------------------------------------------------

def _free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class RealmServer:
    def __init__(self, app):
        self.app = app
        self.port = _free_port()
        # ws_ping_interval=None: we are testing OUR app-level ping/reap,
        # not uvicorn's protocol keepalive.
        self.config = uvicorn.Config(app, host="127.0.0.1", port=self.port,
                                     log_level="error", ws_ping_interval=None,
                                     ws_ping_timeout=None)
        self.server = uvicorn.Server(self.config)
        self.task = None
        self.url = f"ws://127.0.0.1:{self.port}/ws"

    async def __aenter__(self):
        self.task = asyncio.create_task(self.server.serve())
        for _ in range(200):
            if self.server.started:
                return self
            await asyncio.sleep(0.01)
        raise RuntimeError("server failed to start")

    async def __aexit__(self, *exc):
        self.server.should_exit = True
        await self.task


# ---------------------------------------------------------------------------
# Realm websocket client helper
# ---------------------------------------------------------------------------

class RealmClient:
    """Speaks the realm protocol; answers pings; collects typed messages."""

    def __init__(self, url, auto_pong=True):
        self.url = url
        self.auto_pong = auto_pong
        self.ws = None
        self.guid = None
        self.inbox = {}            # type -> list of messages
        self._reader = None
        self.closed_by_server = asyncio.Event()

    async def connect(self):
        self.ws = await websockets.connect(self.url, open_timeout=5)
        self._reader = asyncio.ensure_future(self._read_loop())
        await self.wait_for("user_info", timeout=5)
        self.guid = self.inbox["set_cookie"][0]["value"]
        return self

    async def _read_loop(self):
        try:
            async for raw in self.ws:
                msg = json.loads(raw)
                self.inbox.setdefault(msg["type"], []).append(msg)
                if msg["type"] == "ping" and self.auto_pong:
                    await self.send({"type": "pong"})
        except Exception:
            pass
        finally:
            self.closed_by_server.set()

    async def send(self, payload):
        await self.ws.send(json.dumps(payload))

    async def submit(self, prompt, query_type="chat", model_type="worker_node",
                     audio=None):
        q = {"prompt": prompt, "query_type": query_type,
             "model_type": model_type, "model_name": "test"}
        if audio:
            q["audio"] = audio
        await self.send({"type": "submit_query", "query": q})

    async def wait_for(self, mtype, timeout=10, count=1):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if len(self.inbox.get(mtype, [])) >= count:
                return self.inbox[mtype][:count]
            await asyncio.sleep(0.01)
        raise TimeoutError(
            f"timed out waiting for {count}x {mtype}; "
            f"inbox={ {k: len(v) for k, v in self.inbox.items()} }")

    async def close(self):
        if self._reader:
            self._reader.cancel()
        with contextlib.suppress(Exception):
            await self.ws.close()

    async def kill(self):
        """Abrupt death: closes the TCP transport without a close frame."""
        if self._reader:
            self._reader.cancel()
        with contextlib.suppress(Exception):
            self.ws.transport.abort()
