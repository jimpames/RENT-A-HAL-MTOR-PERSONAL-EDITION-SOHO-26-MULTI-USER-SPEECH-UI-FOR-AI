// run_service_panel_test.js — verify browser-side service-finder logic.
//
// Architecture invariants this test LOCKS IN:
//   - 'bus_service_results' bus event opens the service panel
//   - Browser requests geolocation via navigator.geolocation
//   - Cached location is re-sent on every WebSocket reconnect
//   - Service cards include phone (tel: link), address, distance, hours
//   - OSM attribution is visible in the panel
//   - No Google Places / Yelp API references anywhere

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Test 1: services panel HTML present ──────────────────────
assert(/<div id="services-panel"/.test(html),
       'services panel div present');
assert(/id="services-results"/.test(html),
       'services results container present');
assert(/id="services-status"/.test(html),
       'services status line present');

// ─── Test 2: OSM attribution visible (ODbL license requirement) ──
assert(/OpenStreetMap contributors/.test(html),
       'OpenStreetMap contributors attribution visible');
assert(/openstreetmap\.org\/copyright/.test(html),
       'links to OSM copyright page (ODbL license link)');

// ─── Test 3: Services button in controls row ──────────────────
assert(/onclick="askService\(\)"/.test(html),
       'Services button wired up in controls row');

// ─── Test 4: bus_service_results handler exists ───────────────
assert(/case 'bus_service_results'/.test(html),
       'WebSocket handler for service_results event');
assert(/openServicesPanel/.test(html),
       'openServicesPanel function exists');

// ─── Test 5: geolocation flow ─────────────────────────────────
assert(/navigator\.geolocation/.test(html),
       'uses navigator.geolocation (browser standard)');
assert(/getCurrentPosition/.test(html),
       'calls getCurrentPosition');
assert(/rentahal_user_location/.test(html),
       'caches location in localStorage');
assert(/client_location/.test(html),
       'sends client_location message to realm');
assert(/resendCachedLocation/.test(html),
       'resends cached location on reconnect');

// ─── Test 6: service result cards ─────────────────────────────
const renderCardMatch = html.match(
  /function renderServiceCard[\s\S]+?\n\}/);
assert(renderCardMatch !== null, 'renderServiceCard function exists');

if (renderCardMatch) {
  const body = renderCardMatch[0];
  assert(/tel:/.test(body),
         'phone is rendered as tel: link (tappable on phone)');
  assert(/google\.com\/maps\/search/.test(body),
         'address opens in Maps (works on iOS and desktop)');
  assert(/distance_mi/.test(body),
         'distance is displayed');
  assert(/bearing/.test(body),
         'compass bearing is displayed');
  assert(/opening_hours/.test(body),
         'opening hours are displayed when available');
  assert(/website/.test(body),
         'website link is shown when available');
}

// ─── Test 7: ensureLocation prompts and caches ────────────────
const ensureLocMatch = html.match(/function ensureLocation[\s\S]+?\n\}/);
assert(ensureLocMatch !== null, 'ensureLocation function exists');
if (ensureLocMatch) {
  assert(/Promise/.test(ensureLocMatch[0]),
         'ensureLocation returns a Promise (async permission flow)');
  assert(/localStorage\.setItem/.test(ensureLocMatch[0]),
         'caches location after grant');
}

// ─── Test 8: askService two-step UX (location then prompt) ────
const askServiceMatch = html.match(/function askService[\s\S]+?\n\}/);
assert(askServiceMatch !== null, 'askService function exists');
if (askServiceMatch) {
  assert(/ensureLocation/.test(askServiceMatch[0]),
         'askService ensures location first');
  assert(/sendPrompt\(['"]service finder /.test(askServiceMatch[0]),
         'askService sends "service finder <cat>" through pipeline');
}

// ─── Test 9: hideServices closes the panel ────────────────────
const hideServicesMatch = html.match(/function hideServices[\s\S]+?\n\}/);
assert(hideServicesMatch !== null, 'hideServices function exists');

// ─── Test 10: compliance — no Google Places, no Yelp ──────────
// EXCEPT: google.com/maps/search URL is OK (it's a public link the
// user CLICKS, not an API call). The realm and browser must not
// embed API keys for any proprietary mapping provider.
assert(!/google_places_api_key/i.test(html),
       'no Google Places API key reference');
assert(!/places\.googleapis\.com/i.test(html),
       'no Google Places API endpoint');
assert(!/api\.yelp\.com/i.test(html),
       'no Yelp API endpoint');
assert(!/yelp_api_key/i.test(html),
       'no Yelp API key reference');
// Apple Maps OK to link to but not to call as API
assert(!/api\.apple\.com\/maps/i.test(html),
       'no Apple Maps API endpoint');

// ─── Test 11: cards are NOT phishing — display business name visibly ──
// Defense: the card must clearly show the business name, not bury it
// behind a generic "View" link. Critical for user trust.
if (renderCardMatch) {
  const body = renderCardMatch[0];
  assert(/font-weight:bold/.test(body),
         'business name is rendered as bold (clearly visible)');
}

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} service panel tests passed`);
  process.exit(0);
}
