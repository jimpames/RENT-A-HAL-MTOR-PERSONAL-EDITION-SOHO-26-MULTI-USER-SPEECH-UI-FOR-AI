"""
Regression tests for the music realm — intent classification and slot
extraction for YouTube IFrame search queries.

Architecture invariants this test file LOCKS IN:
  - 'music X' triggers kind='music', captures X as query slot
  - 'music player X' (and 'play music X', 'music play X') all work
  - Empty / keyword-only queries do NOT pollute the slot
  - News intent ('play news feed X') is NOT misclassified as music
  - Trailing politeness words and iOS punctuation are stripped
  - The realm never has a YouTube API key — it only relays the query
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.intent import (
    IntentClassifier,
    extract_music_slots,
    SINGLE_INTENTS,
    SLOT_EXTRACTORS,
)


def _slots(text):
    """Tokenize and run the extractor directly."""
    import re
    tokens = re.findall(r"\w+", text.lower())
    return extract_music_slots(text, tokens)


def _classify(text):
    """Run the full classifier."""
    return IntentClassifier(bus=None).classify(text)


# ─── Registration ─────────────────────────────────────────────

def test_music_is_a_single_intent():
    """The word 'music' must trigger kind='music'."""
    assert SINGLE_INTENTS.get("music") == "music"


def test_music_has_slot_extractor():
    """SLOT_EXTRACTORS must have an entry for music."""
    assert "music" in SLOT_EXTRACTORS
    assert SLOT_EXTRACTORS["music"] is extract_music_slots


# ─── Basic slot extraction ────────────────────────────────────

def test_music_with_simple_query():
    assert _slots("music london calling") == {"query": "london calling"}


def test_music_player_prefix():
    assert _slots("music player london calling") == {"query": "london calling"}


def test_music_play_prefix():
    assert _slots("music play london calling") == {"query": "london calling"}


def test_play_music_prefix():
    assert _slots("play music london calling") == {"query": "london calling"}


def test_long_query_preserved():
    """Multi-word artist + song names must survive intact."""
    s = _slots("music kashmir by led zeppelin")
    assert s == {"query": "kashmir by led zeppelin"}


def test_classical_works_preserved():
    """Real-world example: classical pieces have long, specific titles."""
    s = _slots("music beethoven symphony no 9 in d minor")
    assert s["query"] == "beethoven symphony no 9 in d minor"


# ─── Edge cases — empty / keyword-only queries ────────────────

def test_bare_music_keyword_no_slot():
    """Just 'music' with no song name — should produce no query slot."""
    assert _slots("music") == {}


def test_music_player_alone_no_slot():
    """'music player' without a song — should NOT capture 'player' as query."""
    assert _slots("music player") == {}


def test_music_play_alone_no_slot():
    assert _slots("music play") == {}


def test_play_music_alone_no_slot():
    assert _slots("play music") == {}


def test_music_with_only_politeness_no_slot():
    """Politeness words don't constitute a song name."""
    assert _slots("music please") == {}


# ─── iOS punctuation handling ─────────────────────────────────

def test_trailing_period_stripped():
    """iOS auto-adds period after dictation."""
    assert _slots("music london calling.") == {"query": "london calling"}


def test_trailing_exclamation_stripped():
    assert _slots("music london calling!") == {"query": "london calling"}


def test_trailing_question_mark_stripped():
    assert _slots("music london calling?") == {"query": "london calling"}


def test_ios_capitalization():
    """iOS auto-capitalizes after pauses — extractor lowercases all input."""
    assert _slots("Music London Calling") == {"query": "london calling"}


# ─── Politeness words stripped ────────────────────────────────

def test_trailing_please_stripped():
    assert _slots("music london calling please") == {"query": "london calling"}


def test_trailing_thanks_stripped():
    assert _slots("music tokyo girls thanks") == {"query": "tokyo girls"}


def test_multiple_politeness_words_stripped():
    assert _slots("music london calling please thanks") == {"query": "london calling"}


# ─── Full classifier pipeline ─────────────────────────────────

def test_classifier_music_kind():
    intent = _classify("music player london calling")
    assert intent.kind == "music"
    assert intent.slots == {"query": "london calling"}


def test_classifier_with_wake_word_prefix():
    """In production the wake word is stripped before classify, but the
    classifier should still tolerate it."""
    intent = _classify("computer music player london calling")
    assert intent.kind == "music"
    assert intent.slots.get("query") == "london calling"


def test_classifier_bare_music():
    """Bare 'music' → kind=music with empty slots."""
    intent = _classify("music")
    assert intent.kind == "music"
    assert intent.slots == {}


# ─── CRITICAL: news intent must NOT be misclassified as music ────
# Because "play music" is a music trigger, "play news" must still route
# to news. This was a real concern when "play" was briefly added as a
# single-word music intent.

def test_play_news_routes_to_news():
    intent = _classify("play news feed AP News")
    assert intent.kind == "news", \
        f"'play news...' should be news, got {intent.kind}"


def test_play_news_left_routes_to_news():
    intent = _classify("play news left")
    assert intent.kind == "news"


def test_news_feed_routes_to_news():
    intent = _classify("news feed BBC")
    assert intent.kind == "news"


# ─── CRITICAL: weather/ask intents unaffected ─────────────────

def test_weather_unaffected():
    intent = _classify("weather in boston")
    assert intent.kind == "weather"


def test_ask_unaffected():
    intent = _classify("tell me about mars")
    assert intent.kind == "ask"


def test_question_unaffected():
    intent = _classify("what is the speed of light")
    assert intent.kind == "ask"


# ─── Real-world song queries we expect to work ────────────────

@pytest.mark.parametrize("phrase,expected_query", [
    ("music bohemian rhapsody", "bohemian rhapsody"),
    ("music player stairway to heaven", "stairway to heaven"),
    ("music hotel california", "hotel california"),
    ("play music smells like teen spirit", "smells like teen spirit"),
    ("music player hey jude by the beatles", "hey jude by the beatles"),
    ("music despacito", "despacito"),
    ("music shape of you ed sheeran", "shape of you ed sheeran"),
])
def test_real_world_song_queries(phrase, expected_query):
    intent = _classify(phrase)
    assert intent.kind == "music"
    assert intent.slots.get("query") == expected_query


# ─── Architecture invariant: realm never calls YouTube API ────

def test_realm_has_no_youtube_api_key():
    """The realm code must NEVER contain a YouTube API key or reference
    to api.youtube.com / googleapis.com/youtube. The browser is the
    searcher (via IFrame embed), the realm only relays the query."""
    import pathlib
    realm_dir = pathlib.Path(__file__).resolve().parent.parent
    suspect_files = [
        realm_dir / "app.py",
        realm_dir / "realm" / "orchestrator.py",
        realm_dir / "realm" / "intent.py",
        realm_dir / "realm" / "engine_chain.py",
    ]
    BANNED = [
        "googleapis.com/youtube",
        "youtube_api_key",
        "YOUTUBE_API_KEY",
        "v3/search",
        "youtube.com/v1/",
    ]
    for f in suspect_files:
        if not f.exists():
            continue
        content = f.read_text(encoding="utf-8")
        for banned in BANNED:
            assert banned not in content, (
                f"Realm code at {f} contains '{banned}' — but the music "
                "realm MUST use the browser-side IFrame embed only. "
                "The realm never calls the YouTube Data API directly."
            )
