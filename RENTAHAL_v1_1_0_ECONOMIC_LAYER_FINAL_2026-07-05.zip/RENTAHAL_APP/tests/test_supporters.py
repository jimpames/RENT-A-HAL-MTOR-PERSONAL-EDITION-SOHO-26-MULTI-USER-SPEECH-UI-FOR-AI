"""
test_supporters.py — Supporters page + footer link tests.

Covers:
  - _read_supporters returns shipping defaults when section missing
  - _read_supporters returns disabled when enabled=false
  - _read_supporters reads operator-supplied links in order
  - _read_supporters stops scanning at first missing link_N_name
  - _read_supporters skips entries with empty URLs
  - _read_supporters safety-caps at 100 entries
  - /supporters returns 404 when not enabled (no accidental empty page)
  - /supporters renders when enabled
  - Cockpit footer conditionally renders "Support this project" link
  - Backward compat: missing section behaves like enabled=false
"""
import configparser
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ─── _read_supporters semantics (via the source) ────────────────────


def _make_cfg(text: str) -> configparser.ConfigParser:
    """Build a ConfigParser from inline text."""
    cfg = configparser.ConfigParser()
    cfg.read_string(text)
    return cfg


def _mock_reader(cfg):
    """Reimplementation of _read_supporters used for testing the pure
    logic outside the FastAPI closure. Source of truth is app.py — if
    that closure changes, the integration test (HTML source inspection)
    catches drift."""
    if not cfg.has_section("Supporters"):
        return {"enabled": False, "title": "", "intro": "", "links": []}
    section = cfg["Supporters"]
    enabled = section.get("enabled", "false").strip().lower() in (
        "true", "yes", "on", "1")
    title = section.get("title", "Ways to support this project").strip()
    intro = section.get("intro", "").strip()
    links = []
    n = 1
    while True:
        name_key = f"link_{n}_name"
        if name_key not in section:
            break
        name = section.get(name_key, "").strip()
        if not name:
            break
        url = section.get(f"link_{n}_url", "").strip()
        desc = section.get(f"link_{n}_desc", "").strip()
        if url:
            links.append({"name": name, "url": url, "desc": desc})
        n += 1
        if n > 100:
            break
    return {"enabled": enabled, "title": title, "intro": intro,
            "links": links}


# ─── Default / missing-section behavior ────────────────────────────


def test_read_supporters_missing_section_returns_disabled():
    """Backward compat: pre-2026-06-22 config.ini files have no
    [Supporters] section. Must return disabled with empty links —
    zero behavior change."""
    cfg = _make_cfg("[Server]\nport = 9999\n")
    info = _mock_reader(cfg)
    assert info["enabled"] is False
    assert info["links"] == []


def test_read_supporters_enabled_false_returns_disabled():
    """Operator-explicit opt-out. Same as missing section."""
    cfg = _make_cfg("""[Supporters]
enabled = false
title = SomeTitle
link_1_name = X
link_1_url = https://example.com
""")
    info = _mock_reader(cfg)
    assert info["enabled"] is False
    # Note: links may still parse, but the route enforces enabled=false
    # by returning 404 regardless. That's the safety net.


def test_read_supporters_default_title_when_missing():
    """If operator opts in but doesn't set a title, ship a sensible default."""
    cfg = _make_cfg("[Supporters]\nenabled = true\n")
    info = _mock_reader(cfg)
    assert info["title"] == "Ways to support this project"


def test_read_supporters_empty_intro_allowed():
    """Intro is optional. Empty string means no intro paragraph."""
    cfg = _make_cfg("[Supporters]\nenabled = true\n")
    info = _mock_reader(cfg)
    assert info["intro"] == ""


# ─── Link scanning ──────────────────────────────────────────────────


def test_read_supporters_reads_links_in_order():
    """link_1_*, link_2_*, link_3_* are returned in order."""
    cfg = _make_cfg("""[Supporters]
enabled = true
link_1_name = First
link_1_url = https://first.example
link_1_desc = First desc
link_2_name = Second
link_2_url = https://second.example
link_3_name = Third
link_3_url = https://third.example
link_3_desc = Third desc
""")
    info = _mock_reader(cfg)
    assert len(info["links"]) == 3
    assert info["links"][0]["name"] == "First"
    assert info["links"][1]["name"] == "Second"
    assert info["links"][2]["name"] == "Third"


def test_read_supporters_stops_at_first_missing_name():
    """The scan terminates at the first missing link_N_name. Operators
    don't need to renumber when they delete a link — they just gap-fill."""
    cfg = _make_cfg("""[Supporters]
enabled = true
link_1_name = A
link_1_url = https://a.example
link_3_name = C
link_3_url = https://c.example
""")
    info = _mock_reader(cfg)
    # link_2 missing — scan stops. Only link_1 returned.
    assert len(info["links"]) == 1
    assert info["links"][0]["name"] == "A"


def test_read_supporters_skips_link_with_empty_url():
    """A link with name but no URL is malformed — skip it gracefully
    rather than rendering a broken anchor."""
    cfg = _make_cfg("""[Supporters]
enabled = true
link_1_name = Has URL
link_1_url = https://valid.example
link_2_name = Missing URL
link_2_url =
""")
    info = _mock_reader(cfg)
    # link_2 has no URL — skipped. Scan continues past it.
    # Then link_3 doesn't exist — scan stops.
    assert len(info["links"]) == 1
    assert info["links"][0]["name"] == "Has URL"


def test_read_supporters_optional_description():
    """desc is optional — links without it render as name + url only."""
    cfg = _make_cfg("""[Supporters]
enabled = true
link_1_name = No Desc
link_1_url = https://nodesc.example
""")
    info = _mock_reader(cfg)
    assert len(info["links"]) == 1
    assert info["links"][0]["desc"] == ""


def test_read_supporters_strips_whitespace():
    """Operator-supplied values may have stray whitespace from copy-paste."""
    cfg = _make_cfg("""[Supporters]
enabled = true
link_1_name =    Spaced Name
link_1_url = https://example.com
link_1_desc =     description with leading space
""")
    info = _mock_reader(cfg)
    assert info["links"][0]["name"] == "Spaced Name"
    assert info["links"][0]["desc"] == "description with leading space"


def test_read_supporters_safety_caps_at_100_links():
    """Defensive: operator pastes thousands of links by accident.
    Cap prevents memory issues + page-render explosions."""
    lines = ["[Supporters]", "enabled = true"]
    for n in range(1, 200):
        lines.append(f"link_{n}_name = Link {n}")
        lines.append(f"link_{n}_url = https://link{n}.example")
    cfg = _make_cfg("\n".join(lines))
    info = _mock_reader(cfg)
    # Cap is at n>100, so we get exactly 99 (link_1 through link_99
    # before n becomes 100 then 101 and the safety guard fires)
    assert len(info["links"]) <= 100


# ─── Enabled flag accepts multiple truthy spellings ────────────────


@pytest.mark.parametrize("value,expected", [
    ("true", True), ("True", True), ("TRUE", True),
    ("yes", True), ("on", True), ("1", True),
    ("false", False), ("False", False), ("no", False),
    ("off", False), ("0", False),
    ("", False),
])
def test_read_supporters_enabled_parsing(value, expected):
    """Multiple truthy spellings — operator-friendly."""
    cfg = _make_cfg(f"[Supporters]\nenabled = {value}\n")
    info = _mock_reader(cfg)
    assert info["enabled"] is expected


# ─── Source-level: app.py wires the route + footer correctly ────────


def test_app_has_supporters_route():
    """The /supporters route MUST be registered."""
    app_py = (Path(__file__).resolve().parent.parent / "app.py").read_text()
    assert '@app.get("/supporters"' in app_py


def test_app_returns_404_when_not_enabled():
    """Source-level: the route MUST check enabled and return 404
    when not. Without this, an operator with no opt-in would still
    accidentally serve an empty supporters page."""
    app_py = (Path(__file__).resolve().parent.parent / "app.py").read_text()
    # Find the supporters route body
    m = re.search(r'@app\.get\("/supporters".*?(?=@app\.|@api\.|\Z)',
                  app_py, re.DOTALL)
    assert m, "Supporters route not found in app.py"
    body = m.group(0)
    assert "404" in body, "Route must return 404 when disabled"
    assert 'info["enabled"]' in body, \
        "Route must check the enabled flag before rendering"


def test_app_reader_function_exists():
    """The _read_supporters function MUST exist and be called by the
    index route (so the footer gets the enabled flag)."""
    app_py = (Path(__file__).resolve().parent.parent / "app.py").read_text()
    assert "_read_supporters" in app_py
    # Index route must call it to set supporters_enabled
    assert "supporters_enabled" in app_py


# ─── Cockpit footer renders link only when enabled ──────────────────


def test_cockpit_footer_uses_supporters_enabled_flag():
    """The footer's 'Support this project' link MUST be guarded by
    {% if supporters_enabled %}. Without this guard, every fresh
    install would show the link regardless of config — which is the
    exact failure mode we're protecting against."""
    index_html = (Path(__file__).resolve().parent.parent
                  / "templates" / "index.html").read_text()
    # Find the footer block
    footer_match = re.search(r"<footer>(.*?)</footer>", index_html, re.DOTALL)
    assert footer_match, "Footer not found in index.html"
    footer = footer_match.group(1)
    # The link must be inside a Jinja if-block keyed on supporters_enabled
    assert "supporters_enabled" in footer, \
        "Footer must check supporters_enabled flag"
    assert "/supporters" in footer, \
        "Footer must link to /supporters when enabled"
    # The link MUST be inside the if-block, not floating free
    if_block_match = re.search(
        r"{%\s*if\s+supporters_enabled\s*%}(.*?){%\s*endif\s*%}",
        footer, re.DOTALL)
    assert if_block_match, "supporters_enabled must guard a Jinja if-block"
    if_body = if_block_match.group(1)
    assert "/supporters" in if_body, \
        "The /supporters link MUST be inside the {% if supporters_enabled %} block"


# ─── Supporters page template exists + renders the data ────────────


def test_supporters_template_exists():
    """The template file must ship with the realm."""
    path = (Path(__file__).resolve().parent.parent
            / "templates" / "supporters.html")
    assert path.exists(), "supporters.html template missing"


def test_supporters_template_renders_operator_data_only():
    """The template MUST iterate over s.links and render them. It must
    NOT contain any hardcoded URLs or specific project names — only
    operator-supplied data."""
    template = (Path(__file__).resolve().parent.parent
                / "templates" / "supporters.html").read_text()
    # The template iterates over the operator-supplied links
    assert "{% for lk in s.links %}" in template
    # No specific token URLs, no pump.fun, no hardcoded promotional URLs
    forbidden_substrings = ["pump.fun", "solana", "coin/", "memecoin"]
    for sub in forbidden_substrings:
        assert sub not in template.lower(), (
            f"Template must not contain hardcoded {sub!r} — "
            "supporters page is operator-controlled, no defaults baked in")


def test_supporters_template_has_empty_state():
    """When operator enables the page but configures no links, render
    a helpful empty state explaining how to add links."""
    template = (Path(__file__).resolve().parent.parent
                / "templates" / "supporters.html").read_text()
    assert "{% else %}" in template
    assert "link_N_name" in template or "link_N_url" in template, \
        "Empty state should explain the config.ini schema"


# ─── config.ini schema — Supporters section shipped disabled ────────


def test_shipped_config_has_supporters_disabled_default():
    """The shipping default for [Supporters] enabled MUST be false.
    Operators opt in consciously — nothing promotional ships by
    default."""
    config_ini = (Path(__file__).resolve().parent.parent
                  / "config.ini").read_text()
    cfg = configparser.ConfigParser()
    cfg.read_string(config_ini)
    assert cfg.has_section("Supporters")
    enabled = cfg.get("Supporters", "enabled", fallback="false").strip().lower()
    assert enabled in ("false", "no", "off", "0"), (
        "Shipping default for [Supporters] enabled MUST be false. "
        "Operators must opt in consciously.")


def test_shipped_config_has_no_uncommented_promo_links():
    """The shipped config.ini must not have any uncommented
    link_N_* entries. Every example must be commented out so a fresh
    install ships with zero default promotional content."""
    config_ini_path = (Path(__file__).resolve().parent.parent / "config.ini")
    raw = config_ini_path.read_text()
    # Find the [Supporters] section content
    m = re.search(r"\[Supporters\](.*?)(?=\n\[|\Z)", raw, re.DOTALL)
    assert m, "[Supporters] section missing from shipped config.ini"
    section_body = m.group(1)
    # Check for uncommented link_N_ lines
    for line in section_body.splitlines():
        stripped = line.strip()
        if stripped.startswith(("#", ";")):
            continue        # commented out — fine
        if not stripped:
            continue        # blank — fine
        if "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key.startswith("link_"):
                pytest.fail(
                    f"Shipped config.ini has uncommented link entry: "
                    f"{key!r}. All promotional examples MUST be commented "
                    f"out — operators opt in by uncommenting and editing.")


# ─── Inline-comment defense (the "; ← flip this" paste-error case) ─


def test_read_supporters_strips_inline_comments_from_enabled():
    """The exact bug that bit Jim in production: operator pasted the
    annotation arrow into the value. configparser leaves inline ';'
    comments in values, so the truthy check failed. The fix strips
    inline comments before the truthy check."""
    cfg = _make_cfg("""[Supporters]
enabled = true                        ; ← flip this
""")
    # Reimplemented locally to test the strip logic
    import re
    def _strip(s):
        m = re.search(r"\s+;", s)
        return (s[:m.start()] if m else s).strip()
    raw = cfg["Supporters"].get("enabled", "false")
    assert _strip(raw).lower() in ("true", "yes", "on", "1")


def test_strip_inline_comment_does_not_break_urls():
    """URLs use # for fragments. We MUST NOT strip on '#'. We MUST NOT
    strip on bare ';' without preceding whitespace (URLs with ';' in
    query params would break)."""
    import re
    def _strip(s):
        m = re.search(r"\s+;", s)
        return (s[:m.start()] if m else s).strip()
    # URL with # — preserved
    assert _strip("https://example.com/page#section") == \
           "https://example.com/page#section"
    # URL with ; in query params — preserved (no whitespace before ;)
    assert _strip("https://example.com/api?x=1;y=2") == \
           "https://example.com/api?x=1;y=2"
    # Inline comment with space — stripped
    assert _strip("true ; comment here") == "true"
    # Inline comment with tab — stripped
    assert _strip("true\t; comment") == "true"
    # Multiple spaces — stripped
    assert _strip("on             ; flip this") == "on"
    # No comment — no-op
    assert _strip("plain value") == "plain value"
    # Empty / None safety
    assert _strip("") == ""


def test_strip_inline_comment_handles_multiple_spellings():
    """Different operator paste-paths should all resolve."""
    import re
    def _strip(s):
        m = re.search(r"\s+;", s)
        return (s[:m.start()] if m else s).strip()
    # Different whitespace, same intent
    assert _strip("true ;comment") == "true"
    assert _strip("true   ; long comment") == "true"
    # Empty value followed by comment
    assert _strip(" ; only a comment") == ""


def test_app_uses_inline_comment_stripping_in_supporters():
    """Source-level: app.py MUST use _strip_inline_comment in the
    supporters reader. Without it, the paste-error footgun returns."""
    app_py = (Path(__file__).resolve().parent.parent / "app.py").read_text()
    # The helper must exist somewhere
    assert "_strip_inline_comment" in app_py, \
        "_strip_inline_comment helper must be defined"
    # It must be applied at multiple sites — find them all
    call_sites = app_py.count("_strip_inline_comment(section.get(")
    assert call_sites >= 4, (
        f"Expected _strip_inline_comment to be applied to multiple "
        f"supporter fields (enabled, title, intro, link_*_name, "
        f"link_*_url, link_*_desc). Found {call_sites} call sites — "
        f"too few. Without this, paste-error footgun returns.")


def test_app_strips_inline_comment_from_enabled_field():
    """The exact paste-error case: operator wrote
    `enabled = true                        ; ← flip this`
    and the inline-comment stripping must resolve it to enabled=true.

    Direct invariant: scan the source line-by-line and find the first
    code line inside _read_supporters that begins with `enabled =`.
    That line (or its multi-line continuation) MUST include
    _strip_inline_comment. If it directly calls section.get without
    the wrapper, the paste-error bug returns."""
    app_py = (Path(__file__).resolve().parent.parent / "app.py").read_text()
    fn_start = app_py.find("def _read_supporters")
    assert fn_start >= 0, "_read_supporters function not found"
    fn_body = app_py[fn_start:fn_start + 3000]
    # Skip the docstring (mentions enabled in prose) by finding the
    # first occurrence of `section = cfg["Supporters"]` which is past
    # the docstring + helper def, then take everything after that.
    section_marker = 'section = cfg["Supporters"]'
    marker_idx = fn_body.find(section_marker)
    assert marker_idx >= 0, "section assignment not found"
    code_body = fn_body[marker_idx:]
    # First code line that builds `enabled =` — capture it and any
    # continuation up to the end of the statement.
    m = re.search(r'^\s*enabled\s*=.*?(?=^\s*(?:title|links|n)\s*=)',
                  code_body, re.DOTALL | re.MULTILINE)
    assert m, "Could not find enabled-build statement in code body"
    enabled_stmt = m.group(0)
    assert "_strip_inline_comment" in enabled_stmt, (
        "The enabled-build STATEMENT in _read_supporters MUST wrap "
        "section.get(\"enabled\", ...) in _strip_inline_comment(). "
        "Found this statement instead:\n" + enabled_stmt +
        "\nWithout the wrapper, the paste-error that bit Jim in "
        "production returns: `enabled = true ; ← flip this` reads "
        "as a falsy string and the supporters page never renders.")
