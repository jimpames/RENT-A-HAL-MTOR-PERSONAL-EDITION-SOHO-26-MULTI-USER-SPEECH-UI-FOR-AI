// run_roundup_test.js — verifies the browser-side ROUNDUP module:
// radio-station style auto-shuffle playback of news stories.
//
// What we test:
//   1. State variables exist and are correctly initialized
//   2. ROUNDUP button is wired to startRoundup()
//   3. startRoundup fetches /api/news/roundup
//   4. The alert mp3 is /static/newsroundupaudioalert.mp3
//   5. Synth fallback when alert mp3 fails (Web Audio API tones)
//   6. Auto-advance via player.onended when story finishes
//   7. roundupActive gates auto-advance — false means stop
//   8. silenceAll calls stopRoundup BEFORE pausing player
//   9. bus_intent_stop calls stopRoundup
//  10. Failed story audio skips to next (no stuck-on-broken-story)
//  11. Reaching end of queue calls stopRoundup with friendly message

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else { console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
         failCount++; }
}

// ─── State variables ─────────────────────────────────────────

assert(/let\s+roundupActive\s*=\s*false/.test(html),
       'roundupActive state variable declared, default false');
assert(/let\s+roundupQueue\s*=\s*\[\]/.test(html),
       'roundupQueue state variable declared, default []');
assert(/let\s+roundupIndex\s*=\s*0/.test(html),
       'roundupIndex state variable declared, default 0');

// ─── ROUNDUP button in the realm-buttons row ─────────────────

assert(/onclick="startRoundup\(\)"[\s\S]{0,200}ROUNDUP/.test(html),
       'ROUNDUP button calls startRoundup()');

// Should be visually distinct (a button with custom style — radio mode)
const roundupBtn = html.match(/onclick="startRoundup\(\)"[\s\S]{0,300}<\/button>/);
assert(roundupBtn, 'ROUNDUP button element exists');

// ─── startRoundup function ───────────────────────────────────

const startIdx = html.indexOf('async function startRoundup');
assert(startIdx > 0, 'startRoundup function exists (async)');
const startEnd = html.indexOf('\nasync function ', startIdx + 1);
const startSrc = html.slice(startIdx,
                            startEnd > 0 ? startEnd : startIdx + 3000);

assert(/fetch\(['"`]\/api\/news\/roundup/.test(startSrc),
       'startRoundup fetches /api/news/roundup');
assert(/nukeAllCardPanels\(\)/.test(startSrc),
       'startRoundup nukes other panels first (panel mutex)');
assert(/getElementById\(['"]news-panel['"]\)[\s\S]{0,200}style\.display\s*=\s*['"]block['"]/.test(startSrc),
       'startRoundup opens news panel as visual home');
assert(/roundupActive\s*=\s*true/.test(startSrc),
       'startRoundup sets roundupActive = true');
assert(/playRoundupAlert\(\)/.test(startSrc),
       'startRoundup calls playRoundupAlert() before stories');

// Mash-defense: re-clicking ROUNDUP cancels the in-flight roundup
assert(/roundupActive\s*=\s*false[\s\S]{0,1500}fetch/.test(startSrc),
       'startRoundup cancels previous run before starting new (mash defense)');

// ─── playRoundupAlert — uses the configured mp3 path ─────────

const alertIdx = html.indexOf('async function playRoundupAlert');
assert(alertIdx > 0, 'playRoundupAlert function exists');
const alertSrc = html.slice(alertIdx, alertIdx + 1200);

assert(/\/static\/newsroundupaudioalert\.mp3/.test(alertSrc),
       'playRoundupAlert uses /static/newsroundupaudioalert.mp3');
assert(/new\s+Audio\(['"`]\/static\/newsroundupaudioalert\.mp3['"`]\)/.test(alertSrc),
       'playRoundupAlert creates throwaway Audio for alert mp3');
assert(/playRoundupAlertSynth/.test(alertSrc),
       'playRoundupAlert falls back to synth on error');
assert(/onerror/.test(alertSrc),
       'playRoundupAlert handles audio load error');
assert(/\.catch/.test(alertSrc),
       'playRoundupAlert handles play() promise rejection');

// ─── playRoundupAlertSynth — Web Audio fallback ──────────────

const synthIdx = html.indexOf('async function playRoundupAlertSynth');
assert(synthIdx > 0, 'playRoundupAlertSynth fallback exists');
const synthSrc = html.slice(synthIdx, synthIdx + 1500);

assert(/AudioContext\s*\|\|\s*window\.webkitAudioContext/.test(synthSrc),
       'synth uses AudioContext with webkit prefix fallback');
assert(/createOscillator/.test(synthSrc),
       'synth creates oscillator for tone generation');
assert(/createGain/.test(synthSrc),
       'synth uses gain node for envelope shaping');
assert(/\.frequency\.value\s*=/.test(synthSrc),
       'synth sets oscillator frequency');

// ─── playRoundupStory — auto-advance core ────────────────────

const playStoryIdx = html.indexOf('function playRoundupStory');
assert(playStoryIdx > 0, 'playRoundupStory function exists');
const playSrc = html.slice(playStoryIdx, playStoryIdx + 1800);

// Gate 1: roundupActive must be true to play
assert(/if\s*\(\s*!roundupActive\s*\)/.test(playSrc),
       'playRoundupStory bails if !roundupActive');

// Gate 2: idx must be within queue range — natural finish
assert(/if\s*\(\s*idx\s*>=\s*roundupQueue\.length\s*\)/.test(playSrc),
       'playRoundupStory bails when past end of queue');
assert(/stopRoundup\(/.test(playSrc),
       'playRoundupStory calls stopRoundup at end');

// Auto-advance via onended
assert(/player\.onended/.test(playSrc),
       'playRoundupStory wires player.onended for auto-advance');
assert(/playRoundupStory\s*\(\s*idx\s*\+\s*1\s*\)/.test(playSrc),
       'auto-advance calls playRoundupStory(idx + 1)');

// onended re-checks roundupActive — silence mid-story doesn't advance
const onendedMatch = playSrc.match(
  /player\.onended\s*=[\s\S]{0,400}\}/);
if (onendedMatch) {
  assert(/if\s*\(\s*roundupActive\s*\)/.test(onendedMatch[0]),
         'auto-advance re-checks roundupActive after audio ends (silence mid-story = no next)');
}

// Failed audio also tries next
assert(/player\.onerror/.test(playSrc),
       'playRoundupStory handles audio load error');

// ─── stopRoundup — the cleanup ──────────────────────────────

const stopIdx = html.indexOf('function stopRoundup');
assert(stopIdx > 0, 'stopRoundup function exists');
const stopSrc = html.slice(stopIdx, stopIdx + 1200);

assert(/roundupActive\s*=\s*false/.test(stopSrc),
       'stopRoundup sets roundupActive = false');
assert(/player\.pause\(\)/.test(stopSrc),
       'stopRoundup pauses the player');
assert(/roundupQueue\s*=\s*\[\]/.test(stopSrc),
       'stopRoundup clears the queue');

// ─── silenceAll wiring ──────────────────────────────────────

const silenceIdx = html.indexOf('function silenceAll');
const silenceSrc = html.slice(silenceIdx, silenceIdx + 1400);

assert(/stopRoundup/.test(silenceSrc),
       'silenceAll calls stopRoundup');

// Critical ORDER: stopRoundup must come BEFORE player.pause() because
// pausing the player triggers onended on some browsers, which would
// auto-advance if we hadn't already flipped roundupActive to false.
// Look for the FUNCTION CALL form (with opening paren), not just the
// string — comments mentioning "stopRoundup" should not count.
const stopCallIdx = silenceSrc.search(/stopRoundup\s*\(/);
const pauseIdx = silenceSrc.indexOf('player.pause');
assert(stopCallIdx > 0 && pauseIdx > 0 && stopCallIdx < pauseIdx,
       'silenceAll calls stopRoundup() BEFORE player.pause() (order matters)');

// ─── bus_intent_stop wiring ─────────────────────────────────

const stopCaseMatch = html.match(
  /case\s+'bus_intent_stop'[\s\S]{0,2000}break;/);
assert(stopCaseMatch, "bus_intent_stop case exists in handleMsg");
if (stopCaseMatch) {
  assert(/stopRoundup/.test(stopCaseMatch[0]),
         'bus_intent_stop calls stopRoundup');
}

// ─── Diagnostic logging ─────────────────────────────────────

assert(/console\.log\(['"`]\[roundup\] starting/.test(html),
       'Logs [roundup] starting (visible diagnostic)');
assert(/console\.log\(['"`]\[roundup\] stopped/.test(html),
       'Logs [roundup] stopped');

// ─── Summary ─────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} ROUNDUP tests passed`);
  process.exit(0);
}
