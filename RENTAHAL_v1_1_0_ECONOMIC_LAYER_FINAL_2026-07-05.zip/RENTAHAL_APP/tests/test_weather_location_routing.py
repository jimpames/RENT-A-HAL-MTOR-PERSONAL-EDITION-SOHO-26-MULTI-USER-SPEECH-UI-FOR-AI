"""
Regression test: when a user asks "weather in <city>", the realm must
actually look up THAT city, not the default location.

Jim reported in v176 — "weather always returns newburgh no matter the
city". We trace the full pipeline: browser sends 'weather in boston' →
classifier extracts location slot → orchestrator routes → make_weather_handler
calls OpenWeatherMap geocode → response uses the queried city.

We stub aiohttp so we can observe what city was actually queried.
"""

import asyncio
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

pytestmark = pytest.mark.asyncio


class FakeAiohttpResponse:
    """One-shot response that returns the JSON we set."""
    def __init__(self, json_data, status=200):
        self._json = json_data
        self.status = status
    async def json(self):
        return self._json
    async def __aenter__(self):
        return self
    async def __aexit__(self, *args):
        pass


class FakeAiohttpSession:
    """Records every GET. First call returns geocode result for the queried
    city, second call returns weather data."""
    def __init__(self, *args, **kwargs):
        self.get_calls = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    def get(self, url, params=None, timeout=None):
        self.get_calls.append({"url": url, "params": params or {}})
        # First call is geocoding — return matching coords for whatever city
        if "geo" in url:
            city = (params or {}).get("q", "Unknown")
            return FakeAiohttpResponse([{
                "name": city, "lat": 42.0, "lon": -71.0, "country": "US"
            }])
        # Second call is onecall — return weather data
        return FakeAiohttpResponse({
            "current": {"temp": 65.0,
                        "weather": [{"description": "partly cloudy"}]}
        })


# Shared accumulator so the test can read the captured calls
_captured = {"sessions": []}


def fake_clientsession_factory(*args, **kwargs):
    s = FakeAiohttpSession(*args, **kwargs)
    _captured["sessions"].append(s)
    return s


@pytest.fixture(autouse=True)
def clear_captured():
    _captured["sessions"].clear()
    yield


async def test_weather_handler_uses_location_from_slots():
    """Direct test of make_weather_handler — when called with location slot
    'Boston', must query OpenWeatherMap with city='Boston', not 'Newburgh'."""
    # Build cfg that has an api_key so the handler will actually make calls
    cfg = {
        "Weather": {
            "api_key": "test-key-not-newburgh",
            "units": "imperial",
            "onecall_url": "https://api.openweathermap.org/data/3.0/onecall",
        }
    }

    def fake_cfg_get(c, section, key, default=""):
        return c.get(section, {}).get(key, default)

    with patch("app.cfg_get", side_effect=fake_cfg_get), \
         patch("app.aiohttp.ClientSession", fake_clientsession_factory):
        from app import make_weather_handler
        handler = make_weather_handler(cfg)
        result = await handler({"location": "Boston"}, "test-user")

    # Inspect what was actually queried
    assert len(_captured["sessions"]) == 1, "should make one session"
    calls = _captured["sessions"][0].get_calls
    assert len(calls) == 2, f"expected geocode + onecall, got {len(calls)}: {calls}"

    geocode_call = calls[0]
    assert "geo" in geocode_call["url"], "first call should be geocoding"
    assert geocode_call["params"]["q"] == "Boston", \
        f"BUG: geocoded {geocode_call['params']['q']} instead of Boston"

    # And the response text mentions Boston
    assert "Boston" in result, f"response should mention Boston: {result!r}"
    assert "Newburgh" not in result, \
        f"response should NOT mention Newburgh: {result!r}"


async def test_weather_handler_defaults_to_newburgh_only_when_no_slot():
    """When called with EMPTY slots, defaults to Newburgh (this is correct)."""
    cfg = {"Weather": {"api_key": "test-key", "units": "imperial"}}
    def fake_cfg_get(c, section, key, default=""):
        return c.get(section, {}).get(key, default)
    with patch("app.cfg_get", side_effect=fake_cfg_get), \
         patch("app.aiohttp.ClientSession", fake_clientsession_factory):
        from app import make_weather_handler
        handler = make_weather_handler(cfg)
        result = await handler({}, "test-user")

    calls = _captured["sessions"][0].get_calls
    assert calls[0]["params"]["q"] == "Newburgh"


async def test_weather_handler_handles_multiword_city():
    """'New York' — must pass through intact, not get truncated or split."""
    cfg = {"Weather": {"api_key": "test-key", "units": "imperial"}}
    def fake_cfg_get(c, section, key, default=""):
        return c.get(section, {}).get(key, default)
    with patch("app.cfg_get", side_effect=fake_cfg_get), \
         patch("app.aiohttp.ClientSession", fake_clientsession_factory):
        from app import make_weather_handler
        handler = make_weather_handler(cfg)
        result = await handler({"location": "New York"}, "test-user")
    calls = _captured["sessions"][0].get_calls
    assert calls[0]["params"]["q"] == "New York"
    assert "New York" in result


async def test_full_pipeline_weather_in_boston_extracts_and_uses_boston():
    """Full chain: classifier → orchestrator → handler. Prove slots flow end-to-end."""
    from realm.intent import IntentClassifier
    clf = IntentClassifier(bus=None)
    intent = clf.classify("weather in Boston")
    assert intent.kind == "weather"
    assert intent.slots.get("location") == "boston", \
        f"classifier returned slots={intent.slots}"

    # Now feed those slots into the handler
    cfg = {"Weather": {"api_key": "test-key", "units": "imperial"}}
    def fake_cfg_get(c, section, key, default=""):
        return c.get(section, {}).get(key, default)
    with patch("app.cfg_get", side_effect=fake_cfg_get), \
         patch("app.aiohttp.ClientSession", fake_clientsession_factory):
        from app import make_weather_handler
        handler = make_weather_handler(cfg)
        result = await handler(intent.slots, "test-user")
    calls = _captured["sessions"][0].get_calls
    # boston (lowercase from the classifier) — what matters is NOT Newburgh
    assert calls[0]["params"]["q"].lower() == "boston"
    assert "Newburgh" not in result
