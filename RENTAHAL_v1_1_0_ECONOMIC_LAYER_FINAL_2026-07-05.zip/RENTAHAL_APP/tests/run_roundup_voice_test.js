// run_roundup_voice_test.js — verifies the BROWSER side of the voice
// ROUNDUP path. User says "computer roundup newline":
//   1. Realm classifies kind=roundup, calls roundup_handler
//   2. Handler publishes bus_news_roundup_start with stories
//   3. Browser receives event → calls startRoundup(msg.stories)
//
// What this test covers:
//   - bus_news_roundup_start case exists in handleMsg
//   - Handler calls startRoundup with msg.stories (no second fetch)
//   - startRoundup accepts an optional preloadedStories parameter
//   - preloadedStories voice path skips the /api/news/roundup fetch
//   - preloadedStories button path falls back to fetch (current behavior)
//   - bus_news_roundup_start is in ACK_TRACKED_EVENT_TYPES (so we ACK it)
//   - The case logs a diagnostic [roundup] line so we can verify in DevTools

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else { console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
         failCount++; }
}

// ─── bus_news_roundup_start case in handleMsg ──────────────────

const caseIdx = html.indexOf("case 'bus_news_roundup_start':");
assert(caseIdx > 0,
       "bus_news_roundup_start case exists in handleMsg");

// Slice from the case to the next break — that's the body
const caseEnd = html.indexOf('break;', caseIdx);
const caseBody = html.slice(caseIdx, caseEnd + 6);

assert(/startRoundup\s*\(\s*msg\.stories/.test(caseBody),
       'voice case calls startRoundup(msg.stories)');

assert(/stopThinkingSound\(\)/.test(caseBody),
       'voice case stops thinking sound before starting roundup');

assert(/console\.log\(['"`]\[roundup\] bus_news_roundup_start/.test(caseBody),
       'voice case logs diagnostic [roundup] line');

// ─── startRoundup accepts preloadedStories ─────────────────────

const startIdx = html.indexOf('async function startRoundup');
assert(startIdx > 0, 'startRoundup function exists');

// Match the signature line
const sigLine = html.slice(startIdx, startIdx + 100);
assert(/async function startRoundup\(preloadedStories\)/.test(sigLine),
       'startRoundup signature accepts preloadedStories parameter');

// Function body (generous slice)
const startEnd = html.indexOf('\nasync function ', startIdx + 1);
const startSrc = html.slice(startIdx,
                            startEnd > 0 ? startEnd : startIdx + 4000);

// Voice path branch: if preloadedStories is a non-empty array, use it
assert(/Array\.isArray\(preloadedStories\)[\s\S]{0,200}preloadedStories\.length\s*>\s*0/
       .test(startSrc),
       'startRoundup checks preloadedStories is a non-empty array');

// Voice path filters out stories without audio_url
const voicePathSrc = startSrc.match(
  /Array\.isArray\(preloadedStories\)[\s\S]{0,800}\}/);
assert(voicePathSrc, 'startRoundup has a voice-path branch');
if (voicePathSrc) {
  assert(/preloadedStories\.filter\(s\s*=>\s*s\.audio_url\)/.test(voicePathSrc[0]),
         'voice path filters preloadedStories by audio_url presence');
}

// Button path: when preloadedStories absent, fetch from API
assert(/fetch\(['"`]\/api\/news\/roundup/.test(startSrc),
       'button path still fetches from /api/news/roundup');

// Both paths must end up at the same playlist render + alert + play chain
assert(/playRoundupAlert\(\)/.test(startSrc),
       'startRoundup always plays the intro alert');
assert(/playRoundupStory\(0\)/.test(startSrc),
       'startRoundup always kicks off story 0 after alert');

// Mash defense: roundupActive = false BEFORE any new state
assert(/roundupActive\s*=\s*false[\s\S]{0,200}nukeAllCardPanels/.test(startSrc),
       'startRoundup cancels prior run BEFORE rebuilding state (mash defense)');

// ─── ACK_TRACKED_EVENT_TYPES includes bus_news_roundup_start ────

const ackSetMatch = html.match(
  /const\s+ACK_TRACKED_EVENT_TYPES\s*=\s*new\s+Set\(\[([\s\S]*?)\]\)/);
assert(ackSetMatch, 'ACK_TRACKED_EVENT_TYPES Set found');
if (ackSetMatch) {
  const types = ackSetMatch[1];
  assert(/['"]bus_news_roundup_start['"]/.test(types),
         "bus_news_roundup_start is in browser ACK_TRACKED_EVENT_TYPES");
}

// ─── Diagnostic improvements ───────────────────────────────────

// console.log now distinguishes voice vs button path
assert(/preloadedStories\s*\?\s*['"`]\(voice path\)/.test(startSrc),
       'startRoundup logs voice-vs-button distinction for debugging');

// ─── Summary ─────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} ROUNDUP voice tests passed`);
  process.exit(0);
}
