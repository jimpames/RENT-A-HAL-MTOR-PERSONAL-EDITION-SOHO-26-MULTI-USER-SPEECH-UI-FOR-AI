// run_ack_test.js — verifies the browser-side ACK protocol.
//
// What we test:
//   1. connToken module var exists and starts as null
//   2. The set of ACK_TRACKED_EVENT_TYPES matches realm_core.py
//   3. handleMsg's 'conn_token' case stores msg.value into connToken
//   4. handleMsg has a try/catch around the switch — handler exceptions
//      don't suppress the ACK path (they just prevent the ACK so the
//      realm's timeout warning fires for true handler failures)
//   5. After handler runs, ACK is sent only for tracked event types
//   6. ACK includes connToken AND seq
//   7. ACK is NOT sent if connToken is null (no realm session)
//   8. ACK is NOT sent if handler threw

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else { console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
         failCount++; }
}

// ─── State: connToken module variable ─────────────────────────

assert(/let\s+connToken\s*=\s*null/.test(html),
       'connToken module variable declared and initialized to null');

// ─── ACK_TRACKED_EVENT_TYPES matches realm side ───────────────

const ackSetMatch = html.match(
  /const\s+ACK_TRACKED_EVENT_TYPES\s*=\s*new\s+Set\(\[([\s\S]*?)\]\)/);
assert(ackSetMatch, 'ACK_TRACKED_EVENT_TYPES Set declared');

if (ackSetMatch) {
  const ackTypes = ackSetMatch[1];
  // These five must match realm_core.py's ACK_TRACKED_EVENT_TYPES
  const expected = [
    'bus_service_results',
    'bus_music_search_request',
    'bus_news_bundle',
    'bus_news_stories',
    'bus_query_result',
  ];
  for (const t of expected) {
    assert(ackTypes.includes(`'${t}'`) || ackTypes.includes(`"${t}"`),
           `ACK_TRACKED_EVENT_TYPES includes ${t}`);
  }
  // Untracked events should NOT be in the set (catches accidental adds)
  const shouldNotBeTracked = [
    'bus_tts_chunk',
    'bus_tts_complete',
    'bus_metrics_snapshot',
    'bus_query_processing',
    'ping',
  ];
  for (const t of shouldNotBeTracked) {
    assert(!ackTypes.includes(`'${t}'`) && !ackTypes.includes(`"${t}"`),
           `ACK_TRACKED_EVENT_TYPES does NOT include ${t} (would be wasteful)`);
  }
}

// ─── handleMsg structure ─────────────────────────────────────

const handleMsgIdx = html.indexOf('function handleMsg(msg)');
assert(handleMsgIdx > 0, 'handleMsg function exists');
// Body extends until the next top-level function declaration. We take
// a generous slice that grows as handleMsg grows — this test should
// not break just because we added cases or per-case logic.
const handleMsgSrc = html.slice(handleMsgIdx, handleMsgIdx + 12000);

// 'conn_token' case stores into connToken
assert(/case\s+'conn_token'[\s\S]*?connToken\s*=\s*msg\.value/.test(handleMsgSrc),
       "handleMsg's 'conn_token' case assigns msg.value to connToken");

// try-catch wraps the switch
assert(/let\s+handlerOk\s*=\s*false[\s\S]*?try\s*\{[\s\S]*?switch\s*\(msg\.type\)/
       .test(handleMsgSrc),
       'handleMsg wraps switch in try with handlerOk flag');

// handlerOk = true is set ONLY after switch completes (so an exception
// in any case leaves it false)
assert(/handlerOk\s*=\s*true/.test(handleMsgSrc),
       'handleMsg sets handlerOk = true after switch');

// catch block exists and logs without throwing
assert(/catch\s*\(\s*err\s*\)\s*\{[\s\S]*?console\.error/.test(handleMsgSrc),
       'handleMsg catches handler exceptions and logs them');

// ─── ACK send logic — the critical correctness check ──────────

// After the catch block, ACK is sent only if all four conditions met:
//   handlerOk
//   ACK_TRACKED_EVENT_TYPES.has(msg.type)
//   typeof msg._seq === 'number'
//   connToken !== null
const ackBlock = handleMsgSrc.match(
  /if\s*\(\s*handlerOk[\s\S]*?send\s*\(\s*\{\s*type:\s*['"]ack['"][\s\S]*?\}\s*\)\s*;?\s*\}/);
assert(ackBlock, 'handleMsg has ACK-send block after handler');

if (ackBlock) {
  const block = ackBlock[0];
  assert(/handlerOk/.test(block),
         'ACK send guarded by handlerOk (no ACK if handler threw)');
  assert(/ACK_TRACKED_EVENT_TYPES\.has\(msg\.type\)/.test(block),
         'ACK send guarded by ACK_TRACKED_EVENT_TYPES membership');
  assert(/typeof\s+msg\._seq\s*===\s*['"]number['"]/.test(block),
         'ACK send guarded by msg._seq being a number');
  assert(/connToken\s*!==\s*null/.test(block),
         'ACK send guarded by connToken being non-null');

  // ACK payload includes type, conn_token, and seq
  assert(/type:\s*['"]ack['"]/.test(block),
         "ACK payload has type: 'ack'");
  assert(/conn_token:\s*connToken/.test(block),
         'ACK payload includes conn_token from module state');
  assert(/seq:\s*msg\._seq/.test(block),
         'ACK payload includes seq from incoming event');
}

// ─── Diagnostic logging ──────────────────────────────────────

assert(/console\.log\(['"`]\[ack\] connection token established/.test(handleMsgSrc),
       'Logs when conn_token is established (visible diagnostic)');

assert(/console\.error\(['"`]\[handleMsg\] exception/.test(handleMsgSrc),
       'Logs when a handler throws (catches handler bugs)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} ACK tests passed`);
  process.exit(0);
}
