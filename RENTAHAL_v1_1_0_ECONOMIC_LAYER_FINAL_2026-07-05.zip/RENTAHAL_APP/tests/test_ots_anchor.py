"""
Sprint 12 — tests for realm/ots_anchor.py.

Three tiers of testing, matching three tiers of what's actually
verifiable from this environment:

  1. LOCAL/STRUCTURAL, against REAL data (no network at all): uses
     tests/fixtures/hello-world.txt(.ots) — a genuine, publicly-known,
     already-Bitcoin-anchored proof fetched from the OpenTimestamps
     client's own GitHub repo (see fixtures/README.md for provenance).
     This is real cryptographic verification against real data, just
     not requiring a live calendar/Bitcoin connection to run.

  2. DB-BACKED (OtsAnchorStore), against a REAL Postgres instance —
     same per-test-database isolation pattern as test_ledger.py.

  3. LIVE NETWORK (submit_to_calendars against real calendar servers)
     — genuinely cannot be guaranteed from every environment this
     suite might run in. Written to skip gracefully (not fail) when
     the calendars aren't reachable, with a clear message about why,
     rather than either lying about coverage or breaking CI on
     networks that restrict egress to third-party services. See
     ECONOMIC_LAYER_DESIGN.md's Sprint 12 notes for the actual
     documented sandbox behavior this was built against.
"""
import asyncio
import hashlib
import os
import sys
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

asyncpg = pytest.importorskip("asyncpg")
otsclient_lib = pytest.importorskip("opentimestamps")

from realm.ledger import Ledger
from realm.ots_anchor import (
    AttestationInfo, LocalVerificationResult, OtsAnchorStore,
    build_detached_timestamp, deserialize, local_verify, serialize,
    submit_to_calendars,
)

FIXTURES = Path(__file__).parent / "fixtures"
HELLO_WORLD_TXT = FIXTURES / "hello-world.txt"
HELLO_WORLD_OTS = FIXTURES / "hello-world.txt.ots"

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


def _dsn_for_db(db_name: str) -> str:
    prefix = BASE_DSN.rsplit("/", 1)[0]
    return f"{prefix}/{db_name}"


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


pytestmark = pytest.mark.asyncio


# ─── Local/structural verification against REAL fixture data ───────

def test_fixture_files_exist():
    """Sanity check the fixtures themselves are present and non-empty
    — everything else in this section depends on them."""
    assert HELLO_WORLD_TXT.exists()
    assert HELLO_WORLD_OTS.exists()
    assert HELLO_WORLD_TXT.read_bytes() == b"Hello World!\n"


def test_deserialize_real_fixture():
    dts = deserialize(HELLO_WORLD_OTS.read_bytes())
    expected_digest = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).digest()
    assert dts.file_digest == expected_digest


def test_serialize_deserialize_round_trip_is_byte_identical():
    """Not just 'parses again' — genuinely identical bytes, proving
    serialize() doesn't silently normalize/lose anything relative to
    the original real-world proof file."""
    original = HELLO_WORLD_OTS.read_bytes()
    dts = deserialize(original)
    reserialized = serialize(dts)
    assert reserialized == original


def test_local_verify_real_complete_proof():
    dts = deserialize(HELLO_WORLD_OTS.read_bytes())
    expected_digest = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).digest()
    result = local_verify(dts, expected_digest)

    assert result.digest_matches is True
    assert result.has_complete_attestation is True
    assert result.is_fully_pending is False


def test_local_verify_extracts_correct_bitcoin_block_height():
    """The real, documented, publicly-known block height for this
    exact fixture (README.md's own worked example says the same
    number) — not just 'some number came back'."""
    dts = deserialize(HELLO_WORLD_OTS.read_bytes())
    expected_digest = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).digest()
    result = local_verify(dts, expected_digest)

    bitcoin_attestations = [a for a in result.attestations if a.kind == "bitcoin"]
    assert len(bitcoin_attestations) == 1
    assert bitcoin_attestations[0].bitcoin_block_height == 358391


def test_local_verify_derived_msg_is_real_hex():
    dts = deserialize(HELLO_WORLD_OTS.read_bytes())
    expected_digest = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).digest()
    result = local_verify(dts, expected_digest)
    derived = result.attestations[0].derived_msg_hex
    assert len(derived) == 64
    int(derived, 16)   # raises if not valid hex


def test_local_verify_detects_wrong_digest():
    """A proof genuinely attesting to 'Hello World!' must NOT verify
    against a different piece of data — this is the actual security
    property local_verify exists to check."""
    dts = deserialize(HELLO_WORLD_OTS.read_bytes())
    wrong_digest = hashlib.sha256(b"not hello world").digest()
    result = local_verify(dts, wrong_digest)
    assert result.digest_matches is False


def test_build_detached_timestamp_fresh_has_no_attestations():
    digest = hashlib.sha256(b"brand new data, never submitted anywhere").digest()
    dts = build_detached_timestamp(digest)
    result = local_verify(dts, digest)
    assert result.digest_matches is True
    assert result.attestations == []
    assert result.has_complete_attestation is False
    assert result.is_fully_pending is False   # zero attestations != pending


# ─── LocalVerificationResult properties (pure, no I/O) ──────────────

def test_has_complete_attestation_true_with_bitcoin_kind():
    result = LocalVerificationResult(
        digest_matches=True,
        attestations=[AttestationInfo(kind="bitcoin", derived_msg_hex="ab" * 32,
                                      bitcoin_block_height=1)])
    assert result.has_complete_attestation is True
    assert result.is_fully_pending is False


def test_is_fully_pending_true_with_only_pending_kind():
    result = LocalVerificationResult(
        digest_matches=True,
        attestations=[AttestationInfo(kind="pending", derived_msg_hex="ab" * 32,
                                      calendar_url="https://example.com")])
    assert result.has_complete_attestation is False
    assert result.is_fully_pending is True


def test_mixed_pending_and_complete_counts_as_complete():
    """If AT LEAST ONE calendar path is confirmed, the proof is usable
    — you don't need every submitted calendar to confirm, just one
    real Bitcoin attestation."""
    result = LocalVerificationResult(
        digest_matches=True,
        attestations=[
            AttestationInfo(kind="pending", derived_msg_hex="ab" * 32,
                           calendar_url="https://example.com"),
            AttestationInfo(kind="bitcoin", derived_msg_hex="cd" * 32,
                           bitcoin_block_height=999),
        ])
    assert result.has_complete_attestation is True


# ─── OtsAnchorStore — real Postgres, per-test database isolation ───

@pytest.fixture
async def ledger():
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable — see test_ledger.py's fixture "
                    "for the same pattern and reasoning.")
    db_name = f"rentahal_ots_test_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    dsn = _dsn_for_db(db_name)
    led = await Ledger.connect(dsn)
    led.dsn = dsn
    try:
        yield led
    finally:
        await led.close()
        admin_conn = await asyncpg.connect(BASE_DSN)
        await admin_conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
        await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
        await admin_conn.close()


async def test_record_new_stamp_and_get_latest(ledger):
    store = OtsAnchorStore(ledger)
    proof_bytes = HELLO_WORLD_OTS.read_bytes()
    digest_hex = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).hexdigest()

    anchor_id = await store.record_new_stamp(1, digest_hex, proof_bytes)
    assert anchor_id is not None

    latest = await store.get_latest_anchor()
    assert latest["id"] == anchor_id
    assert latest["chain_tip_hash"] == digest_hex
    assert bytes(latest["ots_proof"]) == proof_bytes
    assert latest["is_complete"] is False


async def test_get_latest_anchor_none_when_empty(ledger):
    store = OtsAnchorStore(ledger)
    latest = await store.get_latest_anchor()
    assert latest is None


async def test_get_incomplete_anchors_finds_pending_ones(ledger):
    store = OtsAnchorStore(ledger)
    digest_hex = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).hexdigest()
    await store.record_new_stamp(1, digest_hex, HELLO_WORLD_OTS.read_bytes())

    incomplete = await store.get_incomplete_anchors()
    assert len(incomplete) == 1
    assert incomplete[0]["is_complete"] is False


async def test_mark_upgrade_attempted_complete(ledger):
    store = OtsAnchorStore(ledger)
    digest_hex = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).hexdigest()
    anchor_id = await store.record_new_stamp(1, digest_hex, HELLO_WORLD_OTS.read_bytes())

    new_proof = HELLO_WORLD_OTS.read_bytes()   # same bytes, just simulating an upgrade
    await store.mark_upgrade_attempted(anchor_id, new_proof, is_complete=True)

    latest = await store.get_latest_anchor()
    assert latest["is_complete"] is True
    assert latest["completed_at"] is not None

    incomplete = await store.get_incomplete_anchors()
    assert incomplete == []   # no longer shows up as incomplete


async def test_mark_upgrade_attempted_still_pending(ledger):
    store = OtsAnchorStore(ledger)
    digest_hex = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).hexdigest()
    anchor_id = await store.record_new_stamp(1, digest_hex, HELLO_WORLD_OTS.read_bytes())

    await store.mark_upgrade_attempted(anchor_id, HELLO_WORLD_OTS.read_bytes(),
                                       is_complete=False)

    latest = await store.get_latest_anchor()
    assert latest["is_complete"] is False
    assert latest["completed_at"] is None
    assert latest["last_upgrade_attempt_at"] is not None


async def test_get_latest_anchor_is_most_recent_by_id(ledger):
    store = OtsAnchorStore(ledger)
    digest_hex = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).hexdigest()
    await store.record_new_stamp(1, "a" * 64, HELLO_WORLD_OTS.read_bytes())
    second_id = await store.record_new_stamp(2, "b" * 64, HELLO_WORLD_OTS.read_bytes())

    latest = await store.get_latest_anchor()
    assert latest["id"] == second_id
    assert latest["chain_tip_hash"] == "b" * 64


async def test_ots_anchors_table_allows_updates_unlike_ledger_entries(ledger):
    """Deliberate contrast test: ots_anchors is NOT append-only the
    way ledger_entries is — see 003_ots_anchors.sql's header comment
    for why that's the correct, honest design rather than an
    inconsistency."""
    store = OtsAnchorStore(ledger)
    digest_hex = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).hexdigest()
    anchor_id = await store.record_new_stamp(1, digest_hex, b"placeholder-bytes")

    # This UPDATE succeeding at all (not raising a permissions error)
    # confirms the table is genuinely mutable, by design.
    await store.mark_upgrade_attempted(anchor_id, b"different-bytes-now",
                                       is_complete=True)
    latest = await store.get_latest_anchor()
    assert bytes(latest["ots_proof"]) == b"different-bytes-now"


# ─── Live network — genuinely best-effort, skips honestly ──────────

async def test_submit_to_calendars_live_network():
    """The one test in this file that needs REAL internet access to
    third-party OpenTimestamps calendar servers. Skips (doesn't fail)
    if they're unreachable — confirmed to genuinely happen from some
    sandboxed/restricted-egress environments (see this module's
    docstring and ECONOMIC_LAYER_DESIGN.md's Sprint 12 notes for the
    actual documented failure this was built against). On a normal
    deployment's network, this should actually succeed and is worth
    running deliberately at least once to confirm real connectivity."""
    digest = hashlib.sha256(
        f"rentahal-sprint12-test-{uuid.uuid4().hex}".encode()).digest()
    try:
        dts, count = submit_to_calendars(digest, timeout_s=10)
    except RuntimeError as e:
        pytest.skip(f"OTS calendar servers unreachable from this network "
                   f"(expected in some sandboxed CI environments): {e}")
    assert count >= 2
    result = local_verify(dts, digest)
    assert result.digest_matches is True
    assert result.is_fully_pending is True   # freshly stamped, not yet confirmed
