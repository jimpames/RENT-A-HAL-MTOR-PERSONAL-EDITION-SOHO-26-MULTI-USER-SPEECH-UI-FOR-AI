// run_music_panel_test.js — verify the browser-side music panel logic.
//
// Architecture invariants this test LOCKS IN:
//   - 'bus_music_search_request' bus event opens the music panel
//   - The iframe src uses YouTube's official listType=search pattern
//   - The query is URL-encoded so special characters (spaces, etc.) survive
//   - No YouTube API calls — pure IFrame embed
//   - The "Powered by YouTube" attribution is visible
//   - stop_stop clears the player container

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Test 1: music panel HTML exists ──────────────────────────
assert(/<div id="music-panel"/.test(html),
       'music panel div present in HTML');

assert(/id="music-player-container"/.test(html),
       'music player container present');

assert(/id="music-search-input"/.test(html),
       'music search input present');

assert(/Powered by YouTube/.test(html),
       'attribution "Powered by YouTube" visible in panel');

// ─── Test 2: Music button alongside News and Weather ─────────
assert(/askMusic\(\)/.test(html),
       'Music button onclick calls askMusic()');

assert(/onclick="askMusic\(\)"/.test(html),
       'Music button wired up in controls row');

// ─── Test 3: bus_music_search_request handler exists ─────────
assert(/case 'bus_music_search_request'/.test(html),
       'WebSocket message handler for music search request');

assert(/openMusicPanel/.test(html),
       'openMusicPanel function exists');

// ─── Test 4: YouTube IFrame embed pattern ────────────────────
// The legally critical bit: must use the IFrame embed pattern,
// NOT a custom AJAX call to YouTube's Data API.
// Architecture: realm sends a video_id; browser embeds it via the
// standard youtube.com/embed/<VIDEO_ID> URL.
assert(/youtube\.com\/embed/.test(html),
       'uses youtube.com/embed URL (IFrame pattern)');

// The deprecated listType=search pattern was killed by YouTube 2020-11-15;
// we MUST NOT use it. Embed by video ID instead.
assert(!/listType=search/.test(html),
       'does NOT use deprecated listType=search (killed by YouTube 2020-11-15)');

assert(/encodeURIComponent\(videoId\)/.test(html),
       'video ID is URL-encoded (defense; IDs are safe chars but be safe)');

// Verify the embed URL uses /embed/<id> path form (the documented one)
assert(/embed\/['"]?\s*\+\s*encodeURIComponent\(videoId\)/.test(html),
       'iframe.src uses youtube.com/embed/<id> path pattern');

// ─── Test 5: critical compliance — no YouTube API key used ───
assert(!/googleapis\.com\/youtube/.test(html),
       'browser does NOT call YouTube Data API (googleapis.com)');

assert(!/youtube\.com\/v3\//.test(html),
       'browser does NOT call YouTube v3 API directly');

assert(!/YOUTUBE_API_KEY|youtube_api_key/.test(html),
       'no YouTube API key reference in browser code');

// ─── Test 6: stop_stop clears the music container ────────────
// The realm's STOP STOP should halt YouTube playback. The only
// cross-browser-reliable way is to remove the iframe.
const stopHandlerMatch = html.match(
  /case 'bus_intent_stop':[\s\S]{0,1500}?break;/);
assert(stopHandlerMatch !== null, 'bus_intent_stop handler exists');

if (stopHandlerMatch) {
  assert(/music-player-container/.test(stopHandlerMatch[0]),
         'stop_stop clears music-player-container');
}

// ─── Test 7: hideMusic also clears the iframe ─────────────────
// Closing the panel via the ✕ button must stop playback too.
const hideMusicMatch = html.match(/function hideMusic\(\)[\s\S]{0,400}?\n\}/);
assert(hideMusicMatch !== null, 'hideMusic function exists');

if (hideMusicMatch) {
  assert(/innerHTML\s*=\s*['"]['"]/.test(hideMusicMatch[0]),
         'hideMusic clears player container innerHTML');
}

// ─── Test 8: askMusic uses the normal pipeline ───────────────
// The Music button should route through the same intent classifier
// as voice — keeps voice and button behavior identical.
const askMusicMatch = html.match(/function askMusic\(\)[\s\S]{0,500}?\n\}/);
assert(askMusicMatch !== null, 'askMusic function exists');

if (askMusicMatch) {
  assert(/sendPrompt\(['"]music player /.test(askMusicMatch[0]),
         'askMusic sends "music player <query>" through sendPrompt',
         'goes through intent classifier just like voice');
}

// ─── Test 9: iframe attributes for autoplay + security ───────
const renderEmbedMatch = html.match(
  /function renderYouTubeEmbed[\s\S]+?\n\}/);
assert(renderEmbedMatch !== null, 'renderYouTubeEmbed function exists');

if (renderEmbedMatch) {
  assert(/allow[\s\S]*autoplay/.test(renderEmbedMatch[0]),
         'iframe allows autoplay (so first track plays on user gesture)');
  assert(/referrerpolicy/.test(renderEmbedMatch[0]),
         'iframe sets referrerpolicy (security best practice)');
  assert(/allowfullscreen/.test(renderEmbedMatch[0]),
         'iframe allows fullscreen (user choice)');
  // Defense in depth: validate the video ID format before embedding
  assert(/A-Za-z0-9_-\]\{11\}/.test(renderEmbedMatch[0]),
         'browser validates video_id format (11 chars [A-Za-z0-9_-])');
}

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} music panel tests passed`);
  process.exit(0);
}
