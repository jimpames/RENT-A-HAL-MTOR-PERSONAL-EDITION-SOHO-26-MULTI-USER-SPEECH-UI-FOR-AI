"""
Loose-end fix — the capability_avg_s staleness bug flagged (and
deliberately left unfixed) back in Sprint 6/7's docstrings.

The bug: FederationMatrix.upsert() used to MERGE incoming capability_avg_s
into the stored dict (only ever adding/updating keys, never removing
one). Combined with the client only sending the capability_avg_s key
when non-empty, and the endpoint collapsing "key absent" and "key
present but empty" into the same {} via `or {}`, a capability dropped
from a node's reporting (operator disables LLaVA without restarting)
would advertise its last-known average FOREVER — nothing ever cleared
it.

The fix has three cooperating parts, each covered here:
  1. FederationMatrix.upsert() now REPLACES capability_avg_s wholesale
     when the caller passes a dict (even {}), and only preserves
     existing data when the caller passes None outright.
  2. FederationClient._do_checkin() now sends the capability_avg_s key
     whenever the stats callable provides it at all (`is not None`),
     not just when truthy — so a real client can actually communicate
     "I currently have nothing to report" as an explicit empty dict,
     not by omitting the key.
  3. The check-in endpoint preserves the None-vs-{}-vs-populated
     distinction all the way through to upsert(), instead of collapsing
     "absent" and "empty" together.
"""
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import FederationMatrix, FederationConfig, FederationState, FederationClient

pytestmark = pytest.mark.asyncio


# ─── FederationMatrix.upsert — replace, not merge ───────────────────

async def test_capability_dropped_from_payload_gets_cleared():
    """THE bug, at the matrix level: report vision, then stop reporting
    it (explicit empty dict) — the stale average must be gone, not
    just untouched."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 1.0, 1.0, 0,
                   capability_avg_s={"vision": 2.5})
    rec = m.members["https://a.com"]
    assert rec.capability_avg_s == {"vision": 2.5}

    rec = await m.upsert("https://a.com", 1.0, 1.0, 0, capability_avg_s={})
    assert rec.capability_avg_s == {}
    assert rec.has_capability("vision") is False


async def test_capability_partial_update_drops_unreported_keys():
    """Reporting vision+imagine, then only vision — imagine must be
    dropped, not left stale. This is REPLACE semantics, not merge."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 1.0, 1.0, 0,
                   capability_avg_s={"vision": 2.5, "imagine": 6.0})
    rec = await m.upsert("https://a.com", 1.0, 1.0, 0,
                         capability_avg_s={"vision": 3.0})
    assert rec.capability_avg_s == {"vision": 3.0}
    assert "imagine" not in rec.capability_avg_s


async def test_passing_none_preserves_existing_capability_data():
    """The backward-compat path: a caller that passes None (doesn't
    know about capabilities at all) must NOT clear existing data."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 1.0, 1.0, 0,
                   capability_avg_s={"vision": 2.5})
    rec = await m.upsert("https://a.com", 1.0, 1.0, 0)   # no capability_avg_s arg at all
    assert rec.capability_avg_s == {"vision": 2.5}   # untouched


async def test_stale_capability_no_longer_wins_best_peer_for():
    """The actual real-world consequence: once cleared, a formerly-
    vision-reporting node must stop being eligible for best_peer_for
    ('vision', ...) — it no longer has_capability('vision') at all."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://stale-vision.com", 1.0, 1.0, 0,
                   capability_avg_s={"vision": 0.1})   # was fast, would win
    await m.upsert("https://real-vision.com", 1.0, 1.0, 0,
                   capability_avg_s={"vision": 5.0})
    # Operator disables LLaVA on stale-vision.com and restarts — next
    # check-in reports the empty set.
    await m.upsert("https://stale-vision.com", 1.0, 1.0, 0, capability_avg_s={})
    best = await m.best_peer_for("vision", exclude_url="https://other.com")
    assert best == "https://real-vision.com"   # not the faster-but-stale one


# ─── FederationClient — sends the key even when empty ───────────────

class _MockResp:
    def __init__(self, body, status=200):
        self._body = body
        self.status = status
    async def json(self):
        return self._body
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass


async def test_client_sends_empty_capability_dict_explicitly():
    """If the stats callable reports capability_avg_s: {} (this node
    genuinely has nothing configured, or just disabled its last
    capability), the client must send that empty dict, not omit the key."""
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0,
        "capability_avg_s": {}})
    client = FederationClient(state)

    captured = {}
    def mock_post(url, json=None):
        captured["payload"] = json
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()

    assert "capability_avg_s" in captured["payload"]
    assert captured["payload"]["capability_avg_s"] == {}


async def test_client_omits_key_when_stats_callable_doesnt_know_about_it():
    """True backward compat: a stats callable that never mentions
    capability_avg_s at all (old-style) must not send the key."""
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    client = FederationClient(state)

    captured = {}
    def mock_post(url, json=None):
        captured["payload"] = json
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None})
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()

    assert "capability_avg_s" not in captured["payload"]


# ─── Full wire round trip over real HTTP ─────────────────────────────

async def _boot_federator(tmp_path):
    import os
    os.environ["RENTAHAL_FAKE_ENGINES"] = "1"
    import app as app_module
    cfg = app_module.load_ini()
    fed_ini = tmp_path / "federator.ini"
    fed_ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n")
    cfg.read(fed_ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


async def test_staleness_fix_over_real_http(tmp_path):
    import asyncio, uvicorn, aiohttp
    app = await _boot_federator(tmp_path)
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=9947, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    try:
        async with aiohttp.ClientSession() as s:
            # Node reports vision capability.
            await s.post("http://127.0.0.1:9947/api/federate/checkin", json={
                "member_url": "https://was-vision.example", "llm_avg_s": 1.0,
                "tts_avg_s": 1.0, "tokens_out": 0,
                "capability_avg_s": {"vision": 0.1}})
            async with s.get("http://127.0.0.1:9947/api/federate/matrix") as r:
                matrix = await r.json()
                assert matrix["members"]["https://was-vision.example"]["capability_avg_s"] == {"vision": 0.1}

            # Same node checks in again, now reporting NO capabilities
            # (operator disabled LLaVA, restarted).
            await s.post("http://127.0.0.1:9947/api/federate/checkin", json={
                "member_url": "https://was-vision.example", "llm_avg_s": 1.0,
                "tts_avg_s": 1.0, "tokens_out": 0,
                "capability_avg_s": {}})
            async with s.get("http://127.0.0.1:9947/api/federate/matrix") as r:
                matrix = await r.json()
                # capability_avg_s must be gone entirely (to_dict omits
                # when empty), not lingering with the stale value.
                assert "capability_avg_s" not in matrix["members"]["https://was-vision.example"]
    finally:
        server.should_exit = True
        await task
