"""
test_wizard.py — Boot wizard tests.

Covers:
  - _read_config_ini reads relevant fields with defaults
  - _read_federation_ini reads federation fields with shipping defaults
  - _write_federation_ini preserves existing settings + comments
  - _write_federation_ini creates a minimal file when none exists
  - _write_config_ini uses comment-preserving save_value
  - probe_gpt4all detects up/down/timeout/no-models
  - is_go_allowed gate logic — every false case
  - launch_realm + halt_realm subprocess lifecycle (mocked Popen)
  - FastAPI endpoints return correct shapes
"""
import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import wizard


# ─── _read_config_ini ─────────────────────────────────────────────


def test_read_config_returns_expected_keys(tmp_path, monkeypatch):
    """Sanity: read returns the dict shape the UI depends on."""
    ini = tmp_path / "config.ini"
    ini.write_text("""[GPT4All]
host = localhost
port = 4891
model = Llama 3 8B Instruct

[KokoroService]
host = localhost
port = 9998

[Server]
host = 0.0.0.0
port = 9999

[Branding]
realm_name = Test Realm
""")
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)
    cfg = wizard._read_config_ini()
    assert cfg["gpt4all_host"] == "localhost"
    assert cfg["gpt4all_port"] == 4891
    assert cfg["gpt4all_model"] == "Llama 3 8B Instruct"
    assert cfg["server_port"] == 9999
    assert cfg["realm_name"] == "Test Realm"


def test_read_config_uses_defaults_for_missing_sections(tmp_path, monkeypatch):
    """A minimal ini still works — missing sections get fallback values."""
    ini = tmp_path / "config.ini"
    ini.write_text("[Server]\nport = 9999\n")
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)
    cfg = wizard._read_config_ini()
    assert cfg["gpt4all_port"] == 4891  # default
    assert cfg["realm_name"] == wizard.DEFAULT_REALM_NAME


# ─── _read_federation_ini ─────────────────────────────────────────


def test_read_federation_returns_shipping_defaults_when_file_missing(
        tmp_path, monkeypatch):
    """Critical: fresh install with no federation.ini should still
    advertise rentahal.com as the Federator and desire=on. Operators
    who don't configure anything still join the public federation."""
    monkeypatch.setattr(wizard, "FEDERATION_INI", tmp_path / "nope.ini")
    fed = wizard._read_federation_ini()
    assert fed["desire"] == "on"
    assert fed["master_url"] == wizard.DEFAULT_FEDERATOR
    assert fed["self_url"] == ""


def test_read_federation_reads_existing_values(tmp_path, monkeypatch):
    ini = tmp_path / "federation.ini"
    ini.write_text("""[Federation]
desire = off
master_url = https://my.federator.example/api/federate
self_url = https://my.realm.ngrok.app
""")
    monkeypatch.setattr(wizard, "FEDERATION_INI", ini)
    fed = wizard._read_federation_ini()
    assert fed["desire"] == "off"
    assert fed["master_url"] == "https://my.federator.example/api/federate"
    assert fed["self_url"] == "https://my.realm.ngrok.app"


# ─── _write_federation_ini ────────────────────────────────────────


def test_write_federation_preserves_other_settings_and_comments(
        tmp_path, monkeypatch):
    """The whole reason we wrote a custom in-place editor: configparser
    strips comments. Verify our edit preserves them."""
    ini = tmp_path / "federation.ini"
    ini.write_text("""# RENT-A-HAL Federation configuration
# ===================================

[Federation]
# Operator opt-in toggle
desire = off
master_url = https://old.example/api/federate
self_url = https://old-realm.example

# Optional shared token (no comment edit)
token =

[Federator]
enabled = false
state_file = federation_state.json
""")
    monkeypatch.setattr(wizard, "FEDERATION_INI", ini)
    wizard._write_federation_ini(
        desire=True,
        master_url="https://new.example/api/federate",
        self_url="https://new-realm.example",
    )
    content = ini.read_text()
    # Edits landed
    assert "desire = on" in content
    assert "master_url = https://new.example/api/federate" in content
    assert "self_url = https://new-realm.example" in content
    # Comments preserved
    assert "# RENT-A-HAL Federation configuration" in content
    assert "# Operator opt-in toggle" in content
    # Other sections untouched
    assert "[Federator]" in content
    assert "enabled = false" in content
    assert "token =" in content


def test_write_federation_creates_minimal_file_when_missing(
        tmp_path, monkeypatch):
    """Fresh install path — no federation.ini exists. Write a minimal
    one with the three operator-managed fields plus [Federator] off."""
    ini = tmp_path / "federation.ini"
    monkeypatch.setattr(wizard, "FEDERATION_INI", ini)
    wizard._write_federation_ini(
        desire=True,
        master_url="https://rentahal.com/api/federate",
        self_url="https://my.ngrok.app",
    )
    assert ini.exists()
    content = ini.read_text()
    assert "[Federation]" in content
    assert "desire = on" in content
    assert "self_url = https://my.ngrok.app" in content
    assert "[Federator]" in content
    assert "enabled = false" in content


def test_write_federation_handles_desire_off(tmp_path, monkeypatch):
    ini = tmp_path / "federation.ini"
    ini.write_text("[Federation]\ndesire = on\nmaster_url = old\nself_url = old\n")
    monkeypatch.setattr(wizard, "FEDERATION_INI", ini)
    wizard._write_federation_ini(False, "new", "new")
    assert "desire = off" in ini.read_text()


# ─── probe_gpt4all ────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_probe_returns_models_on_success():
    """Successful probe returns the list of loaded model names."""
    class _MockResp:
        status = 200
        async def json(self):
            # OpenAI-compatible shape that GPT4All returns
            return {"data": [
                {"id": "Llama 3 8B Instruct", "object": "model"},
                {"id": "Mistral 7B", "object": "model"},
            ]}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_gpt4all("localhost", 4891)
    assert result["up"] is True
    assert "Llama 3 8B Instruct" in result["models"]
    assert "Mistral 7B" in result["models"]
    assert result["error"] is None


@pytest.mark.asyncio
async def test_probe_handles_empty_model_list():
    """GPT4All is up but no model is loaded — `up=True, models=[]`.
    The gate will block GO on this because of the no-models check."""
    class _MockResp:
        status = 200
        async def json(self): return {"data": []}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_gpt4all("localhost", 4891)
    assert result["up"] is True
    assert result["models"] == []


@pytest.mark.asyncio
async def test_probe_handles_http_error():
    class _MockResp:
        status = 500
        async def json(self): return {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_gpt4all("localhost", 4891)
    assert result["up"] is False
    assert "500" in result["error"]


@pytest.mark.asyncio
async def test_probe_handles_timeout():
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=asyncio.TimeoutError()):
        result = await wizard.probe_gpt4all("localhost", 4891)
    assert result["up"] is False
    assert "imed out" in result["error"]


@pytest.mark.asyncio
async def test_probe_handles_connection_refused():
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=aiohttp.ClientConnectorError(
                          MagicMock(), OSError(111, "refused"))):
        result = await wizard.probe_gpt4all("localhost", 4891)
    assert result["up"] is False
    assert "not running" in result["error"].lower()


# ─── is_go_allowed gate logic ─────────────────────────────────────


def _probe(up=True, models=None):
    # Use `is None` rather than `or` so an explicit empty list passes through
    if models is None:
        models = ["Llama 3 8B Instruct"]
    return {"up": up, "models": models, "error": None}


def _cuda_ok():
    """Healthy CUDA probe helper for tests that aren't testing the
    CUDA gate itself. Returns the shape the gate logic expects."""
    return {"ok": True, "device_name": "NVIDIA GeForce RTX 4060",
            "error": None}


def _completion_ok():
    """Healthy completion probe helper. Returns the shape the gate
    logic expects when the model actually answered."""
    return {"answers": True, "elapsed_s": 2.5, "preview": "OK",
            "error": None}


def test_gate_allows_when_everything_is_set():
    """The happy path: GPT4All up, model loaded, ngrok URL set,
    federation desire on, CUDA detected, model answered test prompt.
    GO is allowed."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe=_completion_ok(),
        cuda_probe=_cuda_ok(),
    )
    assert allowed is True
    assert reason == ""


def test_gate_blocks_when_gpt4all_down():
    """The primary fool-prevention gate. Operator can't launch a realm
    that would immediately fall through to Echo."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(up=False),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe=None,        # not run when GPT4All is down
        cuda_probe=_cuda_ok(),
    )
    assert allowed is False
    assert "GPT4All" in reason


def test_gate_blocks_when_no_model_loaded():
    """GPT4All is responding but no model is loaded. Same fix path."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(models=[]),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe=None,
        cuda_probe=_cuda_ok(),
    )
    assert allowed is False
    assert "model" in reason.lower()


def test_gate_blocks_when_no_model_selected():
    """User cleared the dropdown somehow."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="",
        completion_probe=None,
        cuda_probe=_cuda_ok(),
    )
    assert allowed is False


def test_gate_blocks_federation_on_with_no_self_url():
    """Federation enabled but operator hasn't filled in their ngrok URL."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="   ",   # whitespace = empty
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe=_completion_ok(),
        cuda_probe=_cuda_ok(),
    )
    assert allowed is False
    assert "ngrok" in reason.lower() or "self_url" in reason.lower() \
           or "url" in reason.lower()


def test_gate_allows_federation_off_with_no_self_url():
    """Standalone mode: operator opted out of federation. No need for
    ngrok URL. Should still be able to GO."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="",
        desire=False,
        selected_model="Llama 3 8B Instruct",
        completion_probe=_completion_ok(),
        cuda_probe=_cuda_ok(),
    )
    assert allowed is True


def test_gate_gpt4all_check_takes_priority():
    """When GPT4All is down AND federation is misconfigured, surface
    the GPT4All error first — it's the more critical fix.
    (CUDA is even higher priority — but assume healthy CUDA here.)"""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(up=False),
        self_url="",
        desire=True,
        selected_model="",
        completion_probe=None,
        cuda_probe=_cuda_ok(),
    )
    assert allowed is False
    assert "GPT4All" in reason


# ─── launch_realm / halt_realm ────────────────────────────────────


def test_launch_returns_pid_on_success(monkeypatch):
    """Launch spawns the realm subprocess and tracks it."""
    mock_proc = MagicMock()
    mock_proc.pid = 12345
    mock_proc.poll.return_value = None  # still running
    monkeypatch.setattr("subprocess.Popen", lambda *a, **kw: mock_proc)
    monkeypatch.setattr(wizard, "_realm_proc", None)
    pid = wizard.launch_realm()
    assert pid == 12345
    assert wizard._realm_proc is mock_proc


def test_launch_returns_existing_pid_if_already_running(monkeypatch):
    """Double-click safety: clicking GO twice doesn't spawn two realms."""
    existing = MagicMock()
    existing.pid = 999
    existing.poll.return_value = None
    monkeypatch.setattr(wizard, "_realm_proc", existing)
    # If Popen is called, the test fails — we should NOT spawn again
    monkeypatch.setattr("subprocess.Popen",
                        lambda *a, **kw: pytest.fail("should not respawn"))
    pid = wizard.launch_realm()
    assert pid == 999


def test_launch_returns_none_on_spawn_failure(monkeypatch):
    def _raise(*a, **kw):
        raise OSError("can't spawn")
    monkeypatch.setattr("subprocess.Popen", _raise)
    monkeypatch.setattr(wizard, "_realm_proc", None)
    pid = wizard.launch_realm()
    assert pid is None
    assert wizard._realm_proc is None


def test_halt_returns_false_when_no_realm_running(monkeypatch):
    monkeypatch.setattr(wizard, "_realm_proc", None)
    assert wizard.halt_realm() is False


def test_halt_sends_sigterm_and_waits(monkeypatch):
    """The graceful shutdown path: terminate, wait, done."""
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_proc.wait.return_value = 0
    monkeypatch.setattr(wizard, "_realm_proc", mock_proc)
    assert wizard.halt_realm() is True
    mock_proc.terminate.assert_called_once()
    mock_proc.wait.assert_called()
    # After halt, _realm_proc reset to None
    assert wizard._realm_proc is None


def test_halt_falls_back_to_sigkill_on_timeout(monkeypatch):
    """If SIGTERM doesn't kill it within REALM_HALT_GRACE_S, kill it."""
    import subprocess as _sp
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    # First wait() raises Timeout (SIGTERM ignored), second succeeds (SIGKILL)
    mock_proc.wait.side_effect = [
        _sp.TimeoutExpired("python", 8),
        0,
    ]
    monkeypatch.setattr(wizard, "_realm_proc", mock_proc)
    assert wizard.halt_realm() is True
    mock_proc.terminate.assert_called_once()
    mock_proc.kill.assert_called_once()


def test_realm_status_running(monkeypatch):
    mock_proc = MagicMock()
    mock_proc.pid = 555
    mock_proc.poll.return_value = None
    monkeypatch.setattr(wizard, "_realm_proc", mock_proc)
    s = wizard.realm_status()
    assert s["running"] is True
    assert s["pid"] == 555


def test_realm_status_exited_clears_state(monkeypatch):
    """If the realm exited unexpectedly, status reports running=False
    and resets the global so a new launch can succeed."""
    mock_proc = MagicMock()
    mock_proc.poll.return_value = 1  # exited
    monkeypatch.setattr(wizard, "_realm_proc", mock_proc)
    s = wizard.realm_status()
    assert s["running"] is False
    assert s["pid"] is None
    assert wizard._realm_proc is None


def test_realm_status_no_realm(monkeypatch):
    monkeypatch.setattr(wizard, "_realm_proc", None)
    s = wizard.realm_status()
    assert s["running"] is False
    assert s["pid"] is None


# ─── FastAPI endpoints — structural sanity ────────────────────────


def test_build_app_registers_expected_routes():
    """The wizard exposes 4 routes. If someone removes or renames one,
    this test fails — UI breaks silently otherwise."""
    app = wizard.build_app()
    paths = {r.path for r in app.routes if hasattr(r, "path")}
    assert "/" in paths
    assert "/api/wizard/state" in paths
    assert "/api/wizard/save" in paths
    assert "/api/wizard/launch" in paths
    assert "/api/wizard/halt" in paths


def test_wizard_html_template_exists():
    """The / route reads templates/wizard.html. If the file is missing,
    the route returns an error — catch that here."""
    html_path = (Path(wizard.__file__).parent / "templates" / "wizard.html")
    assert html_path.exists(), "Wizard HTML template missing"
    content = html_path.read_text()
    # Sanity: minimal expected elements exist
    assert "btn-go" in content
    assert "btn-halt" in content.lower() or "halt" in content.lower()
    assert "federation-desire" in content
    assert "self-url" in content
    assert "master-url" in content
    assert "gpt4all-model" in content


# ─── New gate: CUDA hard gate ──────────────────────────────────────


def test_gate_blocks_when_no_cuda_and_required():
    """Most fundamental gate — operator can't launch without a GPU
    (unless they consciously opted into cloud-only mode)."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe=_completion_ok(),
        cuda_probe={"ok": False, "device_name": "",
                    "error": "nvidia-smi not found"},
        require_cuda=True,
    )
    assert allowed is False
    assert "CUDA" in reason


def test_gate_allows_no_cuda_when_require_cuda_false():
    """The override path: operator with cloud-only setup (Claude/HF
    API keys) explicitly sets [Hardware] require_cuda = false. Gate
    skips CUDA check."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe=_completion_ok(),
        cuda_probe={"ok": False, "device_name": "",
                    "error": "no gpu"},
        require_cuda=False,
    )
    assert allowed is True


def test_gate_blocks_when_cuda_probe_missing():
    """Defensive: caller forgot to pass cuda_probe but require_cuda=True.
    Don't silently allow — treat as failure."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe=_completion_ok(),
        cuda_probe=None,
        require_cuda=True,
    )
    assert allowed is False


def test_gate_cuda_takes_priority_over_gpt4all():
    """CUDA is the most fundamental — without GPU, nothing else matters.
    Even if GPT4All happens to be running, the gate surfaces the CUDA
    problem first (most actionable: install drivers)."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(up=False),    # also down
        self_url="",
        desire=True,
        selected_model="",
        completion_probe=None,
        cuda_probe={"ok": False, "device_name": "", "error": "no gpu"},
        require_cuda=True,
    )
    assert allowed is False
    assert "CUDA" in reason


# ─── New gate: completion probe (the BLOKE doesn't answer case) ─────


def test_gate_blocks_when_completion_probe_fails():
    """The specific bug Jim hit: TheBloke model loads, API responds to
    /v1/models, but the model itself doesn't answer. Without this gate
    the operator launches a useless realm."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="TheBloke/something",
        completion_probe={"answers": False, "elapsed_s": 15.0,
                          "preview": "", "error": "Model did not respond"},
        cuda_probe=_cuda_ok(),
    )
    assert allowed is False
    assert "test prompt" in reason.lower()


def test_gate_allows_when_completion_probe_succeeds():
    """Happy path: model answered. Gate proceeds."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe={"answers": True, "elapsed_s": 2.5,
                          "preview": "OK", "error": None},
        cuda_probe=_cuda_ok(),
    )
    assert allowed is True


def test_gate_allows_when_completion_probe_not_yet_run():
    """During initial wizard render, the completion probe takes ~10s
    so it's deferred. Gate allows pending probe (will re-check on
    launch endpoint)."""
    allowed, reason = wizard.is_go_allowed(
        gpt4all_probe=_probe(),
        self_url="https://me.ngrok.app",
        desire=True,
        selected_model="Llama 3 8B Instruct",
        completion_probe=None,                # not yet run
        cuda_probe=_cuda_ok(),
    )
    assert allowed is True


# ─── probe_gpt4all_completion ──────────────────────────────────────


@pytest.mark.asyncio
async def test_completion_probe_detects_answering_model():
    """Happy path: model returns non-empty content."""
    class _MockResp:
        status = 200
        async def json(self):
            return {"choices": [
                {"message": {"role": "assistant", "content": "OK"}}
            ]}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_gpt4all_completion(
            "localhost", 4891, "Llama 3 8B Instruct")
    assert result["answers"] is True
    assert result["preview"] == "OK"
    assert result["elapsed_s"] >= 0


@pytest.mark.asyncio
async def test_completion_probe_detects_empty_answer():
    """The Bloke case: model "responds" but returns nothing useful."""
    class _MockResp:
        status = 200
        async def json(self):
            return {"choices": [{"message": {"content": ""}}]}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_gpt4all_completion(
            "localhost", 4891, "TheBloke/something")
    assert result["answers"] is False
    assert "empty" in result["error"].lower()


@pytest.mark.asyncio
async def test_completion_probe_detects_no_choices():
    """Malformed response — no choices array at all."""
    class _MockResp:
        status = 200
        async def json(self): return {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_gpt4all_completion(
            "localhost", 4891, "broken-model")
    assert result["answers"] is False


@pytest.mark.asyncio
async def test_completion_probe_detects_timeout():
    """Model loaded but completely stuck."""
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=asyncio.TimeoutError()):
        result = await wizard.probe_gpt4all_completion(
            "localhost", 4891, "stuck-model")
    assert result["answers"] is False
    assert "did not respond" in result["error"].lower() \
           or "broken" in result["error"].lower()


@pytest.mark.asyncio
async def test_completion_probe_detects_http_error():
    class _MockResp:
        status = 500
        async def json(self): return {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_gpt4all_completion(
            "localhost", 4891, "model")
    assert result["answers"] is False
    assert "500" in result["error"]


@pytest.mark.asyncio
async def test_completion_probe_sends_correct_payload():
    """The test prompt is deterministic and minimal so it works on
    every model and finishes fast."""
    captured = {}
    class _MockResp:
        status = 200
        async def json(self):
            return {"choices": [{"message": {"content": "OK"}}]}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    def mock_post(url, json=None, timeout=None):
        captured["url"] = url
        captured["body"] = json
        return _MockResp()
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await wizard.probe_gpt4all_completion(
            "myhost", 4891, "test-model")
    assert captured["url"] == "http://myhost:4891/v1/chat/completions"
    assert captured["body"]["model"] == "test-model"
    assert captured["body"]["max_tokens"] == 10
    assert captured["body"]["temperature"] == 0.0


# ─── probe_cuda ─────────────────────────────────────────────────────


def test_cuda_probe_detects_gpu(monkeypatch):
    """Happy path: nvidia-smi -L returns a GPU listing."""
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = ("GPU 0: NVIDIA GeForce RTX 4060 "
                          "(UUID: GPU-12345)\n")
    mock_result.stderr = ""
    monkeypatch.setattr("subprocess.run", lambda *a, **kw: mock_result)
    result = wizard.probe_cuda()
    assert result["ok"] is True
    assert "RTX 4060" in result["device_name"]


def test_cuda_probe_handles_no_gpu(monkeypatch):
    """nvidia-smi exists but no devices."""
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = ""
    mock_result.stderr = ""
    monkeypatch.setattr("subprocess.run", lambda *a, **kw: mock_result)
    result = wizard.probe_cuda()
    assert result["ok"] is False
    assert "no GPU" in result["error"] or "no gpu" in result["error"].lower()


def test_cuda_probe_handles_missing_nvidia_smi(monkeypatch):
    """nvidia-smi not on PATH — driver not installed."""
    def _raise(*a, **kw):
        raise FileNotFoundError("nvidia-smi")
    monkeypatch.setattr("subprocess.run", _raise)
    result = wizard.probe_cuda()
    assert result["ok"] is False
    assert "nvidia-smi" in result["error"]


def test_cuda_probe_handles_timeout(monkeypatch):
    """Driver hung."""
    import subprocess as _sp
    def _raise(*a, **kw):
        raise _sp.TimeoutExpired("nvidia-smi", 5)
    monkeypatch.setattr("subprocess.run", _raise)
    result = wizard.probe_cuda()
    assert result["ok"] is False
    assert "timed out" in result["error"].lower()


def test_cuda_probe_extracts_device_name_cleanly(monkeypatch):
    """The parser strips 'GPU 0:' prefix and the UUID suffix."""
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = "GPU 0: NVIDIA RTX 2070 Super (UUID: GPU-abc)\n"
    mock_result.stderr = ""
    monkeypatch.setattr("subprocess.run", lambda *a, **kw: mock_result)
    result = wizard.probe_cuda()
    # No "GPU 0:" prefix, no "(UUID:..." suffix
    assert "GPU 0" not in result["device_name"]
    assert "UUID" not in result["device_name"]
    assert "RTX 2070 Super" in result["device_name"]


# ─── ngrok subprocess lifecycle ─────────────────────────────────────


def test_launch_ngrok_skipped_when_url_empty(monkeypatch):
    """No reserved URL configured → don't try to spawn ngrok."""
    monkeypatch.setattr(wizard, "_ngrok_proc", None)
    result = wizard.launch_ngrok("", 9999)
    assert result["started"] is False
    assert "no reserved URL" in result["error"]


def test_launch_ngrok_builds_correct_command(monkeypatch):
    """The command shape Jim showed:
       ngrok http --url=rentahal.com 9999"""
    captured = {}
    mock_proc = MagicMock()
    mock_proc.pid = 5555
    mock_proc.poll.return_value = None
    mock_proc.stdout = iter([])     # empty stream

    def fake_popen(cmd, **kw):
        captured["cmd"] = cmd
        return mock_proc
    monkeypatch.setattr("subprocess.Popen", fake_popen)
    monkeypatch.setattr(wizard, "_ngrok_proc", None)

    result = wizard.launch_ngrok("rentahal.com", 9999)
    assert result["started"] is True
    assert result["pid"] == 5555
    assert captured["cmd"] == ["ngrok", "http", "--url=rentahal.com", "9999"]


def test_launch_ngrok_strips_protocol_from_url(monkeypatch):
    """Operator might paste https://yourrealm.ngrok.app — strip to just
    yourrealm.ngrok.app for the --url= flag."""
    captured = {}
    mock_proc = MagicMock()
    mock_proc.pid = 1
    mock_proc.poll.return_value = None
    mock_proc.stdout = iter([])
    monkeypatch.setattr("subprocess.Popen",
                        lambda cmd, **kw: (captured.update({"cmd": cmd}),
                                            mock_proc)[1])
    monkeypatch.setattr(wizard, "_ngrok_proc", None)
    wizard.launch_ngrok("https://yourrealm.ngrok.app/", 9999)
    assert "--url=yourrealm.ngrok.app" in captured["cmd"]


def test_launch_ngrok_handles_missing_binary(monkeypatch):
    """ngrok not installed — graceful failure (doesn't crash)."""
    def _raise(*a, **kw):
        raise FileNotFoundError("ngrok")
    monkeypatch.setattr("subprocess.Popen", _raise)
    monkeypatch.setattr(wizard, "_ngrok_proc", None)
    result = wizard.launch_ngrok("rentahal.com", 9999)
    assert result["started"] is False
    assert "not found" in result["error"].lower()


def test_launch_ngrok_doesnt_restart_if_running(monkeypatch):
    """Already-running ngrok is left alone."""
    existing = MagicMock()
    existing.pid = 999
    existing.poll.return_value = None      # still running
    monkeypatch.setattr(wizard, "_ngrok_proc", existing)
    # Popen should NOT be called
    monkeypatch.setattr("subprocess.Popen",
                        lambda *a, **kw: pytest.fail("should not respawn"))
    result = wizard.launch_ngrok("rentahal.com", 9999)
    assert result["started"] is True
    assert result["pid"] == 999


def test_halt_ngrok_sends_terminate(monkeypatch):
    """SIGTERM → wait → done."""
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_proc.wait.return_value = 0
    monkeypatch.setattr(wizard, "_ngrok_proc", mock_proc)
    assert wizard.halt_ngrok() is True
    mock_proc.terminate.assert_called_once()


def test_halt_ngrok_returns_false_when_not_running(monkeypatch):
    monkeypatch.setattr(wizard, "_ngrok_proc", None)
    assert wizard.halt_ngrok() is False


def test_ngrok_status_reports_running(monkeypatch):
    mock_proc = MagicMock()
    mock_proc.pid = 7
    mock_proc.poll.return_value = None
    monkeypatch.setattr(wizard, "_ngrok_proc", mock_proc)
    monkeypatch.setattr(wizard, "_ngrok_last_lines", ["session established"])
    s = wizard.ngrok_status()
    assert s["running"] is True
    assert s["pid"] == 7
    assert s["last_lines"] == ["session established"]


def test_ngrok_status_no_process(monkeypatch):
    monkeypatch.setattr(wizard, "_ngrok_proc", None)
    monkeypatch.setattr(wizard, "_ngrok_last_lines", [])
    s = wizard.ngrok_status()
    assert s["running"] is False
    assert s["pid"] is None


# ─── Federation tuning persistence ──────────────────────────────────


def test_write_federation_updates_tuning_knobs(tmp_path, monkeypatch):
    """The new tuning knobs (overflow thresholds, request timeout) must
    persist through the comment-preserving write."""
    ini = tmp_path / "federation.ini"
    ini.write_text("""[Federation]
desire = on
master_url = https://rentahal.com/api/federate
self_url =
# Operator notes here should survive
prefer_federation_for_llm_avg_s = 31.0
prefer_federation_for_tts_avg_s = 31.0
request_timeout_s = 59.0
""")
    monkeypatch.setattr(wizard, "FEDERATION_INI", ini)
    wizard._write_federation_ini(
        desire=True, master_url="https://rentahal.com/api/federate",
        self_url="https://me.ngrok.app",
        prefer_llm=15.0, prefer_tts=20.0, request_timeout_s=90.0)
    content = ini.read_text()
    assert "prefer_federation_for_llm_avg_s = 15.0" in content
    assert "prefer_federation_for_tts_avg_s = 20.0" in content
    assert "request_timeout_s = 90.0" in content
    # Comments preserved
    assert "# Operator notes here should survive" in content


def test_write_federation_skips_tuning_when_none(tmp_path, monkeypatch):
    """When tuning kwargs are None, existing values are left alone."""
    ini = tmp_path / "federation.ini"
    ini.write_text("[Federation]\ndesire = on\nmaster_url = X\n"
                   "self_url = Y\nprefer_federation_for_llm_avg_s = 99.0\n")
    monkeypatch.setattr(wizard, "FEDERATION_INI", ini)
    wizard._write_federation_ini(
        desire=False, master_url="X", self_url="Y")    # no tuning kwargs
    # Existing value untouched
    assert "prefer_federation_for_llm_avg_s = 99.0" in ini.read_text()


def test_read_federation_returns_tuning_defaults(tmp_path, monkeypatch):
    """Missing tuning fields fall back to shipping defaults."""
    monkeypatch.setattr(wizard, "FEDERATION_INI", tmp_path / "nope.ini")
    fed = wizard._read_federation_ini()
    assert fed["prefer_federation_for_llm_avg_s"] == 31.0
    assert fed["prefer_federation_for_tts_avg_s"] == 31.0
    assert fed["request_timeout_s"] == 59.0


# ─── _read_config_ini extended fields ──────────────────────────────


def test_read_config_returns_new_fields(tmp_path, monkeypatch):
    """All the new fields the wizard manages get read with sensible
    defaults when missing."""
    ini = tmp_path / "config.ini"
    ini.write_text("""[Server]
port = 9999
[Branding]
realm_name = Test
tagline = MY-CUSTOM-TAG
[VoiceLoop]
wake_word_duration = medium
privacy_beacon = false
[Weather]
api_key = abc123
[ngrok]
authtoken = ng-token
url = my.ngrok.app
[Hardware]
require_cuda = false
""")
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)
    cfg = wizard._read_config_ini()
    assert cfg["tagline"] == "MY-CUSTOM-TAG"
    assert cfg["wake_word_duration"] == "medium"
    assert cfg["privacy_beacon"] is False
    assert cfg["weather_api_key"] == "abc123"
    assert cfg["ngrok_authtoken"] == "ng-token"
    assert cfg["ngrok_url"] == "my.ngrok.app"
    assert cfg["require_cuda"] is False


def test_read_config_returns_sensible_defaults_for_new_fields(
        tmp_path, monkeypatch):
    """Empty config.ini — every new field has a default."""
    ini = tmp_path / "config.ini"
    ini.write_text("[Server]\nport = 9999\n")
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)
    cfg = wizard._read_config_ini()
    assert cfg["tagline"] == "BETA-5 System Terminal"
    assert cfg["wake_word_duration"] == "short"
    assert cfg["privacy_beacon"] is True
    assert cfg["require_cuda"] is True
    assert cfg["weather_api_key"] == ""
    assert cfg["ngrok_authtoken"] == ""
