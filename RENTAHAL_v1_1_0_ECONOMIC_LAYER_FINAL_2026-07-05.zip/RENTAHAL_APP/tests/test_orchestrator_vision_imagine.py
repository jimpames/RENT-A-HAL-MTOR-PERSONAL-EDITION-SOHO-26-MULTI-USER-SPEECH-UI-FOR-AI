"""
End-to-end orchestrator dispatch tests for the vision/imagine kinds —
prompt_text -> IntentClassifier -> intent_classified -> Orchestrator._route
-> vision_handler/imagine_handler -> query_result.

Same fixture shape as test_metrics_pipeline.py: real EventBus, real
IntentClassifier, real Orchestrator, fake handlers standing in for
make_vision_handler/make_imagine_handler (those are unit-tested
separately in test_vision_handler.py / test_imagine_handler.py — this
file is about the WIRING between intent classification and dispatch,
in particular that image_b64 survives the trip from prompt_text all
the way to the handler call).
"""
import asyncio
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.event_bus import EventBus
from realm.intent import IntentClassifier
from realm.engine_chain import LLMChain, TTSChain, EchoLLMProvider, EchoTTSProvider
from realm.orchestrator import Orchestrator

pytestmark = pytest.mark.asyncio


async def _await_event(log, name, timeout=5):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for t, p in log:
            if t == name:
                return p
        await asyncio.sleep(0.01)
    raise TimeoutError(f"no {name}; saw {[t for t, _ in log]}")


async def _make_realm(vision_handler=None, imagine_handler=None):
    bus = EventBus()
    llm = LLMChain([EchoLLMProvider()])
    tts = TTSChain([EchoTTSProvider()])
    orch = Orchestrator(bus, llm, tts,
                        vision_handler=vision_handler,
                        imagine_handler=imagine_handler)
    clf = IntentClassifier(bus)
    await clf.attach()
    await orch.attach()
    log = []
    await bus.subscribe_all(
        lambda ev: log.append((ev.type, dict(ev.payload))) or asyncio.sleep(0))
    return bus, orch, log


# ─── Vision dispatch ────────────────────────────────────────────────

async def test_vision_intent_calls_vision_handler_with_image():
    calls = []
    async def fake_vision_handler(image_b64, slots, guid, bus):
        calls.append({"image_b64": image_b64, "slots": slots, "guid": guid})
        return "A red ball on a table."

    bus, orch, log = await _make_realm(vision_handler=fake_vision_handler)
    try:
        await bus.publish("prompt_text", text="take a look",
                          nonce="n1", user_guid="u1",
                          image_b64="ZmFrZWZyYW1l")
        payload = await _await_event(log, "query_result")
        assert payload["kind"] == "vision"
        assert payload["text"] == "A red ball on a table."
        assert len(calls) == 1
        assert calls[0]["image_b64"] == "ZmFrZWZyYW1l"
        assert calls[0]["guid"] == "u1"
    finally:
        await orch.detach()


async def test_vision_intent_with_no_image_still_calls_handler_with_none():
    """A vision phrase with no image attached (browser didn't send one
    — e.g. the client hasn't shipped webcam capture yet, or capture
    failed) must still dispatch to the handler, just with image_b64=None.
    The handler itself is responsible for the friendly apology."""
    calls = []
    async def fake_vision_handler(image_b64, slots, guid, bus):
        calls.append(image_b64)
        return "I didn't get a picture to look at."

    bus, orch, log = await _make_realm(vision_handler=fake_vision_handler)
    try:
        await bus.publish("prompt_text", text="what do you see",
                          nonce="n1", user_guid="u1")
        payload = await _await_event(log, "query_result")
        assert payload["kind"] == "vision"
        assert calls == [None]
    finally:
        await orch.detach()


async def test_vision_intent_unconfigured_returns_friendly_text():
    bus, orch, log = await _make_realm(vision_handler=None)
    try:
        await bus.publish("prompt_text", text="take a look",
                          nonce="n1", user_guid="u1")
        payload = await _await_event(log, "query_result")
        assert payload["kind"] == "vision"
        assert "not configured" in payload["text"].lower()
    finally:
        await orch.detach()


# ─── Imagine dispatch ───────────────────────────────────────────────

async def test_imagine_intent_calls_imagine_handler_with_slots():
    calls = []
    async def fake_imagine_handler(slots, guid, bus):
        calls.append({"slots": slots, "guid": guid})
        return "Here's what I imagined for a kitten."

    bus, orch, log = await _make_realm(imagine_handler=fake_imagine_handler)
    try:
        await bus.publish("prompt_text", text="imagine a kitten wearing a hat",
                          nonce="n1", user_guid="u1")
        payload = await _await_event(log, "query_result")
        assert payload["kind"] == "imagine"
        assert payload["text"] == "Here's what I imagined for a kitten."
        assert len(calls) == 1
        assert calls[0]["slots"] == {"prompt": "a kitten wearing a hat"}
        assert calls[0]["guid"] == "u1"
    finally:
        await orch.detach()


async def test_imagine_intent_via_draw_trigger():
    calls = []
    async def fake_imagine_handler(slots, guid, bus):
        calls.append(slots)
        return "Here's what I imagined."

    bus, orch, log = await _make_realm(imagine_handler=fake_imagine_handler)
    try:
        await bus.publish("prompt_text", text="draw a dragon breathing fire",
                          nonce="n1", user_guid="u1")
        payload = await _await_event(log, "query_result")
        assert payload["kind"] == "imagine"
        assert calls == [{"prompt": "a dragon breathing fire"}]
    finally:
        await orch.detach()


async def test_imagine_intent_unconfigured_returns_friendly_text():
    bus, orch, log = await _make_realm(imagine_handler=None)
    try:
        await bus.publish("prompt_text", text="imagine a castle",
                          nonce="n1", user_guid="u1")
        payload = await _await_event(log, "query_result")
        assert payload["kind"] == "imagine"
        assert "not configured" in payload["text"].lower()
    finally:
        await orch.detach()


# ─── Non-vision/imagine intents unaffected ──────────────────────────

async def test_ask_intent_unaffected_by_vision_imagine_wiring():
    """Sanity check: adding vision_handler/imagine_handler to the
    constructor and _route table must not change plain 'ask' behavior."""
    bus, orch, log = await _make_realm()
    try:
        await bus.publish("prompt_text", text="what is the realm",
                          nonce="n1", user_guid="u1")
        payload = await _await_event(log, "query_result")
        assert payload["kind"] == "ask"
        assert len(payload["text"]) > 0
    finally:
        await orch.detach()
