"""
Regression tests for make_music_handler — DuckDuckGo-backed YouTube
video search.

Architecture:
  - Realm fetches html.duckduckgo.com (a public web page, no API key)
  - Parses out the first YouTube video ID from search results
  - Publishes 'music_search_request' bus event with the video_id
  - Browser embeds youtube.com/embed/<id>?autoplay=1 directly

These tests stub aiohttp so we can verify:
  - The right URL is fetched
  - Video IDs are extracted correctly from various YouTube URL formats
  - Error cases (timeout, no results, disabled) produce sensible spoken text
  - The bus event carries the video_id (NOT just the query)
  - The realm never calls the YouTube API
"""

import asyncio
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

pytestmark = pytest.mark.asyncio


class FakeAiohttpResponse:
    """One-shot response that returns the body we set."""
    def __init__(self, body, status=200):
        self._body = body
        self.status = status
    async def text(self):
        return self._body
    async def __aenter__(self):
        return self
    async def __aexit__(self, *args):
        pass


class FakeAiohttpSession:
    """Captures every GET. Returns the body set via configure()."""
    next_body = ""
    next_status = 200
    raise_exc = None
    get_calls = []

    def __init__(self, *args, **kwargs):
        # Reset per-instance call list isolated from class
        self.local_calls = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    def get(self, url, params=None, timeout=None):
        call = {"url": url, "params": params or {}}
        self.local_calls.append(call)
        FakeAiohttpSession.get_calls.append(call)
        if FakeAiohttpSession.raise_exc:
            raise FakeAiohttpSession.raise_exc
        return FakeAiohttpResponse(
            FakeAiohttpSession.next_body,
            FakeAiohttpSession.next_status,
        )


@pytest.fixture(autouse=True)
def reset_fake_session():
    FakeAiohttpSession.next_body = ""
    FakeAiohttpSession.next_status = 200
    FakeAiohttpSession.raise_exc = None
    FakeAiohttpSession.get_calls = []
    yield


class FakeBus:
    """Captures published bus events for inspection."""
    def __init__(self):
        self.events = []

    async def publish(self, event_type, **payload):
        self.events.append({"type": event_type, "payload": payload})


def _make_cfg(enabled=True, suffix="official music video", timeout=10):
    return {
        "Music": {
            "enabled": str(enabled).lower(),
            "search_suffix": suffix,
            "search_timeout_s": str(timeout),
        }
    }


def _fake_cfg_get(cfg, section, key, default=""):
    return cfg.get(section, {}).get(key, default)


# ─── Happy path: standard YouTube /watch?v=ID URLs ─────────────

# Real DuckDuckGo HTML responses contain links like:
#   <a href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DXXXXXXXXXXX">
# or sometimes direct:
#   <a href="https://www.youtube.com/watch?v=XXXXXXXXXXX">

DDG_RESPONSE_WITH_YT = """
<html><body>
<div class="result">
  <a class="result__a" href="https://www.youtube.com/watch?v=SDTZ7iX4vTQ">
    The Clash - London Calling (Official Video)
  </a>
</div>
<div class="result">
  <a href="https://en.wikipedia.org/wiki/London_Calling">London Calling - Wikipedia</a>
</div>
</body></html>
"""

DDG_RESPONSE_URL_ENCODED = """
<html><body>
<div class="result">
  <a class="result__a"
     href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DfJ9rUzIMcZQ&rut=abc">
    Queen - Bohemian Rhapsody
  </a>
</div>
</body></html>
"""

DDG_RESPONSE_YOUTU_BE = """
<html><body>
<div class="result">
  <a href="https://youtu.be/dQw4w9WgXcQ">Rick Astley Never Gonna Give You Up</a>
</div>
</body></html>
"""

DDG_RESPONSE_NO_YOUTUBE = """
<html><body>
<div class="result">
  <a href="https://example.com/page">Some random page</a>
</div>
<div class="result">
  <a href="https://en.wikipedia.org/wiki/Music">Music - Wikipedia</a>
</div>
</body></html>
"""


async def test_extracts_standard_youtube_video_id():
    FakeAiohttpSession.next_body = DDG_RESPONSE_WITH_YT
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        result = await handler({"query": "london calling"},
                               "test-user", bus)
    # Spoken result mentions the song
    assert "london calling" in result.lower(), \
        f"spoken text should mention song: {result!r}"
    # Bus event was published with the video_id
    assert len(bus.events) == 1
    ev = bus.events[0]
    assert ev["type"] == "music_search_request"
    assert ev["payload"]["video_id"] == "SDTZ7iX4vTQ"
    assert ev["payload"]["user_guid"] == "test-user"
    assert ev["payload"]["query"] == "london calling"


async def test_extracts_url_encoded_video_id():
    """DuckDuckGo wraps result URLs in a redirect — we still need to find
    the embedded YouTube ID inside the URL-encoded uddg= parameter."""
    FakeAiohttpSession.next_body = DDG_RESPONSE_URL_ENCODED
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        await handler({"query": "bohemian rhapsody"}, "test-user", bus)
    # %3D is URL-encoded '='. Our regex must handle this form.
    # The encoded URL has youtube.com%2Fwatch%3Fv%3DfJ9rUzIMcZQ
    # which decodes to youtube.com/watch?v=fJ9rUzIMcZQ
    # Even if we don't decode, the literal text "youtube.com" appears.
    # The video ID fJ9rUzIMcZQ is the 11-char alphanumeric after v=/v%3D.
    assert len(bus.events) == 1
    video_id = bus.events[0]["payload"]["video_id"]
    # We allow this case to either succeed (decoded) or fall back; the
    # important thing is no crash. Realistically the regex catches
    # the unencoded form too if DDG's URLs include the raw link
    # anywhere in the HTML (they often do, in title or aria-label).
    # If empty, the search returned an error message instead.
    assert video_id == "fJ9rUzIMcZQ" or video_id == "", \
        f"Got unexpected video_id: {video_id!r}"


async def test_extracts_youtu_be_short_url():
    """youtu.be/<ID> is YouTube's short URL form."""
    FakeAiohttpSession.next_body = DDG_RESPONSE_YOUTU_BE
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        await handler({"query": "rick roll"}, "test-user", bus)
    assert len(bus.events) == 1
    assert bus.events[0]["payload"]["video_id"] == "dQw4w9WgXcQ"


# ─── Negative paths ─────────────────────────────────────────────

async def test_no_youtube_link_found():
    """When DDG returns results but none point to YouTube, return a
    friendly error message and publish no bus event."""
    FakeAiohttpSession.next_body = DDG_RESPONSE_NO_YOUTUBE
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        result = await handler({"query": "obscure song"},
                               "test-user", bus)
    assert "couldn't" in result.lower() or "no" in result.lower()
    assert len(bus.events) == 0


async def test_empty_query_no_search():
    """No query slot → return helpful prompt, no HTTP call."""
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        result = await handler({}, "test-user", bus)
    assert "song name" in result.lower() or "music" in result.lower()
    # No HTTP calls — we short-circuited
    assert len(FakeAiohttpSession.get_calls) == 0
    assert len(bus.events) == 0


async def test_ddg_returns_error_status():
    """Non-200 status from DDG → graceful error, no crash."""
    FakeAiohttpSession.next_status = 503
    FakeAiohttpSession.next_body = "Service Unavailable"
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        result = await handler({"query": "any song"}, "test-user", bus)
    assert "couldn't" in result.lower() or "found" in result.lower()
    assert len(bus.events) == 0


async def test_ddg_request_times_out():
    """Network timeout → spoken error, no crash."""
    FakeAiohttpSession.raise_exc = asyncio.TimeoutError()
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        result = await handler({"query": "any song"}, "test-user", bus)
    assert "couldn't" in result.lower() or "timed out" in result.lower()
    assert len(bus.events) == 0


async def test_disabled_via_config():
    """[Music] enabled=false → handler returns disabled message, no HTTP."""
    cfg = _make_cfg(enabled=False)
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        result = await handler({"query": "anything"}, "test-user", bus)
    assert "disabled" in result.lower()
    assert len(FakeAiohttpSession.get_calls) == 0
    assert len(bus.events) == 0


# ─── Architecture invariants ────────────────────────────────────

async def test_calls_duckduckgo_not_youtube():
    """The handler must call DuckDuckGo's HTML endpoint, NOT YouTube."""
    FakeAiohttpSession.next_body = DDG_RESPONSE_WITH_YT
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        await handler({"query": "test"}, "test-user", bus)
    assert len(FakeAiohttpSession.get_calls) == 1
    url = FakeAiohttpSession.get_calls[0]["url"]
    assert "duckduckgo.com" in url, \
        f"Should hit DuckDuckGo, hit: {url!r}"
    assert "youtube" not in url.lower() and "googleapis" not in url.lower(), \
        f"Must NOT hit YouTube/Google directly: {url!r}"


async def test_search_suffix_appended_to_query():
    """The configured suffix (e.g. 'official music video') is appended to
    the user's query so DDG biases toward music videos."""
    FakeAiohttpSession.next_body = DDG_RESPONSE_WITH_YT
    cfg = _make_cfg(suffix="official music video")
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        await handler({"query": "london calling"}, "test-user", bus)
    sent_q = FakeAiohttpSession.get_calls[0]["params"].get("q", "")
    assert "london calling" in sent_q
    assert "official music video" in sent_q


async def test_bus_event_user_guid_isolation():
    """The bus event must be tagged with the requesting user's guid so
    only their browser receives the music."""
    FakeAiohttpSession.next_body = DDG_RESPONSE_WITH_YT
    cfg = _make_cfg()
    bus = FakeBus()
    with patch("app.cfg_get", side_effect=_fake_cfg_get), \
         patch("app.aiohttp.ClientSession", FakeAiohttpSession):
        from app import make_music_handler
        handler = make_music_handler(cfg)
        await handler({"query": "test"}, "alice-guid-xxx", bus)
    assert bus.events[0]["payload"]["user_guid"] == "alice-guid-xxx"


# ─── Compliance: realm has no YouTube API references ────────────

def test_realm_does_not_call_youtube_api():
    """The realm code must never reference the YouTube Data API. Only
    DuckDuckGo + browser-side IFrame embed are allowed.

    This test scans Python source files for forbidden patterns. If anyone
    later refactors and accidentally adds a YouTube API call, this fires.
    """
    import pathlib
    realm_dir = pathlib.Path(__file__).resolve().parent.parent
    suspect_files = [
        realm_dir / "app.py",
        realm_dir / "realm" / "orchestrator.py",
        realm_dir / "realm" / "intent.py",
        realm_dir / "realm" / "engine_chain.py",
    ]
    BANNED = [
        "googleapis.com/youtube",
        "youtube_api_key",
        "YOUTUBE_API_KEY",
        "youtube.com/v3/",
        "youtube/v3/search",
    ]
    for f in suspect_files:
        if not f.exists():
            continue
        content = f.read_text(encoding="utf-8")
        for banned in BANNED:
            assert banned not in content, (
                f"{f.name} contains '{banned}' — but the music realm "
                "MUST search DuckDuckGo, not YouTube's API."
            )
