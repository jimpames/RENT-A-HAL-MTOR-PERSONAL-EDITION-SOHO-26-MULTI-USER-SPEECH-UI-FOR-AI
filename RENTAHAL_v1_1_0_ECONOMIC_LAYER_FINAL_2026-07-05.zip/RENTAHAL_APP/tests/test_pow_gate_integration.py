"""
Sprint 10 — end-to-end HTTP integration tests for the PoW gate wired
into /api/ask, /api/speak, /federate/checkin.

tests/test_pow_gate.py covers the mechanism in isolation (fast, low
difficulty). This file covers the WIRING — that a real booted app
actually enforces the gate correctly on real HTTP calls, including the
one branching decision that only exists at the app.py integration
layer: federated forwards (X-Federation-Hops present) skip PoW
entirely and rely on the token check instead, while direct/anonymous
callers get the IP-keyed PoW gate.

Deliberately uses the REAL DEFAULT_TIERS ladder (10 free calls, then
4 bits ≈ a few seconds to solve) rather than a mocked-down one — this
is the actual configuration a real deployment runs, and the puzzle-
solving cost at the first paid tier is small enough to keep this file
fast without needing to fake the difficulty ladder.
"""
import asyncio
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

os.environ["RENTAHAL_FAKE_ENGINES"] = "1"

from realm.pow_gate import solve_challenge


async def _boot(tmp_path, abuse_gate_enabled: bool = True):
    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[AbuseGate]\n"
        f"enabled = {'true' if abuse_gate_enabled else 'false'}\n"
        "secret = integration-test-secret-32-bytes!!\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    return app_module.create_app(cfg, logger)


async def _run_server(app, port):
    import uvicorn
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=port, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    return server, task


@pytest.mark.asyncio
async def test_ask_free_tier_calls_succeed_without_solution(tmp_path):
    import aiohttp
    app = await _boot(tmp_path)
    server, task = await _run_server(app, 9990)
    try:
        async with aiohttp.ClientSession() as s:
            for _ in range(5):
                async with s.post("http://127.0.0.1:9990/api/ask",
                                  json={"text": "what is the realm"}) as r:
                    assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_ask_past_free_tier_requires_and_accepts_pow(tmp_path):
    import aiohttp
    app = await _boot(tmp_path)
    server, task = await _run_server(app, 9991)
    try:
        async with aiohttp.ClientSession() as s:
            # Consume the free allowance (10 calls).
            for _ in range(10):
                async with s.post("http://127.0.0.1:9991/api/ask",
                                  json={"text": "what is the realm"}) as r:
                    assert r.status == 200

            # 11th call: past the free threshold, must get a challenge.
            async with s.post("http://127.0.0.1:9991/api/ask",
                              json={"text": "what is the realm"}) as r:
                assert r.status == 402
                data = await r.json()
                assert data["error"] == "proof_of_work_required"
                assert data["tier"] == "pi-100"
                assert data["difficulty_bits"] == 4

            # Solve it and resubmit the SAME request with pow_solution attached.
            solution = solve_challenge(data)
            assert solution is not None
            async with s.post("http://127.0.0.1:9991/api/ask", json={
                "text": "what is the realm", "pow_solution": solution}) as r:
                assert r.status == 200
                answer = await r.json()
                assert answer["intent"] in ("ask", "weather")  # got a real answer through
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_ask_tampered_pow_solution_rejected(tmp_path):
    import aiohttp
    app = await _boot(tmp_path)
    server, task = await _run_server(app, 9992)
    try:
        async with aiohttp.ClientSession() as s:
            for _ in range(10):
                await s.post("http://127.0.0.1:9992/api/ask",
                             json={"text": "hi"})
            async with s.post("http://127.0.0.1:9992/api/ask",
                              json={"text": "hi"}) as r:
                data = await r.json()
            solution = solve_challenge(data)
            solution["difficulty_bits"] = 0   # attempt to downgrade
            async with s.post("http://127.0.0.1:9992/api/ask", json={
                "text": "hi", "pow_solution": solution}) as r:
                assert r.status == 402
                body = await r.json()
                assert "invalid_proof_of_work" in body["error"]
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_ask_federated_forward_bypasses_pow_entirely(tmp_path):
    """A federated forward (X-Federation-Hops present) must NOT be
    asked to solve a puzzle at all, even past the free-call threshold
    — it's gated by the token check instead (or nothing, if no token
    is configured, matching the Little-Johnny-adjacent 'open unless
    explicitly locked down' posture for federation itself)."""
    import aiohttp
    app = await _boot(tmp_path)
    server, task = await _run_server(app, 9993)
    try:
        async with aiohttp.ClientSession() as s:
            # Blow well past the free threshold using DIRECT calls.
            for _ in range(15):
                await s.post("http://127.0.0.1:9993/api/ask", json={"text": "hi"})
            # A federated forward right after must still succeed with
            # no pow_solution attached at all.
            async with s.post("http://127.0.0.1:9993/api/ask",
                              json={"text": "hi"},
                              headers={"X-Federation-Hops": "0"}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_ask_different_ips_tracked_independently(tmp_path):
    """Two different callers must not share a rate-limit bucket. We
    can't easily fake source IP over real HTTP from one test process,
    so this test goes through the PowGate object directly instead —
    the wiring-level guarantee (correct KEY extraction from request)
    is covered by the other tests in this file; this confirms the
    underlying tracker keys correctly once given two different keys,
    which is what request.client.host actually provides per-caller."""
    from realm.pow_gate import PowGate
    gate = PowGate(secret=b"x" * 32)
    for _ in range(10):
        gate.check("203.0.113.1", None)
    result_a = gate.check("203.0.113.1", None)
    assert result_a.allowed is False   # exhausted its own free tier
    result_b = gate.check("203.0.113.2", None)
    assert result_b.allowed is True    # different IP, untouched


@pytest.mark.asyncio
async def test_speak_gate_wired_the_same_way(tmp_path):
    import aiohttp
    app = await _boot(tmp_path)
    server, task = await _run_server(app, 9994)
    try:
        async with aiohttp.ClientSession() as s:
            for _ in range(10):
                async with s.post("http://127.0.0.1:9994/api/speak",
                                  json={"text": "hello"}) as r:
                    assert r.status == 200
            async with s.post("http://127.0.0.1:9994/api/speak",
                              json={"text": "hello"}) as r:
                assert r.status == 402
                data = await r.json()
            solution = solve_challenge(data)
            async with s.post("http://127.0.0.1:9994/api/speak", json={
                "text": "hello", "pow_solution": solution}) as r:
                assert r.status == 200
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_checkin_is_never_pow_gated_even_under_heavy_call_volume(tmp_path):
    """Regression test for a real production incident: /federate/checkin
    is a legitimate, expected, HIGH-FREQUENCY (every checkin_interval_s,
    15s by default) bookkeeping call — not the kind of anonymous,
    expensive-compute abuse surface the PoW gate exists to protect. It
    must never be PoW-gated, at any call volume, because the check-in
    CLIENT has no ability to solve a PoW challenge and resubmit — if it
    ever were gated, a realm would exhaust the free tier in minutes and
    every check-in after that would fail forever, until a restart reset
    the in-memory counter, only to repeat the same cycle. Confirmed as a
    real, guaranteed-to-recur incident, not a hypothetical — every
    federated realm running more than ~2.5 minutes hit this before the
    fix. federation_token_error is the correct, sufficient
    authentication layer for this endpoint instead."""
    import aiohttp
    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[AbuseGate]\nenabled = true\n"
        "secret = integration-test-secret-32-bytes!!\n"
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)
    server, task = await _run_server(app, 9995)
    try:
        async with aiohttp.ClientSession() as s:
            # Far beyond the PoW gate's 10-call free tier — every single
            # one of these must still succeed with no PoW challenge ever
            # appearing, matching real check-in traffic over several
            # minutes at the default 15s interval.
            for i in range(50):
                async with s.post("http://127.0.0.1:9995/api/federate/checkin", json={
                    "member_url": "https://a.example", "llm_avg_s": 1.0,
                    "tts_avg_s": 1.0, "tokens_out": 0}) as r:
                    assert r.status == 200, (
                        f"checkin #{i+1} was gated (status {r.status}) — "
                        f"the PoW-on-checkin regression is back")
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_gate_disabled_via_config_bypasses_everywhere(tmp_path):
    import aiohttp
    app = await _boot(tmp_path, abuse_gate_enabled=False)
    server, task = await _run_server(app, 9996)
    try:
        async with aiohttp.ClientSession() as s:
            for _ in range(20):   # would be well into a paid tier if enabled
                async with s.post("http://127.0.0.1:9996/api/ask",
                                  json={"text": "hi"}) as r:
                    assert r.status == 200
    finally:
        server.should_exit = True
        await task
