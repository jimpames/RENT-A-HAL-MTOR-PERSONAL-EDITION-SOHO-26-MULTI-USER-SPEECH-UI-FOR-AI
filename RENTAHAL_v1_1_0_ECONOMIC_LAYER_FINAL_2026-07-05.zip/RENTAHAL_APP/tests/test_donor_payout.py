"""
Sprint 14 — tests for realm/donor_payout.py.

THE acceptance criterion from ECONOMIC_LAYER_DESIGN.md: "a synthetic
conscription scenario where requester and donor claims match ->
payout credits correctly; a mismatched-claim scenario -> flagged, not
paid." This file covers exactly that, against REAL Postgres — the
bilateral confirmation logic is the sprint's real complexity, and it
needs zero external network access to test for real, so it gets the
most thorough testing.

Stripe Connect (account creation, onboarding, transfers) needs real
network access to api.stripe.com, unreachable from this sandbox (same
restriction documented in Sprints 12-13) — tested via mocking the SDK
calls, clearly labeled.
"""
import asyncio
import os
import sys
import time
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

stripe = pytest.importorskip("stripe")
asyncpg = pytest.importorskip("asyncpg")

from realm.ledger import Ledger
from realm.donor_payout import (
    ClaimStore, ClaimResult, DonorAccountStore, PayoutConfig,
    check_payouts_enabled, create_connect_account, create_onboarding_link,
    execute_payout,
)

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


def _dsn_for_db(db_name: str) -> str:
    prefix = BASE_DSN.rsplit("/", 1)[0]
    return f"{prefix}/{db_name}"


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


pytestmark = pytest.mark.asyncio


@pytest.fixture
async def ledger():
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable — see test_ledger.py's fixture "
                    "for the same pattern and reasoning.")
    db_name = f"rentahal_payout_test_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()

    dsn = _dsn_for_db(db_name)
    led = await Ledger.connect(dsn)
    led.dsn = dsn
    try:
        yield led
    finally:
        await led.close()
        admin_conn = await asyncpg.connect(BASE_DSN)
        await admin_conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
        await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
        await admin_conn.close()


@pytest.fixture
def payout_cfg():
    return PayoutConfig(stripe_secret_key="sk_test_fake",
                        conscription_payout_rate_micros=80,
                        claim_match_tolerance_s=60.0)


# ─── PayoutConfig ─────────────────────────────────────────────────

def test_payout_config_enabled_requires_stripe_key():
    assert PayoutConfig().enabled is False
    assert PayoutConfig(stripe_secret_key="sk_x").enabled is True


def test_claim_result_defaults():
    r = ClaimResult(claim_id=1, matched=False)
    assert r.matched_claim_id is None
    assert r.credited is False
    assert r.credit_amount_micros is None


# ─── ClaimStore — validation ──────────────────────────────────────

async def test_submit_claim_rejects_invalid_role(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    with pytest.raises(ValueError):
        await store.submit_claim("attacker", "https://d.example",
                                 "https://r.example", "chat")


async def test_submit_claim_rejects_invalid_rank(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    with pytest.raises(ValueError):
        await store.submit_claim("requester", "https://d.example",
                                 "https://r.example", "not-a-real-rank")


# ─── THE acceptance criterion: matched claims credit correctly ────

async def test_matched_claims_credit_the_donor(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()

    r1 = await store.submit_claim(
        "requester", "https://vision-donor.example",
        "https://chat-struggling.example", "chat", claimed_at=now)
    assert r1.matched is False
    assert r1.credited is False

    r2 = await store.submit_claim(
        "donor", "https://vision-donor.example",
        "https://chat-struggling.example", "chat", claimed_at=now + 5)
    assert r2.matched is True
    assert r2.matched_claim_id == r1.claim_id
    assert r2.credited is True
    assert r2.credit_amount_micros == 80

    balance = await ledger.get_balance("https://vision-donor.example")
    assert balance == 80


async def test_matching_works_regardless_of_which_role_arrives_first(ledger, payout_cfg):
    """The donor's claim can legitimately arrive BEFORE the requester's
    — e.g. if the donor answers instantly but the requester takes a
    moment to log its own claim. Matching must work either order."""
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()

    r1 = await store.submit_claim(
        "donor", "https://vision-donor.example",
        "https://chat-x.example", "chat", claimed_at=now)
    assert r1.matched is False

    r2 = await store.submit_claim(
        "requester", "https://vision-donor.example",
        "https://chat-x.example", "chat", claimed_at=now + 3)
    assert r2.matched is True
    assert r2.credited is True

    balance = await ledger.get_balance("https://vision-donor.example")
    assert balance == 80


async def test_multiple_confirmed_requests_credit_multiple_times(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    for i in range(3):
        await store.submit_claim("requester", "https://vision-donor.example",
                                 "https://chat-x.example", "chat",
                                 claimed_at=now + i * 200)
        await store.submit_claim("donor", "https://vision-donor.example",
                                 "https://chat-x.example", "chat",
                                 claimed_at=now + i * 200 + 2)
    balance = await ledger.get_balance("https://vision-donor.example")
    assert balance == 240   # 3 * 80


# ─── THE acceptance criterion: mismatched claims are flagged, not paid ──

async def test_lying_donor_claim_with_no_requester_confirmation_not_paid(
        ledger, payout_cfg):
    """A donor claiming work the requester never confirms — the core
    security property bilateral confirmation exists to protect."""
    store = ClaimStore(ledger, payout_cfg)
    result = await store.submit_claim(
        "donor", "https://lying-donor.example",
        "https://chat-victim.example", "chat", claimed_at=time.time())

    assert result.matched is False
    assert result.credited is False

    balance = await ledger.get_balance("https://lying-donor.example")
    assert balance == 0


async def test_claims_outside_tolerance_window_do_not_match(ledger, payout_cfg):
    """Same donor/requester/rank, but timestamps too far apart to be
    the same piece of work — must not falsely match."""
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    await store.submit_claim("requester", "https://d.example",
                             "https://r.example", "chat", claimed_at=now)
    far_result = await store.submit_claim(
        "donor", "https://d.example", "https://r.example", "chat",
        claimed_at=now + 120)   # well outside the 60s tolerance

    assert far_result.matched is False
    balance = await ledger.get_balance("https://d.example")
    assert balance == 0


async def test_claims_just_inside_tolerance_do_match(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    await store.submit_claim("requester", "https://d.example",
                             "https://r.example", "chat", claimed_at=now)
    close_result = await store.submit_claim(
        "donor", "https://d.example", "https://r.example", "chat",
        claimed_at=now + 59)   # just inside the 60s tolerance

    assert close_result.matched is True


async def test_different_donor_never_matches_a_claim(ledger, payout_cfg):
    """A claim for donor A must never match a claim for donor B, even
    with an identical requester/rank/timestamp."""
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    await store.submit_claim("requester", "https://donor-a.example",
                             "https://r.example", "chat", claimed_at=now)
    result = await store.submit_claim(
        "donor", "https://donor-b.example",   # DIFFERENT donor
        "https://r.example", "chat", claimed_at=now)
    assert result.matched is False


async def test_different_requester_never_matches_a_claim(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    await store.submit_claim("requester", "https://d.example",
                             "https://requester-a.example", "chat", claimed_at=now)
    result = await store.submit_claim(
        "donor", "https://d.example", "https://requester-b.example",
        "chat", claimed_at=now)
    assert result.matched is False


async def test_different_rank_never_matches_a_claim(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    await store.submit_claim("requester", "https://d.example",
                             "https://r.example", "chat", claimed_at=now)
    result = await store.submit_claim(
        "donor", "https://d.example", "https://r.example", "vision",
        claimed_at=now)
    assert result.matched is False


async def test_same_role_twice_never_matches_each_other(ledger, payout_cfg):
    """Two REQUESTER claims (no donor claim at all) must never match
    each other — matching only happens across OPPOSITE roles."""
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    await store.submit_claim("requester", "https://d.example",
                             "https://r.example", "chat", claimed_at=now)
    result = await store.submit_claim(
        "requester", "https://d.example", "https://r.example", "chat",
        claimed_at=now + 1)
    assert result.matched is False


# ─── Idempotency of the resulting credit ─────────────────────────

async def test_credit_is_idempotent_even_if_matching_ran_twice(ledger, payout_cfg):
    """Belt and suspenders: even if a bug somehow caused the SAME
    matched pair to attempt crediting twice, the ledger's own
    idempotency constraint (extended in 005_donor_payout.sql) prevents
    a double-payout."""
    from realm.ledger import DuplicateEntryError
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    r1 = await store.submit_claim("requester", "https://d.example",
                                  "https://r.example", "chat", claimed_at=now)
    r2 = await store.submit_claim("donor", "https://d.example",
                                  "https://r.example", "chat", claimed_at=now + 1)
    assert r2.credited is True

    # Manually attempt to re-append the exact same credit reference —
    # simulating what WOULD happen if reconciliation ran twice on the
    # same pair.
    pair_low, pair_high = sorted([r1.claim_id, r2.claim_id])
    with pytest.raises(DuplicateEntryError):
        await ledger.append_entry(
            "conscription_credit", "https://d.example", 80,
            reference=f"claim-match-{pair_low}-{pair_high}")

    balance = await ledger.get_balance("https://d.example")
    assert balance == 80   # still just one credit


# ─── get_unmatched_claims ─────────────────────────────────────────

async def test_get_unmatched_claims_excludes_matched_ones(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    now = time.time()
    await store.submit_claim("requester", "https://matched.example",
                             "https://r.example", "chat", claimed_at=now)
    await store.submit_claim("donor", "https://matched.example",
                             "https://r.example", "chat", claimed_at=now + 1)
    await store.submit_claim("donor", "https://still-unmatched.example",
                             "https://r.example", "chat", claimed_at=now)

    unmatched = await store.get_unmatched_claims()
    urls = {c["donor_url"] for c in unmatched}
    assert "https://still-unmatched.example" in urls
    assert "https://matched.example" not in urls


async def test_get_unmatched_claims_max_age_filter(ledger, payout_cfg):
    store = ClaimStore(ledger, payout_cfg)
    await store.submit_claim("donor", "https://old-liar.example",
                             "https://r.example", "chat", claimed_at=time.time())
    # With a max_age of 0, this claim (just submitted) should NOT show
    # as "old enough to be abandoned" yet.
    recent_only = await store.get_unmatched_claims(max_age_s=999999)
    assert not any(c["donor_url"] == "https://old-liar.example" for c in recent_only)


# ─── DonorAccountStore ────────────────────────────────────────────

async def test_link_account_and_get_account(ledger):
    store = DonorAccountStore(ledger)
    await store.link_account("https://vision-donor.example", "acct_abc123")
    account = await store.get_account("https://vision-donor.example")
    assert account["stripe_account_id"] == "acct_abc123"
    assert account["payouts_enabled"] is False


async def test_link_account_upserts_on_relink(ledger):
    store = DonorAccountStore(ledger)
    await store.link_account("https://d.example", "acct_old")
    await store.link_account("https://d.example", "acct_new")
    account = await store.get_account("https://d.example")
    assert account["stripe_account_id"] == "acct_new"


async def test_get_account_none_for_unknown_donor(ledger):
    store = DonorAccountStore(ledger)
    account = await store.get_account("https://never-linked.example")
    assert account is None


async def test_mark_payouts_enabled(ledger):
    store = DonorAccountStore(ledger)
    await store.link_account("https://d.example", "acct_x")
    await store.mark_payouts_enabled("https://d.example", True)
    account = await store.get_account("https://d.example")
    assert account["payouts_enabled"] is True


async def test_get_payout_ready_accounts_only_returns_enabled(ledger):
    store = DonorAccountStore(ledger)
    await store.link_account("https://ready.example", "acct_ready")
    await store.mark_payouts_enabled("https://ready.example", True)
    await store.link_account("https://not-ready.example", "acct_notready")

    ready = await store.get_payout_ready_accounts()
    urls = [a["donor_url"] for a in ready]
    assert "https://ready.example" in urls
    assert "https://not-ready.example" not in urls


# ─── Stripe Connect — mocked, clearly labeled ─────────────────────

def test_create_connect_account_calls_real_sdk():
    cfg = PayoutConfig(stripe_secret_key="sk_test_fake")
    fake_account = MagicMock()
    fake_account.id = "acct_fake"
    with patch("stripe.Account.create", return_value=fake_account) as m:
        account_id = create_connect_account(cfg, "https://vision-donor.example")
    assert account_id == "acct_fake"
    assert m.call_args.kwargs["type"] == "express"
    assert m.call_args.kwargs["metadata"]["donor_url"] == "https://vision-donor.example"


def test_create_onboarding_link_calls_real_sdk():
    cfg = PayoutConfig(stripe_secret_key="sk_test_fake",
                       onboarding_refresh_url="https://x.example/refresh",
                       onboarding_return_url="https://x.example/return")
    fake_link = MagicMock()
    fake_link.url = "https://connect.stripe.com/setup/fake"
    with patch("stripe.AccountLink.create", return_value=fake_link) as m:
        url = create_onboarding_link(cfg, "acct_fake")
    assert url == "https://connect.stripe.com/setup/fake"
    assert m.call_args.kwargs["refresh_url"] == "https://x.example/refresh"
    assert m.call_args.kwargs["type"] == "account_onboarding"


def test_check_payouts_enabled_true():
    cfg = PayoutConfig(stripe_secret_key="sk_test_fake")
    fake_account = MagicMock()
    fake_account.payouts_enabled = True
    with patch("stripe.Account.retrieve", return_value=fake_account):
        assert check_payouts_enabled(cfg, "acct_fake") is True


def test_check_payouts_enabled_false():
    cfg = PayoutConfig(stripe_secret_key="sk_test_fake")
    fake_account = MagicMock()
    fake_account.payouts_enabled = False
    with patch("stripe.Account.retrieve", return_value=fake_account):
        assert check_payouts_enabled(cfg, "acct_fake") is False


def test_execute_payout_calls_real_sdk_with_correct_amount():
    cfg = PayoutConfig(stripe_secret_key="sk_test_fake")
    fake_transfer = MagicMock()
    fake_transfer.id = "tr_fake"
    with patch("stripe.Transfer.create", return_value=fake_transfer) as m:
        transfer_id = execute_payout(cfg, "acct_fake", 5_000_000)
    assert transfer_id == "tr_fake"
    assert m.call_args.kwargs["amount"] == 500   # $5.00 -> 500 cents
    assert m.call_args.kwargs["destination"] == "acct_fake"


def test_execute_payout_rejects_amount_rounding_to_zero_cents():
    cfg = PayoutConfig(stripe_secret_key="sk_test_fake")
    with pytest.raises(ValueError):
        execute_payout(cfg, "acct_fake", 80)   # 80 micros = 0.008 cents -> rounds to 0
