"""
Sprint 6 tests — federation capability matrix generalization.

Covers the extension of FederationMatrix/MemberRecord from two hardcoded
columns (llm_avg_s, tts_avg_s) to an open-ended per-capability dict, with
backward compatibility as the acceptance bar (rentahal.com's own
Federator is live production).

  MemberRecord
    - capability_avg_s defaults empty; llm_avg_s/tts_avg_s unaffected
    - get_avg/set_avg unify legacy and open-ended capability access
    - has_capability: legacy kinds always present; others only if
      explicitly reported
    - to_dict omits capability_avg_s entirely when empty (byte-identical
      to pre-Sprint-6 output for members that never report anything new)
    - from_dict round-trips capability_avg_s and tolerates corrupted
      entries without losing the rest of the record

  FederationMatrix
    - upsert() with no capability_avg_s behaves exactly as before
    - upsert() merges capability_avg_s without disturbing llm/tts
    - best_peer_for('vision') returns None when nobody has ever
      reported vision — the whole point of has_capability()
    - best_peer_for('vision') picks the correct argmin among only the
      members who reported it, ignoring chat-only members entirely
    - rotation bump applies correctly to non-legacy capabilities too
    - old-format state file (no capability_avg_s key at all) loads fine

  FederationConfig
    - node_type defaults to 'chat'
    - node_type parses from federation.ini

  FederationClient
    - capability_avg_s is included in the check-in payload when present
    - capability_avg_s is OMITTED when the stats callable doesn't
      provide one (old-style stats dict — proves backward compat on
      the sending side too)
    - node_type always included regardless
    - best_peer dict is stored from the response when present
    - best_peer defaults to empty dict when the Federator's response
      doesn't include it (a pre-Sprint-6 Federator)
"""
import asyncio
import sys
import time
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import (
    FederationMatrix, FederationConfig, FederationState, FederationClient,
    MemberRecord, DEGRADED_AVG_S, DEFAULTS,
)

pytestmark = pytest.mark.asyncio


# ─── MemberRecord ───────────────────────────────────────────────────

def test_capability_avg_s_defaults_empty():
    rec = MemberRecord(url="https://example.com")
    assert rec.capability_avg_s == {}
    assert rec.llm_avg_s == DEGRADED_AVG_S
    assert rec.tts_avg_s == DEGRADED_AVG_S


def test_get_avg_legacy_kinds_read_dedicated_fields():
    rec = MemberRecord(url="https://example.com", llm_avg_s=2.5, tts_avg_s=1.1)
    assert rec.get_avg("llm") == 2.5
    assert rec.get_avg("tts") == 1.1


def test_get_avg_new_kind_reads_capability_dict():
    rec = MemberRecord(url="https://example.com",
                       capability_avg_s={"vision": 3.3})
    assert rec.get_avg("vision") == 3.3


def test_get_avg_never_reported_kind_returns_degraded_sentinel():
    rec = MemberRecord(url="https://example.com")
    assert rec.get_avg("vision") == DEGRADED_AVG_S
    assert rec.get_avg("imagine") == DEGRADED_AVG_S


def test_set_avg_legacy_kinds_write_dedicated_fields():
    rec = MemberRecord(url="https://example.com")
    rec.set_avg("llm", 9.9)
    rec.set_avg("tts", 8.8)
    assert rec.llm_avg_s == 9.9
    assert rec.tts_avg_s == 8.8
    assert rec.capability_avg_s == {}   # legacy writes don't leak into the dict


def test_set_avg_new_kind_writes_capability_dict():
    rec = MemberRecord(url="https://example.com")
    rec.set_avg("vision", 4.4)
    assert rec.capability_avg_s == {"vision": 4.4}


def test_has_capability_legacy_kinds_always_true():
    rec = MemberRecord(url="https://example.com")
    assert rec.has_capability("llm") is True
    assert rec.has_capability("tts") is True


def test_has_capability_new_kind_false_until_reported():
    rec = MemberRecord(url="https://example.com")
    assert rec.has_capability("vision") is False
    rec.set_avg("vision", 2.0)
    assert rec.has_capability("vision") is True


def test_to_dict_omits_capability_avg_s_when_empty():
    """Byte-identical to pre-Sprint-6 output for a member that has never
    reported anything beyond llm/tts — EXCEPT node_type, which Sprint 8
    added as an always-present field (not sparse like capability_avg_s,
    since every member has SOME node_type, defaulting to 'chat')."""
    rec = MemberRecord(url="https://example.com", llm_avg_s=1.0, tts_avg_s=0.5)
    d = rec.to_dict()
    assert "capability_avg_s" not in d
    assert set(d.keys()) == {"url", "llm_avg_s", "tts_avg_s", "tokens_out",
                             "last_seen", "node_type"}


def test_to_dict_includes_capability_avg_s_when_present():
    rec = MemberRecord(url="https://example.com",
                       capability_avg_s={"vision": 2.123456})
    d = rec.to_dict()
    assert d["capability_avg_s"] == {"vision": 2.123}   # rounded to 3dp


def test_from_dict_round_trips_capability_avg_s():
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 10, "last_seen": 123.0,
         "capability_avg_s": {"vision": 2.5, "imagine": 6.1}}
    rec = MemberRecord.from_dict(d)
    assert rec.capability_avg_s == {"vision": 2.5, "imagine": 6.1}
    assert rec.llm_avg_s == 1.0


def test_from_dict_missing_capability_avg_s_defaults_empty():
    """The OLD state-file shape — no capability_avg_s key at all."""
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 10, "last_seen": 123.0}
    rec = MemberRecord.from_dict(d)
    assert rec.capability_avg_s == {}


def test_from_dict_tolerates_corrupted_capability_entry():
    """One bad entry doesn't blow up the whole record."""
    d = {"url": "https://a.com", "llm_avg_s": 1.0, "tts_avg_s": 0.5,
         "tokens_out": 10, "last_seen": 123.0,
         "capability_avg_s": {"vision": "not-a-number", "imagine": 4.0}}
    rec = MemberRecord.from_dict(d)
    assert rec.capability_avg_s == {"imagine": 4.0}
    assert "vision" not in rec.capability_avg_s


# ─── FederationMatrix.upsert — backward compat ──────────────────────

async def test_upsert_without_capability_avg_s_unchanged_behavior():
    m = FederationMatrix(missed_after_s=60.0)
    rec = await m.upsert("https://a.com", 2.0, 1.5, 100)
    assert rec.llm_avg_s == 2.0
    assert rec.tts_avg_s == 1.5
    assert rec.capability_avg_s == {}


async def test_upsert_with_capability_avg_s_merges_without_disturbing_llm_tts():
    m = FederationMatrix(missed_after_s=60.0)
    rec = await m.upsert("https://a.com", 2.0, 1.5, 100,
                         capability_avg_s={"vision": 3.0})
    assert rec.llm_avg_s == 2.0
    assert rec.tts_avg_s == 1.5
    assert rec.capability_avg_s == {"vision": 3.0}


async def test_upsert_capability_avg_s_overwrites_on_subsequent_checkins():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 2.0, 1.5, 100, capability_avg_s={"vision": 3.0})
    rec = await m.upsert("https://a.com", 2.0, 1.5, 100, capability_avg_s={"vision": 5.0})
    assert rec.capability_avg_s == {"vision": 5.0}


async def test_upsert_tolerates_corrupted_capability_entry():
    m = FederationMatrix(missed_after_s=60.0)
    rec = await m.upsert("https://a.com", 2.0, 1.5, 100,
                         capability_avg_s={"vision": "garbage", "imagine": 4.0})
    assert rec.capability_avg_s == {"imagine": 4.0}


# ─── best_peer_for — new capability kinds ───────────────────────────

async def test_best_peer_for_new_capability_returns_none_when_nobody_reports_it():
    """The core has_capability() guarantee: chat-only members must
    never be recommended as a vision peer just because they tie at the
    DEGRADED sentinel for a capability they've never mentioned."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://chat-only.com", 2.0, 1.0, 0)   # no vision at all
    best = await m.best_peer_for("vision", exclude_url="https://other.com")
    assert best is None


async def test_best_peer_for_new_capability_ignores_non_reporters():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://chat-only.com", 0.5, 0.5, 0)   # would "win" if considered
    await m.upsert("https://vision-node.com", 2.0, 1.0, 0,
                   capability_avg_s={"vision": 4.0})
    best = await m.best_peer_for("vision", exclude_url="https://other.com")
    assert best == "https://vision-node.com"


async def test_best_peer_for_new_capability_argmin_among_reporters():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://fast-vision.com", 0, 0, 0, capability_avg_s={"vision": 1.5})
    await m.upsert("https://slow-vision.com", 0, 0, 0, capability_avg_s={"vision": 5.0})
    best = await m.best_peer_for("vision", exclude_url="https://other.com")
    assert best == "https://fast-vision.com"


async def test_best_peer_for_new_capability_excludes_self():
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://self.com", 0, 0, 0, capability_avg_s={"vision": 0.5})
    await m.upsert("https://other.com", 0, 0, 0, capability_avg_s={"vision": 2.0})
    best = await m.best_peer_for("vision", exclude_url="https://self.com")
    assert best == "https://other.com"


async def test_best_peer_for_new_capability_applies_rotation_bump():
    m = FederationMatrix(missed_after_s=60.0, peer_advice_bump_s=0.5)
    await m.upsert("https://a.com", 0, 0, 0, capability_avg_s={"vision": 2.0})
    await m.best_peer_for("vision", exclude_url="https://x.com")
    assert m.members["https://a.com"].capability_avg_s["vision"] == pytest.approx(2.5)


async def test_best_peer_for_new_capability_stale_member_excluded():
    """A member that HAS reported vision but hasn't checked in recently
    must still fall out via is_alive(), same as llm/tts always have."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://stale.com", 0, 0, 0, capability_avg_s={"vision": 0.1})
    m.members["https://stale.com"].last_seen = time.monotonic() - 120  # long gone
    await m.upsert("https://fresh.com", 0, 0, 0, capability_avg_s={"vision": 5.0})
    best = await m.best_peer_for("vision", exclude_url="https://other.com")
    assert best == "https://fresh.com"


async def test_legacy_llm_tts_best_peer_for_unaffected_by_capability_additions():
    """Sanity check: adding has_capability() filtering must not change
    llm/tts behavior — every alive member is always a candidate for
    those two, exactly as before."""
    m = FederationMatrix(missed_after_s=60.0)
    await m.upsert("https://a.com", 1.5, 0.8, 0)   # no capability_avg_s at all
    best = await m.best_peer_for("llm", exclude_url="https://other.com")
    assert best == "https://a.com"


# ─── Old-format state file loads fine ───────────────────────────────

async def test_old_format_state_file_loads_without_capability_avg_s(tmp_path):
    """Simulates a state file written by pre-Sprint-6 code — no
    capability_avg_s key anywhere. Must load cleanly."""
    import json
    state_file = tmp_path / "old_state.json"
    state_file.write_text(json.dumps({
        "members": [
            {"url": "https://a.com", "llm_avg_s": 2.0, "tts_avg_s": 1.0,
             "tokens_out": 100, "last_seen": time.time()},
        ],
        "saved_at": time.time(),
    }))
    m = FederationMatrix(state_file=state_file, missed_after_s=60.0)
    assert "https://a.com" in m.members
    assert m.members["https://a.com"].llm_avg_s == 2.0
    assert m.members["https://a.com"].capability_avg_s == {}


async def test_new_format_state_file_round_trips_capability_avg_s(tmp_path):
    state_file = tmp_path / "state.json"
    m1 = FederationMatrix(state_file=state_file, missed_after_s=60.0)
    await m1.upsert("https://a.com", 2.0, 1.0, 100,
                    capability_avg_s={"vision": 3.5, "imagine": 6.0})
    m2 = FederationMatrix(state_file=state_file, missed_after_s=60.0)
    assert m2.members["https://a.com"].capability_avg_s == {"vision": 3.5, "imagine": 6.0}


# ─── FederationConfig.node_type ─────────────────────────────────────

def test_node_type_defaults_to_chat():
    fc = FederationConfig()
    assert fc.node_type == "chat"
    assert DEFAULTS["node_type"] == "chat"


def test_node_type_parses_from_cfg(tmp_path):
    import configparser
    ini_path = tmp_path / "federation.ini"
    ini_path.write_text("[Federation]\nnode_type = vision\n")
    cfg = configparser.ConfigParser()
    cfg.read(ini_path)
    fc = FederationConfig.from_cfg(cfg)
    assert fc.node_type == "vision"


def test_node_type_missing_key_falls_back_to_chat(tmp_path):
    import configparser
    ini_path = tmp_path / "federation.ini"
    ini_path.write_text("[Federation]\ndesire = on\n")   # no node_type at all
    cfg = configparser.ConfigParser()
    cfg.read(ini_path)
    fc = FederationConfig.from_cfg(cfg)
    assert fc.node_type == "chat"


# ─── FederationClient — capability_avg_s / node_type / best_peer ────

class _MockResp:
    def __init__(self, body, status=200):
        self._body = body
        self.status = status
    async def json(self):
        return self._body
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass


async def test_checkin_payload_includes_capability_avg_s_when_present():
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate",
                           node_type="vision")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 4.2, "tts_avg_s": 1.8, "tokens_out": 1000,
        "capability_avg_s": {"vision": 2.1}})
    client = FederationClient(state)

    captured = {}
    def mock_post(url, json=None):
        captured["payload"] = json
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None})

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()

    assert captured["payload"]["capability_avg_s"] == {"vision": 2.1}
    assert captured["payload"]["node_type"] == "vision"


async def test_checkin_payload_omits_capability_avg_s_when_stats_dont_provide_one():
    """Backward compat on the SENDING side: a stats callable that only
    returns the old llm_avg_s/tts_avg_s/tokens_out shape (as if this
    were pre-Sprint-6 orchestrator wiring) must not crash, and must not
    send a bogus empty capability_avg_s key."""
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 4.2, "tts_avg_s": 1.8, "tokens_out": 1000})
    client = FederationClient(state)

    captured = {}
    def mock_post(url, json=None):
        captured["payload"] = json
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None})

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()

    assert "capability_avg_s" not in captured["payload"]
    assert captured["payload"]["node_type"] == "chat"   # default


async def test_checkin_response_stores_best_peer_dict():
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    client = FederationClient(state)

    def mock_post(url, json=None):
        return _MockResp({
            "best_llm_peer": "https://a.example",
            "best_tts_peer": None,
            "best_peer": {"vision": "https://vision-peer.example"},
        })

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()

    assert state.best_peer == {"vision": "https://vision-peer.example"}


async def test_checkin_response_missing_best_peer_defaults_empty_dict():
    """A pre-Sprint-6 Federator's response has no best_peer key at all."""
    cfg = FederationConfig(desire=True, self_url="https://me.example",
                           master_url="https://fed.example/api/federate")
    state = FederationState(cfg, lambda: {
        "llm_avg_s": 1.0, "tts_avg_s": 1.0, "tokens_out": 0})
    client = FederationClient(state)

    def mock_post(url, json=None):
        return _MockResp({"best_llm_peer": None, "best_tts_peer": None})

    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        await client._do_checkin()

    assert state.best_peer == {}


async def test_to_ui_dict_includes_node_type_and_best_peer():
    cfg = FederationConfig(desire=True, node_type="imagine")
    state = FederationState(cfg, lambda: {})
    state.best_peer = {"vision": "https://v.example"}
    d = state.to_ui_dict()
    assert d["node_type"] == "imagine"
    assert d["best_peer"] == {"vision": "https://v.example"}
