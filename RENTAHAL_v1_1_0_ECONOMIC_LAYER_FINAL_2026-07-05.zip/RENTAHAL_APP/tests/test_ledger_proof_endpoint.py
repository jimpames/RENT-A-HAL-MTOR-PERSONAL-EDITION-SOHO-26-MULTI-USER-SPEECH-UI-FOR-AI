"""
Sprint 12 — end-to-end HTTP integration test for /api/ledger/proof and
/api/ledger/proof/info, against a REALLY booted app with a real
Postgres-backed Ledger connected via lifespan startup.

This is the one piece of Sprint 12's wiring that test_ots_anchor.py
doesn't cover — that file tests the module and DB-store in isolation;
this file proves the actual FastAPI endpoints work end to end,
including the [Ledger] dsn config gate (endpoints absent entirely when
unset) and the lifespan-managed async connection.
"""
import asyncio
import hashlib
import os
import sys
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

asyncpg = pytest.importorskip("asyncpg")

os.environ["RENTAHAL_FAKE_ENGINES"] = "1"

from realm.ledger import Ledger
from realm.ots_anchor import OtsAnchorStore

FIXTURES = Path(__file__).parent / "fixtures"
HELLO_WORLD_TXT = FIXTURES / "hello-world.txt"
HELLO_WORLD_OTS = FIXTURES / "hello-world.txt.ots"

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


async def _postgres_reachable() -> bool:
    try:
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


async def _run_server(app, port):
    import uvicorn
    server = uvicorn.Server(uvicorn.Config(
        app, host="127.0.0.1", port=port, log_level="warning"))
    task = asyncio.create_task(server.serve())
    for _ in range(200):
        if server.started:
            break
        await asyncio.sleep(0.02)
    return server, task


@pytest.mark.asyncio
async def test_ledger_proof_endpoints_absent_when_not_configured(tmp_path):
    """No [Ledger] dsn at all -> the endpoints must not exist (404),
    not just return an empty/error response — same "opt-in means
    genuinely absent" posture as every other feature."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    import app as app_module
    cfg = app_module.load_ini()
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)
    server, task = await _run_server(app, 9997)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:9997/api/ledger/proof") as r:
                assert r.status == 404
            async with s.get("http://127.0.0.1:9997/api/ledger/proof/info") as r:
                assert r.status == 404
    finally:
        server.should_exit = True
        await task


@pytest.mark.asyncio
async def test_ledger_proof_info_404_when_no_anchor_yet(tmp_path):
    """Ledger IS configured and connects, but no anchor has been
    stamped yet — must be a clean 404 with a helpful message, not a
    500 or an empty 200."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_endpoint_test_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()
    dsn = BASE_DSN.rsplit("/", 1)[0] + f"/{db_name}"

    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(f"[Ledger]\ndsn = {dsn}\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)
    server, task = await _run_server(app, 9998)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:9998/api/ledger/proof") as r:
                assert r.status == 404
            async with s.get("http://127.0.0.1:9998/api/ledger/proof/info") as r:
                assert r.status == 404
    finally:
        server.should_exit = True
        await task
        admin_conn = await asyncpg.connect(BASE_DSN)
        await admin_conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
        await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
        await admin_conn.close()


@pytest.mark.asyncio
async def test_ledger_proof_endpoints_serve_real_anchor(tmp_path):
    """The real path: seed a genuine anchor (using the real fixture
    proof) directly via OtsAnchorStore before the app boots, then
    confirm both endpoints serve it correctly over real HTTP."""
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")
    db_name = f"rentahal_endpoint_test_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()
    dsn = BASE_DSN.rsplit("/", 1)[0] + f"/{db_name}"

    # Seed a real anchor before booting the app.
    seed_ledger = await Ledger.connect(dsn)
    store = OtsAnchorStore(seed_ledger)
    digest_hex = hashlib.sha256(HELLO_WORLD_TXT.read_bytes()).hexdigest()
    proof_bytes = HELLO_WORLD_OTS.read_bytes()
    anchor_id = await store.record_new_stamp(1, digest_hex, proof_bytes)
    await store.mark_upgrade_attempted(anchor_id, proof_bytes, is_complete=True)
    await seed_ledger.close()

    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(f"[Ledger]\ndsn = {dsn}\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    app = app_module.create_app(cfg, logger)
    server, task = await _run_server(app, 9999)
    try:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            # /api/ledger/proof serves the exact raw bytes.
            async with s.get("http://127.0.0.1:9999/api/ledger/proof") as r:
                assert r.status == 200
                body = await r.read()
                assert body == proof_bytes
                assert "ledger.ots" in r.headers.get("Content-Disposition", "")

            # /api/ledger/proof/info gives correct, real details.
            async with s.get("http://127.0.0.1:9999/api/ledger/proof/info") as r:
                assert r.status == 200
                info = await r.json()
                assert info["chain_tip_hash"] == digest_hex
                assert info["is_complete"] is True
                assert len(info["bitcoin_attestations"]) == 1
                assert info["bitcoin_attestations"][0]["block_height"] == 358391
                assert len(info["how_to_verify_independently"]) > 0
    finally:
        server.should_exit = True
        await task
        admin_conn = await asyncpg.connect(BASE_DSN)
        await admin_conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
        await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
        await admin_conn.close()
