// run_destroy_recreate_test.js — regression tests for the user's
// design instinct: "DESTROY that area just prior to presenting new
// service search cards...music video....news....ai chat... etc..."
//
// Implementation: a destroyAndRecreate(id) helper that replaces the
// element in the DOM with a fresh clone (cloneNode(false)). This is
// stronger than innerHTML='' because it eliminates:
//   - layout cache staleness on the container
//   - YouTube iframe lingering attachments
//   - any event listeners that may have been attached
//   - any internal browser state tied to the old element
//
// The fresh element has the SAME id, class, and inline style attributes
// (because cloneNode(false) copies attributes) but ZERO inherited state.
//
// Applied to the three card-rendering entry points:
//   1. renderNewsStories     → destroys #news-stories
//   2. renderYouTubeEmbed    → destroys #music-player-container
//   3. openServicesPanel     → destroys #services-results
//
// (Not applied to #answer for AI chat because that has many cached
// callers using `answerEl` and the simple text container hasn't shown
// the stale-state symptom.)

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── The helper exists and uses cloneNode(false) ──────────────

assert(/function destroyAndRecreate/.test(html),
       'destroyAndRecreate helper function exists');

const helpIdx = html.indexOf('function destroyAndRecreate');
const helpEnd = html.indexOf('\nfunction ', helpIdx + 1);
const helpSrc = html.slice(helpIdx, helpEnd);

assert(/cloneNode\(\s*false\s*\)/.test(helpSrc),
       'helper uses cloneNode(false) — preserves tag/id/attrs, drops children');
assert(/replaceChild/.test(helpSrc),
       'helper uses replaceChild to swap the element in place');
assert(/parentNode/.test(helpSrc),
       'helper navigates via parentNode for the swap');
assert(/return\s+fresh/.test(helpSrc),
       'helper returns the fresh element so caller can use it directly');
// Defensive guards
assert(/if\s*\(\s*!old\s*\)/.test(helpSrc),
       'helper guards against missing element (returns null)');
assert(/if\s*\(\s*!old\.parentNode\s*\)/.test(helpSrc),
       'helper guards against orphan element (returns old, not crash)');

// Diagnostic log so we can see when recreation happens
assert(/console\.log\(['"`]\[destroy\]/.test(helpSrc),
       'helper logs [destroy] diagnostic on success');

// ─── Each render function uses destroyAndRecreate at the top ──

// News
const newsIdx = html.indexOf('function renderNewsStories');
const newsEnd = html.indexOf('\nfunction ', newsIdx + 1);
const newsSrc = html.slice(newsIdx, newsEnd);
assert(/destroyAndRecreate\(['"]news-stories['"]\)/.test(newsSrc),
       'renderNewsStories destroys #news-stories before rendering');
// Order: must happen near the top (before any rendering work)
const newsDestroyIdx = newsSrc.indexOf('destroyAndRecreate');
const newsRenderIdx = newsSrc.indexOf('for (const source');
assert(newsDestroyIdx > 0 &&
       (newsRenderIdx === -1 || newsDestroyIdx < newsRenderIdx),
       'renderNewsStories destroys BEFORE rendering loop');

// Music (YouTube embed)
const ytIdx = html.indexOf('function renderYouTubeEmbed');
const ytEnd = html.indexOf('\nfunction ', ytIdx + 1);
const ytSrc = html.slice(ytIdx, ytEnd);
assert(/destroyAndRecreate\(['"]music-player-container['"]\)/.test(ytSrc),
       'renderYouTubeEmbed destroys #music-player-container before rendering');
const ytDestroyIdx = ytSrc.indexOf('destroyAndRecreate');
const ytIframeIdx = ytSrc.indexOf('createElement(\'iframe\')');
assert(ytDestroyIdx > 0 && ytDestroyIdx < ytIframeIdx,
       'renderYouTubeEmbed destroys BEFORE creating iframe');

// Services
const svcIdx = html.indexOf('function openServicesPanel');
const svcEnd = html.indexOf('\nfunction ', svcIdx + 1);
const svcSrc = html.slice(svcIdx, svcEnd);
assert(/destroyAndRecreate\(['"]services-results['"]\)/.test(svcSrc),
       'openServicesPanel destroys #services-results before rendering');
const svcDestroyIdx = svcSrc.indexOf('destroyAndRecreate');
const svcRenderIdx = svcSrc.indexOf('results.forEach');
assert(svcDestroyIdx > 0 &&
       (svcRenderIdx === -1 || svcDestroyIdx < svcRenderIdx),
       'openServicesPanel destroys BEFORE rendering loop');

// ─── Defensive fallback if destroy returns null ───────────────
// Each caller falls back to getElementById so a failure to destroy
// doesn't crash the render path — the function still renders.

assert(/destroyAndRecreate\(['"]news-stories['"]\)\s*\|\|\s*\n*\s*document\.getElementById/.test(newsSrc),
       'renderNewsStories falls back to getElementById if destroy returns null');
assert(/destroyAndRecreate\(['"]music-player-container['"]\)\s*\|\|\s*\n*\s*document\.getElementById/.test(ytSrc),
       'renderYouTubeEmbed falls back to getElementById if destroy returns null');
assert(/destroyAndRecreate\(['"]services-results['"]\)\s*\|\|\s*\n*\s*document\.getElementById/.test(svcSrc),
       'openServicesPanel falls back to getElementById if destroy returns null');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} destroy-recreate tests passed`);
  process.exit(0);
}
