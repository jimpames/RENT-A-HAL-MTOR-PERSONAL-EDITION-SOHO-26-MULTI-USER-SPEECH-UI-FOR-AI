"""
test_degraded_tracker.py — Wall-clock degraded watchdog tests.

Covers:
  - Initial state: is_degraded() False, no callbacks fired
  - mark_federated starts the wall-clock on first call
  - is_degraded flips to True after wall-clock crosses threshold
  - on_degraded callback fires ONCE per transition (not every call)
  - mark_local_recovered resets the timer and clears degraded
  - on_recovered callback fires only when actually exiting degraded
  - Recovery before threshold: timer cleared without recovery callback
  - Callback exceptions don't propagate (must not block query path)
  - Independent trackers for LLM and TTS — neither affects the other
  - elapsed_s reflects monotonic time correctly
  - to_ui_dict snapshot for cockpit
"""
import time
from unittest.mock import MagicMock

import pytest

from realm.degraded_tracker import DegradedTracker


# ─── Initial state ───────────────────────────────────────────────────


def test_initial_state_not_degraded():
    """Fresh tracker reports not degraded — no federation observed yet."""
    t = DegradedTracker(chain_label="LLM", degraded_after_s=300.0)
    assert t.is_degraded() is False
    assert t.elapsed_s() == 0.0


def test_initial_state_no_callbacks_fired():
    """A tracker that's never been touched fires no callbacks."""
    on_degraded = MagicMock()
    on_recovered = MagicMock()
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=300.0,
        on_degraded=on_degraded, on_recovered=on_recovered)
    # is_degraded check is a query, not a state change — no callback
    t.is_degraded()
    on_degraded.assert_not_called()
    on_recovered.assert_not_called()


def test_recovery_on_initial_state_is_noop():
    """Calling mark_local_recovered when no federation has happened
    is a no-op — no callback, no state change."""
    on_recovered = MagicMock()
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=300.0,
        on_recovered=on_recovered)
    t.mark_local_recovered()
    on_recovered.assert_not_called()
    assert t.is_degraded() is False


# ─── Transition into degraded ────────────────────────────────────────


def test_mark_federated_starts_clock():
    """First mark_federated sets the timer. is_degraded still False
    immediately after (we haven't crossed threshold yet)."""
    t = DegradedTracker(chain_label="LLM", degraded_after_s=300.0)
    t.mark_federated()
    assert t.is_degraded() is False
    # elapsed_s should be tiny (sub-second) but non-zero after the call
    assert 0.0 <= t.elapsed_s() < 1.0


def test_repeated_mark_federated_does_not_restart_clock():
    """Calling mark_federated many times doesn't reset the timer. The
    first call started the clock; subsequent calls only update
    _last_federated_at."""
    t = DegradedTracker(chain_label="LLM", degraded_after_s=300.0)
    t.mark_federated()
    first_elapsed = t.elapsed_s()
    # Sleep a tiny bit, call again
    time.sleep(0.01)
    t.mark_federated()
    second_elapsed = t.elapsed_s()
    # The clock kept running — second elapsed is greater than first
    assert second_elapsed >= first_elapsed


def test_degraded_flips_after_threshold_crossed(monkeypatch):
    """After degraded_after_s of wall-clock time, is_degraded flips
    True. We mock time.monotonic to skip the wait."""
    # Use a small threshold and mock monotonic to advance past it
    t = DegradedTracker(chain_label="LLM", degraded_after_s=10.0)

    # Track the simulated time. Initial monotonic = 1000.0
    sim_time = [1000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])

    t.mark_federated()                     # clock starts at sim 1000
    assert t.is_degraded() is False        # 0s elapsed
    sim_time[0] = 1005.0                   # 5s — under threshold
    assert t.is_degraded() is False
    sim_time[0] = 1011.0                   # 11s — over threshold
    assert t.is_degraded() is True


def test_on_degraded_callback_fires_once(monkeypatch):
    """on_degraded fires exactly once per degraded episode, not on
    every mark_federated/is_degraded after the transition."""
    on_degraded = MagicMock()
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=10.0,
        on_degraded=on_degraded)

    sim_time = [2000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])

    t.mark_federated()                     # clock starts
    sim_time[0] = 2015.0                   # over threshold
    t.mark_federated()                     # this should trigger
    assert on_degraded.call_count == 1
    t.mark_federated()                     # already degraded
    t.mark_federated()
    t.is_degraded()
    t.is_degraded()
    assert on_degraded.call_count == 1     # still 1


def test_on_degraded_callback_receives_chain_and_elapsed(monkeypatch):
    """Callback signature: on_degraded(chain_label, elapsed_s)."""
    captured = []
    def cb(chain, elapsed):
        captured.append((chain, elapsed))
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=10.0, on_degraded=cb)

    sim_time = [3000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])

    t.mark_federated()
    sim_time[0] = 3020.0
    t.mark_federated()
    assert len(captured) == 1
    chain, elapsed = captured[0]
    assert chain == "LLM"
    assert elapsed >= 10.0


def test_is_degraded_can_trigger_callback_lazy(monkeypatch):
    """Edge case: time advances between mark_federated calls and the
    operator's first is_degraded check. The callback should still fire
    on the is_degraded call that observes the transition."""
    on_degraded = MagicMock()
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=10.0,
        on_degraded=on_degraded)

    sim_time = [4000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])

    t.mark_federated()                     # start clock
    sim_time[0] = 4020.0
    # No subsequent mark_federated. is_degraded is the only call.
    assert t.is_degraded() is True
    assert on_degraded.call_count == 1


# ─── Transition out of degraded ──────────────────────────────────────


def test_recovery_clears_degraded(monkeypatch):
    """mark_local_recovered() flips is_degraded back to False."""
    t = DegradedTracker(chain_label="LLM", degraded_after_s=10.0)

    sim_time = [5000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])
    t.mark_federated()
    sim_time[0] = 5020.0
    t.mark_federated()
    assert t.is_degraded() is True

    t.mark_local_recovered()
    assert t.is_degraded() is False
    assert t.elapsed_s() == 0.0


def test_on_recovered_fires_only_when_was_degraded(monkeypatch):
    """The recovery callback fires only when we actually exit degraded.
    If we federated some but never crossed the threshold, recovery is
    quiet — there was no observable degraded transition to recover from."""
    on_recovered = MagicMock()
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=10.0,
        on_recovered=on_recovered)

    sim_time = [6000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])
    t.mark_federated()                     # start
    sim_time[0] = 6005.0                   # under threshold
    t.mark_local_recovered()
    on_recovered.assert_not_called()       # no transition to recover from
    assert t.is_degraded() is False


def test_on_recovered_fires_when_actually_recovering(monkeypatch):
    """When we DID cross the threshold and then recover, on_recovered
    fires exactly once."""
    on_recovered = MagicMock()
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=10.0,
        on_recovered=on_recovered)

    sim_time = [7000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])
    t.mark_federated()
    sim_time[0] = 7020.0
    t.mark_federated()
    assert t.is_degraded() is True

    t.mark_local_recovered()
    on_recovered.assert_called_once_with("LLM")


def test_re_entering_degraded_after_recovery(monkeypatch):
    """Operator restarts engine, it recovers, then crashes again. We
    enter degraded → recover → enter degraded → recover → ..."""
    on_degraded = MagicMock()
    on_recovered = MagicMock()
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=10.0,
        on_degraded=on_degraded, on_recovered=on_recovered)

    sim_time = [8000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])

    # Episode 1
    t.mark_federated(); sim_time[0] = 8020.0; t.mark_federated()
    t.mark_local_recovered()
    # Episode 2
    sim_time[0] = 9000.0
    t.mark_federated(); sim_time[0] = 9020.0; t.mark_federated()
    t.mark_local_recovered()
    # Each episode should have fired callbacks exactly once
    assert on_degraded.call_count == 2
    assert on_recovered.call_count == 2


# ─── Callback safety ─────────────────────────────────────────────────


def test_on_degraded_exception_does_not_propagate(monkeypatch):
    """A buggy callback must not block the query path. Exceptions are
    logged and swallowed."""
    def bad(chain, elapsed):
        raise RuntimeError("callback exploded")
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=10.0,
        on_degraded=bad)
    sim_time = [10000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])
    t.mark_federated()
    sim_time[0] = 10020.0
    # Must NOT raise
    t.mark_federated()
    assert t.is_degraded() is True


def test_on_recovered_exception_does_not_propagate(monkeypatch):
    def bad(chain):
        raise RuntimeError("recovery callback exploded")
    t = DegradedTracker(
        chain_label="LLM", degraded_after_s=10.0,
        on_recovered=bad)
    sim_time = [11000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])
    t.mark_federated()
    sim_time[0] = 11020.0
    t.mark_federated()
    # Must NOT raise
    t.mark_local_recovered()
    assert t.is_degraded() is False


# ─── Independence: LLM tracker doesn't affect TTS and vice versa ────


def test_independent_trackers():
    """LLM and TTS chains fail independently. Two trackers must not
    share any state."""
    llm_t = DegradedTracker(chain_label="LLM", degraded_after_s=10.0)
    tts_t = DegradedTracker(chain_label="TTS", degraded_after_s=10.0)
    llm_t.mark_federated()
    # TTS tracker should still be untouched
    assert tts_t.elapsed_s() == 0.0
    assert tts_t.is_degraded() is False


def test_to_ui_dict_shape():
    """The cockpit snapshot has chain, degraded, elapsed_s, threshold_s."""
    t = DegradedTracker(chain_label="LLM", degraded_after_s=300.0)
    snap = t.to_ui_dict()
    assert snap["chain"] == "LLM"
    assert snap["degraded"] is False
    assert snap["elapsed_s"] == 0.0
    assert snap["threshold_s"] == 300.0


def test_to_ui_dict_reflects_degraded(monkeypatch):
    t = DegradedTracker(chain_label="TTS", degraded_after_s=10.0)
    sim_time = [12000.0]
    monkeypatch.setattr(
        "realm.degraded_tracker.time.monotonic",
        lambda: sim_time[0])
    t.mark_federated()
    sim_time[0] = 12020.0
    snap = t.to_ui_dict()
    assert snap["degraded"] is True
    assert snap["elapsed_s"] >= 10.0
