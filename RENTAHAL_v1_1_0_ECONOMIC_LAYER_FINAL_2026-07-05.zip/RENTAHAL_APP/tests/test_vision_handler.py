"""
Regression tests for make_vision_handler — runs a webcam frame through
the VisionChain and threads the result into the query_result/answer-box
pipeline, with a shared easter-egg-video bus event when the Echo floor
fires (see engine_chain.py's EchoVisionProvider).

These tests use a fake VisionChain (same shape as engine_chain.py's real
one: async describe(), .last_provider) rather than standing up a real
LLaVA server — mirrors how test_music_handler.py fakes aiohttp instead
of hitting DuckDuckGo for real.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

pytestmark = pytest.mark.asyncio


class FakeBus:
    """Captures published bus events for inspection."""
    def __init__(self):
        self.events = []

    async def publish(self, event_type, **payload):
        self.events.append({"type": event_type, "payload": payload})


class FakeVisionChain:
    """Same call shape as engine_chain.VisionChain — describe() + last_provider."""
    def __init__(self, describe_result, last_provider):
        self._describe_result = describe_result
        self.last_provider = last_provider
        self.calls = []

    async def describe(self, image_b64, prompt="What do you see?"):
        self.calls.append({"image_b64": image_b64, "prompt": prompt})
        return self._describe_result


FAKE_FRAME = "ZmFrZWZyYW1lYnl0ZXM="   # "fakeframebytes"


async def test_real_provider_answers_with_description_only():
    """When a real provider (not Echo) answers, no easter-egg event
    should fire — just the description text."""
    from app import make_vision_handler
    chain = FakeVisionChain(
        describe_result="A red ball on a wooden table.",
        last_provider="LLaVA (llava)")
    bus = FakeBus()
    handler = make_vision_handler({}, chain)

    result = await handler(FAKE_FRAME, {}, "test-user", bus)

    assert result == "A red ball on a wooden table."
    assert bus.events == []


async def test_echo_floor_fires_easter_egg_video():
    """When the Echo floor answers, the vision handler must publish the
    shared easter_egg_video event with source='vision' AND still return
    the floor's spoken text."""
    from app import make_vision_handler
    from realm.engine_chain import EchoVisionProvider
    chain = FakeVisionChain(
        describe_result="I heard you ask what I see, but no vision "
                        "model is currently online to look.",
        last_provider=EchoVisionProvider.name)
    bus = FakeBus()
    handler = make_vision_handler({}, chain)

    result = await handler(FAKE_FRAME, {}, "test-user", bus)

    assert "no vision model" in result.lower()
    assert len(bus.events) == 1
    ev = bus.events[0]
    assert ev["type"] == "easter_egg_video"
    assert ev["payload"]["source"] == "vision"
    assert ev["payload"]["youtube_id"] == EchoVisionProvider.EASTER_EGG_YOUTUBE_ID
    assert ev["payload"]["user_guid"] == "test-user"


async def test_missing_image_short_circuits_without_calling_chain():
    """No webcam frame (permission denied, capture failed, or the
    browser's pre-emptive guess was wrong) must not call the chain at
    all — just a friendly apology."""
    from app import make_vision_handler
    chain = FakeVisionChain(describe_result="should never be returned",
                            last_provider="LLaVA (llava)")
    bus = FakeBus()
    handler = make_vision_handler({}, chain)

    result = await handler(None, {}, "test-user", bus)

    assert "camera" in result.lower() or "picture" in result.lower()
    assert chain.calls == []
    assert bus.events == []


async def test_empty_string_image_also_short_circuits():
    from app import make_vision_handler
    chain = FakeVisionChain(describe_result="should never be returned",
                            last_provider="LLaVA (llava)")
    handler = make_vision_handler({}, chain)

    result = await handler("", {}, "test-user", FakeBus())

    assert chain.calls == []
    assert len(result) > 0


async def test_chain_receives_the_actual_frame_and_default_prompt():
    from app import make_vision_handler
    chain = FakeVisionChain(describe_result="a description",
                            last_provider="LLaVA (llava)")
    handler = make_vision_handler({}, chain)

    await handler(FAKE_FRAME, {}, "test-user", FakeBus())

    assert len(chain.calls) == 1
    assert chain.calls[0]["image_b64"] == FAKE_FRAME
    assert chain.calls[0]["prompt"] == "What do you see?"
