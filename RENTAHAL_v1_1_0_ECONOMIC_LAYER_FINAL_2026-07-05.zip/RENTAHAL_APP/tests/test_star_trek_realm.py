"""
Comprehensive harness for the Star Trek voice realm.

Layers:
  1. Bus invariants            : isolation, concurrency, ping/pong, unsub-during-handler
  2. Intent algebra            : doubled STOP/REPEAT, single-word, n-gram ask, slots
  3. Chain fall-through        : LLM and TTS chains try providers in order, skip dead
  4. Orchestrator integration  : full pipeline, STOP kills TTS, REPEAT replays
  5. Star Trek end-to-end      : wake -> capture -> stt -> intent -> answer -> speak
"""

import asyncio
import base64
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pytest

from realm.event_bus import EventBus, Event
from realm.intent import IntentClassifier
import realm.intent as intent_mod
from realm.engine_chain import (LLMChain, TTSChain, EchoLLMProvider, EchoTTSProvider,
                          LLMProvider, TTSProvider)
from realm.orchestrator import Orchestrator

pytestmark = pytest.mark.asyncio


# ===========================================================================
# Layer 1 — Bus invariants
# ===========================================================================

async def test_bus_publish_never_raises_on_bad_subscriber():
    bus = EventBus()
    fired = []

    async def good(ev): fired.append(ev.type)
    async def bad(ev): raise RuntimeError("subscriber explosion")

    await bus.subscribe("test", good)
    await bus.subscribe("test", bad)
    await bus.publish_wait("test", x=1)
    assert "test" in fired, "good subscriber was starved by bad one"


async def test_bus_concurrent_subscribers_do_not_starve():
    bus = EventBus()
    started = []
    finished = []

    async def slow(ev):
        started.append("slow"); await asyncio.sleep(0.2); finished.append("slow")
    async def fast(ev):
        started.append("fast"); finished.append("fast")

    await bus.subscribe("go", slow)
    await bus.subscribe("go", fast)
    await bus.publish_wait("go")
    # Fast should finish before slow even though slow was subscribed first
    assert finished[0] == "fast", "slow subscriber starved fast one"


async def test_bus_unsubscribe_during_handler_does_not_crash():
    bus = EventBus()
    count = [0]

    async def once(ev):
        count[0] += 1
        await bus.unsubscribe("burst", once)

    await bus.subscribe("burst", once)
    for _ in range(5):
        await bus.publish_wait("burst")
    assert count[0] == 1, f"unsub-from-inside-handler failed; ran {count[0]}x"


async def test_bus_ping_counts_subscribers_without_invoking_them():
    bus = EventBus()
    called = [0]
    async def h(ev): called[0] += 1

    assert bus.ping("foo") == 0
    await bus.subscribe("foo", h)
    assert bus.ping("foo") == 1
    assert called[0] == 0, "ping invoked the handler"


async def test_bus_wildcard_receives_everything():
    bus = EventBus()
    seen = []
    async def trace(ev): seen.append(ev.type)
    await bus.subscribe_all(trace)
    await bus.publish_wait("alpha")
    await bus.publish_wait("beta", n=1)
    await bus.publish_wait("gamma")
    assert seen == ["alpha", "beta", "gamma"]


# ===========================================================================
# Layer 2 — Intent algebra
# ===========================================================================

async def test_doubled_stop_fires_intent_stop_not_classified():
    bus = EventBus()
    clf = IntentClassifier(bus)
    await clf.attach()
    captured = {}
    async def cap_stop(ev): captured["stop"] = ev.payload
    async def cap_class(ev): captured["class"] = ev.payload
    await bus.subscribe("intent_stop", cap_stop)
    await bus.subscribe("intent_classified", cap_class)
    await bus.publish_wait("prompt_text", text="stop stop", nonce="n1")
    await asyncio.sleep(0.05)
    assert "stop" in captured, "doubled STOP did not fire intent_stop"
    assert "class" not in captured, "doubled STOP wrongly also fired intent_classified"


async def test_single_stop_does_not_fire_stop():
    """'I want to stop for coffee' must NOT abort TTS."""
    clf = IntentClassifier(EventBus())
    intent = clf.classify("I want to stop for coffee")
    assert intent.kind != "stop", \
        f"single 'stop' wrongly classified as stop: {intent}"


async def test_doubled_repeat_fires_intent_repeat():
    bus = EventBus()
    clf = IntentClassifier(bus)
    await clf.attach()
    fired = []
    await bus.subscribe("intent_repeat", lambda ev: fired.append(ev) or asyncio.sleep(0))
    await bus.publish_wait("prompt_text", text="repeat repeat please", nonce="n2")
    await asyncio.sleep(0.05)
    assert len(fired) == 1, "doubled REPEAT did not fire"


async def test_weather_intent_extracts_location_slot():
    clf = IntentClassifier(EventBus())
    intent = clf.classify("weather in San Francisco tomorrow")
    assert intent.kind == "weather"
    assert intent.slots.get("location") == "san francisco", \
        f"location slot wrong: {intent.slots}"
    assert intent.slots.get("when") == "tomorrow"


async def test_ask_intent_scores_questions_above_threshold():
    clf = IntentClassifier(EventBus())
    high = clf.classify("what is the capital of France")
    low = clf.classify("uhh well i mean kinda")
    assert high.kind == "ask"
    assert high.confidence > low.confidence, \
        f"question scoring did not separate clear question from filler"


async def test_gmail_intent_recognized():
    clf = IntentClassifier(EventBus())
    for phrase in ("gmail", "check my email", "any new mail"):
        intent = clf.classify(phrase)
        assert intent.kind == "gmail", f"{phrase!r} -> {intent.kind}"


# ===========================================================================
# Layer 3 — Chain fall-through
# ===========================================================================

class DeadLLM(LLMProvider):
    name = "Dead LLM"
    async def is_available(self): return False
    async def generate(self, prompt, max_tokens=400): return None


class WorkingLLM(LLMProvider):
    name = "Working LLM"
    def __init__(self): self.calls = 0
    async def is_available(self): return True
    async def generate(self, prompt, max_tokens=400):
        self.calls += 1
        return f"answered: {prompt}"


async def test_llm_chain_skips_unavailable_provider():
    working = WorkingLLM()
    chain = LLMChain([DeadLLM(), working, EchoLLMProvider()])
    result = await chain.generate("hello?")
    assert result == "answered: hello?"
    assert chain.last_provider == "Working LLM"
    assert working.calls == 1


async def test_llm_chain_falls_to_echo_when_all_dead():
    chain = LLMChain([DeadLLM(), DeadLLM(), EchoLLMProvider()])
    result = await chain.generate("anyone home?")
    assert "I heard you ask" in result
    assert chain.last_provider == "Echo (offline fallback)"


class DeadTTS(TTSProvider):
    name = "Dead TTS"
    async def is_available(self): return False
    async def synth(self, text): return None


async def test_tts_chain_falls_through_to_echo():
    chain = TTSChain([DeadTTS(), DeadTTS(), EchoTTSProvider()])
    audio = await chain.synth("hello")
    assert audio is not None
    assert chain.last_provider == "Echo TTS (test)"


async def test_tts_chain_returns_none_when_all_fail():
    class FailingTTS(TTSProvider):
        name = "FT"
        async def is_available(self): return True
        async def synth(self, text): return None
    chain = TTSChain([FailingTTS()])
    assert await chain.synth("anything") is None
    assert chain.last_provider == "none"


async def test_provider_can_come_online_after_boot():
    """The whole point of the recheck pattern: a GPT4All started AFTER the
    realm boots must be picked up on the very next request without a restart."""
    class FlakeProvider(LLMProvider):
        name = "Flake"
        def __init__(self): self.up = False
        async def is_available(self): return self.up
        async def generate(self, prompt, max_tokens=400):
            return "now available" if self.up else None
    flake = FlakeProvider()
    chain = LLMChain([flake, EchoLLMProvider()])
    first = await chain.generate("hi")
    assert chain.last_provider == "Echo (offline fallback)"
    flake.up = True
    second = await chain.generate("hi again")
    assert chain.last_provider == "Flake", \
        "flake provider not picked up after coming online"


# ===========================================================================
# Layer 4 — Orchestrator integration
# ===========================================================================

@pytest.fixture
async def realm():
    bus = EventBus()
    llm = LLMChain([EchoLLMProvider()])
    tts = TTSChain([EchoTTSProvider()])
    orch = Orchestrator(bus, llm, tts)
    clf = IntentClassifier(bus)
    await clf.attach()
    await orch.attach()
    # Collect everything for assertions
    log = []
    async def trace(ev): log.append((ev.type, ev.payload))
    await bus.subscribe_all(trace)
    yield bus, orch, log
    await orch.detach()


async def test_ask_intent_flows_through_full_pipeline(realm):
    bus, orch, log = realm
    await bus.publish("prompt_text", text="what is the realm",
                      nonce="n1", user_guid="user1")
    # Wait for tts_complete to land
    for _ in range(200):
        if any(t == "tts_complete" for t, _ in log):
            break
        await asyncio.sleep(0.01)
    types = [t for t, _ in log]
    for required in ("intent_classified", "query_queued", "query_processing",
                     "query_result", "tts_started", "tts_chunk", "tts_complete"):
        assert required in types, f"missing event {required}; got {types}"


async def test_stop_stop_aborts_active_tts(realm):
    bus, orch, log = realm
    # Inject a slow TTS so we can interrupt it
    slow_done = []
    class SlowTTS(TTSProvider):
        name = "SlowTTS"
        async def is_available(self): return True
        async def synth(self, text):
            try:
                await asyncio.sleep(1.0)
                slow_done.append(text)
                return base64.b64encode(b"slow").decode()
            except asyncio.CancelledError:
                raise
    orch.tts = TTSChain([SlowTTS()])
    await bus.publish("prompt_text", text="what is the realm",
                      nonce="n1", user_guid="user1")
    # Wait until TTS has actually started
    for _ in range(200):
        if any(t == "tts_started" for t, _ in log):
            break
        await asyncio.sleep(0.01)
    assert any(t == "tts_started" for t, _ in log), "tts never started"
    # Fire STOP STOP
    await bus.publish("prompt_text", text="stop stop", nonce="n2", user_guid="user1")
    # Should see tts_aborted very soon
    for _ in range(100):
        if any(t == "tts_aborted" for t, _ in log):
            break
        await asyncio.sleep(0.01)
    assert any(t == "tts_aborted" for t, _ in log), \
        "STOP STOP did not abort TTS"
    assert not slow_done, "synth completed instead of being cancelled"


async def test_repeat_repeat_replays_last_result(realm):
    bus, orch, log = realm
    await bus.publish("prompt_text", text="what is the answer",
                      nonce="n1", user_guid="user1")
    for _ in range(200):
        if sum(1 for t, _ in log if t == "tts_complete") >= 1:
            break
        await asyncio.sleep(0.01)
    pre_complete = sum(1 for t, _ in log if t == "tts_complete")
    pre_started = sum(1 for t, _ in log if t == "tts_started")
    await bus.publish("prompt_text", text="repeat repeat",
                      nonce="n2", user_guid="user1")
    for _ in range(200):
        if sum(1 for t, _ in log if t == "tts_complete") > pre_complete:
            break
        await asyncio.sleep(0.01)
    post_started = sum(1 for t, _ in log if t == "tts_started")
    assert post_started > pre_started, \
        "REPEAT REPEAT did not fire a second tts_started"


async def test_per_user_isolation(realm):
    """STOP from user A must NOT cancel user B's query."""
    bus, orch, log = realm
    class SlowTTS(TTSProvider):
        name = "SlowTTS"
        async def is_available(self): return True
        async def synth(self, text):
            await asyncio.sleep(0.4)
            return base64.b64encode(b"slow").decode()
    orch.tts = TTSChain([SlowTTS()])
    await bus.publish("prompt_text", text="what is up",
                      nonce="nA", user_guid="userA")
    await bus.publish("prompt_text", text="what is up too",
                      nonce="nB", user_guid="userB")
    # Wait until both TTSes have started
    for _ in range(200):
        if sum(1 for t, p in log if t == "tts_started") >= 2:
            break
        await asyncio.sleep(0.01)
    # A says STOP STOP
    await bus.publish("prompt_text", text="stop stop", nonce="nA2",
                      user_guid="userA")
    # Wait for the dust to settle
    for _ in range(200):
        a_aborted = any(t == "tts_aborted" and p.get("user_guid") == "userA"
                        for t, p in log)
        b_done = any(t == "tts_complete" and p.get("user_guid") == "userB"
                     for t, p in log)
        if a_aborted and b_done:
            break
        await asyncio.sleep(0.02)
    assert any(t == "tts_aborted" and p.get("user_guid") == "userA"
               for t, p in log), "user A's TTS was not aborted"
    assert any(t == "tts_complete" and p.get("user_guid") == "userB"
               for t, p in log), \
        "user B's TTS was wrongly aborted by user A's STOP"


async def test_weather_intent_routed_to_handler(realm):
    bus, orch, log = realm
    received = []
    async def weather(slots, guid):
        received.append((slots, guid))
        return f"It's 72 in {slots.get('location', 'your area')}."
    orch.weather_handler = weather
    await bus.publish("prompt_text", text="weather in Newburgh today",
                      nonce="n1", user_guid="u1")
    for _ in range(200):
        if any(t == "query_result" for t, _ in log):
            break
        await asyncio.sleep(0.01)
    assert received, "weather handler not invoked"
    assert received[0][0].get("location") == "newburgh"
    result_text = next(p["text"] for t, p in log if t == "query_result")
    assert "72" in result_text and "newburgh" in result_text.lower()


async def test_ping_gets_pong(realm):
    bus, orch, log = realm
    await bus.publish("ping", who="harness")
    for _ in range(50):
        if any(t == "pong" for t, _ in log):
            break
        await asyncio.sleep(0.01)
    assert any(t == "pong" for t, _ in log), "orchestrator did not pong"
