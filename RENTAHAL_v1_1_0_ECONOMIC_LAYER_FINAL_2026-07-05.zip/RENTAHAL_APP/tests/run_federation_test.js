// run_federation_test.js — verifies the browser-side federation UI
// machinery: the federation-row badge, status polling, and color-coding
// for HEALTHY / DEGRADED / OFF states.
//
// What we test:
//   1. Federation row HTML elements exist (desire, master, state, peers)
//   2. Federation row is HIDDEN by default (display:none)
//   3. pollFederationStatus fetches /api/federation/status
//   4. renderFederationStatus shows row when configured
//   5. renderFederationStatus hides row when not configured
//   6. Badge colors match HEALTHY (green) / DEGRADED (orange) / OFF (gray)
//   7. Peer URLs are displayed as short hostnames (not full URLs)
//   8. Full URLs are accessible on hover (title attribute)
//   9. DEGRADED state shows diagnostic info in title (failures + error)
//  10. federationPollTimer is 20s interval
//  11. DOMContentLoaded auto-starts polling

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else { console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
         failCount++; }
}

// ─── HTML elements exist ─────────────────────────────────────

assert(/id="federation-row"/.test(html),
       'federation-row element exists');
assert(/id="federation-desire"/.test(html),
       'federation-desire span exists');
assert(/id="federation-master"/.test(html),
       'federation-master span exists');
assert(/id="federation-state"/.test(html),
       'federation-state span exists');
assert(/id="federation-peers"/.test(html),
       'federation-peers span exists');

// Federation row hidden by default — only shown if configured
const rowMatch = html.match(/id="federation-row"[\s\S]{0,200}>/);
assert(rowMatch && /display\s*:\s*none/.test(rowMatch[0]),
       'federation-row defaults to display:none');

// ─── pollFederationStatus function ───────────────────────────

const pollIdx = html.indexOf('async function pollFederationStatus');
assert(pollIdx > 0, 'pollFederationStatus function exists');
const pollSrc = html.slice(pollIdx, pollIdx + 1000);

assert(/fetch\(['"`]\/api\/federation\/status/.test(pollSrc),
       'pollFederationStatus fetches /api/federation/status');
assert(/renderFederationStatus/.test(pollSrc),
       'pollFederationStatus calls renderFederationStatus');

// Defensive: 404 hides the row (older realm without federation)
assert(/r\.ok[\s\S]{0,200}display\s*=\s*['"`]none['"`]/.test(pollSrc),
       'pollFederationStatus hides row on 404 (older realm support)');

// Network errors don't crash — leave badge alone
assert(/catch.{0,30}\{[\s\S]{0,200}console\.log/.test(pollSrc),
       'pollFederationStatus catches network errors gracefully');

// ─── renderFederationStatus function ─────────────────────────

const renderIdx = html.indexOf('function renderFederationStatus');
assert(renderIdx > 0, 'renderFederationStatus function exists');
const renderSrc = html.slice(renderIdx, renderIdx + 3000);

// Conditional visibility — shown only when federation is configured
assert(/desire\s*\|\|\s*s\.master_url\s*\|\|\s*s\.self_url/.test(renderSrc),
       'renderFederationStatus shows row if any federation field is set');
assert(/style\.display\s*=\s*configured\s*\?\s*['"]flex['"]\s*:\s*['"]none['"]/.test(renderSrc),
       'renderFederationStatus toggles display based on config');

// DESIRE field rendering
assert(/desireEl[\s\S]{0,300}s\.desire\s*\?\s*['"]ON['"]\s*:\s*['"]OFF['"]/.test(renderSrc),
       'DESIRE shows ON/OFF based on s.desire');
assert(/desireEl[\s\S]{0,500}#5a5/.test(renderSrc),
       'DESIRE green when ON');

// MASTER field — short host, full URL on hover
assert(/masterEl[\s\S]{0,500}new URL\(masterUrl\)/.test(renderSrc),
       'MASTER parses URL to get host');
assert(/masterEl\.title\s*=\s*masterUrl/.test(renderSrc),
       'MASTER full URL stored in title attribute');

// STATE field — three colors
assert(/HEALTHY[\s\S]{0,100}#5a5/.test(renderSrc),
       'STATE green for HEALTHY');
assert(/DEGRADED[\s\S]{0,100}#fa3/.test(renderSrc),
       'STATE orange for DEGRADED');
// Gray for OFF/UNKNOWN
assert(/['"]\#888['"]/.test(renderSrc),
       'STATE gray for OFF/UNKNOWN');

// DEGRADED state shows diagnostic info
assert(/DEGRADED[\s\S]{0,800}consecutive_failures/.test(renderSrc),
       'DEGRADED title shows consecutive_failures');
assert(/last_checkin_error/.test(renderSrc),
       'DEGRADED title shows last error');

// PEERS — short hosts, both LLM and TTS
assert(/best_llm_peer/.test(renderSrc),
       'PEERS renders best_llm_peer');
assert(/best_tts_peer/.test(renderSrc),
       'PEERS renders best_tts_peer (TTS-ready)');
assert(/LLM→/.test(renderSrc),
       'PEERS shows LLM→host indicator');
assert(/TTS→/.test(renderSrc),
       'PEERS shows TTS→host indicator');

// ─── Polling timer & auto-start ─────────────────────────────

assert(/setInterval\(pollFederationStatus,\s*20000\)/.test(html),
       'pollFederationStatus runs on a 20-second interval');

assert(/window\.addEventListener\(['"`]DOMContentLoaded['"`],\s*startFederationPolling\)/.test(html),
       'startFederationPolling auto-runs on DOMContentLoaded');
// Test-sandbox safety: guard for partial window objects
assert(/typeof\s+window\.addEventListener\s*===\s*['"`]function['"`]/.test(html),
       'DOMContentLoaded listener is guarded for test-sandbox compatibility');

// Don't double-start (idempotent)
assert(/if\s*\(federationPollTimer\)\s*return/.test(html),
       'startFederationPolling is idempotent (early return if already running)');

// Initial poll is immediate (no 20s wait at page load)
const startIdx = html.indexOf('function startFederationPolling');
const startSrc = html.slice(startIdx, startIdx + 400);
assert(/pollFederationStatus\(\)[\s\S]{0,100}setInterval/.test(startSrc),
       'startFederationPolling calls pollFederationStatus immediately (no 20s wait)');

// ─── Summary ─────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} federation browser tests passed`);
  process.exit(0);
}
