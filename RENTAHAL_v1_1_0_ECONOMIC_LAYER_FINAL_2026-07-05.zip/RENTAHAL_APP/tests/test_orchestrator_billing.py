"""
Sprint 13 — orchestrator billing wiring tests.

Same fixture shape as test_orchestrator_vision_imagine.py: real
EventBus, real IntentClassifier, real Orchestrator. Two tiers:

  1. FAST WIRING TESTS (FakeLedger — an in-memory stand-in): does the
     orchestrator call append_entry/get_balance with the right
     arguments at the right point, and does it publish low_balance at
     the right threshold? These don't need real Postgres and run in
     milliseconds — they're about the WIRING, not re-proving
     realm/ledger.py's own correctness (already covered thoroughly in
     test_ledger.py and test_billing.py).

  2. REAL END-TO-END CONFIRMATION (actual Ledger, real Postgres): a
     couple of tests using the genuine Ledger class, to catch anything
     a hand-rolled fake might hide — a signature mismatch, a real
     asyncpg-specific behavior the fake doesn't replicate, etc.
"""
import asyncio
import os
import sys
import time
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.event_bus import EventBus
from realm.intent import IntentClassifier
from realm.engine_chain import LLMChain, TTSChain, EchoLLMProvider, EchoTTSProvider
from realm.orchestrator import Orchestrator

pytestmark = pytest.mark.asyncio


class FakeLedger:
    """In-memory stand-in exposing exactly the two methods Orchestrator
    actually calls — append_entry and get_balance — with real async
    signatures matching realm.ledger.Ledger's. Not a general-purpose
    ledger mock; deliberately minimal, just enough to observe what the
    orchestrator does."""

    def __init__(self):
        self.entries = []          # [(entry_type, account_id, amount_micros, reference)]
        self._balances: dict = {}

    async def append_entry(self, entry_type, account_id, amount_micros,
                           reference="", metadata=None):
        self.entries.append((entry_type, account_id, amount_micros, reference))
        self._balances[account_id] = self._balances.get(account_id, 0) + amount_micros

    async def get_balance(self, account_id):
        return self._balances.get(account_id, 0)


class SimpleBillingConfig:
    """Plain stand-in for realm.billing.BillingConfig — Orchestrator
    only ever reads .price_per_submit_micros and
    .low_balance_threshold_micros off whatever object it's given, so a
    minimal object with just those two fields is a faithful test
    double without needing the real (stripe-dependent) class."""
    def __init__(self, price_per_submit_micros=100,
                low_balance_threshold_micros=10_000):
        self.price_per_submit_micros = price_per_submit_micros
        self.low_balance_threshold_micros = low_balance_threshold_micros


async def _await_event(log, name, timeout=5):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for t, p in log:
            if t == name:
                return p
        await asyncio.sleep(0.01)
    raise TimeoutError(f"no {name}; saw {[t for t, _ in log]}")


async def _event_count(log, name):
    return sum(1 for t, _ in log if t == name)


async def _make_realm(ledger=None, billing_cfg=None):
    bus = EventBus()
    llm = LLMChain([EchoLLMProvider()])
    tts = TTSChain([EchoTTSProvider()])
    orch = Orchestrator(bus, llm, tts, ledger=ledger, billing_cfg=billing_cfg)
    clf = IntentClassifier(bus)
    await clf.attach()
    await orch.attach()
    log = []
    await bus.subscribe_all(
        lambda ev: log.append((ev.type, dict(ev.payload))) or asyncio.sleep(0))
    return bus, orch, log


async def _ask(bus, guid="user-alice", text="what time is it"):
    await bus.publish("prompt_text", nonce="n1", user_guid=guid, text=text)


# ─── Billing OFF by default ──────────────────────────────────────────

async def test_no_debit_when_ledger_and_billing_cfg_both_none():
    """The default construction — Orchestrator(bus, llm, tts) with no
    billing args at all, exactly how every pre-Sprint-13 test and every
    realm that's never touched the economic layer constructs it."""
    bus, orch, log = await _make_realm()
    assert orch.ledger is None
    assert orch.billing_cfg is None
    await _ask(bus)
    await _await_event(log, "query_result")
    assert await _event_count(log, "low_balance") == 0


async def test_no_debit_when_only_ledger_set():
    """ledger set but billing_cfg is None — must not attempt a debit
    (would crash on billing_cfg.price_per_submit_micros otherwise;
    confirms the wiring checks BOTH, not just one)."""
    fake_ledger = FakeLedger()
    bus, orch, log = await _make_realm(ledger=fake_ledger, billing_cfg=None)
    await _ask(bus)
    await _await_event(log, "query_result")
    assert fake_ledger.entries == []


async def test_no_debit_when_only_billing_cfg_set():
    """billing_cfg set but ledger is None — same reasoning, reversed."""
    bus, orch, log = await _make_realm(ledger=None, billing_cfg=SimpleBillingConfig())
    await _ask(bus)
    await _await_event(log, "query_result")
    # No exception, no crash — the query still completes normally.


# ─── Debit happens when both are set ─────────────────────────────────

async def test_debit_happens_after_query_with_correct_price():
    fake_ledger = FakeLedger()
    cfg = SimpleBillingConfig(price_per_submit_micros=250)
    bus, orch, log = await _make_realm(ledger=fake_ledger, billing_cfg=cfg)
    await _ask(bus, guid="user-alice")
    await _await_event(log, "query_result")

    assert len(fake_ledger.entries) == 1
    entry_type, account_id, amount_micros, reference = fake_ledger.entries[0]
    assert entry_type == "debit"
    assert account_id == "user-alice"
    assert amount_micros == -250   # NEGATIVE — a debit reduces balance
    assert reference == ""         # debits don't need idempotency references


async def test_debit_keyed_to_the_correct_user():
    fake_ledger = FakeLedger()
    cfg = SimpleBillingConfig()
    bus, orch, log = await _make_realm(ledger=fake_ledger, billing_cfg=cfg)
    await _ask(bus, guid="user-bob")
    await _await_event(log, "query_result")
    assert fake_ledger.entries[0][1] == "user-bob"


async def test_multiple_queries_debit_multiple_times():
    fake_ledger = FakeLedger()
    cfg = SimpleBillingConfig(price_per_submit_micros=100)
    bus, orch, log = await _make_realm(ledger=fake_ledger, billing_cfg=cfg)
    for i in range(3):
        log.clear()
        await _ask(bus, guid="user-alice", text=f"question {i}")
        await _await_event(log, "query_result")
    assert len(fake_ledger.entries) == 3
    assert await fake_ledger.get_balance("user-alice") == -300


# ─── low_balance event ────────────────────────────────────────────────

async def test_low_balance_event_fires_when_threshold_crossed():
    fake_ledger = FakeLedger()
    fake_ledger._balances["user-alice"] = 150   # already low before this query
    cfg = SimpleBillingConfig(price_per_submit_micros=100,
                              low_balance_threshold_micros=1000)
    bus, orch, log = await _make_realm(ledger=fake_ledger, billing_cfg=cfg)
    await _ask(bus, guid="user-alice")
    await _await_event(log, "query_result")

    payload = await _await_event(log, "low_balance")
    assert payload["user_guid"] == "user-alice"
    assert payload["balance_micros"] == 50   # 150 - 100 = 50, below threshold 1000


async def test_low_balance_event_does_not_fire_above_threshold():
    fake_ledger = FakeLedger()
    fake_ledger._balances["user-alice"] = 1_000_000   # plenty
    cfg = SimpleBillingConfig(price_per_submit_micros=100,
                              low_balance_threshold_micros=1000)
    bus, orch, log = await _make_realm(ledger=fake_ledger, billing_cfg=cfg)
    await _ask(bus, guid="user-alice")
    await _await_event(log, "query_result")
    assert await _event_count(log, "low_balance") == 0


async def test_low_balance_event_fires_exactly_at_the_query_that_crosses_it():
    """Balance stays above threshold for the first two queries, then
    drops below on the third — low_balance must fire on exactly that
    one, not earlier."""
    fake_ledger = FakeLedger()
    fake_ledger._balances["user-alice"] = 250   # 2.5 queries' worth at 100/query
    cfg = SimpleBillingConfig(price_per_submit_micros=100,
                              low_balance_threshold_micros=100)
    bus, orch, log = await _make_realm(ledger=fake_ledger, billing_cfg=cfg)

    log.clear()
    await _ask(bus, guid="user-alice", text="q1")
    await _await_event(log, "query_result")
    assert await _event_count(log, "low_balance") == 0   # 250-100=150, still >= 100

    log.clear()
    await _ask(bus, guid="user-alice", text="q2")
    await _await_event(log, "query_result")
    assert await _event_count(log, "low_balance") == 1   # 150-100=50, now < 100


# ─── Billing never breaks the actual query ───────────────────────────

async def test_ledger_failure_does_not_break_the_query():
    """A billing/Postgres hiccup must be logged and swallowed, never
    allowed to break the actual chat response — see
    Orchestrator._debit_and_check_balance's caller in _handle, which
    wraps the call in try/except specifically for this."""
    class ExplodingLedger:
        async def append_entry(self, *a, **kw):
            raise RuntimeError("simulated Postgres outage")
        async def get_balance(self, *a, **kw):
            raise RuntimeError("simulated Postgres outage")

    bus, orch, log = await _make_realm(
        ledger=ExplodingLedger(), billing_cfg=SimpleBillingConfig())
    await _ask(bus, guid="user-alice")
    # Must still get a normal query_result despite the ledger exploding.
    result = await _await_event(log, "query_result")
    assert result is not None


# ─── Real Postgres confirmation (not just the fake) ──────────────────

BASE_DSN = os.environ.get(
    "RENTAHAL_LEDGER_TEST_DSN",
    "postgresql://postgres:rentahal_test@localhost:5432/postgres")


async def _postgres_reachable() -> bool:
    try:
        import asyncpg
        conn = await asyncio.wait_for(asyncpg.connect(BASE_DSN), timeout=3.0)
        await conn.close()
        return True
    except Exception:
        return False


async def test_debit_against_real_ledger_end_to_end():
    """Not the fake — the genuine realm.ledger.Ledger class, against a
    real throwaway Postgres database, confirming the orchestrator's
    actual calls work against the real append_entry/get_balance
    signatures, not just what a hand-rolled fake happens to accept."""
    try:
        import asyncpg
    except ImportError:
        pytest.skip("asyncpg not installed")
    if not await _postgres_reachable():
        pytest.skip("Postgres not reachable")

    from realm.ledger import Ledger

    db_name = f"rentahal_orch_billing_test_{uuid.uuid4().hex[:12]}"
    admin_conn = await asyncpg.connect(BASE_DSN)
    await admin_conn.execute(f'CREATE DATABASE "{db_name}"')
    await admin_conn.close()
    prefix = BASE_DSN.rsplit("/", 1)[0]
    dsn = f"{prefix}/{db_name}"

    real_ledger = await Ledger.connect(dsn)
    try:
        cfg = SimpleBillingConfig(price_per_submit_micros=100)
        bus, orch, log = await _make_realm(ledger=real_ledger, billing_cfg=cfg)
        await _ask(bus, guid="user-real")
        await _await_event(log, "query_result")

        balance = await real_ledger.get_balance("user-real")
        assert balance == -100
    finally:
        await real_ledger.close()
        admin_conn = await asyncpg.connect(BASE_DSN)
        await admin_conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = $1 AND pid <> pg_backend_pid()", db_name)
        await admin_conn.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
        await admin_conn.close()
