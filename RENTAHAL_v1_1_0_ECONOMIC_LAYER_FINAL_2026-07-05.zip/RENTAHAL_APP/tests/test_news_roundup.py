"""
Tests for the ROUNDUP feature — radio-station style news playback.

Architecture:
  - /api/news/roundup endpoint fetches NPR + Guardian in parallel from
    the Kokoro service, then calls _build_roundup() (pure function)
    to combine/shuffle/slim the result.
  - We test _build_roundup() directly here.

Coverage:
  - Combines two source lists into one
  - Shuffles for radio-style variety
  - Caps at the count parameter
  - Rewrites /audio/<id> URLs to /api/news/audio/<id> (Cloudflare-friendly)
  - Strips fields the browser doesn't need (smaller payload)
  - Handles empty lists gracefully
  - Handles None input (defensive)
  - Always returns enabled=True (the HTTP wrapper handles the disabled case)
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import _build_roundup


def test_combines_two_source_lists():
    npr = [{"title": f"N{i}", "source": "NPR",
            "audio_url": f"/a/n{i}"} for i in range(5)]
    guardian = [{"title": f"G{i}", "source": "The Guardian",
                 "audio_url": f"/a/g{i}"} for i in range(5)]
    out = _build_roundup(npr, guardian, count=20)
    assert out["enabled"] is True
    assert out["total"] == 10
    assert len(out["stories"]) == 10
    sources = {s["source"] for s in out["stories"]}
    assert sources == {"NPR", "The Guardian"}


def test_caps_at_count():
    npr = [{"title": f"N{i}", "source": "NPR",
            "audio_url": f"/a/n{i}"} for i in range(30)]
    guardian = [{"title": f"G{i}", "source": "The Guardian",
                 "audio_url": f"/a/g{i}"} for i in range(30)]
    out = _build_roundup(npr, guardian, count=10)
    assert len(out["stories"]) == 10
    assert out["total"] == 10


def test_rewrites_relative_audio_urls():
    """Audio URLs starting with / get rewritten to route through the realm.
    The browser plays them via /api/news/audio/<id> which the realm
    proxies to the Kokoro service. This makes the audio Cloudflare-friendly."""
    npr = [{"title": "x", "source": "NPR", "audio_url": "/audio/abc123"}]
    out = _build_roundup(npr, [], count=10)
    assert len(out["stories"]) == 1
    assert out["stories"][0]["audio_url"] == "/api/news/audio/abc123"


def test_preserves_absolute_audio_urls():
    """If the upstream returns a fully-qualified URL, we leave it alone.
    Defensive — the Kokoro service today returns relative URLs but a
    future version might return absolute ones."""
    story = {"title": "x", "source": "NPR",
             "audio_url": "https://example.com/audio/full.wav"}
    out = _build_roundup([story], [], count=10)
    assert out["stories"][0]["audio_url"] == "https://example.com/audio/full.wav"


def test_strips_unused_fields_for_smaller_payload():
    """The browser only needs title/source/audio_url/link for roundup
    playback. We strip summary/category/audio_ready/etc. to reduce
    payload size — important when 20 stories are bundled together."""
    fat_story = {
        "title": "T", "source": "NPR",
        "audio_url": "/audio/x", "link": "https://example.com/x",
        # These should be stripped:
        "summary": "long summary text that the browser does not need",
        "category": "center",
        "audio_ready": True,
        "encode_failed": False,
        "published": "2026-06-19T10:30:00Z",
    }
    out = _build_roundup([fat_story], [], count=10)
    story = out["stories"][0]
    # Required fields present
    assert "title" in story
    assert "source" in story
    assert "audio_url" in story
    assert "link" in story
    # Unused fields stripped
    assert "summary" not in story
    assert "category" not in story
    assert "audio_ready" not in story
    assert "published" not in story


def test_handles_empty_lists():
    out = _build_roundup([], [], count=20)
    assert out["enabled"] is True
    assert out["stories"] == []
    assert out["total"] == 0


def test_handles_one_empty_source():
    npr = [{"title": "N1", "source": "NPR", "audio_url": "/a/n1"}]
    out = _build_roundup(npr, [], count=20)
    assert len(out["stories"]) == 1
    assert out["stories"][0]["source"] == "NPR"


def test_handles_none_inputs_defensively():
    """If a source fetch failed and returned None instead of [], we
    should still build a valid roundup from whatever we have."""
    out = _build_roundup(None, None, count=10)
    assert out["enabled"] is True
    assert out["stories"] == []


def test_shuffles_output():
    """Output order should NOT match input concatenation order. Probability
    of shuffle producing the original order with 20 items is 1/20! —
    effectively zero."""
    npr = [{"title": f"N{i}", "source": "NPR",
            "audio_url": f"/a/n{i}"} for i in range(10)]
    guardian = [{"title": f"G{i}", "source": "The Guardian",
                 "audio_url": f"/a/g{i}"} for i in range(10)]
    out = _build_roundup(npr, guardian, count=20)
    titles = [s["title"] for s in out["stories"]]
    unshuffled = [f"N{i}" for i in range(10)] + [f"G{i}" for i in range(10)]
    assert titles != unshuffled, \
        "output appears not to be shuffled (matches input order exactly)"


def test_uses_defaults_when_fields_missing():
    """If upstream returns a story missing a field, we substitute a
    safe default (empty string, '(untitled)' for title)."""
    out = _build_roundup([{}], [], count=10)
    assert len(out["stories"]) == 1
    story = out["stories"][0]
    assert story["title"] == "(untitled)"
    assert story["source"] == ""
    assert story["audio_url"] == ""
    assert story["link"] == ""


def test_audio_url_rewrite_with_nested_path():
    """Audio URLs with nested paths like /audio/cache/abc still rewrite
    correctly — we always take the final path segment as the audio_id."""
    npr = [{"title": "x", "source": "NPR",
            "audio_url": "/audio/cache/abc123"}]
    out = _build_roundup(npr, [], count=10)
    assert out["stories"][0]["audio_url"] == "/api/news/audio/abc123"


def test_audio_url_rewrite_skips_empty_string():
    """Empty audio_url stays empty — no spurious rewriting."""
    npr = [{"title": "x", "source": "NPR", "audio_url": ""}]
    out = _build_roundup(npr, [], count=10)
    assert out["stories"][0]["audio_url"] == ""


def test_returns_enabled_true_always():
    """The pure builder always returns enabled=True. The disabled state
    is the HTTP wrapper's responsibility (returns enabled=False before
    even calling this function when the Kokoro service is unconfigured)."""
    out = _build_roundup([], [], count=10)
    assert out["enabled"] is True
