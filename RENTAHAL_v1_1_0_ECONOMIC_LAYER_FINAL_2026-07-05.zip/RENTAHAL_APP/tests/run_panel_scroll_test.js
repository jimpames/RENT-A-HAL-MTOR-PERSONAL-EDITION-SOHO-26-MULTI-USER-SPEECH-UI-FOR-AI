// run_panel_scroll_test.js — regression test for the "service finder
// tiles render off-screen when news panel is already open" bug.
//
// Repro from production:
//   1. User says "computer news newline" → news panel opens with stories,
//      taking up ~60vh of viewport (max-height:60vh on #news-stories)
//   2. User says "computer service finder haircut newline"
//   3. Realm queries BizData, returns results, browser opens services panel
//   4. BUG: services panel renders fine but user can't see it because it's
//      below the news panel which is below the visible viewport
//   5. Audio plays the spoken summary, but the visual results appear absent
//
// Fix: every panel-open function calls scrollPanelIntoView(panel) after
// the panel is shown and its content rendered. The user sees the new
// content immediately regardless of what other panels are open above.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── The scroll helper exists ────────────────────────────────

assert(/function scrollPanelIntoView/.test(html),
       'scrollPanelIntoView helper function exists');

const scrollHelper = html.match(/function scrollPanelIntoView[\s\S]+?\n\}/);
assert(scrollHelper !== null, 'scrollPanelIntoView extractable');

if (scrollHelper) {
  // Must use requestAnimationFrame so layout settles after display:block
  assert(/requestAnimationFrame/.test(scrollHelper[0]),
         'uses requestAnimationFrame (waits for layout to settle)');
  // Must use scrollIntoView (the standard DOM API)
  assert(/scrollIntoView/.test(scrollHelper[0]),
         'uses scrollIntoView API');
  // Must prefer smooth scroll
  assert(/smooth/.test(scrollHelper[0]),
         'uses smooth scroll behavior (less jarring than instant)');
  // Must have fallback for browsers that don't support options arg
  assert(/catch/.test(scrollHelper[0]),
         'has fallback path if scrollIntoView options unsupported');
}

// ─── Each panel-opener calls the scroll helper ────────────────

// Use index-based extraction (regex can't handle nested braces reliably)
const openServicesIdx = html.indexOf('function openServicesPanel(msg)');
const renderServiceCardIdx = html.indexOf('function renderServiceCard');
assert(openServicesIdx > 0 && renderServiceCardIdx > openServicesIdx,
       'openServicesPanel located in file');
const openServicesSrc = html.slice(openServicesIdx, renderServiceCardIdx);
// The src should contain a CALL to scrollPanelIntoView, not just a mention.
// We require it to follow a panel reference like `scrollPanelIntoView(panel)`
// to distinguish from accidental references.
assert(/scrollPanelIntoView\s*\(\s*panel\s*\)/.test(openServicesSrc),
       'openServicesPanel calls scrollPanelIntoView(panel) (fixes the reported bug)');

// openMusicPanel — same pattern, less critical (music video is shorter)
const openMusicIdx = html.indexOf('function openMusicPanel(query, videoId)');
const musicSearchIdx = html.indexOf('function musicSearch()');
assert(openMusicIdx > 0 && musicSearchIdx > openMusicIdx,
       'openMusicPanel located in file');
const openMusicSrc = html.slice(openMusicIdx, musicSearchIdx);
assert(/scrollPanelIntoView\s*\(\s*panel\s*\)/.test(openMusicSrc),
       'openMusicPanel calls scrollPanelIntoView(panel) (consistency)');

// News voice path opens news panel via bus_news_bundle — also scrolls
const busNewsBundleIdx = html.indexOf("case 'bus_news_bundle'");
const busNewsBundleEnd = html.indexOf('break;', busNewsBundleIdx);
assert(busNewsBundleIdx > 0 && busNewsBundleEnd > busNewsBundleIdx,
       'bus_news_bundle handler located');
const busNewsBundleSrc = html.slice(busNewsBundleIdx, busNewsBundleEnd);
assert(/scrollPanelIntoView\s*\(/.test(busNewsBundleSrc),
       'bus_news_bundle handler scrolls news panel into view');

// ─── Content still renders even when results.length === 0 ───
// Defense: previous version had `return;` inside the if-empty branch,
// which meant scrollPanelIntoView never ran for empty results either.
// Even when there are no results, the user should see the status line
// ("0 haircut results near Newburgh") which requires the panel to be
// scrolled into view.
assert(/No results found/.test(openServicesSrc),
       'openServicesPanel still shows "No results found" message for empty');
// Critically: the scroll call should happen REGARDLESS of whether
// results were found — otherwise empty result sets are silent.
assert(openServicesSrc.indexOf('scrollPanelIntoView') >
       openServicesSrc.indexOf('No results found'),
       'scrollPanelIntoView runs even when no results (status line visible)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} panel-scroll tests passed`);
  process.exit(0);
}
