// run_silence_button_test.js — regression tests for the SILENCE
// button. This is a SURGICAL addition on top of the last-known-good
// index.html. No other behavior changes.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Button presence ──────────────────────────────────────────

assert(/id="silence-btn"/.test(html),
       'silence-btn exists in DOM');
assert(/onclick="silenceAll\(\)"/.test(html),
       'silence button wired to silenceAll()');
assert(/🔇 SILENCE/.test(html),
       'silence button shows clear "🔇 SILENCE" label');
assert(/#cc1f1f/.test(html),
       'silence button is visually distinct (red background)');

// ─── silenceAll function ──────────────────────────────────────

assert(/function silenceAll/.test(html),
       'silenceAll function defined');

const silIdx = html.indexOf('function silenceAll');
const silEnd = html.indexOf('\nfunction ', silIdx + 1);
const silSrc = html.slice(silIdx, silEnd > silIdx ? silEnd : silIdx + 3000);

assert(/player\.pause\(\)/.test(silSrc),
       'silenceAll pauses the audio player');
assert(/player\.src\s*=\s*['"]['"]/.test(silSrc),
       'silenceAll clears player.src');
assert(/stopThinkingSound\(\)/.test(silSrc),
       'silenceAll stops thinking sound');
assert(/isSpeaking\s*=\s*false/.test(silSrc),
       'silenceAll releases speaking lock');
assert(/echoGuardUntil/.test(silSrc),
       'silenceAll extends echo guard briefly');
assert(/music-player-container[\s\S]*?innerHTML\s*=\s*['"]['"]/.test(silSrc),
       'silenceAll kills YouTube iframe');
assert(/sendPrompt\(['"]stop stop['"]\)/.test(silSrc),
       'silenceAll sends "stop stop" to realm');
assert(/SILENCED/.test(silSrc),
       'silence button shows "SILENCED" visual feedback');

// ─── Defensive: each step wrapped in try/catch ────────────────
// If any step throws, the others must still run — silenceAll is the
// last-resort escape hatch, it has to fire on every click.

const tryCount = (silSrc.match(/try\s*\{/g) || []).length;
assert(tryCount >= 5,
       'silenceAll wraps each step in try/catch (>= 5 try blocks)',
       'found ' + tryCount + ' try blocks');

// ─── Defensive: no nukeAllCardPanels, no playAudio changes ────
// The bug-causing changes from the prior drop have NOT been re-introduced.

const procIdx = html.indexOf("case 'bus_query_processing':");
const procEnd = html.indexOf('break;', procIdx);
const procSrc = html.slice(procIdx, procEnd);
assert(!/nukeAllCardPanels/.test(procSrc),
       'bus_query_processing does NOT call nukeAllCardPanels ' +
       '(the speculative change that broke first-run behavior)');

// playAudio.onended must still set isSpeaking = false (the prior
// known-good behavior — reverted from the over-aggressive change)
const playAudioIdx = html.indexOf('function playAudio');
const playAudioEnd = html.indexOf('\nfunction ', playAudioIdx + 1);
const playAudioSrc = html.slice(playAudioIdx, playAudioEnd);
const onendedIdx = playAudioSrc.indexOf('player.onended');
const onendedEnd = playAudioSrc.indexOf('};', onendedIdx);
const onendedSrc = playAudioSrc.slice(onendedIdx, onendedEnd);
assert(/isSpeaking\s*=\s*false/.test(onendedSrc),
       'playAudio.onended still releases isSpeaking ' +
       '(restored from the over-aggressive change)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} silence-button tests passed`);
  process.exit(0);
}
