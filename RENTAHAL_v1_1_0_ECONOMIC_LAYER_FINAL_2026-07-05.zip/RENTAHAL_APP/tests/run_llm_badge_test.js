// run_llm_badge_test.js — verifies bug fix #1: the LLM status badge
// in the cockpit STATUS row updates from each query's actual provider,
// not just from /api/setup_status at page load.
//
// The bug we fixed:
//   - checkSetup() runs once at page load, sets badge to whichever
//     provider was first-available at boot
//   - When GPT4All dies mid-session, badge keeps showing GPT4All until
//     the operator reloads the page
//   - Operator sees a lie in the cockpit
//
// The fix:
//   - bus_query_result already carries msg.llm_provider (it's already
//     displayed in the per-query metadata)
//   - The bus_query_result handler now also calls setStatus on the
//     LLM badge with msg.llm_provider
//   - Every query gives the operator a truthful badge update

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else { console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
         failCount++; }
}

// ─── Locate the bus_query_result case ─────────────────────────

const caseIdx = html.indexOf("case 'bus_query_result':");
assert(caseIdx > 0, "bus_query_result case exists in handleMsg");

const caseEnd = html.indexOf('break;', caseIdx);
const caseBody = html.slice(caseIdx, caseEnd + 6);

// ─── The fix: setStatus called with msg.llm_provider ──────────

assert(/setStatus\(\s*['"]status-llm['"]/.test(caseBody),
       'bus_query_result calls setStatus on status-llm');

assert(/msg\.llm_provider/.test(caseBody),
       'bus_query_result uses msg.llm_provider for the badge update');

assert(/['"]LLM:\s*['"]\s*\+\s*msg\.llm_provider/.test(caseBody),
       'badge text format is "LLM: <provider name>"');

// ─── Defensive: don't set badge if llm_provider is missing ────

// The bus_query_result event could in theory arrive without llm_provider
// (older event format, special cases). We should guard against undefined
// so the badge doesn't display "LLM: undefined".
assert(/if\s*\(\s*msg\.llm_provider/.test(caseBody),
       'badge update is guarded against missing llm_provider');

// Don't blank the badge if provider says 'none' — keep the last known value
assert(/['"]none['"]/.test(caseBody),
       "badge update guards against the 'none' sentinel value");

// ─── State color stays 'ok' — having an answer is success ─────

// Even when llm_provider is "Echo (offline fallback)" or
// "Federation Fallback (peer realms)", SOMETHING answered. The badge
// color reflects "did any provider respond" not "is the primary OK."
assert(/setStatus\(\s*['"]status-llm['"]\s*,[\s\S]{0,200}['"]ok['"]/.test(caseBody),
       "badge uses 'ok' status — having an answer means a provider succeeded");

// ─── Federation-aware: the new fallback provider name is recognizable ──

// The new FederationLLMFallbackProvider has a distinct name from
// FederationLLMProvider. When fallback fires, the badge correctly shows
// "LLM: Federation Fallback (peer realms)" — operator can tell the
// difference between overflow and rescue.
// (We don't assert the exact name here since the provider lives in
// Python, but the format string accepts any provider name.)

// ─── Comment in code explains the bug ─────────────────────────

assert(/stale LLM badge/.test(caseBody) || /reload/.test(caseBody),
       'fix has explanatory comment describing the bug being fixed');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} LLM badge tests passed`);
  process.exit(0);
}
