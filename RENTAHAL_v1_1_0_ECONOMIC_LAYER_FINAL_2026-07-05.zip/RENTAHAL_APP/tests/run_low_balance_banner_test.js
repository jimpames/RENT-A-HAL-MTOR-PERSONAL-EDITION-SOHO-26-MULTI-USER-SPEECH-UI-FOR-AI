// run_low_balance_banner_test.js — Sprint 13: confirms the low-balance
// banner markup exists, starts hidden, and the bus_low_balance case in
// handleMsg is correctly wired to showLowBalanceBanner(), which is in
// turn wired to the real userGuid + /api/billing/checkout endpoint.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Markup ──────────────────────────────────────────────────────

assert(/id="low-balance-banner"/.test(html), 'low-balance-banner element present');
assert(/id="low-balance-banner"[\s\S]{0,40}display:\s*none/.test(html),
       'banner starts hidden by default');
assert(/id="low-balance-text"/.test(html), 'low-balance-text element present');
assert(/onclick="topUp\(500\)"/.test(html), 'Top Up button calls topUp(500)');
assert(/Dismiss/.test(html), 'banner has a Dismiss control');

// ─── JS wiring ───────────────────────────────────────────────────

const caseIdx = html.indexOf("case 'bus_low_balance'");
assert(caseIdx > 0, 'handleMsg has a bus_low_balance case');
const caseEnd = html.indexOf('break;', caseIdx);
const caseSrc = html.slice(caseIdx, caseEnd);
assert(/showLowBalanceBanner\(msg\.balance_micros\)/.test(caseSrc),
       'bus_low_balance case calls showLowBalanceBanner with balance_micros');

const fnIdx = html.indexOf('function showLowBalanceBanner');
assert(fnIdx > 0, 'showLowBalanceBanner function defined');
const fnEnd = html.indexOf('\nfunction ', fnIdx + 1);
const fnSrc = html.slice(fnIdx, fnEnd);
assert(/getElementById\('low-balance-banner'\)/.test(fnSrc),
       'showLowBalanceBanner targets the real banner element');
assert(/style\.display\s*=\s*'block'/.test(fnSrc),
       'showLowBalanceBanner actually shows the banner');

const topUpIdx = html.indexOf('async function topUp');
assert(topUpIdx > 0, 'topUp function defined');
const topUpEnd = html.indexOf('\n// ', topUpIdx + 1);
const topUpSrc = html.slice(topUpIdx, topUpEnd);
assert(/\/api\/billing\/checkout/.test(topUpSrc),
       'topUp calls the real /api/billing/checkout endpoint');
assert(/account_id:\s*userGuid/.test(topUpSrc),
       'topUp uses the real client-side userGuid as account_id — '
       + 'same identity the server debits against, no separate login needed');
assert(/amountCents \* 10000/.test(topUpSrc),
       'topUp converts cents to micros correctly (matches realm/billing.py convention)');
assert(/window\.location\.href = data\.checkout_url/.test(topUpSrc),
       'topUp redirects to the real Stripe-hosted checkout URL');

if (failCount > 0) {
  console.log(`\nFAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`\nOK: ${passCount} low-balance banner tests passed`);
}
