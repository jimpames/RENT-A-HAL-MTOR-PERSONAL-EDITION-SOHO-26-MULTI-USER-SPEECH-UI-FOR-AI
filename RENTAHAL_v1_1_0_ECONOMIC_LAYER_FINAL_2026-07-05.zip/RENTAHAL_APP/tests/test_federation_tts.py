"""
test_federation_tts.py — Federation TTS providers (head + tail).

Mirrors test_federation.py's coverage for LLM providers, applied to
the TTS analogues:
  - FederationTTSProvider (head, overflow on local TTS slow)
  - FederationTTSFallbackProvider (tail, rescue when local TTS dead)

Both providers POST to peer/api/speak with X-Federation-Hops: 1.
Both honor the pre-flight local probe + recovery callback that makes
peering rock solid against race/failover/failback timing.
"""
import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from realm.federation import FederationConfig, FederationState, DEGRADED_AVG_S
from realm.federation_tts_provider import (
    FederationTTSProvider, FederationTTSFallbackProvider,
    _do_federated_synth,
)


def _make_head(desire=True, state="HEALTHY", local_avg=50.0,
               best_peer="https://peer.example",
               self_url="https://me.example", threshold=31.0):
    cfg = FederationConfig(desire=desire, self_url=self_url,
                           prefer_federation_for_tts_avg_s=threshold)
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": 0, "tts_avg_s": local_avg, "tokens_out": 0})
    fed_state.member_state = state
    fed_state.best_tts_peer = best_peer
    return FederationTTSProvider(fed_state)


def _make_tail(desire=True, state="HEALTHY",
               best_peer="https://peer.example",
               self_url="https://me.example"):
    cfg = FederationConfig(desire=desire, self_url=self_url)
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": 0, "tts_avg_s": 0, "tokens_out": 0})
    fed_state.member_state = state
    fed_state.best_tts_peer = best_peer
    return FederationTTSFallbackProvider(fed_state)


# ─── HEAD: should_federate gate ────────────────────────────────────


def test_tts_head_should_federate_happy_path():
    p = _make_head(local_avg=50.0)
    assert p.should_federate(local_tts_avg_s=50.0, allow_federation=True)


def test_tts_head_false_when_desire_off():
    p = _make_head(desire=False)
    assert not p.should_federate(50.0, allow_federation=True)


def test_tts_head_false_when_not_healthy():
    p = _make_head(state="DEGRADED")
    assert not p.should_federate(50.0, allow_federation=True)


def test_tts_head_false_when_below_threshold():
    """Same overflow semantics as LLM head — fast local means don't
    federate. The bug the recovery callback fixes is for cases where
    this gate fires DESPITE local being fast (rolling avg elevated
    by recent federated calls)."""
    p = _make_head(local_avg=10.0, threshold=31.0)
    assert not p.should_federate(10.0, allow_federation=True)


def test_tts_head_false_when_no_peer():
    p = _make_head(best_peer=None)
    assert not p.should_federate(50.0, allow_federation=True)


def test_tts_head_false_when_peer_is_self():
    p = _make_head(best_peer="https://me.example", self_url="https://me.example")
    assert not p.should_federate(50.0, allow_federation=True)


def test_tts_head_false_with_trailing_slash_self():
    p = _make_head(best_peer="https://me.example/", self_url="https://me.example")
    assert not p.should_federate(50.0, allow_federation=True)


def test_tts_head_false_when_hops_exhausted():
    p = _make_head()
    assert not p.should_federate(50.0, allow_federation=False)


# ─── TAIL: should_federate gate (no threshold) ─────────────────────


def test_tts_tail_should_federate_happy_path():
    p = _make_tail()
    assert p.should_federate(allow_federation=True)


def test_tts_tail_false_when_desire_off():
    p = _make_tail(desire=False)
    assert not p.should_federate(allow_federation=True)


def test_tts_tail_false_when_not_healthy():
    p = _make_tail(state="DEGRADED")
    assert not p.should_federate(allow_federation=True)


def test_tts_tail_false_when_no_peer():
    p = _make_tail(best_peer=None)
    assert not p.should_federate(allow_federation=True)


def test_tts_tail_false_when_peer_is_self():
    p = _make_tail(best_peer="https://me.example", self_url="https://me.example")
    assert not p.should_federate(allow_federation=True)


def test_tts_tail_false_when_hops_exhausted():
    """Cascade prevention — federated /api/speak request must NOT
    re-federate even at the tail."""
    p = _make_tail()
    assert not p.should_federate(allow_federation=False)


def test_tts_tail_no_threshold_check():
    """KEY difference from head: no threshold gate. Same as LLM
    fallback. Chain reaching us implies local TTS failed; we don't
    care how fast local 'would have been'."""
    cfg = FederationConfig(
        desire=True, self_url="https://me.example",
        prefer_federation_for_tts_avg_s=999.0)   # very high threshold
    fed_state = FederationState(cfg, lambda: {
        "llm_avg_s": 0,
        "tts_avg_s": 0.1,   # very fast — head would never fire
        "tokens_out": 0})
    fed_state.member_state = "HEALTHY"
    fed_state.best_tts_peer = "https://peer.example"
    p = FederationTTSFallbackProvider(fed_state)
    assert p.should_federate(allow_federation=True)


# ─── is_available ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_tts_head_is_available_true_when_should_federate():
    p = _make_head(local_avg=50.0)
    assert await p.is_available() is True


@pytest.mark.asyncio
async def test_tts_head_is_available_false_when_below_threshold():
    p = _make_head(local_avg=10.0, threshold=31.0)
    assert await p.is_available() is False


@pytest.mark.asyncio
async def test_tts_tail_is_available_when_federation_healthy():
    p = _make_tail()
    assert await p.is_available() is True


# ─── synth: HTTP semantics ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_tts_head_synth_sends_correct_url_and_headers():
    """Federated TTS hits peer/api/speak with X-Federation-Hops: 1."""
    captured = {}

    class _MockResp:
        status = 200
        async def json(self):
            return {"audio_b64": "aGVsbG8=", "provider": "Kokoro"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    def mock_post(url, json=None, headers=None):
        captured["url"] = url
        captured["headers"] = headers
        captured["body"] = json
        return _MockResp()

    p = _make_head(local_avg=50.0, best_peer="https://peer.example")
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post", side_effect=mock_post):
        result = await p.synth("hello world", allow_federation=True)
    assert result == "aGVsbG8="
    assert captured["url"] == "https://peer.example/api/speak"
    assert captured["headers"]["X-Federation-Hops"] == "1"
    assert captured["body"] == {"text": "hello world"}


@pytest.mark.asyncio
async def test_tts_head_synth_returns_none_on_hop_limit():
    p = _make_head(local_avg=50.0)
    result = await p.synth("hello", allow_federation=False)
    assert result is None


@pytest.mark.asyncio
async def test_tts_head_synth_returns_none_on_http_error():
    class _ErrResp:
        status = 500
        async def json(self): return {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    p = _make_head(local_avg=50.0)
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _ErrResp()):
        result = await p.synth("hello", allow_federation=True)
    assert result is None


@pytest.mark.asyncio
async def test_tts_head_synth_returns_none_on_timeout():
    p = _make_head(local_avg=50.0)
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=asyncio.TimeoutError()):
        result = await p.synth("hello", allow_federation=True)
    assert result is None


@pytest.mark.asyncio
async def test_tts_head_synth_returns_none_on_empty_audio():
    """Peer responded 200 but with empty audio_b64 — treat as failure."""
    class _MockResp:
        status = 200
        async def json(self):
            return {"audio_b64": "", "provider": "none"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    p = _make_head(local_avg=50.0)
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await p.synth("hello", allow_federation=True)
    assert result is None


# ─── Pre-flight local probe behavior ───────────────────────────────


@pytest.mark.asyncio
async def test_tts_head_probe_calls_local_recovery_when_local_alive():
    """The crucial fix: probe finds local TTS responding → call
    recovery callback (clears stale state) → return None (chain
    falls through to local). Without this, federation would fire
    even after local TTS recovered."""
    recovered_with = []

    async def recovery(provider_name):
        recovered_with.append(provider_name)

    p = _make_head(local_avg=50.0, best_peer="https://peer.example")
    mock_local = MagicMock()
    mock_local.name = "Kokoro Service (localhost:9998)"
    mock_chain = MagicMock()
    mock_chain.probe_local = AsyncMock(return_value=mock_local)
    p.attach(mock_chain, recovery)

    result = await p.synth("hello", allow_federation=True)
    assert result is None, "Must return None so chain falls to local"
    assert recovered_with == ["Kokoro Service (localhost:9998)"]


@pytest.mark.asyncio
async def test_tts_head_probe_proceeds_with_federation_when_local_dead():
    """When the probe finds local TTS dead, proceed with federated call."""
    recovered_with = []
    async def recovery(provider_name):
        recovered_with.append(provider_name)

    p = _make_head(local_avg=50.0, best_peer="https://peer.example")
    mock_chain = MagicMock()
    mock_chain.probe_local = AsyncMock(return_value=None)
    p.attach(mock_chain, recovery)

    class _MockResp:
        status = 200
        async def json(self):
            return {"audio_b64": "ZmVk", "provider": "Kokoro"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await p.synth("hello", allow_federation=True)
    assert result == "ZmVk"
    assert recovered_with == [], "Recovery callback must NOT fire when local dead"


@pytest.mark.asyncio
async def test_tts_head_probe_callback_failure_does_not_block_query():
    """If the recovery callback raises (e.g. bus publish failed),
    the query path must NOT die. Log and continue."""
    async def bad_recovery(provider_name):
        raise RuntimeError("bus is down")

    p = _make_head(local_avg=50.0, best_peer="https://peer.example")
    mock_local = MagicMock()
    mock_local.name = "Kokoro"
    mock_chain = MagicMock()
    mock_chain.probe_local = AsyncMock(return_value=mock_local)
    p.attach(mock_chain, bad_recovery)

    # Should not raise — returns None so chain falls through
    result = await p.synth("hello", allow_federation=True)
    assert result is None


@pytest.mark.asyncio
async def test_tts_head_no_probe_when_chain_not_attached():
    """If chain is None (attach not called), skip probe and proceed
    with federated call directly. Backward compat for any caller that
    forgets to attach."""
    p = _make_head(local_avg=50.0, best_peer="https://peer.example")
    # No attach() called

    class _MockResp:
        status = 200
        async def json(self): return {"audio_b64": "eA==", "provider": "K"}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "post",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await p.synth("hello", allow_federation=True)
    assert result == "eA=="


# ─── Tail probe (same pattern as head) ─────────────────────────────


@pytest.mark.asyncio
async def test_tts_tail_probe_calls_recovery_when_local_alive():
    """Tail probe is belt-and-suspenders — even at the rescue path,
    one last probe gives local a chance. Same recovery side effects."""
    recovered_with = []
    async def recovery(name):
        recovered_with.append(name)

    p = _make_tail()
    mock_local = MagicMock()
    mock_local.name = "Kokoro Service"
    mock_chain = MagicMock()
    mock_chain.probe_local = AsyncMock(return_value=mock_local)
    p.attach(mock_chain, recovery)

    result = await p.synth("hello", allow_federation=True)
    assert result is None
    assert recovered_with == ["Kokoro Service"]


# ─── Distinct names from each other ────────────────────────────────


def test_tts_providers_have_distinct_names():
    """Cockpit needs to tell the two providers apart in the badge."""
    assert (FederationTTSProvider.name
            != FederationTTSFallbackProvider.name)
    assert "Fallback" in FederationTTSFallbackProvider.name


def test_tts_provider_names_distinct_from_llm_providers():
    """The badge shows 'TTS:' for TTS provider and 'LLM:' for LLM
    provider. The provider NAMES should also be distinct so logs and
    debug output are clear."""
    from realm.federation_provider import (
        FederationLLMProvider, FederationLLMFallbackProvider,
    )
    llm_names = {FederationLLMProvider.name, FederationLLMFallbackProvider.name}
    tts_names = {FederationTTSProvider.name, FederationTTSFallbackProvider.name}
    assert llm_names.isdisjoint(tts_names)


# ─── TTS chain ordering invariant (shower bug #2, 2026-06-22) ──────
# Bug found in production failover test: when KokoroService dies and the
# FALLBACK federation provider is APPENDED at the end of the chain, SAPI5
# always succeeds (Windows OS built-in) and the chain stops there. The
# fallback federation provider is never reached, so federation TTS rescue
# never fires. User hears robot voice instead of getting federated to peer.
#
# Fix: insert the FALLBACK federation provider IMMEDIATELY AFTER the
# preferred local TTS provider (KokoroService at position 1), BEFORE the
# "robot voice" floor providers (SAPI5, in-process Kokoro, ElevenLabs,
# OpenAI, pyttsx3). This matches the LLM chain semantic — federate to a
# peer before falling through to the degraded floor.


def test_tts_fallback_position_is_after_kokoro_service_before_floor():
    """The FALLBACK federation provider must sit AFTER KokoroService but
    BEFORE SAPI5 (and any other floor providers). This pins the chain
    ordering so the production bug stays fixed.

    Without this position, killing KokoroService falls through to SAPI5
    (always succeeds on Windows) and never reaches federation rescue —
    the user hears robot voice instead of being federated to a healthy
    peer realm."""
    # Simulate the chain construction order from app.py with the bug fix:
    # 1. tts_chain starts with operator's tts_order providers
    # 2. HEAD federation provider inserted at index 0
    # 3. FALLBACK federation provider inserted at index 2
    chain = [
        "KokoroService",       # operator's primary local TTS
        "SAPI5",               # OS robot voice — always succeeds on Windows
        "Kokoro",              # in-process Kokoro
        "ElevenLabs",          # cloud
        "OpenAI",              # cloud
        "pyttsx3",             # final floor
    ]
    # Apply app.py's wiring order (mirrors the actual code)
    chain.insert(0, "FederationTTSHead")
    chain.insert(2, "FederationTTSFallback")

    # Invariants:
    # [0] HEAD federation — first crack at every query
    # [1] KokoroService — preferred local
    # [2] FALLBACK federation — fires when Kokoro dead, peer healthy
    # [3+] SAPI5 and other floors — only reached if federation also down
    assert chain[0] == "FederationTTSHead"
    assert chain[1] == "KokoroService"
    assert chain[2] == "FederationTTSFallback"
    assert chain[3] == "SAPI5"

    # The critical invariant: FALLBACK federation is BEFORE SAPI5.
    # If this ever flips, the production bug returns.
    fallback_idx = chain.index("FederationTTSFallback")
    sapi5_idx = chain.index("SAPI5")
    assert fallback_idx < sapi5_idx, (
        "REGRESSION: FederationTTSFallback must fire BEFORE SAPI5. "
        "Otherwise SAPI5 (Windows built-in TTS) always answers and the "
        "chain never reaches federation rescue. Killing Kokoro produces "
        "robot voice instead of federating to peer.")


def test_tts_fallback_is_before_all_floor_providers():
    """Generalization of the previous test: FALLBACK federation must
    precede EVERY floor provider in the chain, not just SAPI5. The 'floor'
    is everything after the preferred local provider."""
    chain = ["KokoroService", "SAPI5", "Kokoro", "ElevenLabs",
             "OpenAI", "pyttsx3"]
    chain.insert(0, "FederationTTSHead")
    chain.insert(2, "FederationTTSFallback")

    fallback_idx = chain.index("FederationTTSFallback")
    floor_providers = ["SAPI5", "Kokoro", "ElevenLabs", "OpenAI", "pyttsx3"]
    for floor in floor_providers:
        floor_idx = chain.index(floor)
        assert fallback_idx < floor_idx, (
            f"REGRESSION: FederationTTSFallback (index {fallback_idx}) "
            f"must precede floor provider {floor} (index {floor_idx})")
