"""
Integration + chaos harness.

test_loop_responsiveness  — the flagship: PROVES the old blocking pattern
                            stalls the loop and the executor pattern doesn't.
test_ws_integration       — full protocol over real sockets via uvicorn.
test_chaos                — 30 clients, random mid-query deaths, terminate
                            storms; the realm must stay correct and live.
"""

import asyncio
import base64
import random

import pytest

import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from realm.realm_core import build_app
from .engines import FakeEngines, BlockingEngines, ExecutorEngines
from .conftest import RealmServer, RealmClient, LoopLagProbe

pytestmark = pytest.mark.asyncio

AUDIO = base64.b64encode(b"fake-webm-audio").decode()


# ---------------------------------------------------------------------------
# THE SPEECH FIX, PROVEN
# ---------------------------------------------------------------------------

async def test_blocking_engines_stall_the_loop__original_bug_reproduced(lag_probe):
    """Documents the original failure: one speech query freezes the realm.
    If this test ever FAILS, the probe is broken — it must detect the stall."""
    app = build_app(BlockingEngines(block_seconds=0.8))
    async with RealmServer(app) as srv:
        # Probe runs in THIS process's loop; uvicorn shares it -> stall visible.
        lag_probe.start()
        c = await RealmClient(srv.url).connect()
        await c.submit("", query_type="speech", audio=AUDIO)
        await c.wait_for("query_result", timeout=10)
        await lag_probe.stop()
        await c.close()
    assert lag_probe.max_lag > 0.6, (
        "expected the blocking engine to stall the loop ~0.8s; "
        f"saw only {lag_probe.max_lag:.3f}s")


async def test_executor_engines_keep_loop_responsive_under_speech_load(lag_probe):
    """The fix: 5 concurrent speech queries (0.8s of 'GPU work' each) while a
    6th client exchanges heartbeats. Loop lag must stay tiny and the
    heartbeat client must never miss a beat."""
    app = build_app(ExecutorEngines(block_seconds=0.8, workers=4))
    async with RealmServer(app) as srv:
        lag_probe.start()
        speakers = [await RealmClient(srv.url).connect() for _ in range(5)]
        bystander = await RealmClient(srv.url).connect()

        for c in speakers:
            await c.submit("", query_type="speech", audio=AUDIO)

        # Bystander pings the realm every 50ms while the "GPU" is busy.
        rtts = []
        for _ in range(20):
            t0 = asyncio.get_event_loop().time()
            await bystander.send({"type": "pong"})  # server touch round
            await asyncio.sleep(0.05)
            rtts.append(asyncio.get_event_loop().time() - t0)

        for c in speakers:
            await c.wait_for("query_result", timeout=15)
        await lag_probe.stop()
        for c in speakers + [bystander]:
            await c.close()

    assert lag_probe.max_lag < 0.15, (
        f"loop stalled {lag_probe.max_lag:.3f}s under speech load — "
        "the executor offload regressed")


# ---------------------------------------------------------------------------
# PROTOCOL INTEGRATION
# ---------------------------------------------------------------------------

async def test_chat_roundtrip_and_accounting():
    stats = []
    app = build_app(FakeEngines(infer_latency=0.02), stats_log=stats)
    async with RealmServer(app) as srv:
        c = await RealmClient(srv.url).connect()
        await c.submit("hello realm")
        (msg,) = await c.wait_for("query_result")
        assert msg["result"] == "echo:hello realm"
        assert msg["result_type"] == "text"
        assert msg["cost"] > 0
        await c.close()
    assert len(stats) == 1 and stats[0]["guid"] == c.guid


async def test_speech_pipeline_stt_then_chat_then_tts():
    app = build_app(FakeEngines())
    async with RealmServer(app) as srv:
        c = await RealmClient(srv.url).connect()
        q = {"prompt": "", "query_type": "speech", "model_type": "speech",
             "model_name": "test", "audio": AUDIO}
        await c.send({"type": "submit_query", "query": q})
        (msg,) = await c.wait_for("query_result")
        assert msg["result_type"] == "audio"
        await c.close()


async def test_disconnect_mid_query_does_not_kill_realm_and_stats_survive():
    """OLD BUG: result sent to a dead socket raised; the error handler then
    raised AGAIN sending the error; accounting was lost; broadcast in finally
    could kill the processor. Now: realm shrugs, stats recorded, next client
    is fine."""
    stats = []
    app = build_app(FakeEngines(infer_latency=0.3), stats_log=stats)
    async with RealmServer(app) as srv:
        doomed = await RealmClient(srv.url).connect()
        await doomed.submit("ill never see this")
        await asyncio.sleep(0.05)          # query now in flight
        await doomed.kill()                 # abrupt TCP death, no close frame

        survivor = await RealmClient(srv.url).connect()
        await survivor.submit("still alive?")
        (msg,) = await survivor.wait_for("query_result", timeout=5)
        assert msg["result"] == "echo:still alive?"
        await survivor.close()

        assert any(s["guid"] == doomed.guid for s in stats), \
            "accounting lost for disconnected client"
        # server cleanup is async; give the finally blocks a beat to land
        for _ in range(100):
            if app.state.manager.count() == 0:
                break
            await asyncio.sleep(0.02)
        assert app.state.manager.count() == 0, "ghost connections remain"
        assert app.state.queue.depth() == 0


async def test_banned_user_leaves_no_ghost():
    users = {"banned-guid": {"guid": "banned-guid", "nickname": "x",
                             "is_sysop": False, "is_banned": True}}
    app = build_app(FakeEngines(), user_store=users)
    async with RealmServer(app) as srv:
        import websockets, json
        ws = await websockets.connect(
            srv.url, additional_headers={"Cookie": "user_guid=banned-guid"})
        msg = json.loads(await ws.recv())
        assert msg["type"] == "error" and msg["message"] == "banned"
        # server closes; recv must terminate
        with pytest.raises(websockets.exceptions.ConnectionClosed):
            await asyncio.wait_for(ws.recv(), timeout=2)
        assert app.state.manager.count() == 0, \
            "banned user ghost left in active_connections (the old bug)"


async def test_sysop_terminate_cancels_inflight_query():
    app = build_app(FakeEngines(infer_latency=5.0))
    async with RealmServer(app) as srv:
        sysop = await RealmClient(srv.url).connect()    # first user = sysop
        victim = await RealmClient(srv.url).connect()
        await victim.submit("doomed work")
        await asyncio.sleep(0.1)
        assert app.state.queue.inflight() == 1
        await sysop.send({"type": "terminate_query", "user_guid": victim.guid})
        await sysop.wait_for("query_terminated")
        for _ in range(50):
            if app.state.queue.depth() == 0:
                break
            await asyncio.sleep(0.05)
        assert app.state.queue.depth() == 0, "terminate left the query running"
        await sysop.close(); await victim.close()


async def test_silent_client_is_reaped_and_responsive_client_is_not():
    app = build_app(FakeEngines(), ping_interval=0.2, stale_after=0.5)
    async with RealmServer(app) as srv:
        good = await RealmClient(srv.url).connect()              # auto-pongs
        mute = await RealmClient(srv.url, auto_pong=False).connect()
        await asyncio.sleep(1.5)
        assert app.state.manager.count() == 1, \
            f"expected mute client reaped; have {app.state.manager.count()}"
        assert good.guid in app.state.manager.active_guids()
        await asyncio.wait_for(mute.closed_by_server.wait(), timeout=2)
        await good.close(); await mute.close()


async def test_queue_full_rejection():
    app = build_app(FakeEngines(infer_latency=2.0), max_queue_size=2)
    async with RealmServer(app) as srv:
        c = await RealmClient(srv.url).connect()
        for i in range(5):
            await c.submit(f"q{i}")
        await c.wait_for("error", timeout=5)
        errs = [m["message"] for m in c.inbox["error"]]
        assert any("full" in e for e in errs)
        await c.close()


# ---------------------------------------------------------------------------
# CHAOS
# ---------------------------------------------------------------------------

async def test_chaos_swarm_random_deaths_and_terminations(lag_probe):
    """30 clients x 3 queries; a third die abruptly at random moments; the
    sysop fires random terminations. Afterward the realm must be: alive,
    drained, ghost-free, responsive, and every surviving client got every
    result for queries that weren't terminated."""
    random.seed(1138)
    app = build_app(FakeEngines(infer_latency=0.05))
    async with RealmServer(app) as srv:
        lag_probe.start()
        sysop = await RealmClient(srv.url).connect()
        clients = [await RealmClient(srv.url).connect() for _ in range(30)]
        doomed = set(random.sample(range(30), 10))
        terminated_guids = set()

        async def client_life(i, c):
            for n in range(3):
                await c.submit(f"c{i}-q{n}")
                await asyncio.sleep(random.uniform(0.01, 0.12))
                if i in doomed and n == 1:
                    await c.kill()
                    return

        async def sysop_storm():
            for _ in range(8):
                await asyncio.sleep(random.uniform(0.05, 0.15))
                victim = random.choice(clients)
                terminated_guids.add(victim.guid)
                await sysop.send({"type": "terminate_query",
                                  "user_guid": victim.guid})

        await asyncio.gather(*(client_life(i, c) for i, c in enumerate(clients)),
                             sysop_storm())

        # let the realm drain
        for _ in range(200):
            if app.state.queue.depth() == 0:
                break
            await asyncio.sleep(0.05)
        await lag_probe.stop()

        assert app.state.queue.depth() == 0, "queue failed to drain"
        assert app.state.processor.status.is_running, "queue processor died"

        # realm still answers a fresh client promptly
        fresh = await RealmClient(srv.url).connect()
        await fresh.submit("post-chaos sanity")
        (msg,) = await fresh.wait_for("query_result", timeout=5)
        assert msg["result"] == "echo:post-chaos sanity"

        # survivors who were never terminated got all 3 results
        for i, c in enumerate(clients):
            if i in doomed or c.guid in terminated_guids:
                continue
            results = c.inbox.get("query_result", [])
            assert len(results) == 3, (
                f"client {i} got {len(results)}/3 results; "
                f"inbox={ {k: len(v) for k, v in c.inbox.items()} }")

        # no ghosts: only sysop + survivors + fresh remain registered
        expected_live = 1 + (30 - len(doomed)) + 1
        assert app.state.manager.count() == expected_live, (
            f"ghost audit: expected {expected_live} live, "
            f"manager has {app.state.manager.count()}")

        assert lag_probe.max_lag < 0.25, \
            f"loop stalled {lag_probe.max_lag:.3f}s during chaos"

        await fresh.close(); await sysop.close()
        for i, c in enumerate(clients):
            if i not in doomed:
                await c.close()
