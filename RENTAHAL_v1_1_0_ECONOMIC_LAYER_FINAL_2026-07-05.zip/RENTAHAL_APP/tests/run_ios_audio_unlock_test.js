// run_ios_audio_unlock_test.js — verify the iOS audio-unlock + tap-to-hear
// fallback exists in the code.
//
// History: this exists because Jim Ames reported on iPhone — "you have to
// play a WAV one of the news THEN it starts talking weather and AI". That
// was iOS WebKit refusing to autoplay <audio> elements outside a user
// gesture window. The unlock pattern is the standard fix.
//
// We verify by inspecting the source: the unlock data URI must exist,
// must target the right element, and the tap-to-hear fallback must be
// wired up.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
if (!scriptMatch) {
  console.error('no <script> block found');
  process.exit(1);
}
const js = scriptMatch[1];

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// Test 1: silent WAV data URI present (the iOS unlock)
const unlockExists = /silentWav\s*=\s*['"]?\s*['"]?data:audio\/wav/.test(js);
assert(unlockExists,
       'installStartupSound contains silent-WAV data URI for iOS unlock');

// Test 2: the unlock primes the player element (not a new Audio)
// This is the critical detail — has to be the SAME <audio> the realm
// uses for TTS, otherwise the "user activation" doesn't transfer
const usesPlayerElement = /player\.src\s*=\s*silentWav/.test(js);
assert(usesPlayerElement,
       'unlock primes player element (not new Audio)',
       'iOS unlock has to target the SAME element TTS will use');

// Test 3: touchend listener registered (iPhone-specific — click events
// have a 300ms delay on Safari that can miss the gesture window)
const hasTouchend = /addEventListener\(['"]touchend['"]/.test(js);
assert(hasTouchend, 'touchend listener registered (covers iPhone)');

// Test 4: offerTapToHear function exists as the bottom-of-stack fallback
const hasFallback = /function offerTapToHear/.test(js);
assert(hasFallback, 'offerTapToHear fallback function defined');

// Test 5: playAudio calls offerTapToHear when both formats fail.
// Look for offerTapToHear inside the tryNext closure that's INSIDE playAudio's
// function body. Using non-greedy match + check the i >= tryFormats.length
// branch specifically calls offerTapToHear.
const playAudioCallsOffer = /i\s*>=\s*tryFormats\.length[\s\S]{0,400}?offerTapToHear\s*\(/.test(js);
assert(playAudioCallsOffer,
       'playAudio falls through to offerTapToHear after both formats fail');

// Test 6: the tap-to-hear button is a real, clickable UI element
const buttonHasOnclick = /tap-to-hear|🔊|Tap to hear/.test(js);
assert(buttonHasOnclick,
       'tap-to-hear button has user-visible label');

// Test 7: the unlock sets volume = 0 (so the silent WAV makes no actual sound)
const silentVolume = /silentWav[\s\S]{1,200}volume\s*=\s*0/.test(js);
assert(silentVolume,
       'silent WAV plays at volume 0 (truly inaudible)');

// Test 8: after unlock, volume gets restored to 1 (for real TTS)
const restoresVolume = /player\.volume\s*=\s*1/.test(js);
assert(restoresVolume,
       'volume restored to 1 after unlock so real TTS is audible');

console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} iOS audio unlock tests passed`);
  process.exit(0);
}
