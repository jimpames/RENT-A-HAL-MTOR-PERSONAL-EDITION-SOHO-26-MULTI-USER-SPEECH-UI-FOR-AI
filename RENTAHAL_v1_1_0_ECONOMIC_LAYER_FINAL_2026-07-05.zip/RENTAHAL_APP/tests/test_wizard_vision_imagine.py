"""
Sprint 9 tests — wizard glue-up for Vision (LLaVA) and Imagine
(Automatic1111). Mirrors test_wizard.py's existing probe_gpt4all test
conventions exactly.

  probe_llava — same shape as probe_gpt4all: {up, models, error}
    - success returns installed Ollama model names
    - empty model list still up=True
    - HTTP error, timeout, connection-refused all handled
    - connection-refused error message reassures it's optional (doesn't
      read like a hard failure, since it isn't one)

  probe_automatic1111 — same shape
    - success returns checkpoint names (model_name field)
    - falls back to 'title' field when model_name absent
    - empty list, HTTP error, timeout, connection-refused all handled

  Gate behavior — node_type-aware
    - node_type='chat' (the default, every pre-existing deployment):
      behaves EXACTLY as before — GPT4All required, vision/imagine
      probes irrelevant regardless of their state
    - node_type='vision'/'imagine': the corresponding backend becomes
      the actual gate requirement INSTEAD of GPT4All — a vision-primary
      or imagine-primary deployment (a completely valid mode per the
      multi-mode federation design) doesn't need chat working at all
    - This is a deliberate design decision made explicitly, not a side
      effect: an EARLIER version of this file asserted vision/imagine
      could NEVER influence the gate under any circumstances. That was
      correct for a chat-primary realm (where vision/imagine really are
      optional extras) but wrong for a realm that's explicitly declared
      a different primary role — see is_go_allowed's docstring for the
      full reasoning.

  _read_config_ini / save() — the wiring
    - reads llava_host/port/model and automatic1111_host/port with
      sane defaults
    - save() writes them regardless of whether a GPT4All model is
      selected (the bug this sprint fixed — previously the ENTIRE
      fields dict, including realm_name/tagline, was silently skipped
      whenever gpt4all_model was empty)
"""
import asyncio
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import wizard


# ─── probe_llava ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_probe_llava_returns_models_on_success():
    class _MockResp:
        status = 200
        async def json(self):
            # Ollama's /api/tags shape
            return {"models": [
                {"name": "llava:latest", "size": 4700000000},
                {"name": "llava:13b", "size": 8000000000},
            ]}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_llava("localhost", 11434)
    assert result["up"] is True
    assert "llava:latest" in result["models"]
    assert "llava:13b" in result["models"]
    assert result["error"] is None


@pytest.mark.asyncio
async def test_probe_llava_handles_empty_model_list():
    class _MockResp:
        status = 200
        async def json(self): return {"models": []}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_llava("localhost", 11434)
    assert result["up"] is True
    assert result["models"] == []


@pytest.mark.asyncio
async def test_probe_llava_handles_http_error():
    class _MockResp:
        status = 500
        async def json(self): return {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_llava("localhost", 11434)
    assert result["up"] is False
    assert "500" in result["error"]


@pytest.mark.asyncio
async def test_probe_llava_handles_timeout():
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=asyncio.TimeoutError()):
        result = await wizard.probe_llava("localhost", 11434)
    assert result["up"] is False
    assert "imed out" in result["error"]


@pytest.mark.asyncio
async def test_probe_llava_handles_connection_refused_reassuringly():
    """The error message must read as 'this is fine, it's optional' —
    not as an alarming failure, since Ollama not running is a
    completely normal state for a chat-primary or imagine-primary
    deployment."""
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=aiohttp.ClientConnectorError(
                          MagicMock(), OSError(111, "refused"))):
        result = await wizard.probe_llava("localhost", 11434)
    assert result["up"] is False
    assert "optional" in result["error"].lower()


# ─── probe_automatic1111 ────────────────────────────────────────────

@pytest.mark.asyncio
async def test_probe_automatic1111_returns_models_on_success():
    class _MockResp:
        status = 200
        async def json(self):
            # AUTOMATIC1111's /sdapi/v1/sd-models shape
            return [
                {"title": "sd_xl_base_1.0.safetensors [abc123]",
                 "model_name": "sd_xl_base_1.0"},
                {"title": "v1-5-pruned.safetensors [def456]",
                 "model_name": "v1-5-pruned"},
            ]
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_automatic1111("localhost", 7860)
    assert result["up"] is True
    assert "sd_xl_base_1.0" in result["models"]
    assert "v1-5-pruned" in result["models"]
    assert result["error"] is None


@pytest.mark.asyncio
async def test_probe_automatic1111_falls_back_to_title_when_no_model_name():
    class _MockResp:
        status = 200
        async def json(self):
            return [{"title": "some_checkpoint.safetensors"}]
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_automatic1111("localhost", 7860)
    assert result["models"] == ["some_checkpoint.safetensors"]


@pytest.mark.asyncio
async def test_probe_automatic1111_handles_empty_list():
    class _MockResp:
        status = 200
        async def json(self): return []
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_automatic1111("localhost", 7860)
    assert result["up"] is True
    assert result["models"] == []


@pytest.mark.asyncio
async def test_probe_automatic1111_handles_http_error():
    class _MockResp:
        status = 404
        async def json(self): return {}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=lambda *a, **kw: _MockResp()):
        result = await wizard.probe_automatic1111("localhost", 7860)
    assert result["up"] is False
    assert "404" in result["error"]


@pytest.mark.asyncio
async def test_probe_automatic1111_handles_timeout():
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=asyncio.TimeoutError()):
        result = await wizard.probe_automatic1111("localhost", 7860)
    assert result["up"] is False
    assert "imed out" in result["error"]


@pytest.mark.asyncio
async def test_probe_automatic1111_handles_connection_refused_reassuringly():
    import aiohttp
    with patch.object(aiohttp.ClientSession, "get",
                      side_effect=aiohttp.ClientConnectorError(
                          MagicMock(), OSError(111, "refused"))):
        result = await wizard.probe_automatic1111("localhost", 7860)
    assert result["up"] is False
    assert "optional" in result["error"].lower()


# ─── Gate exclusion — the actual point ──────────────────────────────

def test_chat_mode_default_gate_unaffected_by_node_type_addition():
    """node_type='chat' (the default — every pre-existing deployment)
    must behave EXACTLY as before: GPT4All still required, vision/
    imagine probes still irrelevant regardless of their state."""
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True,
        node_type="chat",
        vision_probe={"up": True, "models": ["llava"], "error": None},
        imagine_probe={"up": True, "models": ["sdxl"], "error": None})
    assert allowed is False
    assert "GPT4All" in reason


def test_vision_primary_node_gates_on_vision_not_gpt4all():
    """A vision-primary node ([Federation] node_type = vision) must be
    blocked by a DOWN vision backend, even if GPT4All is also down —
    and the reason must be about vision, not GPT4All. This is the
    deliberate reversal: chat is the OPTIONAL one for this deployment
    shape, not the hard requirement."""
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},   # GPT4All down too
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True,
        node_type="vision",
        vision_probe={"up": False, "models": [], "error": "not running"})
    assert allowed is False
    assert "vision" in reason.lower() or "Ollama" in reason


def test_vision_primary_node_allowed_when_vision_backend_up():
    """The positive case: vision backend up + models installed, GPT4All
    completely down and irrelevant — GO must still be allowed."""
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True,
        node_type="vision",
        vision_probe={"up": True, "models": ["llava:latest"], "error": None})
    assert allowed is True


def test_vision_primary_node_blocked_when_up_but_no_models():
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True,
        node_type="vision",
        vision_probe={"up": True, "models": [], "error": None})
    assert allowed is False
    assert "ollama pull llava" in reason.lower()


def test_imagine_primary_node_gates_on_imagine_not_gpt4all():
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True,
        node_type="imagine",
        imagine_probe={"up": False, "models": [], "error": "not running"})
    assert allowed is False
    assert "imagine" in reason.lower() or "AUTOMATIC1111" in reason


def test_imagine_primary_node_allowed_when_imagine_backend_up():
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True,
        node_type="imagine",
        imagine_probe={"up": True, "models": ["sd_xl_base_1.0"], "error": None})
    assert allowed is True


def test_cuda_gate_still_applies_to_vision_and_imagine_modes():
    """CUDA check is universal — a vision-primary node with no GPU is
    still blocked, same as chat."""
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": False, "error": "no driver"}, require_cuda=True,
        node_type="vision",
        vision_probe={"up": True, "models": ["llava"], "error": None})
    assert allowed is False
    assert "CUDA" in reason


def test_unknown_node_type_falls_back_to_chat_gate():
    """A typo or genuinely new node_type value falls back to the chat
    gate rather than silently allowing GO with no real check at all."""
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True,
        node_type="some_typo_value")
    assert allowed is False
    assert "GPT4All" in reason


def test_federation_desire_gate_still_applies_in_vision_mode():
    """The federation self_url check must still apply regardless of
    node_type — it's an orthogonal concern."""
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=True, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True,
        node_type="vision",
        vision_probe={"up": True, "models": ["llava"], "error": None})
    assert allowed is False
    assert "ngrok" in reason.lower() or "Federation" in reason


def test_is_go_allowed_still_gates_on_gpt4all_regardless_of_vision_imagine():
    """Sanity check the existing hard gate is completely untouched —
    still blocks on GPT4All down, with no new escape hatch."""
    allowed, reason = wizard.is_go_allowed(
        {"up": False, "models": [], "error": "down"},
        self_url="", desire=False, selected_model="",
        cuda_probe={"ok": True}, require_cuda=True)
    assert allowed is False
    assert "GPT4All" in reason


# ─── _read_config_ini — Vision/Imagine fields ───────────────────────

def test_read_config_ini_includes_vision_imagine_defaults(tmp_path, monkeypatch):
    ini = tmp_path / "config.ini"
    ini.write_text("[Server]\nhost = 0.0.0.0\n")   # minimal, no LLaVA/A1111 section
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)
    cfg = wizard._read_config_ini()
    assert cfg["llava_host"] == "localhost"
    assert cfg["llava_port"] == 11434
    assert cfg["llava_model"] == "llava"
    assert cfg["automatic1111_host"] == "localhost"
    assert cfg["automatic1111_port"] == 7860


def test_read_config_ini_reads_custom_vision_imagine_values(tmp_path, monkeypatch):
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[LLaVA]\nhost = 192.168.1.50\nport = 11500\nmodel = llava:34b\n"
        "[Automatic1111]\nhost = 192.168.1.51\nport = 7861\n")
    monkeypatch.setattr(wizard, "CONFIG_INI", ini)
    cfg = wizard._read_config_ini()
    assert cfg["llava_host"] == "192.168.1.50"
    assert cfg["llava_port"] == 11500
    assert cfg["llava_model"] == "llava:34b"
    assert cfg["automatic1111_host"] == "192.168.1.51"
    assert cfg["automatic1111_port"] == 7861


# ─── save() — the fields dict gate fix ──────────────────────────────

@pytest.mark.asyncio
async def test_save_writes_vision_imagine_fields_even_without_gpt4all_model(
        tmp_path, monkeypatch):
    """THE bug this sprint fixed: previously the entire fields dict —
    including realm_name/tagline, not just vision/imagine — was
    silently skipped whenever gpt4all_model was empty. A vision-primary
    or imagine-primary deployment (a completely valid 'mode' per the
    multi-mode federation design) might never select a GPT4All model
    at all, and must still get ITS OWN fields saved."""
    config_ini = tmp_path / "config.ini"
    config_ini.write_text(
        "[GPT4All]\nmodel = \n"
        "[Branding]\nrealm_name = Old Name\n"
        "[LLaVA]\nhost = localhost\nport = 11434\nmodel = llava\n"
        "[Automatic1111]\nhost = localhost\nport = 7860\n"
        "[VoiceLoop]\nwake_word_duration = short\nprivacy_beacon = true\n"
        "[ngrok]\nurl = \n"
    )
    monkeypatch.setattr(wizard, "CONFIG_INI", config_ini)
    federation_ini = tmp_path / "federation.ini"
    federation_ini.write_text("[Federation]\ndesire = on\n")
    monkeypatch.setattr(wizard, "FEDERATION_INI", federation_ini)

    app = wizard.build_app()
    from fastapi.testclient import TestClient
    client = TestClient(app)

    resp = client.post("/api/wizard/save", json={
        "gpt4all_model": "",           # deliberately empty — the bug trigger
        "realm_name": "Vision Node One",
        "tagline": "Vision Realm",
        "wake_word_duration": "short",
        "privacy_beacon": True,
        "desire": True,
        "master_url": "https://rentahal.com/api/federate",
        "self_url": "",
        "llava_host": "192.168.1.99",
        "llava_port": "11434",
        "llava_model": "llava:13b",
        "automatic1111_host": "192.168.1.98",
        "automatic1111_port": "7860",
    })
    assert resp.status_code == 200
    assert resp.json()["saved"] is True

    written = config_ini.read_text()
    assert "Vision Node One" in written          # realm_name WAS written
    assert "192.168.1.99" in written              # llava_host WAS written
    assert "192.168.1.98" in written              # a1111_host WAS written
