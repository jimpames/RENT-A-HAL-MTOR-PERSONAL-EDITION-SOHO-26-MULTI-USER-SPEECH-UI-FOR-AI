// run_service_voice_path_test.js — regression tests for:
//   1. Voice path triggers location prompt when service-finder phrase
//      is detected and no location is cached (was missing before; voice
//      users got "I need your location" but no actual prompt).
//   2. startThinkingSound has a generation counter to prevent the
//      async mp3.play().catch() callback from creating an untracked
//      AudioContext after stop has been called (the "beep forever" bug).
//   3. Wake-word click also requests geolocation upfront, so one user
//      gesture grants both microphone and location.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Bug 1 fix: thinking-sound race-condition guard ─────────────

// The generation counter must be declared as a global.
assert(/let thinkingGeneration\s*=\s*0/.test(html),
       'thinkingGeneration counter declared as global');

// startThinkingSound bumps the counter and captures the local value.
// We don't try to nested-brace-match the function; instead we slice the
// file between the function header and the next top-level "function "
// declaration.
const startIdx = html.indexOf('function startThinkingSound()');
const stopIdx = html.indexOf('function stopThinkingSound()');
assert(startIdx > 0 && stopIdx > startIdx,
       'startThinkingSound found before stopThinkingSound');
const startFnSrc = (startIdx > 0 && stopIdx > startIdx)
  ? html.slice(startIdx, stopIdx) : '';
const startFn = startFnSrc ? [startFnSrc] : null;
assert(startFn !== null, 'startThinkingSound function extractable');
if (startFn) {
  assert(/thinkingGeneration\s*=\s*\(?\s*thinkingGeneration/.test(startFn[0]),
         'startThinkingSound bumps thinkingGeneration on entry');
  assert(/const\s+myGen\s*=\s*thinkingGeneration/.test(startFn[0]),
         'startThinkingSound captures myGen for race detection');
  // Look for the bail-out specifically inside the .catch() block —
  // it must check stale generation and RETURN before creating any new
  // AudioContext. We require the literal "skipping synth fallback" log
  // string so a future refactor that removes the guard fails this test.
  assert(/skipping synth fallback/.test(startFn[0]),
         'startThinkingSound checks generation in async catch (bails if stale)');
}

// stopThinkingSound also bumps so any pending catch sees a fresh gen.
const stopFn = html.match(/function stopThinkingSound\(\)[\s\S]+?\n\}/);
assert(stopFn !== null, 'stopThinkingSound function extractable');
if (stopFn) {
  assert(/thinkingGeneration\s*=\s*\(?\s*thinkingGeneration/.test(stopFn[0]),
         'stopThinkingSound bumps thinkingGeneration so pending catches see stale state');
}

// The synth fallback's tick() function checks generation each call.
if (startFn) {
  const tickMatch = startFn[0].match(/const\s+tick\s*=\s*\(\)\s*=>\s*\{[\s\S]+?\}/);
  if (tickMatch) {
    assert(/myGen\s*!==\s*thinkingGeneration/.test(tickMatch[0]),
           'tick() bails out if generation changed (no more zombie ticks)');
  } else {
    assert(false, 'tick() function should exist inside startThinkingSound');
  }
}

// ─── Bug 2 fix: voice path triggers location prompt ─────────────

assert(/SERVICE_TRIGGERS\s*=\s*\/\^/.test(html),
       'SERVICE_TRIGGERS regex defined for voice-path detection');
assert(/service finder /i.test(html),
       'SERVICE_TRIGGERS regex includes "service finder " prefix');
assert(/find a /i.test(html) && /find me /i.test(html) && /find nearby /i.test(html),
       'SERVICE_TRIGGERS regex includes find/find me/find nearby alternates');

// sendPrompt checks the trigger and ensures location FIRST
const sendPromptFn = html.match(/function sendPrompt\(text\)[\s\S]+?_actuallySendPrompt/);
assert(sendPromptFn !== null, 'sendPrompt extractable');
if (sendPromptFn) {
  assert(/SERVICE_TRIGGERS\.test/.test(sendPromptFn[0]),
         'sendPrompt tests for service-finder pattern');
  assert(/rentahal_user_location/.test(sendPromptFn[0]),
         'sendPrompt checks cached location before requesting');
  assert(/ensureLocation\(\)/.test(sendPromptFn[0]),
         'sendPrompt calls ensureLocation when no cache + service intent');
}

// _actuallySendPrompt is the inner send (gated behind location check)
assert(/function _actuallySendPrompt/.test(html),
       '_actuallySendPrompt helper exists (gated behind location check)');
assert(/_actuallySendPrompt[\s\S]+?startThinkingSound/.test(html),
       '_actuallySendPrompt is what starts thinking sound (location-gated)');

// Critically: when service-finder voice path lacks location AND user
// denies, we do NOT start thinking sound and do NOT send to realm.
// Otherwise the user gets the "beep forever" symptom for an actual
// scenario where nothing should happen.
if (sendPromptFn) {
  assert(/Service finder needs location permission/.test(html),
         'when user denies, shows inline error WITHOUT starting beep');
}

// ─── Bug 3 fix: wake-word click also requests geolocation ──────

const startWakeFn = html.match(/async function startWake\(\)[\s\S]+?\n\}/);
assert(startWakeFn !== null, 'startWake function extractable');
if (startWakeFn) {
  assert(/ensureLocation\(\)/.test(startWakeFn[0]),
         'startWake calls ensureLocation (piggybacks on user gesture)');
  // Must be fire-and-forget (not awaited) — denial shouldn't block wake
  assert(/ensureLocation\(\)\s*\.\s*catch/.test(startWakeFn[0]),
         'startWake uses .catch (not await) so denial doesn\'t block wake');
}

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} voice-path service tests passed`);
  process.exit(0);
}
