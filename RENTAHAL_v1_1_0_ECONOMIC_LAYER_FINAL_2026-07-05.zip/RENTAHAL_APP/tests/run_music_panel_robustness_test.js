// run_music_panel_robustness_test.js — regression tests for the music
// panel "iframe doesn't display after news+services" bug.
//
// User repro:
//   1. Run service finder haircut → results render
//   2. Run news → tiles render
//   3. Run music → audio says "playing X on youtube" but iframe doesn't
//      display and nothing plays
//
// Defensive fixes shipped:
//   - Music panel explicitly sets display:block AND visibility:visible
//   - Player container gets explicit minHeight, width, display so it
//     can't collapse to 0px from any parent layout interaction
//   - Iframe gets explicit width and height in its style.cssText
//   - openMusicPanel scrolls to the player container (not just the panel)
//     so the iframe is centered in the viewport, not hidden below the
//     panel header
//   - Diagnostic console logs report computed display + offsetHeight so
//     if this regresses, the console tells us exactly what's wrong
//
// What this test cannot verify: actual YouTube autoplay behavior. YouTube
// may refuse to autoplay when Chrome's autoplay policy considers the
// user-gesture context expired (e.g. after lots of intermediate actions).
// That's a YouTube/Chrome interaction outside our control. The fixes
// ensure WE present the iframe correctly; YouTube's response is YouTube's.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Extract relevant functions ───────────────────────────────

const openMusicIdx = html.indexOf('function openMusicPanel(query, videoId)');
const renderEmbedIdx = html.indexOf('function renderYouTubeEmbed');
const nextAfterRender = html.indexOf('\n// ──', renderEmbedIdx);
assert(openMusicIdx > 0 && renderEmbedIdx > openMusicIdx,
       'openMusicPanel and renderYouTubeEmbed both present');

const openMusicSrc = html.slice(openMusicIdx, renderEmbedIdx);
const renderEmbedSrc = html.slice(renderEmbedIdx, nextAfterRender);

// ─── Panel display defenses ────────────────────────────────────

assert(/panel\.style\.display\s*=\s*['"]block['"]/.test(openMusicSrc),
       'openMusicPanel sets style.display = block');
assert(/panel\.style\.visibility\s*=\s*['"]visible['"]/.test(openMusicSrc),
       'openMusicPanel also sets visibility:visible (belt-and-suspenders)');
assert(/getComputedStyle/.test(openMusicSrc),
       'openMusicPanel logs computed display for diagnostics');
assert(/panel\.offsetHeight/.test(openMusicSrc),
       'openMusicPanel logs panel offsetHeight (catches 0px parents)');

// ─── Player container forcing ─────────────────────────────────

assert(/container\.style\.minHeight/.test(renderEmbedSrc),
       'renderYouTubeEmbed forces container minHeight (no collapse to 0px)');
assert(/container\.style\.width\s*=\s*['"]100%['"]/.test(renderEmbedSrc),
       'renderYouTubeEmbed forces container width 100%');
assert(/container\.style\.display\s*=\s*['"]block['"]/.test(renderEmbedSrc),
       'renderYouTubeEmbed forces container display:block');
assert(/container\.offsetWidth/.test(renderEmbedSrc) &&
       /container\.offsetHeight/.test(renderEmbedSrc),
       'renderYouTubeEmbed logs container dimensions for diagnostics');

// ─── Iframe styling redundancy ────────────────────────────────

// iframe gets BOTH width attribute AND CSS width so if one fails the
// other still applies. Same for height.
assert(/iframe\.width\s*=\s*['"]100%['"]/.test(renderEmbedSrc),
       'iframe gets width attribute = 100%');
assert(/iframe\.height\s*=\s*['"]360['"]/.test(renderEmbedSrc),
       'iframe gets height attribute = 360');
assert(/width:100%;height:360px;display:block/.test(renderEmbedSrc) ||
       (/width:100%/.test(renderEmbedSrc) && /height:360px/.test(renderEmbedSrc)),
       'iframe also has explicit width/height in CSS (redundancy)');

// ─── Iframe load/error diagnostics ────────────────────────────

assert(/iframe\.onload\s*=/.test(renderEmbedSrc),
       'iframe.onload diagnostic handler attached');
assert(/iframe\.onerror\s*=/.test(renderEmbedSrc),
       'iframe.onerror diagnostic handler attached');

// ─── Scroll behavior ─────────────────────────────────────────

assert(/music-player-container/.test(openMusicSrc) &&
       /scrollPanelIntoView/.test(openMusicSrc),
       'openMusicPanel scrolls into view');

// Critically: when there's a video to play, scroll to the player
// container (not just the outer panel) so iframe is centered in viewport
const playerContainerScrollMatch =
  /scrollPanelIntoView\s*\(\s*playerContainer\s*\)/.test(openMusicSrc);
assert(playerContainerScrollMatch,
       'openMusicPanel scrolls to playerContainer when videoId present (not outer panel)');

// Fallback: when there's no video (empty open), scroll to panel
assert(/scrollPanelIntoView\s*\(\s*panel\s*\)/.test(openMusicSrc),
       'openMusicPanel scrolls to outer panel when no videoId (empty state)');

// ─── Compliance still intact ──────────────────────────────────
// These were passing before; verifying my changes didn't break them.

assert(!/listType=search/.test(renderEmbedSrc),
       'still no deprecated listType=search');
assert(/youtube\.com\/embed\//.test(renderEmbedSrc),
       'still uses canonical youtube.com/embed/<id> path');
assert(/autoplay=1/.test(renderEmbedSrc),
       'autoplay=1 retained (will be honored when Chrome permits)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} music panel robustness tests passed`);
  process.exit(0);
}
