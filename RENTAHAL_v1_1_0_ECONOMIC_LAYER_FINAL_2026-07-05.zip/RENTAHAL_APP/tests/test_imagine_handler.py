"""
Regression tests for make_imagine_handler — runs a free-form prompt
through the ImagineChain, publishing either an 'imagine_result' bus
event (real provider) or the shared 'easter_egg_video' event (Echo
floor — the rickroll, per engine_chain.py's EchoImagineProvider).

Same fake-chain approach as test_vision_handler.py.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

pytestmark = pytest.mark.asyncio


class FakeBus:
    def __init__(self):
        self.events = []

    async def publish(self, event_type, **payload):
        self.events.append({"type": event_type, "payload": payload})


class FakeImagineChain:
    """Same call shape as engine_chain.ImagineChain — generate() + last_provider."""
    def __init__(self, generate_result, last_provider):
        self._generate_result = generate_result
        self.last_provider = last_provider
        self.calls = []

    async def generate(self, prompt):
        self.calls.append(prompt)
        return self._generate_result


FAKE_PNG_B64 = "aWFtYWZha2Vwbmc="   # "iamafakepng"


async def test_real_provider_publishes_imagine_result():
    from app import make_imagine_handler
    chain = FakeImagineChain(generate_result=FAKE_PNG_B64,
                             last_provider="Automatic1111 (txt2img)")
    bus = FakeBus()
    handler = make_imagine_handler({}, chain)

    result = await handler({"prompt": "a kitten wearing a hat"},
                           "test-user", bus)

    assert "kitten" in result.lower()
    assert len(bus.events) == 1
    ev = bus.events[0]
    assert ev["type"] == "imagine_result"
    assert ev["payload"]["image_b64"] == FAKE_PNG_B64
    assert ev["payload"]["prompt"] == "a kitten wearing a hat"
    assert ev["payload"]["user_guid"] == "test-user"


async def test_echo_floor_fires_rickroll_not_imagine_result():
    """When the Echo floor answers, we must publish easter_egg_video
    (the rickroll) — NOT imagine_result. Showing a fake stub image
    labeled as the user's actual prompt would be misleading; the video
    makes the floor state obvious instead."""
    from app import make_imagine_handler
    from realm.engine_chain import EchoImagineProvider
    chain = FakeImagineChain(
        generate_result=EchoImagineProvider._STUB_PNG,
        last_provider=EchoImagineProvider.name)
    bus = FakeBus()
    handler = make_imagine_handler({}, chain)

    result = await handler({"prompt": "a dragon"}, "test-user", bus)

    assert "no image model" in result.lower()
    assert len(bus.events) == 1
    ev = bus.events[0]
    assert ev["type"] == "easter_egg_video"
    assert ev["payload"]["source"] == "imagine"
    assert ev["payload"]["youtube_id"] == EchoImagineProvider.RICKROLL_YOUTUBE_ID
    assert ev["payload"]["user_guid"] == "test-user"
    # Explicitly NOT an imagine_result
    assert all(e["type"] != "imagine_result" for e in bus.events)


async def test_empty_prompt_short_circuits_without_calling_chain():
    from app import make_imagine_handler
    chain = FakeImagineChain(generate_result=FAKE_PNG_B64,
                             last_provider="Automatic1111 (txt2img)")
    bus = FakeBus()
    handler = make_imagine_handler({}, chain)

    result = await handler({}, "test-user", bus)

    assert "imagine" in result.lower()
    assert chain.calls == []
    assert bus.events == []


async def test_whitespace_only_prompt_short_circuits():
    from app import make_imagine_handler
    chain = FakeImagineChain(generate_result=FAKE_PNG_B64,
                             last_provider="Automatic1111 (txt2img)")
    handler = make_imagine_handler({}, chain)

    result = await handler({"prompt": "   "}, "test-user", FakeBus())

    assert chain.calls == []
    assert len(result) > 0


async def test_total_failure_no_provider_at_all():
    """Only reachable if an operator explicitly excludes echo from
    imagine_order — ImagineChain.generate() can then legitimately
    return None (see test_engine_chain_imagine.py)."""
    from app import make_imagine_handler
    chain = FakeImagineChain(generate_result=None, last_provider="none")
    bus = FakeBus()
    handler = make_imagine_handler({}, chain)

    result = await handler({"prompt": "a dragon"}, "test-user", bus)

    assert "no image model" in result.lower()
    assert bus.events == []


async def test_chain_receives_the_prompt_verbatim():
    from app import make_imagine_handler
    chain = FakeImagineChain(generate_result=FAKE_PNG_B64,
                             last_provider="Automatic1111 (txt2img)")
    handler = make_imagine_handler({}, chain)

    await handler({"prompt": "a watercolor mountain"}, "test-user", FakeBus())

    assert chain.calls == ["a watercolor mountain"]
