// run_metrics_display_test.js — regression tests for the system metrics
// display row that shows AI queue depth, TTS queue depth, rolling avg
// service times, and cumulative tokens out.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── DOM elements present ────────────────────────────────────

assert(/id="metric-ai-queue"/.test(html),
       'metric-ai-queue span exists');
assert(/id="metric-tts-queue"/.test(html),
       'metric-tts-queue span exists');
assert(/id="metric-ai-avg"/.test(html),
       'metric-ai-avg span exists');
assert(/id="metric-tts-avg"/.test(html),
       'metric-tts-avg span exists');
assert(/id="metric-tokens"/.test(html),
       'metric-tokens span exists');

// Each has an explanatory title attribute (tooltip)
assert(/id="metric-ai-queue"\s+title=/.test(html),
       'metric-ai-queue has title tooltip');
assert(/id="metric-tts-queue"\s+title=/.test(html),
       'metric-tts-queue has title tooltip');
assert(/id="metric-tokens"\s+title=[\s\S]*?savings/.test(html),
       'metric-tokens tooltip mentions "savings" (frames the value)');

// ─── WebSocket handler dispatches metrics_snapshot ────────────

assert(/case 'bus_metrics_snapshot'/.test(html),
       "case 'bus_metrics_snapshot' handler present");
assert(/updateMetricsDisplay/.test(html),
       'updateMetricsDisplay function called');

// ─── updateMetricsDisplay defined and correct ────────────────

assert(/function updateMetricsDisplay/.test(html),
       'updateMetricsDisplay function defined');

const updIdx = html.indexOf('function updateMetricsDisplay');
const nextIdx = html.indexOf('\nasync function ', updIdx);
const updEndIdx = nextIdx > updIdx ? nextIdx : updIdx + 2500;
const updSrc = html.slice(updIdx, updEndIdx);

// Updates each metric element (called via setQueueText/setAvgText helpers)
assert(/['"]metric-ai-queue['"]/.test(updSrc),
       'updates metric-ai-queue element');
assert(/['"]metric-tts-queue['"]/.test(updSrc),
       'updates metric-tts-queue element');
assert(/['"]metric-ai-avg['"]/.test(updSrc),
       'updates metric-ai-avg element');
assert(/['"]metric-tts-avg['"]/.test(updSrc),
       'updates metric-tts-avg element');
assert(/['"]metric-tokens['"]/.test(updSrc),
       'updates metric-tokens element');

// Reads all expected fields from the message
assert(/msg\.ai_queue_depth/.test(updSrc),
       'reads ai_queue_depth from message');
assert(/msg\.tts_queue_depth/.test(updSrc),
       'reads tts_queue_depth from message');
assert(/msg\.ai_avg_service_s/.test(updSrc),
       'reads ai_avg_service_s from message');
assert(/msg\.tts_avg_service_s/.test(updSrc),
       'reads tts_avg_service_s from message');
assert(/msg\.total_tokens_out/.test(updSrc),
       'reads total_tokens_out from message');

// Color-codes queue depths so the user notices when busy
assert(/\.style\.color/.test(updSrc),
       'color-codes queue display (green/amber/red by depth)');

// Tokens count uses thousands separator for readability at scale
assert(/toLocaleString\(\)/.test(updSrc),
       'tokens displayed with thousands separator');

// Defensive: guard against missing msg
assert(/if\s*\(\s*!msg\s*\)/.test(updSrc),
       'updateMetricsDisplay guards against missing msg');

// Avg-time format: shows "—" when no samples (not "0.00s" — that would
// imply impossibly fast queries)
assert(/—'/.test(updSrc) || /—"/.test(updSrc) ||
       /&mdash;/.test(updSrc),
       'avg fields show "—" when no samples (not misleading 0s)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} metrics display tests passed`);
  process.exit(0);
}
