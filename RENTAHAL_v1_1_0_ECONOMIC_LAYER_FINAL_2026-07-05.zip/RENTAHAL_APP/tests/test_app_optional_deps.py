"""
Sprint 12 — regression test for a real bug found and fixed during
this sprint's own development, not a hypothetical one: app.py had
UNCONDITIONAL top-level imports of realm.ledger / realm.ots_anchor,
which transitively import asyncpg / opentimestamps. Both are OPTIONAL
dependencies (requirements.txt, commented out by default) — the
economic layer is meant to be entirely opt-in via [Ledger] dsn.

The bug: because those imports lived at module level, ANY operator who
hadn't installed the optional packages would find their ENTIRE REALM
failing to boot — `import app` itself raised ImportError — even if
they never configured [Ledger] dsn and had no interest in the economic
layer at all. Confirmed directly (not assumed) before fixing, using
the exact technique this test now automates: setting sys.modules
entries to None, which makes Python's import system raise ImportError
for that module cleanly, without needing the package to actually be
uninstalled from this environment.

Fix: the Ledger/ots_anchor imports moved inside create_app(), lazy,
and only attempted at all when [Ledger] dsn is non-empty. If the
import still fails at that point (dsn configured but packages
missing), the feature is disabled gracefully with a clear warning
rather than crashing the whole realm.
"""
import importlib
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def _simulate_missing(monkeypatch, *module_names):
    """Make `import <name>` raise ImportError for each given module,
    without needing it to be genuinely uninstalled from this
    environment. Standard technique: a None entry in sys.modules
    tells Python's import machinery "this name is known to not be
    importable," which is exactly the failure mode a real missing
    package produces."""
    for name in module_names:
        monkeypatch.setitem(sys.modules, name, None)
    # Also drop the real app module from the cache if present, so the
    # next `import app` genuinely re-executes app.py's top-level code
    # under the simulated-missing-package condition, rather than
    # reusing an already-imported (real-dependencies-available) module
    # object left over from a previous test or import elsewhere in
    # this test session.
    monkeypatch.delitem(sys.modules, "app", raising=False)


def test_app_imports_cleanly_without_asyncpg_or_opentimestamps(monkeypatch):
    """THE regression test — app.py must import successfully even when
    neither optional economic-layer package is installed at all."""
    _simulate_missing(monkeypatch, "asyncpg", "opentimestamps")
    try:
        import app   # noqa: F401 — the import succeeding IS the test
    except ImportError as e:
        pytest.fail(
            f"app.py failed to import without asyncpg/opentimestamps "
            f"installed — this is the exact Sprint 12 bug regressing. "
            f"Error: {e}")
    finally:
        # Leave a clean module cache for whatever test runs next.
        monkeypatch.delitem(sys.modules, "app", raising=False)


def test_app_imports_cleanly_without_stripe(monkeypatch):
    """Sprint 13's own version of the same check, applied proactively
    this time (verified clean before it ever shipped, not found as a
    bug afterward) — `stripe` is the third optional economic-layer
    package, and app.py's billing wiring must not require it to be
    installed for the rest of the realm to boot."""
    _simulate_missing(monkeypatch, "stripe")
    try:
        import app   # noqa: F401
    except ImportError as e:
        pytest.fail(f"app.py failed to import without stripe alone: {e}")
    finally:
        monkeypatch.delitem(sys.modules, "app", raising=False)


def test_app_imports_cleanly_with_all_three_economic_packages_missing(monkeypatch):
    """The full combination — asyncpg, opentimestamps, AND stripe all
    absent at once. The realistic 'operator never touched the economic
    layer at all' scenario."""
    _simulate_missing(monkeypatch, "asyncpg", "opentimestamps", "stripe")
    try:
        import app   # noqa: F401
    except ImportError as e:
        pytest.fail(f"app.py failed to import with all three economic-layer "
                   f"packages absent: {e}")
    finally:
        monkeypatch.delitem(sys.modules, "app", raising=False)


def test_app_imports_cleanly_without_asyncpg_alone(monkeypatch):
    """Same check, isolating just asyncpg — confirms the guard doesn't
    depend on BOTH packages being absent together to trigger."""
    _simulate_missing(monkeypatch, "asyncpg")
    try:
        import app   # noqa: F401
    except ImportError as e:
        pytest.fail(f"app.py failed to import without asyncpg alone: {e}")
    finally:
        monkeypatch.delitem(sys.modules, "app", raising=False)


def test_app_imports_cleanly_without_opentimestamps_alone(monkeypatch):
    _simulate_missing(monkeypatch, "opentimestamps")
    try:
        import app   # noqa: F401
    except ImportError as e:
        pytest.fail(f"app.py failed to import without opentimestamps alone: {e}")
    finally:
        monkeypatch.delitem(sys.modules, "app", raising=False)


def test_create_app_degrades_gracefully_when_dsn_set_but_packages_missing(
        monkeypatch, tmp_path):
    """The other half of the fix: [Ledger] dsn IS configured, but the
    packages are missing anyway — create_app() must log a warning and
    disable the feature, not raise."""
    import os
    monkeypatch.setenv("RENTAHAL_FAKE_ENGINES", "1")
    _simulate_missing(monkeypatch, "asyncpg", "opentimestamps")

    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text("[Ledger]\ndsn = postgresql://fake:fake@localhost/fake\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    try:
        realm_app = app_module.create_app(cfg, logger)
        assert realm_app is not None
    except ImportError as e:
        pytest.fail(f"create_app() crashed instead of disabling the "
                   f"ledger feature gracefully: {e}")
    finally:
        monkeypatch.delitem(sys.modules, "app", raising=False)


def test_create_app_degrades_gracefully_when_billing_configured_but_stripe_missing(
        monkeypatch, tmp_path):
    """Sprint 13's version: [Billing] stripe keys ARE set (and
    [Ledger] dsn too, since billing requires both), but `stripe`
    itself isn't installed — create_app() must disable billing
    gracefully, not crash the whole realm over an optional package."""
    monkeypatch.setenv("RENTAHAL_FAKE_ENGINES", "1")
    _simulate_missing(monkeypatch, "stripe")

    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[Ledger]\ndsn = postgresql://fake:fake@localhost/fake\n"
        "[Billing]\nstripe_secret_key = sk_test_fake\n"
        "stripe_webhook_secret = whsec_fake\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    try:
        realm_app = app_module.create_app(cfg, logger)
        assert realm_app is not None
    except ImportError as e:
        pytest.fail(f"create_app() crashed instead of disabling billing "
                   f"gracefully: {e}")
    finally:
        monkeypatch.delitem(sys.modules, "app", raising=False)


def test_create_app_degrades_gracefully_when_payout_configured_but_stripe_missing(
        monkeypatch, tmp_path):
    """Sprint 14's version of the same check: [Payout] stripe_secret_key
    is set (and [Federator] enabled + [Ledger] dsn, since payout is
    Federator-only functionality), but `stripe` isn't installed —
    create_app() must disable the payout/claim endpoints gracefully."""
    monkeypatch.setenv("RENTAHAL_FAKE_ENGINES", "1")
    _simulate_missing(monkeypatch, "stripe")

    import app as app_module
    cfg = app_module.load_ini()
    ini = tmp_path / "config.ini"
    ini.write_text(
        "[Federator]\nenabled = true\n"
        f"state_file = {tmp_path / 'state.json'}\n"
        "[Ledger]\ndsn = postgresql://fake:fake@localhost/fake\n"
        "[Payout]\nstripe_secret_key = sk_test_fake\n")
    cfg.read(ini)
    logger = app_module.setup_logging(cfg)
    try:
        realm_app = app_module.create_app(cfg, logger)
        assert realm_app is not None
    except ImportError as e:
        pytest.fail(f"create_app() crashed instead of disabling payout "
                   f"gracefully: {e}")
    finally:
        monkeypatch.delitem(sys.modules, "app", raising=False)
