// run_thinking_sound_test.js — regression test for the race condition
// where stopThinkingSound() ran during the gap between Audio.play()
// being called and its Promise resolving. If start...stop happens fast
// (which it does on cached news WAVs), the stop became a no-op and the
// sound looped forever.
//
// We extract the REAL startThinkingSound and stopThinkingSound from
// index.html, install a controllable Audio mock that lets us hold the
// play() Promise unresolved, fire start → stop in that window, then
// resolve the Promise — and assert that the audio is paused, not playing.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
if (!scriptMatch) {
  console.error('no <script> block found in index.html');
  process.exit(1);
}
let js = scriptMatch[1];

// Strip the IIFE that runs on DOMContentLoaded
js = js.replace(/^\(async \(\) => \{[\s\S]*?\}\)\(\);?/m, '');
// Strip top-level let declarations that conflict with our stubs
const stubbed = ['CFG', 'socket', 'userGuid', 'wakeOn', 'recognition',
                 'audioCtx', 'analyser', 'micStream', 'isSpeaking',
                 'echoGuardUntil', 'recognitionRunning', 'restartGeneration'];
for (const name of stubbed) {
  const re = new RegExp('^let\\s+' + name + '\\s*(=\\s*[^;]*)?;\\s*$', 'm');
  js = js.replace(re, '');
}
// Convert top-level let → var for eval-scope access
js = js.replace(/^let\s+(\w+)/gm, 'var $1');
// Strip the DOM lookups
js = js.replace(/^const\s+player\s*=[^;]+;\s*$/m, '');
js = js.replace(/^const\s+transcriptEl\s*=[^;]+;\s*$/m, '');
js = js.replace(/^const\s+answerEl\s*=[^;]+;\s*$/m, '');
js = js.replace(/^const\s+wakeBtn\s*=[^;]+;\s*$/m, '');

global.window = global;

let passCount = 0, failCount = 0;
function assert(cond, label) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else      { console.log('FAIL: ' + label); failCount++; }
}

// =========================================================================
// Test 1: The race — start then immediately stop while play() is in-flight
// =========================================================================
{
  // Controllable Audio mock: play() returns a Promise we can resolve later
  let activeAudio = null;
  let resolveFn = null;
  let pauseCalled = false;
  let loopValue = null;

  function MockAudio(src) {
    pauseCalled = false;
    loopValue = null;
    const audio = {
      src,
      volume: 0,
      _paused: true,        // starts paused; only goes false when play resolves
      _loop: false,
      currentTime: 0,
      play() {
        return new Promise((resolve) => {
          resolveFn = () => {
            // Only mark playing if we weren't paused first
            if (!pauseCalled) this._paused = false;
            resolve();
          };
        });
      },
      pause() {
        pauseCalled = true;
        this._paused = true;
      },
    };
    Object.defineProperty(audio, 'loop', {
      set(v) { loopValue = v; this._loop = v; },
      get() { return this._loop; },
    });
    activeAudio = audio;
    return audio;
  }

  // Audio context stub — we only care about Audio, not the WebAudio fallback
  function MockAudioContext() {
    return {
      currentTime: 0,
      destination: {},
      createOscillator() { return { type:'', frequency:{value:0}, connect(g){return g;}, start(){}, stop(){} }; },
      createGain() { return { gain:{value:0,cancelScheduledValues(){},setValueAtTime(){},linearRampToValueAtTime(){}}, connect(d){return d;} }; },
      close() {},
    };
  }

  const stubs = `
    const CFG = {};
    const transcriptEl = {}, answerEl = {}, wakeBtn = {};
    const player = { pause(){}, play(){return {catch(){}};} };
    var socket = null, userGuid = null, isSpeaking = false;
    var echoGuardUntil = 0, wakeOn = false, recognition = null;
    var audioCtx = null, micStream = null, recognitionRunning = false;
    var restartGeneration = 0, analyser = null;
    function setStatus(){}
    const Audio = ${MockAudio.toString()};
    const AudioContext = ${MockAudioContext.toString()};
  `;
  // Provide MockAudio access by name globally
  global.Audio = MockAudio;
  global.AudioContext = MockAudioContext;

  try {
    eval(stubs + js);
  } catch (e) {
    console.error('Failed to load thinking-sound code:', e.message);
    process.exit(1);
  }

  // Now reach into the loaded code via eval
  const startFn = eval('startThinkingSound');
  const stopFn = eval('stopThinkingSound');

  // === The race scenario ===
  // 1. Start thinking
  startFn();
  // 2. Audio.play() returned an unresolved promise. Immediately stop.
  stopFn();
  // 3. NOW resolve the play promise — too late, sound should already be paused
  if (resolveFn) resolveFn();

  // Wait one microtask tick for promise resolution to land
  setTimeout(() => {
    assert(pauseCalled, 'pause() was called during the race window');
    assert(loopValue === false || activeAudio.loop === false,
           'loop was set to false to prevent restart');
    assert(activeAudio._paused === true,
           'audio is in paused state after race-stop');

    // =====================================================================
    // Test 2: Normal flow — start, wait for play to resolve, then stop
    // =====================================================================
    pauseCalled = false;
    resolveFn = null;
    startFn();
    if (resolveFn) resolveFn();
    setTimeout(() => {
      stopFn();
      assert(pauseCalled, 'normal stop after play resolved also pauses');

      // =====================================================================
      // Test 3: Stop without start is a no-op (no errors)
      // =====================================================================
      let threw = false;
      try {
        stopFn();
        stopFn();
        stopFn();
      } catch (e) {
        threw = true;
      }
      assert(!threw, 'multiple stops without start are safe');

      // =====================================================================
      // Test 4: Start-stop-start-stop rapid cycling (the news scenario)
      // =====================================================================
      pauseCalled = false;
      for (let i = 0; i < 5; i++) {
        startFn();
        if (resolveFn) resolveFn();
        stopFn();
      }
      // After all that, no audio should be playing
      assert(activeAudio._paused === true,
             'rapid start/stop cycles end with audio paused');

      // Summary
      console.log('');
      if (failCount > 0) {
        console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
        process.exit(1);
      } else {
        console.log(`OK: ${passCount} thinking-sound tests passed`);
        process.exit(0);
      }
    }, 10);
  }, 10);
}
