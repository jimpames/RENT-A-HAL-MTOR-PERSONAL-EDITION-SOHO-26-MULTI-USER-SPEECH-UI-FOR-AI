// run_service_rerender_test.js — regression tests for the user-reported bug:
//   "second service query → audio plays but new cards don't render,
//    old cards stay up"
//
// Fix: openServicesPanel now clears the results container BEFORE doing
// any work that could throw, and uses per-card try/catch so one bad
// result doesn't break the whole panel. Also logs each step so we can
// diagnose any future regression from the browser console.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else {
    console.log('FAIL: ' + label + (detail ? '  (' + detail + ')' : ''));
    failCount++;
  }
}

// ─── Locate openServicesPanel ────────────────────────────────

const openIdx = html.indexOf('function openServicesPanel(msg)');
const renderCardIdx = html.indexOf('function renderServiceCard');
assert(openIdx > 0 && renderCardIdx > openIdx,
       'openServicesPanel located in file');

const openSrc = html.slice(openIdx, renderCardIdx);

// ─── No duplicate escapeHtml ─────────────────────────────────

const escapeHtmlMatches = (html.match(/function\s+escapeHtml\s*\(/g) || []).length;
assert(escapeHtmlMatches === 1,
       'escapeHtml is defined exactly once (was 2 — duplicate removed)',
       'found ' + escapeHtmlMatches + ' definitions');

// ─── Critical: clear results BEFORE doing other work ─────────

// The old code cleared resultsEl AFTER the early-return guards. If a
// guard triggered for a second call (rare but possible during a race),
// the old cards would stay. New code DESTROYS the results container
// (replaces it with a fresh clone) BEFORE any conditional work — this
// is stronger than innerHTML='' and forces a fresh layout context.
const destroyIdx = openSrc.indexOf("destroyAndRecreate('services-results')");
const displayIdx = openSrc.indexOf("panel.style.display");
assert(destroyIdx > 0 && displayIdx > 0,
       'destroyAndRecreate and display change both present');
assert(destroyIdx < displayIdx,
       'destroyAndRecreate runs BEFORE display change ' +
       '(belt-and-suspenders — recreate no matter what)');

// ─── Per-card try/catch (one bad card doesn't kill the rest) ──

assert(/try\s*\{[\s\S]*?renderServiceCard/.test(openSrc),
       'renderServiceCard wrapped in try/catch (per-card resilience)');
assert(/catch\s*\(\s*err\s*\)\s*\{[\s\S]*?console\.error/.test(openSrc),
       'caught errors are logged with details');
assert(/⚠/.test(openSrc) || /Result unavailable/.test(openSrc),
       'failed cards get a fallback stub (not silently skipped)');

// ─── Diagnostic console logging at every step ────────────────

assert(/console\.log\(['"`]\[service\] openServicesPanel called/.test(openSrc),
       'logs entry with result count');
assert(/console\.log\(['"`]\[service\] destroyed-and-recreated/.test(openSrc),
       'logs the moment the results container is destroyed and recreated');
assert(/console\.log\(['"`]\[service\] rendered/.test(openSrc),
       'logs how many cards were successfully rendered');

// ─── Visibility belt-and-suspenders ──────────────────────────

assert(/panel\.style\.visibility\s*=\s*['"]visible['"]/.test(openSrc),
       'sets visibility:visible (in case CSS override is hiding it)');

// ─── Scroll behavior preserved ───────────────────────────────

assert(/scrollPanelIntoView/.test(openSrc),
       'still scrolls panel into view after rendering');

// ─── renderServiceCard returns truthy (verify the contract) ──

const renderCardEndIdx = html.indexOf('\n// ', renderCardIdx);
const renderCardSrc = html.slice(renderCardIdx,
                                 renderCardEndIdx > renderCardIdx
                                   ? renderCardEndIdx
                                   : renderCardIdx + 2000);
assert(/return\s+card\s*;/.test(renderCardSrc),
       'renderServiceCard returns the card element (so appendChild works)');

// ─── Status line still updates ───────────────────────────────

assert(/statusEl\.textContent\s*=/.test(openSrc),
       'status line text is updated (results count + category + city)');

// ─── Summary ──────────────────────────────────────────────────
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} service re-render tests passed`);
  process.exit(0);
}
