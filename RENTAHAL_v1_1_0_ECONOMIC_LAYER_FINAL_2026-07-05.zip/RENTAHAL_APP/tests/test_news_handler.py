"""
Realm-side test for the news handler — proves it makes the right HTTP
call to the Kokoro service and publishes news_bundle to the bus so the
browser can render the story list.

We stub the HTTP call so we don't need a real Kokoro service running.
"""

import asyncio
import sys
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import make_news_handler

pytestmark = pytest.mark.asyncio


def fake_cfg_get(cfg, section, key, default=""):
    """Simulate cfg_get behavior over a dict."""
    return cfg.get(section, {}).get(key, default)


@pytest.fixture
def cfg_with_service():
    """Config that points at a (fake) Kokoro service."""
    cfg = {
        "KokoroService": {
            "host": "localhost",
            "port": "9998",
        }
    }
    with patch("app.cfg_get", side_effect=fake_cfg_get):
        yield cfg


@pytest.fixture
def cfg_no_service():
    cfg = {"KokoroService": {"host": ""}}
    with patch("app.cfg_get", side_effect=fake_cfg_get):
        yield cfg


async def test_news_handler_returns_error_when_service_not_configured(cfg_no_service):
    handler = make_news_handler(cfg_no_service)
    bus = MagicMock()
    bus.publish = AsyncMock()
    result = await handler({}, "user-1", bus)
    assert "needs the kokoro service" in result.lower()
    bus.publish.assert_not_called()


async def test_news_handler_publishes_bundle_on_success(cfg_with_service):
    """The handler must emit news_bundle so the browser opens the panel."""
    handler = make_news_handler(cfg_with_service)

    fake_response = {
        "enabled": True,
        "story_count": 2,
        "stories": [
            {"title": "Story one", "source": "AP News", "category": "center",
             "summary": "...", "audio_ready": True, "audio_url": "/audio/abc",
             "encode_failed": False},
            {"title": "Story two", "source": "BBC", "category": "center",
             "summary": "...", "audio_ready": True, "audio_url": "/audio/def",
             "encode_failed": False},
        ],
        "last_refresh": 1234567890.0,
        "refresh_in_progress": False,
    }

    # Mock aiohttp session entirely
    class FakeResp:
        def __init__(self, data, status=200):
            self._data = data
            self.status = status
        async def json(self): return self._data
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class FakeSession:
        def __init__(self, *a, **kw): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
        def get(self, url, params=None):
            assert "/news" in url
            return FakeResp(fake_response)

    bus = MagicMock()
    bus.publish = AsyncMock()

    with patch("app.aiohttp.ClientSession", FakeSession):
        result = await handler({}, "user-1", bus)

    # Should return a spoken summary
    assert "2 stories" in result
    assert "AP News" in result or "BBC" in result

    # Should have published the bundle to the bus
    bus.publish.assert_awaited_once()
    call_args = bus.publish.await_args
    assert call_args[0][0] == "news_bundle"
    assert call_args[1]["user_guid"] == "user-1"
    assert len(call_args[1]["stories"]) == 2

    # Audio URLs should be rewritten through the realm
    for story in call_args[1]["stories"]:
        assert story["audio_url"].startswith("/api/news/audio/")


async def test_news_handler_passes_feed_slot_as_source_param(cfg_with_service):
    """Slot 'feed' should map to query param 'source' on the service."""
    handler = make_news_handler(cfg_with_service)
    captured_params = []

    fake_response = {"enabled": True, "stories": [], "story_count": 0}

    class FakeResp:
        def __init__(self, data, status=200):
            self._data, self.status = data, status
        async def json(self): return self._data
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass

    class FakeSession:
        def __init__(self, *a, **kw): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
        def get(self, url, params=None):
            captured_params.append(params)
            return FakeResp(fake_response)

    bus = MagicMock(); bus.publish = AsyncMock()

    with patch("app.aiohttp.ClientSession", FakeSession):
        await handler({"feed": "ap news"}, "user-1", bus)

    assert len(captured_params) == 1
    assert captured_params[0]["source"] == "ap news"


async def test_news_handler_passes_category_slot(cfg_with_service):
    """Slot 'category' → query param 'category'."""
    handler = make_news_handler(cfg_with_service)
    captured = []

    class FakeResp:
        status = 200
        async def json(self): return {"enabled": True, "stories": [], "story_count": 0}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    class FakeSession:
        def __init__(self, *a, **kw): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
        def get(self, url, params=None):
            captured.append(params)
            return FakeResp()

    bus = MagicMock(); bus.publish = AsyncMock()
    with patch("app.aiohttp.ClientSession", FakeSession):
        await handler({"category": "left"}, "user-1", bus)
    assert captured[0]["category"] == "left"


async def test_news_handler_returns_message_when_no_stories(cfg_with_service):
    """Empty result from service → polite message, no bundle published."""
    handler = make_news_handler(cfg_with_service)

    class FakeResp:
        status = 200
        async def json(self): return {"enabled": True, "stories": [], "story_count": 0}
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
    class FakeSession:
        def __init__(self, *a, **kw): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
        def get(self, *a, **kw): return FakeResp()

    bus = MagicMock(); bus.publish = AsyncMock()
    with patch("app.aiohttp.ClientSession", FakeSession):
        result = await handler({}, "user-1", bus)
    assert "no news" in result.lower() or "no stories" in result.lower()
    bus.publish.assert_not_called()
