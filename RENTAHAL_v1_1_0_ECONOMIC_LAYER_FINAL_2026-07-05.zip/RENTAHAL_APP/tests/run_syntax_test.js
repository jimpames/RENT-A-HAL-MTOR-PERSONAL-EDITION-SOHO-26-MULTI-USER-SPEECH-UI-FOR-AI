// run_syntax_test.js — verifies the raw <script> block in index.html is
// syntactically valid JavaScript. Catches things the existing browser-test
// harness misses because it pre-processes the script (strips `let`, etc.)
// to make Node-eval-able stubs.
//
// History: this test exists because a duplicate `let thinkingAudio = null;`
// declaration shipped in v1 of the click-to-listen thinking-sound fix.
// The duplicate caused a SyntaxError that killed the entire <script> block
// in real browsers, so NOTHING on the page worked — but the existing
// browser-test harness converted `let` → `var` for its own purposes, which
// silently hid the duplicate. This test parses the raw script unmodified
// so any future syntax error is caught regardless of harness quirks.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(
  path.join(__dirname, '..', 'templates', 'index.html'), 'utf8');

let passCount = 0, failCount = 0;
function assert(cond, label, detail) {
  if (cond) { console.log('PASS: ' + label); passCount++; }
  else      {
    console.log('FAIL: ' + label);
    if (detail) console.log('      ' + detail);
    failCount++;
  }
}

// Test 1: there is exactly one <script> block in index.html
const scriptBlocks = html.match(/<script>([\s\S]*?)<\/script>/g) || [];
assert(scriptBlocks.length === 1,
       'index.html has exactly one <script> block',
       `found ${scriptBlocks.length}`);

if (scriptBlocks.length !== 1) {
  console.log(`\nFAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
}

const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
const scriptBody = scriptMatch[1];

// Test 2: the raw script parses as JavaScript (no syntax errors)
// new Function() runs the parser without executing the code — exactly
// what we need to validate syntax in isolation.
let parseError = null;
try {
  new Function(scriptBody);
} catch (e) {
  parseError = e;
}
assert(parseError === null,
       'script block parses as valid JavaScript',
       parseError ? `${parseError.name}: ${parseError.message}` : '');

// Test 3: no duplicate top-level `let` declarations.
// Anchored to column 0 (no leading whitespace) so function-scoped `let`
// inside callbacks doesn't false-positive. Specifically guards against
// the v1 bug where a refactor re-declared an existing top-level variable
// and silently broke the entire script via SyntaxError.
const letDecls = scriptBody.match(/^let\s+(\w+)/gm) || [];
const names = letDecls.map(d => d.match(/let\s+(\w+)/)[1]);
const counts = {};
for (const n of names) counts[n] = (counts[n] || 0) + 1;
const duplicates = Object.entries(counts).filter(([_, c]) => c > 1);
assert(duplicates.length === 0,
       'no duplicate top-level let declarations',
       duplicates.length ? `duplicates: ${JSON.stringify(duplicates)}` : '');

// Test 4: NOTE — we don't try to detect "duplicate const" because that's
// scope-dependent and our regex can't distinguish function-scoped consts
// (which are fine to share names) from genuine top-level duplicates.
// Test 2 (raw parse) already catches any real duplicate that matters.

// Test 5: no obviously broken patterns we've hit before
const knownBadPatterns = [
  // We've never had these; this is the place to add new ones as we find them
  // { pattern: /something_we_should_never_ship/, label: 'no X' },
];
for (const { pattern, label } of knownBadPatterns) {
  assert(!pattern.test(scriptBody), label);
}

// Summary
console.log('');
if (failCount > 0) {
  console.log(`FAILED: ${failCount} tests failed, ${passCount} passed`);
  process.exit(1);
} else {
  console.log(`OK: ${passCount} syntax tests passed`);
  process.exit(0);
}
