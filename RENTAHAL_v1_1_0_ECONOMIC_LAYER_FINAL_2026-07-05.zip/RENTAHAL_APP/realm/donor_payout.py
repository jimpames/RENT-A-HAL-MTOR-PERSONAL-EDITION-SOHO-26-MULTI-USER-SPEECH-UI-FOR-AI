"""
realm/donor_payout.py — Sprint 14: donor payout rail, with bilateral
confirmation protecting against a single lying party.

WHY BILATERAL CONFIRMATION (see ECONOMIC_LAYER_DESIGN.md Part C.3 for
the full reasoning, and 005_donor_payout.sql's header comment for the
schema-level explanation): federation's self-reported health averages
are fine to trust unilaterally — lying about them only costs the liar
their own routing quality. A donor self-reporting "I served this
conscripted request, pay me" is a different risk class entirely, since
lying is directly profitable. Both sides — the REQUESTER (who received
an answer from a donor via FederationConscriptionProvider) and the
DONOR (who served it, identifiable via the X-Federation-Conscripted
header on the inbound /api/ask call) — independently submit a claim
about the same piece of work. A payout only ever credits the donor for
claims that match on BOTH sides within a tolerance window. An
unmatched claim is flagged for review, never auto-paid — the FEDERATOR
(the same already-centralized point both requester and donor already
trust for routing decisions, via check-in) is where reconciliation
happens, reusing an existing trust relationship rather than inventing
a new one.

Two testability tiers here, same discipline as Sprints 12-13:
  1. CLAIM SUBMISSION + RECONCILIATION (ClaimStore): real Postgres,
     fully testable — this is genuinely the sprint's core complexity,
     and it needs zero external network access to test for real.
  2. STRIPE CONNECT (account creation, onboarding links, transfers):
     real network calls to api.stripe.com, unreachable from this
     sandbox (same restriction documented in Sprints 12-13). Tested by
     mocking the SDK calls, clearly labeled.
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import stripe

from realm.ledger import DuplicateEntryError, Ledger

VALID_ROLES = ("requester", "donor")
VALID_RANKS = ("chat", "vision", "imagine")


@dataclass
class PayoutConfig:
    stripe_secret_key: str = ""
    # Flat rate paid to a donor per confirmed (bilaterally-matched)
    # conscripted request served — see module docstring in
    # realm/billing.py for why Sprint 13's consumer price is ALSO
    # flat, not metered; same reasoning applies here for the same
    # simplicity/predictability reasons.
    conscription_payout_rate_micros: int = 80
    # Below this accrued balance, a donor's confirmed credits just
    # accumulate — Stripe's own transfer isn't free, so batching
    # avoids a $0.25 fee eating a $0.08 payout. See payout_batch_job.py.
    minimum_payout_micros: int = 5_000_000     # $5.00
    # How close two claims' timestamps must be to count as the same
    # piece of work. Generous on purpose — network latency, clock
    # drift between two independently-run realms, and the natural gap
    # between "donor answered" and "requester received the answer"
    # all eat into this.
    claim_match_tolerance_s: float = 60.0
    # Unmatched claims older than this are considered abandoned
    # (flagged for operator review, never auto-paid) rather than left
    # waiting forever for a pair that's never coming.
    unmatched_claim_max_age_s: float = 3600.0
    onboarding_refresh_url: str = ""
    onboarding_return_url: str = ""

    @property
    def enabled(self) -> bool:
        return bool(self.stripe_secret_key)


@dataclass
class ClaimResult:
    claim_id: int
    matched: bool
    matched_claim_id: Optional[int] = None
    credited: bool = False
    credit_amount_micros: Optional[int] = None


def _claim_lock_key(donor_url: str, requester_url: str, rank: str) -> int:
    """A stable, deterministic advisory-lock key for one (donor,
    requester, rank) triple — same purpose as ledger.py's fixed
    _APPEND_LOCK_KEY, but scoped per-triple here rather than global,
    since unrelated donor/requester pairs' claims shouldn't serialize
    against each other unnecessarily. Truncated to fit Postgres's
    64-bit signed advisory-lock key range."""
    digest = hashlib.sha256(f"{donor_url}|{requester_url}|{rank}".encode()).digest()
    return int.from_bytes(digest[:8], "big", signed=True)


class ClaimStore:
    """Bilateral confirmation — the sprint's real complexity. Reuses
    the Ledger's own connection pool, same pattern as Sprint 12's
    OtsAnchorStore."""

    def __init__(self, ledger: Ledger, cfg: PayoutConfig):
        self._pool = ledger._pool
        self._ledger = ledger
        self.cfg = cfg

    async def submit_claim(self, role: str, donor_url: str, requester_url: str,
                           rank: str, claimed_at: Optional[float] = None
                           ) -> ClaimResult:
        """Submit one side's claim about a piece of conscripted work.
        If a matching unmatched claim from the OPPOSITE role already
        exists (same donor/requester/rank, timestamp within
        cfg.claim_match_tolerance_s), both get marked matched and the
        donor is credited immediately. Otherwise this claim is stored
        as unmatched, waiting for its pair.

        Serialized via a Postgres advisory lock scoped to this
        (donor_url, requester_url, rank) triple — prevents a race
        where both sides' claims arrive at nearly the same moment and
        each fails to see the other as already present."""
        if role not in VALID_ROLES:
            raise ValueError(f"role must be one of {VALID_ROLES}, got {role!r}")
        if rank not in VALID_RANKS:
            raise ValueError(f"rank must be one of {VALID_RANKS}, got {rank!r}")

        claimed_at = claimed_at if claimed_at is not None else time.time()
        claimed_at_epoch_micros = int(claimed_at * 1_000_000)
        opposite_role = "donor" if role == "requester" else "requester"
        tolerance_micros = int(self.cfg.claim_match_tolerance_s * 1_000_000)

        async with self._pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    "SELECT pg_advisory_xact_lock($1)",
                    _claim_lock_key(donor_url, requester_url, rank))

                candidate = await conn.fetchrow(
                    """
                    SELECT id, claimed_at_epoch_micros FROM conscription_claims
                    WHERE role = $1 AND donor_url = $2 AND requester_url = $3
                          AND rank = $4 AND matched = false
                          AND ABS(claimed_at_epoch_micros - $5) <= $6
                    ORDER BY ABS(claimed_at_epoch_micros - $5) ASC
                    LIMIT 1
                    """,
                    opposite_role, donor_url, requester_url, rank,
                    claimed_at_epoch_micros, tolerance_micros)

                if candidate is None:
                    new_id = await conn.fetchval(
                        """
                        INSERT INTO conscription_claims
                            (role, donor_url, requester_url, rank,
                             claimed_at_epoch_micros, matched)
                        VALUES ($1, $2, $3, $4, $5, false)
                        RETURNING id
                        """,
                        role, donor_url, requester_url, rank,
                        claimed_at_epoch_micros)
                    return ClaimResult(claim_id=new_id, matched=False)

                new_id = await conn.fetchval(
                    """
                    INSERT INTO conscription_claims
                        (role, donor_url, requester_url, rank,
                         claimed_at_epoch_micros, matched, matched_claim_id)
                    VALUES ($1, $2, $3, $4, $5, true, $6)
                    RETURNING id
                    """,
                    role, donor_url, requester_url, rank,
                    claimed_at_epoch_micros, candidate["id"])
                await conn.execute(
                    "UPDATE conscription_claims SET matched = true, "
                    "matched_claim_id = $1 WHERE id = $2",
                    new_id, candidate["id"])

        # Credit happens OUTSIDE the matching transaction, using the
        # ledger's own append_entry (which has its own advisory-lock
        # serialization for the hash chain — nesting two different
        # advisory locks inside one transaction invites deadlocks
        # between concurrent claims, so this is deliberately a
        # separate step, separate transaction).
        pair_low, pair_high = sorted([new_id, candidate["id"]])
        credit_reference = f"claim-match-{pair_low}-{pair_high}"
        try:
            await self._ledger.append_entry(
                "conscription_credit", donor_url,
                self.cfg.conscription_payout_rate_micros,
                reference=credit_reference,
                metadata={"requester_url": requester_url, "rank": rank,
                         "claim_ids": [pair_low, pair_high]})
            credited = True
        except DuplicateEntryError:
            # Already credited by a previous attempt at matching this
            # exact pair — the reference-level idempotency guard means
            # even a bug here can't double-pay.
            credited = False

        return ClaimResult(
            claim_id=new_id, matched=True, matched_claim_id=candidate["id"],
            credited=credited,
            credit_amount_micros=self.cfg.conscription_payout_rate_micros)

    async def get_unmatched_claims(self, max_age_s: Optional[float] = None
                                   ) -> List[dict]:
        """Claims still waiting for their pair. If max_age_s is given,
        only returns ones older than that — the "flagged for review,
        abandoned" set, not claims that just haven't had time to be
        matched yet."""
        async with self._pool.acquire() as conn:
            if max_age_s is None:
                rows = await conn.fetch(
                    "SELECT * FROM conscription_claims WHERE matched = false "
                    "ORDER BY submitted_at ASC")
            else:
                cutoff = datetime.now(timezone.utc).timestamp() - max_age_s
                rows = await conn.fetch(
                    "SELECT * FROM conscription_claims WHERE matched = false "
                    "AND EXTRACT(EPOCH FROM submitted_at) < $1 "
                    "ORDER BY submitted_at ASC", cutoff)
        return [dict(r) for r in rows]


# ─── Stripe Connect — real network calls, mocked in tests ───────────

def create_connect_account(cfg: PayoutConfig, donor_url: str) -> str:
    """Real Stripe API call. Creates a new Express-type connected
    account for a donor realm. Returns the Stripe account ID."""
    account = stripe.Account.create(
        api_key=cfg.stripe_secret_key,
        type="express",
        capabilities={"transfers": {"requested": True}},
        metadata={"donor_url": donor_url},
    )
    return account.id


def create_onboarding_link(cfg: PayoutConfig, stripe_account_id: str) -> str:
    """Real Stripe API call. Returns a one-time URL to redirect the
    donor operator to for identity/bank-account onboarding."""
    link = stripe.AccountLink.create(
        api_key=cfg.stripe_secret_key,
        account=stripe_account_id,
        refresh_url=cfg.onboarding_refresh_url or "https://example.com/payout/refresh",
        return_url=cfg.onboarding_return_url or "https://example.com/payout/return",
        type="account_onboarding",
    )
    return link.url


def check_payouts_enabled(cfg: PayoutConfig, stripe_account_id: str) -> bool:
    """Real Stripe API call. True once the donor has actually
    completed onboarding (identity verified, bank account linked) —
    an account can exist without this being true yet."""
    account = stripe.Account.retrieve(stripe_account_id, api_key=cfg.stripe_secret_key)
    return bool(account.payouts_enabled)


def execute_payout(cfg: PayoutConfig, stripe_account_id: str,
                   amount_micros: int) -> str:
    """Real Stripe API call. Transfers money FROM the platform's own
    Stripe balance TO the donor's connected account. Returns the
    transfer ID — the caller (payout_batch_job.py) uses this as the
    ledger entry's reference for idempotency, same pattern as Sprint
    13's checkout session ID."""
    from realm.billing import micros_to_cents
    amount_cents = micros_to_cents(amount_micros)
    if amount_cents < 1:
        raise ValueError(f"amount_micros={amount_micros} rounds to zero cents")
    transfer = stripe.Transfer.create(
        api_key=cfg.stripe_secret_key,
        amount=amount_cents,
        currency="usd",
        destination=stripe_account_id,
    )
    return transfer.id


class DonorAccountStore:
    """CRUD for donor_payout_accounts — mutable operational state
    (payouts_enabled flips as onboarding completes), same category as
    Sprint 12's OtsAnchorStore, not the ledger itself."""

    def __init__(self, ledger: Ledger):
        self._pool = ledger._pool

    async def link_account(self, donor_url: str, stripe_account_id: str) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO donor_payout_accounts (donor_url, stripe_account_id)
                VALUES ($1, $2)
                ON CONFLICT (donor_url) DO UPDATE
                    SET stripe_account_id = EXCLUDED.stripe_account_id
                """,
                donor_url, stripe_account_id)

    async def get_account(self, donor_url: str) -> Optional[dict]:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM donor_payout_accounts WHERE donor_url = $1",
                donor_url)
        return dict(row) if row else None

    async def mark_payouts_enabled(self, donor_url: str, enabled: bool) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE donor_payout_accounts SET payouts_enabled = $1, "
                "last_checked_at = now() WHERE donor_url = $2",
                enabled, donor_url)

    async def get_payout_ready_accounts(self) -> List[dict]:
        """Donors with a linked, onboarded Stripe account — the
        candidate set payout_batch_job.py checks accrued balance for."""
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM donor_payout_accounts WHERE payouts_enabled = true")
        return [dict(r) for r in rows]
