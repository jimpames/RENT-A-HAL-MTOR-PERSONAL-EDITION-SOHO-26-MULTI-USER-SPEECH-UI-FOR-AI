"""
engine_chain.py — provider chain for LLM and TTS, modeled exactly on Jim's
llm_providers.py from the world generator.

LLM chain order (config-driven, defaults shown):
  GPT4All (local, free)  ->  Claude (cloud, premium)  ->  HuggingFace  ->  Echo
TTS chain order:
  Kokoro (local ONNX)  ->  ElevenLabs (premium online)
                        ->  OpenAI TTS (cheap online)  ->  pyttsx3 (always)

Each provider:
  - is_available()  : fast probe, must be safe to call at any time
  - generate(...)   : returns result or None on failure (chain falls through)

The chain remembers who answered (last_provider) so the realm can show it
in the sysop panel and the setup card. Re-probes on each request so a
GPT4All started AFTER the realm boots gets picked up automatically.

NO heavy imports at module load. Provider classes import their deps lazily.
"""

from __future__ import annotations

import asyncio
import base64
import logging
import os
import sys
import threading
from abc import ABC, abstractmethod

# Suppress ONNX Runtime's verbose C++ stderr (Conv fallback warnings).
# Must be set before any onnxruntime import. See kokoro_service/service.py
# for the longer explanation. Level 3 = errors only; GPU activation
# unaffected.
os.environ.setdefault("ORT_LOGGING_LEVEL", "3")
from typing import Optional

import aiohttp

logger = logging.getLogger("engine_chain")


# ===========================================================================
# LLM CHAIN
# ===========================================================================

class LLMProvider(ABC):
    name: str = "abstract"

    @abstractmethod
    async def is_available(self) -> bool: ...

    @abstractmethod
    async def generate(self, prompt: str, max_tokens: int = 400) -> Optional[str]: ...


class GPT4AllProvider(LLMProvider):
    """Local GPT4All via its OpenAI-compatible API. Free, private, RTX-friendly."""

    def __init__(self, host="localhost", port=4891, model="Llama 3 8B Instruct",
                 timeout=60):
        self.host, self.port, self.model, self.timeout = host, port, model, timeout
        self.base_url = f"http://{host}:{port}/v1"
        self.name = f"GPT4All ({model})"
        # Per-call telemetry the chain reads after generate() returns.
        # None = "no data this call"; dict = real usage info.
        self.last_usage: Optional[dict] = None

    async def is_available(self) -> bool:
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{self.base_url}/models", timeout=3) as r:
                    return r.status == 200
        except Exception:
            return False

    async def generate(self, prompt: str, max_tokens: int = 400) -> Optional[str]:
        self.last_usage = None
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.7,
        }
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(f"{self.base_url}/chat/completions",
                                  json=payload, timeout=self.timeout) as r:
                    if r.status != 200:
                        return None
                    data = await r.json()
                    # GPT4All returns a `usage` block when it can — capture it.
                    # Shape: {prompt_tokens, completion_tokens, total_tokens}
                    usage = data.get("usage") or {}
                    if usage.get("completion_tokens") is not None:
                        self.last_usage = {
                            "tokens_out": int(usage["completion_tokens"]),
                            "tokens_in": int(usage.get("prompt_tokens", 0)),
                            "approx": False,
                        }
                    return data["choices"][0]["message"]["content"].strip()
        except Exception as e:
            logger.warning("GPT4All generate failed: %s", e)
            return None


class ClaudeProvider(LLMProvider):
    """Cloud Claude — go nuclear when local doesn't satisfy."""
    ENDPOINT = "https://api.anthropic.com/v1/messages"

    def __init__(self, api_key="", model="claude-haiku-4-5-20251001",
                 max_tokens=500, version="2023-06-01"):
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens
        self.version = version
        self.name = f"Claude ({model})"
        self.last_usage: Optional[dict] = None

    async def is_available(self) -> bool:
        return bool(self.api_key and self.api_key.startswith("sk-ant-"))

    async def generate(self, prompt: str, max_tokens: int = 400) -> Optional[str]:
        self.last_usage = None
        if not await self.is_available():
            return None
        headers = {"x-api-key": self.api_key, "anthropic-version": self.version,
                   "content-type": "application/json"}
        payload = {"model": self.model, "max_tokens": max(max_tokens, self.max_tokens),
                   "messages": [{"role": "user", "content": prompt}]}
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(self.ENDPOINT, headers=headers, json=payload,
                                  timeout=30) as r:
                    if r.status != 200:
                        return None
                    data = await r.json()
                    # Claude usage: {input_tokens, output_tokens}
                    usage = data.get("usage") or {}
                    if usage.get("output_tokens") is not None:
                        self.last_usage = {
                            "tokens_out": int(usage["output_tokens"]),
                            "tokens_in": int(usage.get("input_tokens", 0)),
                            "approx": False,
                        }
                    return data["content"][0]["text"].strip()
        except Exception as e:
            logger.warning("Claude generate failed: %s", e)
            return None


class HuggingFaceProvider(LLMProvider):
    BASE = "https://api-inference.huggingface.co/models/{model}"

    def __init__(self, api_key="", model="meta-llama/Meta-Llama-3-8B-Instruct"):
        self.api_key = api_key
        self.model = model
        self.name = f"HuggingFace ({model.split('/')[-1]})"
        self.last_usage: Optional[dict] = None

    async def is_available(self) -> bool:
        return bool(self.api_key) and len(self.api_key) > 10

    async def generate(self, prompt: str, max_tokens: int = 400) -> Optional[str]:
        self.last_usage = None
        if not await self.is_available():
            return None
        try:
            url = self.BASE.format(model=self.model)
            async with aiohttp.ClientSession() as s:
                async with s.post(url,
                                  headers={"Authorization": f"Bearer {self.api_key}"},
                                  json={"inputs": prompt,
                                        "parameters": {"max_new_tokens": max_tokens,
                                                       "return_full_text": False}},
                                  timeout=60) as r:
                    if r.status != 200:
                        return None
                    data = await r.json()
                    # HF inference rarely returns usage; leave last_usage None
                    # so the chain approximates from word count.
                    if isinstance(data, list) and data:
                        return data[0].get("generated_text", "").strip()
                    return None
        except Exception as e:
            logger.warning("HF generate failed: %s", e)
            return None


class EchoLLMProvider(LLMProvider):
    """Always available. Used when nothing else is up — and by every test."""
    name = "Echo (offline fallback)"

    def __init__(self):
        self.last_usage: Optional[dict] = None

    async def is_available(self) -> bool:
        return True

    async def generate(self, prompt: str, max_tokens: int = 400) -> Optional[str]:
        self.last_usage = None    # always approximated for echo
        return f"I heard you ask: {prompt[:120]}. No language model is currently online to answer."


def _approximate_tokens(text: str) -> int:
    """Rough English word→token approximation. ~1.3 tokens per word for
    Llama/GPT tokenizers; we round up. Used only when the provider didn't
    return real usage info."""
    if not text:
        return 0
    words = len(text.split())
    return max(1, int(words * 1.3 + 0.5))


class LLMChain:
    def __init__(self, providers: list[LLMProvider]):
        self.providers = providers
        self.last_provider: Optional[str] = None
        self.last_usage: Optional[dict] = None

    async def detect(self) -> dict[str, bool]:
        results = await asyncio.gather(
            *(p.is_available() for p in self.providers),
            return_exceptions=True)
        return {p.name: (r is True) for p, r in zip(self.providers, results)}

    async def probe_local(self) -> Optional[LLMProvider]:
        """Probe the first LOCAL LLM provider (skip federation + echo)
        and return it if it's responding. Used by the federation
        providers as a pre-flight "second chance for local" check
        before they commit to a federated call.

        Why this exists: when the realm has been answering via federation
        rescue for a while, the rolling avg might still be elevated even
        after local LLM recovers — meaning we'd keep federating even
        though local is back. The probe gives local one more chance
        right before a federated call fires. If local responds, we
        skip federation, clear stale state, and serve locally.

        Returns the local provider if reachable, None otherwise.
        Fast — uses each provider's existing is_available() check
        which is designed to be cheap (a single HTTP HEAD or quick GET
        against the provider's health endpoint)."""
        for p in self.providers:
            # Skip federation providers — they wrap peers, not local
            if "Federation" in p.name:
                continue
            # Skip echo — it's the always-available offline fallback,
            # not a real LLM
            if "Echo" in p.name:
                continue
            try:
                if await p.is_available():
                    return p
            except Exception as e:
                logger.debug("probe_local: %s is_available raised %s",
                             p.name, e)
                continue
        return None

    async def generate(self, prompt: str, max_tokens: int = 400,
                       allow_federation: bool = True) -> str:
        """Generate a response via the first available provider.

        `allow_federation` is passed to providers that support it (the
        FederationLLMProvider in particular). When False, federation is
        bypassed even if its is_available() returned True — this is the
        hop-limit mechanism: inbound /api/ask requests with
        X-Federation-Hops: 1 set allow_federation=False so the receiver
        runs locally and doesn't re-forward."""
        for p in self.providers:
            if not await p.is_available():
                continue
            # Federation provider needs allow_federation to honor hop
            # limit. Other providers don't care. Use kwargs sniffing
            # so we don't break the existing provider interface.
            try:
                result = await p.generate(
                    prompt, max_tokens=max_tokens,
                    allow_federation=allow_federation)
            except TypeError:
                # Provider doesn't accept allow_federation — that's fine,
                # it's a non-federation provider (GPT4All, Claude, etc.)
                result = await p.generate(prompt, max_tokens=max_tokens)
            if result and len(result.strip()) > 0:
                self.last_provider = p.name
                # Read provider's per-call usage; approximate if not present.
                provider_usage = getattr(p, "last_usage", None)
                if provider_usage:
                    self.last_usage = dict(provider_usage)   # copy
                else:
                    self.last_usage = {
                        "tokens_out": _approximate_tokens(result),
                        "tokens_in": _approximate_tokens(prompt),
                        "approx": True,
                    }
                return result
        self.last_provider = "none"
        self.last_usage = None
        return "All language models are offline."


# ===========================================================================
# TTS CHAIN — Kokoro local, then online quality, then pyttsx3 floor
# ===========================================================================

class TTSProvider(ABC):
    name: str = "abstract"

    @abstractmethod
    async def is_available(self) -> bool: ...

    @abstractmethod
    async def synth(self, text: str) -> Optional[str]:
        """Returns base64-encoded WAV/MP3 audio, or None on failure."""


class KokoroTTSProvider(TTSProvider):
    """
    Kokoro via ONNX Runtime. GPU when available, CPU fallback.

    GPU activation requires three things to align:
      1. The kokoro_onnx Python package (`pip install kokoro-onnx`)
      2. CUDA/cuDNN DLLs reachable by onnxruntime — either via the
         `onnxruntime-gpu` wheel or a portable `cuda/` folder next to app.py
      3. The CUDA provider being available AND able to load this specific
         model (cuDNN's 1-D conv kernels fail on Kokoro without
         `cudnn_conv1d_pad_to_nc1d=1`).

    The session-builder pattern (taken from Jim's working news_reader.py):
      Build the InferenceSession yourself with explicit provider options,
      then hand it to Kokoro.from_session(). The plain Kokoro() constructor
      doesn't expose provider config and falls silently to CPU.

    Setup (in config.ini under [Kokoro]):
      model_path     = full path to kokoro-v1.0.onnx
      voices_path    = full path to voices-v1.0.bin (or empty for sibling)
      voice          = af_sarah, af_nicole, am_michael, bf_emma, etc.
      onnx_provider  = CUDAExecutionProvider (default) or CPUExecutionProvider

    On boot the realm logs "Kokoro ACTIVE providers: [...]" — if you asked
    for CUDA but only CPU appears, you'll see a WARNING and you know.
    """
    name = "Kokoro (local ONNX)"

    def __init__(self, model_path: str = "", voice: str = "af_sarah",
                 voices_path: str = "",
                 onnx_provider: str = "CUDAExecutionProvider",
                 cudnn_conv_algo_search: str = "DEFAULT"):
        self.model_path = (model_path or "").strip()
        self.voices_path = (voices_path or "").strip()
        self.voice = voice
        self.onnx_provider = onnx_provider
        self.cudnn_conv_algo_search = cudnn_conv_algo_search
        self._kokoro = None
        self._loaded = False
        self._load_failed = False
        self._active_providers = None
        self._lock = threading.Lock()

    def _resolve_voices_path(self) -> str:
        if self.voices_path:
            return self.voices_path
        # Default: look for voices file next to the .onnx model. Try the
        # common names in order — v1 uses 'voices-v1.0.bin', some bundles
        # ship plain 'voices.bin'.
        model_dir = os.path.dirname(self.model_path)
        for candidate in ("voices-v1.0.bin", "voices.bin"):
            path = os.path.join(model_dir, candidate)
            if os.path.isfile(path):
                return path
        # Fallback to the v1 name so the error message points there
        return os.path.join(model_dir, "voices-v1.0.bin")

    def _preload_cuda_dlls(self):
        """Make portable cuda/ folder loadable, or fall back to pip wheels.

        Windows DLL search: add_dll_directory alone isn't enough because
        ONNX Runtime resolves provider deps via plain LoadLibrary. So we
        (1) prepend the folder to PATH, (2) add it as a DLL directory,
        (3) force-load every DLL by absolute path in passes (to resolve
        inter-DLL dependencies). Once loaded, Windows resolves them by
        name for ONNX Runtime."""
        try:
            import onnxruntime as ort
        except ImportError:
            return
        here = os.path.dirname(os.path.abspath(__file__))
        app_dir = os.path.dirname(here)
        # Look for cuda/ next to the realm/ folder, then next to CWD
        cuda_dir = next((d for d in (
            os.path.join(app_dir, "cuda"),
            os.path.join(os.getcwd(), "cuda"),
        ) if os.path.isdir(d)), None)
        if cuda_dir:
            os.environ["PATH"] = cuda_dir + os.pathsep + os.environ.get("PATH", "")
            try:
                os.add_dll_directory(cuda_dir)
            except (OSError, AttributeError):
                pass  # non-Windows or already added
            import ctypes
            import glob
            pending = sorted(glob.glob(os.path.join(cuda_dir, "*.dll")))
            last_errors = {}    # dll_name -> last error message
            for _ in range(3):  # three passes resolves inter-DLL deps
                failed = []
                for p in pending:
                    try:
                        ctypes.WinDLL(p)
                    except OSError as e:
                        failed.append(p)
                        last_errors[os.path.basename(p)] = str(e)
                if not failed:
                    break
                pending = failed
            loaded = len(glob.glob(os.path.join(cuda_dir, "*.dll"))) - len(pending)
            msg = f"Kokoro CUDA: loaded {loaded} DLLs from {cuda_dir}"
            if pending:
                msg += f", failed: {[os.path.basename(p) for p in pending]}"
            logger.info(msg)
            # Log the specific error for the FIRST failure — root cause usually
            # cascades from one missing dep (e.g. cudart fails → cublas fails
            # because cublas depends on cudart). Surfacing one error keeps the
            # log readable; surfacing all 14 is noise.
            if pending:
                first_fail = os.path.basename(pending[0])
                err = last_errors.get(first_fail, "unknown")
                logger.warning(
                    "Kokoro CUDA: first DLL load failure — %s: %s "
                    "(WinError code is the key: 126=not found / missing dep, "
                    "193=wrong architecture, 1114=init routine failed)",
                    first_fail, err)
        elif hasattr(ort, "preload_dlls"):
            # No portable folder — try pip-installed NVIDIA wheels
            try:
                ort.preload_dlls()
                logger.info("Kokoro CUDA: preload_dlls() called (using pip wheels)")
            except Exception as e:
                logger.info("Kokoro CUDA: preload_dlls failed: %s", e)

    def _try_load(self):
        with self._lock:
            if self._loaded or self._load_failed:
                return
            # Fast-fail: empty path = "user hasn't configured Kokoro"
            if not self.model_path:
                logger.info("Kokoro: model_path empty in config.ini [Kokoro]; "
                            "provider disabled")
                self._load_failed = True
                return
            if not os.path.isfile(self.model_path):
                if os.path.isdir(self.model_path):
                    logger.warning("Kokoro: model_path is a directory, not a "
                                   "file: %s — set it to the full path of "
                                   "kokoro-v1.0.onnx", self.model_path)
                else:
                    logger.warning("Kokoro: model file not found at %s — "
                                   "check [Kokoro] model_path in config.ini",
                                   self.model_path)
                self._load_failed = True
                return
            voices = self._resolve_voices_path()
            if not os.path.isfile(voices):
                logger.warning("Kokoro: voices file not found at %s — "
                               "either set [Kokoro] voices_path or put "
                               "voices-v1.0.bin next to the .onnx model",
                               voices)
                self._load_failed = True
                return

            # Preload CUDA DLLs BEFORE importing ONNX Runtime providers
            self._preload_cuda_dlls()

            try:
                import onnxruntime as ort
                from kokoro_onnx import Kokoro
            except ImportError as e:
                logger.warning("Kokoro: package not installed (%s) — "
                               "pip install kokoro-onnx onnxruntime-gpu", e)
                self._load_failed = True
                return

            available_providers = ort.get_available_providers()
            logger.info("Kokoro: available ONNX providers: %s",
                        available_providers)

            # Catch the most common GPU-fails-to-engage cause: user has the
            # CPU-only `onnxruntime` package installed, not `onnxruntime-gpu`.
            # The CPU-only package does NOT register CUDAExecutionProvider
            # even if cuDNN/CUDA DLLs are present on disk. EVEN WORSE: if
            # BOTH packages are installed simultaneously (which pip allows),
            # the CPU one wins and shadows the GPU one. Jim Ames confirmed
            # this on Win11 — fix below is the exact sequence that worked.
            want_cuda = "CUDA" in self.onnx_provider
            cuda_available = "CUDAExecutionProvider" in available_providers
            if want_cuda and not cuda_available:
                logger.warning(
                    "Kokoro: CUDAExecutionProvider not registered. Most "
                    "common cause is BOTH 'onnxruntime' and 'onnxruntime-gpu' "
                    "installed in the same venv — the CPU one shadows the "
                    "GPU one. Verified fix sequence: "
                    "  pip uninstall -y onnxruntime onnxruntime-gpu && "
                    "pip install onnxruntime-gpu  "
                    "Then restart. (If you only want CPU TTS, set "
                    "[Kokoro] onnx_provider = CPUExecutionProvider in config.ini.)")

            # kokoro-onnx reads ONNX_PROVIDER env var (NOT ORT_PROVIDER).
            # Must be set BEFORE the Kokoro constructor builds its session.
            os.environ["ONNX_PROVIDER"] = self.onnx_provider

            # If user asked for CUDA AND it's available, build the session
            # ourselves with the cuDNN workaround for Kokoro's 1-D convs.
            if want_cuda and cuda_available:
                try:
                    cuda_opts = {
                        "cudnn_conv1d_pad_to_nc1d": "1",
                        "cudnn_conv_algo_search": self.cudnn_conv_algo_search,
                    }
                    so = ort.SessionOptions()
                    so.log_severity_level = 3   # hide benign per-conv warnings
                    sess = ort.InferenceSession(
                        self.model_path, sess_options=so,
                        providers=[("CUDAExecutionProvider", cuda_opts),
                                   "CPUExecutionProvider"])
                    self._kokoro = Kokoro.from_session(sess, voices)
                except Exception as e:
                    logger.warning("Kokoro: CUDA session build failed (%s); "
                                   "falling back to default loader", e)
                    self._kokoro = None

            # Fallback path: plain constructor (uses ONNX_PROVIDER env var)
            if self._kokoro is None:
                try:
                    self._kokoro = Kokoro(self.model_path, voices)
                except Exception as e:
                    logger.warning("Kokoro: default loader failed: %s", e)
                    self._load_failed = True
                    return

            # Verification: what providers did we actually end up with?
            try:
                self._active_providers = self._kokoro.sess.get_providers()
                logger.info("Kokoro ACTIVE providers: %s",
                            self._active_providers)
                if want_cuda and "CUDAExecutionProvider" not in self._active_providers:
                    logger.warning(
                        "Kokoro: CUDA requested but not active — running on "
                        "CPU. Check NVIDIA drivers and onnxruntime-gpu install. "
                        "Available: %s", available_providers)
            except Exception:
                logger.info("Kokoro loaded (provider list unavailable)")

            self._loaded = True
            logger.info("Kokoro loaded: model=%s voice=%s",
                        os.path.basename(self.model_path), self.voice)

    def _kokoro_create(self, text: str):
        """Call kokoro.create with graceful fallback for older signatures."""
        try:
            return self._kokoro.create(text, voice=self.voice, speed=1.0,
                                       lang="en-us")
        except TypeError:
            pass
        try:
            return self._kokoro.create(text, voice=self.voice, speed=1.0)
        except TypeError:
            pass
        return self._kokoro.create(text, voice=self.voice)

    async def is_available(self) -> bool:
        if not self._loaded and not self._load_failed:
            await asyncio.to_thread(self._try_load)
        return self._loaded

    async def synth(self, text: str) -> Optional[str]:
        if not await self.is_available():
            return None
        try:
            def _work():
                import io
                from scipy.io import wavfile
                import numpy as np
                samples, sample_rate = self._kokoro_create(text)
                buf = io.BytesIO()
                wavfile.write(buf, sample_rate, (samples * 32767).astype(np.int16))
                return base64.b64encode(buf.getvalue()).decode()
            return await asyncio.to_thread(_work)
        except Exception as e:
            logger.warning("Kokoro synth failed: %s", e)
            return None


class KokoroHTTPProvider(TTSProvider):
    """
    HTTP client for the dedicated Kokoro microservice (kokoro_service/).

    Use this instead of the in-process KokoroTTSProvider when you want:
      * The GPU model to stay warm across realm restarts
      * Multiple users to queue against a single GPU instance cleanly
      * The realm process itself to stay free of ONNX/CUDA dependencies
      * The same Kokoro to be reused by other apps (news_reader, etc.)

    Set [Kokoro] host = localhost (or remote) and port = 9998 in the
    realm's config.ini, and add "kokoro_service" to tts_order.

    Two modes:
      Inline (default)  → POST /tts → WAV bytes → base64 → tts_chunk event
      Deferred          → POST /tts {deferred:true} → audio_id, browser
                          fetches WAV on user click. For when autoplay
                          is blocked or playback is opt-in.
    """
    def __init__(self, host: str = "localhost", port: int = 9998,
                 voice: str = "af_sarah", speed: float = 1.0,
                 timeout: int = 30, deferred: bool = False):
        self.host = (host or "").strip()
        self.port = int(port)
        self.voice = voice
        self.speed = float(speed)
        self.timeout = int(timeout)
        self.deferred = bool(deferred)
        self.base_url = f"http://{self.host}:{self.port}"
        self.name = f"Kokoro Service ({self.host}:{self.port})"
        self._last_audio_id: Optional[str] = None

    @property
    def last_audio_id(self) -> Optional[str]:
        return self._last_audio_id

    async def is_available(self) -> bool:
        if not self.host:
            return False
        try:
            timeout = aiohttp.ClientTimeout(total=3)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"{self.base_url}/health") as r:
                    if r.status != 200:
                        return False
                    data = await r.json()
                    return bool(data.get("ready"))
        except Exception:
            return False

    async def synth(self, text: str) -> Optional[str]:
        self._last_audio_id = None
        payload = {"text": text, "voice": self.voice, "speed": self.speed,
                   "deferred": self.deferred}
        try:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.post(f"{self.base_url}/tts", json=payload) as r:
                    if r.status != 200:
                        logger.warning("Kokoro service %d: %s",
                                       r.status, (await r.text())[:200])
                        return None
                    if self.deferred:
                        data = await r.json()
                        self._last_audio_id = data.get("audio_id")
                        return ""
                    return base64.b64encode(await r.read()).decode()
        except asyncio.TimeoutError:
            logger.warning("Kokoro service timeout after %ds", self.timeout)
            return None
        except Exception as e:
            logger.warning("Kokoro service failed: %s", e)
            return None


class ElevenLabsTTSProvider(TTSProvider):
    """Premium online voice. ~$0.15-0.30 per 1000 chars."""
    BASE = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"

    def __init__(self, api_key="", voice_id="EXAVITQu4vr4xnSDxMaL",
                 model_id="eleven_turbo_v2_5"):
        self.api_key = api_key
        self.voice_id = voice_id
        self.model_id = model_id
        self.name = f"ElevenLabs ({voice_id[:8]})"

    async def is_available(self) -> bool:
        return bool(self.api_key) and len(self.api_key) > 10

    async def synth(self, text: str) -> Optional[str]:
        if not await self.is_available():
            return None
        url = self.BASE.format(voice_id=self.voice_id)
        headers = {"xi-api-key": self.api_key, "content-type": "application/json",
                   "accept": "audio/mpeg"}
        payload = {"text": text, "model_id": self.model_id,
                   "voice_settings": {"stability": 0.5, "similarity_boost": 0.75}}
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(url, headers=headers, json=payload,
                                  timeout=45) as r:
                    if r.status != 200:
                        logger.warning("ElevenLabs %s: %s", r.status,
                                       (await r.text())[:120])
                        return None
                    return base64.b64encode(await r.read()).decode()
        except Exception as e:
            logger.warning("ElevenLabs synth failed: %s", e)
            return None


class OpenAITTSProvider(TTSProvider):
    """Cheap, fast, decent. ~$0.015 per 1000 chars."""
    ENDPOINT = "https://api.openai.com/v1/audio/speech"

    def __init__(self, api_key="", model="tts-1", voice="alloy"):
        self.api_key = api_key
        self.model = model
        self.voice = voice
        self.name = f"OpenAI ({model}/{voice})"

    async def is_available(self) -> bool:
        return bool(self.api_key) and self.api_key.startswith("sk-")

    async def synth(self, text: str) -> Optional[str]:
        if not await self.is_available():
            return None
        headers = {"Authorization": f"Bearer {self.api_key}",
                   "Content-Type": "application/json"}
        payload = {"model": self.model, "voice": self.voice,
                   "input": text, "response_format": "mp3"}
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(self.ENDPOINT, headers=headers, json=payload,
                                  timeout=30) as r:
                    if r.status != 200:
                        return None
                    return base64.b64encode(await r.read()).decode()
        except Exception as e:
            logger.warning("OpenAI TTS synth failed: %s", e)
            return None


class SAPI5TTSProvider(TTSProvider):
    """
    Direct SAPI5 via win32com. Windows-only. Bypasses pyttsx3 entirely.

    Why not pyttsx3: pyttsx3's runAndWait() pumps a COM message loop. If
    COM was already initialized in the process (uvicorn + comtypes do this
    on Windows), the message pump deadlocks waiting for an event that the
    SAPI5 voice already fired. First call usually works; subsequent calls
    wedge forever. Documented in pyttsx3 issues #50, #150, others.

    Direct SAPI5 has no message pump. SpFileStream + SpVoice.Speak(text)
    is synchronous: the call returns when the WAV is complete. Same engine,
    same voices, none of the deadlock surface area.

    Each synth call:
      1. Creates a fresh SpFileStream pointing at a tempfile.
      2. Sets it as the voice's output.
      3. Calls Speak(text) with SVSFDefault (synchronous; blocks until done).
      4. Closes the stream; reads the WAV; returns base64.

    Per Microsoft SAPI5 docs, SpVoice is free-threaded and can be called
    from any thread. We still serialize through one worker so two synths
    don't clobber each other's file streams.
    """
    name = "SAPI5 (Windows TTS)"

    def __init__(self):
        import queue as _queue
        self._available: Optional[bool] = None
        self._init_error: Optional[str] = None
        self._requests: _queue.Queue = _queue.Queue()
        self._worker: Optional[threading.Thread] = None
        self._ready = threading.Event()
        self._voice = None  # set on the worker thread

    def _worker_loop(self):
        try:
            import pythoncom
            from win32com.client import Dispatch, constants
            import win32com.client.gencache as _gc
            # Generate type library bindings so `constants.*` works.
            _gc.EnsureDispatch("SAPI.SpVoice")
            pythoncom.CoInitialize()
            self._voice = Dispatch("SAPI.SpVoice")
            self._ready.set()
        except Exception as e:
            self._init_error = f"{type(e).__name__}: {e}"
            self._ready.set()
            return

        import tempfile
        import uuid as _uuid
        from win32com.client import Dispatch, constants

        # SAPI flags — SVSFDefault = 0 = synchronous (block until done)
        SVSFDefault = 0
        # Stream open mode — SSFMCreateForWrite = 3
        SSFMCreateForWrite = 3
        # Audio format — SAFT22kHz16BitMono = 22 (best compatibility)
        SAFT22kHz16BitMono = 22

        while True:
            item = self._requests.get()
            if item is None:
                break
            text, result_q = item
            stream = None
            path = None
            try:
                path = os.path.join(tempfile.gettempdir(),
                                    f"sapi5_{_uuid.uuid4().hex}.wav")
                stream = Dispatch("SAPI.SpFileStream")
                # Force a sensible audio format — some SAPI5 voices default
                # to 8-bit telephony quality otherwise.
                try:
                    fmt = Dispatch("SAPI.SpAudioFormat")
                    fmt.Type = SAFT22kHz16BitMono
                    stream.Format = fmt
                except Exception:
                    pass  # not all voices honor this; keep going
                stream.Open(path, SSFMCreateForWrite, False)
                self._voice.AudioOutputStream = stream
                self._voice.Speak(text, SVSFDefault)   # blocks until done
                stream.Close()
                stream = None

                if not os.path.exists(path) or os.path.getsize(path) < 100:
                    result_q.put(("err",
                                  f"SAPI5 produced empty WAV "
                                  f"({os.path.getsize(path) if os.path.exists(path) else 'missing'} bytes)"))
                    continue
                with open(path, "rb") as f:
                    result_q.put(("ok",
                                  base64.b64encode(f.read()).decode()))
            except Exception as e:
                result_q.put(("err",
                              f"{type(e).__name__}: {e}"))
            finally:
                if stream is not None:
                    try:
                        stream.Close()
                    except Exception:
                        pass
                if path and os.path.exists(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass

    def _start(self):
        if self._worker and self._worker.is_alive():
            return
        self._worker = threading.Thread(target=self._worker_loop,
                                        daemon=True, name="sapi5-worker")
        self._worker.start()
        self._ready.wait(timeout=10)

    async def is_available(self) -> bool:
        if self._available is None:
            await asyncio.to_thread(self._start)
            self._available = self._voice is not None and self._init_error is None
            if self._init_error:
                logger.info("SAPI5 unavailable: %s", self._init_error)
            elif self._available:
                logger.info("SAPI5 worker ready (direct win32com, no pyttsx3)")
        return bool(self._available)

    async def synth(self, text: str) -> Optional[str]:
        if not await self.is_available():
            return None
        import queue as _queue
        result_q: _queue.Queue = _queue.Queue()

        def _submit():
            self._requests.put((text, result_q))
            try:
                return result_q.get(timeout=30)
            except _queue.Empty:
                return ("err", "synth timeout (SAPI5 wedged?)")

        try:
            status, payload = await asyncio.to_thread(_submit)
            if status == "ok":
                logger.debug("SAPI5 synth ok: %d chars -> %d b64 bytes",
                             len(text), len(payload))
                return payload
            logger.warning("SAPI5 synth failed: %s", payload)
            return None
        except Exception as e:
            logger.warning("SAPI5 synth dispatch failed: %s", e)
            return None


class Pyttsx3TTSProvider(TTSProvider):
    """
    Cross-platform pyttsx3 fallback. Kept for Linux/macOS dev work.

    On Windows, prefer SAPI5TTSProvider — pyttsx3's runAndWait() deadlocks
    on second call when COM was initialized by another library first.
    This provider uses asyncio.to_thread with a per-call engine, which is
    safe on Linux espeak / macOS NSSpeechSynthesizer but unreliable on
    Windows SAPI5. The TTS chain order in config.ini puts SAPI5 first on
    Windows; this provider is the floor for everyone else.
    """
    name = "pyttsx3 (cross-platform fallback)"

    def __init__(self):
        self._available: Optional[bool] = None
        self._lock = threading.Lock()

    async def is_available(self) -> bool:
        # Disable on Windows — SAPI5TTSProvider does Windows TTS properly.
        if sys.platform == "win32":
            self._available = False
            return False
        if self._available is None:
            def _probe():
                try:
                    import pyttsx3
                    eng = pyttsx3.init()
                    eng.stop()
                    return True
                except Exception:
                    return False
            self._available = await asyncio.to_thread(_probe)
        return bool(self._available)

    async def synth(self, text: str) -> Optional[str]:
        if not await self.is_available():
            return None
        def _work():
            import pyttsx3
            import tempfile
            import uuid as _uuid
            with self._lock:
                engine = pyttsx3.init()
                path = os.path.join(tempfile.gettempdir(),
                                    f"pyttsx3_{_uuid.uuid4().hex}.wav")
                try:
                    engine.save_to_file(text, path)
                    engine.runAndWait()
                    if not os.path.exists(path) or os.path.getsize(path) < 100:
                        return None
                    with open(path, "rb") as f:
                        return base64.b64encode(f.read()).decode()
                finally:
                    if os.path.exists(path):
                        try:
                            os.remove(path)
                        except OSError:
                            pass
        try:
            return await asyncio.to_thread(_work)
        except Exception as e:
            logger.warning("pyttsx3 synth failed: %s", e)
            return None


class EchoTTSProvider(TTSProvider):
    """Test-only. Always available. Emits a deterministic stub."""
    name = "Echo TTS (test)"

    async def is_available(self) -> bool:
        return True

    async def synth(self, text: str) -> Optional[str]:
        return base64.b64encode(f"STUB:{text[:40]}".encode()).decode()


class TTSChain:
    def __init__(self, providers: list[TTSProvider]):
        self.providers = providers
        self.last_provider: Optional[str] = None

    async def detect(self) -> dict[str, bool]:
        results = await asyncio.gather(
            *(p.is_available() for p in self.providers),
            return_exceptions=True)
        return {p.name: (r is True) for p, r in zip(self.providers, results)}

    async def probe_local(self) -> Optional[TTSProvider]:
        """Probe the first LOCAL TTS provider (skip federation AND skip
        the always-available floor providers). Used by the federation
        TTS providers as a pre-flight "second chance for local" check
        before they commit to a federated TTS call. Returns the provider
        if reachable, None otherwise.

        Why we skip SAPI5 and pyttsx3: they are the "robot voice degraded
        floor" — equivalent to Echo on the LLM side. They report
        is_available()=True unconditionally on Windows (SAPI5 is built
        into the OS; pyttsx3 falls back to it). If probe_local treats
        them as "local TTS responding," the FALLBACK federation provider
        will abort the rescue and the chain will fall through to robot
        voice every single time Kokoro dies.

        The LLM chain has the symmetric skip for Echo (the LLM floor).
        Without these skips the TTS rescue path is structurally broken:
        the chain position is correct (rev-3 hot-patch confirmed this),
        but the probe still triggers a false "local recovered" signal
        from the floor provider, and the rescue never fires.

        Production-validated by N2NHU Labs failover testing on RNL.

        Returns the first real local TTS provider that is_available,
        or None if only floor providers and federation are reachable.
        """
        for p in self.providers:
            if "Federation" in p.name:
                continue
            # Skip the always-available floor providers. These don't
            # represent local TTS recovery — they're the degraded fallback
            # that fires when nothing real is available. Treating them
            # as "local responding" would defeat federation TTS rescue.
            if "SAPI5" in p.name:
                continue
            if "pyttsx3" in p.name:
                continue
            try:
                if await p.is_available():
                    return p
            except Exception as e:
                logger.debug("probe_local TTS: %s is_available raised %s",
                             p.name, e)
                continue
        return None

    async def synth(self, text: str, allow_federation: bool = True) -> Optional[str]:
        """Same hop-limit semantics as LLMChain.generate. When
        allow_federation=False, federation providers are bypassed."""
        for p in self.providers:
            if not await p.is_available():
                continue
            try:
                audio = await p.synth(text, allow_federation=allow_federation)
            except TypeError:
                # Non-federation providers don't accept allow_federation
                audio = await p.synth(text)
            if audio:
                self.last_provider = p.name
                return audio
        self.last_provider = "none"
        return None


# ===========================================================================
# VISION CHAIN — image+prompt -> text description. LLaVA local, Echo floor.
# ===========================================================================

class VisionProvider(ABC):
    name: str = "abstract"

    @abstractmethod
    async def is_available(self) -> bool: ...

    @abstractmethod
    async def describe(self, image_b64: str,
                       prompt: str = "What do you see?") -> Optional[str]:
        """image_b64 is a raw base64-encoded JPEG/PNG (no data: prefix).
        Returns a text description, or None on failure (chain falls
        through)."""


class LLaVAProvider(VisionProvider):
    """Local LLaVA via Ollama's REST API. Free, private, RTX-friendly —
    same shape as GPT4AllProvider, just with an images[] field.

    Setup: `ollama pull llava` then `ollama serve` (default port 11434).
    Realm picks it up on next request, no restart — same re-probe
    pattern as every other provider in this file.
    """

    def __init__(self, host="localhost", port=11434, model="llava",
                 timeout=60):
        self.host, self.port, self.model, self.timeout = host, port, model, timeout
        self.base_url = f"http://{host}:{port}/api"
        self.name = f"LLaVA ({model})"

    async def is_available(self) -> bool:
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{self.base_url}/tags", timeout=3) as r:
                    return r.status == 200
        except Exception:
            return False

    async def describe(self, image_b64: str,
                       prompt: str = "What do you see?") -> Optional[str]:
        payload = {
            "model": self.model,
            "prompt": prompt,
            "images": [image_b64],
            "stream": False,
        }
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(f"{self.base_url}/generate",
                                  json=payload, timeout=self.timeout) as r:
                    if r.status != 200:
                        return None
                    data = await r.json()
                    text = (data.get("response") or "").strip()
                    return text or None
        except Exception as e:
            logger.warning("LLaVA describe failed: %s", e)
            return None


class EchoVisionProvider(VisionProvider):
    """Always available. Used when no vision model is online — and by
    every test. Mirrors EchoLLMProvider exactly.

    Operator easter egg (Sprint 4/5 wiring): EASTER_EGG_YOUTUBE_ID is
    the classic Mr. Magoo "oohhh Magoo, you've done it again" clip —
    thematically perfect for "nothing is actually looking at the
    camera." Same mechanism as EchoImagineProvider.RICKROLL_YOUTUBE_ID:
    when this provider is the one that answered, the orchestrator's
    vision_handler can route the response through the YouTube-iframe
    panel (shared with the Imagine floor's video, not a separate
    code path) instead of — or alongside — the spoken offline message.
    We never download, store, or reproduce the clip; we just point at
    the official video, exactly like Music does for any song.
    """
    name = "Echo Vision (offline fallback)"

    # The realm's official "nothing is actually looking" signal.
    EASTER_EGG_YOUTUBE_ID = "n3UKJq_lxcM"

    async def is_available(self) -> bool:
        return True

    async def describe(self, image_b64: str,
                       prompt: str = "What do you see?") -> Optional[str]:
        return ("I heard you ask what I see, but no vision model is "
                "currently online to look.")


class VisionChain:
    def __init__(self, providers: list[VisionProvider]):
        self.providers = providers
        self.last_provider: Optional[str] = None

    async def detect(self) -> dict[str, bool]:
        results = await asyncio.gather(
            *(p.is_available() for p in self.providers),
            return_exceptions=True)
        return {p.name: (r is True) for p, r in zip(self.providers, results)}

    async def probe_local(self) -> Optional[VisionProvider]:
        """Same shape as LLMChain.probe_local — skip echo, return the
        first real vision provider that's responding."""
        for p in self.providers:
            if "Echo" in p.name:
                continue
            try:
                if await p.is_available():
                    return p
            except Exception as e:
                logger.debug("probe_local vision: %s is_available raised %s",
                             p.name, e)
                continue
        return None

    async def describe(self, image_b64: str,
                       prompt: str = "What do you see?") -> str:
        for p in self.providers:
            if not await p.is_available():
                continue
            try:
                result = await p.describe(image_b64, prompt=prompt)
            except Exception as e:
                logger.warning("Vision provider %s raised: %s", p.name, e)
                result = None
            if result and len(result.strip()) > 0:
                self.last_provider = p.name
                return result
        self.last_provider = "none"
        return "No vision model is currently online."


# ===========================================================================
# IMAGINE CHAIN — prompt -> image. Automatic1111 (txt2img) local, Echo floor.
# ===========================================================================

class ImagineProvider(ABC):
    name: str = "abstract"

    @abstractmethod
    async def is_available(self) -> bool: ...

    @abstractmethod
    async def generate(self, prompt: str) -> Optional[str]:
        """Returns base64-encoded PNG image data, or None on failure
        (chain falls through)."""


class Automatic1111Provider(ImagineProvider):
    """Local Stable Diffusion via AUTOMATIC1111's web UI in API mode.
    Free, private, RTX-friendly — same provider shape as everything
    else in this file, just text-in/image-out instead of text-in/text-out.

    Setup: launch with `--api` (or `--nowebui` for a headless server).
    Realm picks it up on next request, no restart.
    """

    def __init__(self, host="localhost", port=7860, steps=20,
                 width=512, height=512, sampler="Euler a", timeout=120):
        self.host, self.port = host, port
        self.steps, self.width, self.height = steps, width, height
        self.sampler = sampler
        self.timeout = timeout
        self.base_url = f"http://{host}:{port}/sdapi/v1"
        self.name = "Automatic1111 (txt2img)"

    async def is_available(self) -> bool:
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{self.base_url}/sd-models", timeout=3) as r:
                    return r.status == 200
        except Exception:
            return False

    async def generate(self, prompt: str) -> Optional[str]:
        payload = {
            "prompt": prompt,
            "steps": self.steps,
            "width": self.width,
            "height": self.height,
            "sampler_name": self.sampler,
        }
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(f"{self.base_url}/txt2img",
                                  json=payload, timeout=self.timeout) as r:
                    if r.status != 200:
                        return None
                    data = await r.json()
                    images = data.get("images") or []
                    return images[0] if images else None
        except Exception as e:
            logger.warning("Automatic1111 generate failed: %s", e)
            return None


class EchoImagineProvider(ImagineProvider):
    """Always available. Used when no image model is online — and by
    every test. Mirrors EchoLLMProvider exactly. Returns a tiny valid
    1x1 transparent PNG (not real art) so client-side rendering code
    has something decodable to test against.

    Operator easter egg (Sprint 4/5 wiring): RICKROLL_YOUTUBE_ID is the
    well-known "Never Gonna Give You Up" video ID. When this provider
    is the one that answered (chain.last_provider == this .name), the
    orchestrator's imagine_handler can route the response through the
    SAME YouTube-iframe mechanism the Music intent already uses —
    instantly readable by any operator watching the cockpit ("oh, the
    image floor fired") without us shipping any actual Rick Astley
    media in this repo. We just point at the official video, exactly
    like Music does for any song.
    """
    name = "Echo Imagine (offline fallback)"

    # The realm's official "nothing is online" signal. Embedded via
    # YouTube's iframe API (see templates/index.html music panel) —
    # never downloaded, stored, or reproduced by this codebase.
    RICKROLL_YOUTUBE_ID = "dQw4w9WgXcQ"

    # 1x1 transparent PNG, base64-encoded — smallest valid PNG payload.
    # Used when a caller wants strict image bytes (e.g. tests, or an
    # operator who has disabled the easter egg) rather than the video.
    _STUB_PNG = (
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk"
        "+A8AAQUBAScY42YAAAAASUVORK5CYII="
    )

    async def is_available(self) -> bool:
        return True

    async def generate(self, prompt: str) -> Optional[str]:
        return self._STUB_PNG


class ImagineChain:
    def __init__(self, providers: list[ImagineProvider]):
        self.providers = providers
        self.last_provider: Optional[str] = None

    async def detect(self) -> dict[str, bool]:
        results = await asyncio.gather(
            *(p.is_available() for p in self.providers),
            return_exceptions=True)
        return {p.name: (r is True) for p, r in zip(self.providers, results)}

    async def probe_local(self) -> Optional[ImagineProvider]:
        """Same shape as LLMChain.probe_local — skip echo, return the
        first real imagine provider that's responding."""
        for p in self.providers:
            if "Echo" in p.name:
                continue
            try:
                if await p.is_available():
                    return p
            except Exception as e:
                logger.debug("probe_local imagine: %s is_available raised %s",
                             p.name, e)
                continue
        return None

    async def generate(self, prompt: str) -> Optional[str]:
        for p in self.providers:
            if not await p.is_available():
                continue
            try:
                result = await p.generate(prompt)
            except Exception as e:
                logger.warning("Imagine provider %s raised: %s", p.name, e)
                result = None
            if result:
                self.last_provider = p.name
                return result
        self.last_provider = "none"
        return None


# ===========================================================================
# Factories — config -> chain. Same shape as Jim's build_provider_chain.
# ===========================================================================

def build_llm_chain(cfg: dict) -> LLMChain:
    """cfg: flat dict from config.ini [LLMChain] + provider sections."""
    order = [x.strip() for x in cfg.get("llm_order", "gpt4all,claude,huggingface,echo").split(",")]
    factories = {
        "gpt4all": lambda: GPT4AllProvider(
            host=cfg.get("gpt4all_host", "localhost"),
            port=int(cfg.get("gpt4all_port", 4891)),
            model=cfg.get("gpt4all_model", "Llama 3 8B Instruct"),
            timeout=int(cfg.get("gpt4all_timeout", 60))),
        "claude": lambda: ClaudeProvider(
            api_key=cfg.get("claude_api_key", ""),
            model=cfg.get("claude_model", "claude-haiku-4-5-20251001"),
            max_tokens=int(cfg.get("claude_max_tokens", 500))),
        "huggingface": lambda: HuggingFaceProvider(
            api_key=cfg.get("huggingface_api_key", ""),
            model=cfg.get("huggingface_model", "meta-llama/Meta-Llama-3-8B-Instruct")),
        "echo": lambda: EchoLLMProvider(),
    }
    providers = [factories[name]() for name in order if name in factories]
    if not providers or not isinstance(providers[-1], EchoLLMProvider):
        providers.append(EchoLLMProvider())   # floor
    return LLMChain(providers)


def build_tts_chain(cfg: dict) -> TTSChain:
    order = [x.strip() for x in cfg.get("tts_order",
        "kokoro_service,sapi5,kokoro,elevenlabs,openai,pyttsx3").split(",")]
    factories = {
        "kokoro_service": lambda: KokoroHTTPProvider(
            host=cfg.get("kokoro_service_host", "localhost"),
            port=int(cfg.get("kokoro_service_port", 9998)),
            voice=cfg.get("kokoro_voice", "af_sarah"),
            speed=float(cfg.get("kokoro_speed", 1.0)),
            timeout=int(cfg.get("kokoro_service_timeout", 30)),
            deferred=str(cfg.get("kokoro_service_deferred", "false")).lower() in ("1", "true", "yes")),
        "sapi5": lambda: SAPI5TTSProvider(),
        "kokoro": lambda: KokoroTTSProvider(
            model_path=cfg.get("kokoro_model_path", ""),
            voices_path=cfg.get("kokoro_voices_path", ""),
            voice=cfg.get("kokoro_voice", "af_sarah"),
            onnx_provider=cfg.get("kokoro_onnx_provider", "CUDAExecutionProvider"),
            cudnn_conv_algo_search=cfg.get("kokoro_cudnn_conv_algo_search", "DEFAULT")),
        "elevenlabs": lambda: ElevenLabsTTSProvider(
            api_key=cfg.get("elevenlabs_api_key", ""),
            voice_id=cfg.get("elevenlabs_voice_id", "EXAVITQu4vr4xnSDxMaL"),
            model_id=cfg.get("elevenlabs_model_id", "eleven_turbo_v2_5")),
        "openai": lambda: OpenAITTSProvider(
            api_key=cfg.get("openai_api_key", ""),
            model=cfg.get("openai_tts_model", "tts-1"),
            voice=cfg.get("openai_tts_voice", "alloy")),
        "pyttsx3": lambda: Pyttsx3TTSProvider(),
        "echo": lambda: EchoTTSProvider(),
    }
    providers = [factories[name]() for name in order if name in factories]
    return TTSChain(providers)


def build_vision_chain(cfg: dict) -> VisionChain:
    """cfg: flat dict from config.ini [VisionChain] + [LLaVA]."""
    order = [x.strip() for x in cfg.get("vision_order", "llava,echo").split(",")]
    factories = {
        "llava": lambda: LLaVAProvider(
            host=cfg.get("llava_host", "localhost"),
            port=int(cfg.get("llava_port", 11434)),
            model=cfg.get("llava_model", "llava"),
            timeout=int(cfg.get("llava_timeout", 60))),
        "echo": lambda: EchoVisionProvider(),
    }
    providers = [factories[name]() for name in order if name in factories]
    if not providers or not isinstance(providers[-1], EchoVisionProvider):
        providers.append(EchoVisionProvider())   # floor
    return VisionChain(providers)


def build_imagine_chain(cfg: dict) -> ImagineChain:
    """cfg: flat dict from config.ini [ImagineChain] + [Automatic1111]."""
    order = [x.strip() for x in cfg.get("imagine_order", "automatic1111,echo").split(",")]
    factories = {
        "automatic1111": lambda: Automatic1111Provider(
            host=cfg.get("automatic1111_host", "localhost"),
            port=int(cfg.get("automatic1111_port", 7860)),
            steps=int(cfg.get("automatic1111_steps", 20)),
            width=int(cfg.get("automatic1111_width", 512)),
            height=int(cfg.get("automatic1111_height", 512)),
            sampler=cfg.get("automatic1111_sampler", "Euler a"),
            timeout=int(cfg.get("automatic1111_timeout", 120))),
        "echo": lambda: EchoImagineProvider(),
    }
    providers = [factories[name]() for name in order if name in factories]
    if not providers or not isinstance(providers[-1], EchoImagineProvider):
        providers.append(EchoImagineProvider())   # floor
    return ImagineChain(providers)
