"""
realm/ini_location.py — single source of truth for where config.ini
and federation.ini live, used identically by wizard.py and app.py.

WHY THIS EXISTS (incident #1): app.py's compiled-mode logic resolved
the INI directory as "next to the exe" (`Path(sys.executable).
resolve().parent`), while wizard.py's resolved it as
`%LOCALAPPDATA%\\RentAHalSOHO\\<version>`. Two different entry points,
two different answers to "where do the config files live" — meaning
an edit made through the wizard could silently never be seen by the
realm, or vice versa. Fixed by extracting the resolution logic into
ONE function both entry points import and call.

WHY THIS FILE CHANGED AGAIN (incident #2, a real production outage):
the first version of this fix moved compiled-mode's storage location
without a migration path for a machine that ALREADY had real,
hand-tuned settings sitting in the old location(s). The first launch
of a freshly compiled exe found nothing at the new LOCALAPPDATA path,
and — per the original (incomplete) design — fell straight back to
the bundled DEFAULT template. On rentahal.com specifically, that
replaced a working `[Federator] enabled = true` with the template's
`enabled = false`, taking the Federator itself offline and cascading
404s to every member realm checking in against it.

The fix: `ensure_default_ini_files()` now checks every KNOWN prior
location for real settings BEFORE ever falling back to the bundled
default — see `known_legacy_ini_dirs()`. A production config that
worked yesterday keeps working after a rebuild, full stop.
"""
import os
import sys
from pathlib import Path

# MUST match --product-version in BOTH Nuitka compile commands (wizard
# and realm) — this is what forms the LOCALAPPDATA subfolder. Bump
# this alongside the compile commands' --product-version, not
# independently, or a version bump would silently start a fresh,
# empty settings folder instead of finding the existing one. (The
# legacy-migration logic below is exactly what makes THIS specific
# failure mode non-destructive even if it does happen again.)
PRODUCT_VERSION = "26.1.0"

# Deliberately NOT "RentAHalSOHO" or "RentAHalWizard" — those are the
# --onefile-tempdir-spec folder names Nuitka itself uses for onefile's
# OWN extraction cache (both resolve under %LOCALAPPDATA% too, since
# Nuitka's {CACHE_DIR} placeholder maps there on Windows). Reusing
# either name here would put this module's PERSISTENT, operator-edited
# config.ini/federation.ini in the exact same folder Nuitka unpacks its
# bundled payload into on every launch.
APP_SUBFOLDER = "RentAHalSOHO-Settings"

# The folder name wizard.py hardcoded before this module existed —
# kept here, explicitly labeled legacy, so known_legacy_ini_dirs() can
# still find real settings an operator configured before this fix.
# Never used for new writes.
_LEGACY_APP_SUBFOLDER = "RentAHalSOHO"


def is_compiled() -> bool:
    """Nuitka detection: multiple signals because `"__compiled__" in
    globals()` alone has proven unreliable in onefile mode
    specifically — deliberately not even checked here, since the two
    signals below are the ones actually doing the work (this function
    lives in a shared module, and relying on a marker injected into
    the CALLING module's own globals() wouldn't reliably cross that
    boundary anyway)."""
    return bool(
        os.environ.get("NUITKA_ONEFILE_PARENT")   # Nuitka onefile bootstrapper
        or getattr(sys, "frozen", False)          # PyInstaller / generic marker
    )


def resolve_ini_dir(source_dir: Path) -> Path:
    """`source_dir` is the caller's own script/extraction directory —
    used as-is in source mode, and as the fallback in the (very
    unusual on real Windows) case where LOCALAPPDATA isn't set even
    though we're running compiled."""
    if not is_compiled():
        return source_dir
    local_appdata = os.environ.get("LOCALAPPDATA")
    if local_appdata:
        return Path(local_appdata) / APP_SUBFOLDER / PRODUCT_VERSION
    return Path(sys.executable).resolve().parent


def known_legacy_ini_dirs() -> tuple:
    """Every location this codebase has EVER resolved config.ini/
    federation.ini to, oldest-relevant-first — checked by
    ensure_default_ini_files() before it ever falls back to a bundled
    default. This is the actual fix for the production incident: a
    real, working config sitting in any of these must always win over
    a generic template.

    Deliberately a function, not a constant — it needs sys.executable,
    which only means anything once the process has actually started."""
    dirs = []
    local_appdata = os.environ.get("LOCALAPPDATA")
    if local_appdata:
        # wizard.py's own pre-this-module hardcoded location.
        dirs.append(Path(local_appdata) / _LEGACY_APP_SUBFOLDER / PRODUCT_VERSION)
    # app.py's own pre-this-module "next to the exe" location — this
    # is also just "wherever the compiled exe currently sits," which
    # covers the common case of an operator running a fresh build from
    # the same folder they'd been running the previous one (or source)
    # from all along.
    dirs.append(Path(sys.executable).resolve().parent)
    return tuple(dirs)


def ensure_default_ini_files(ini_dir: Path, template_dir: Path,
                             legacy_dirs: tuple = ()) -> None:
    """First-run bootstrap — but "first-run" for the LOCATION, not
    necessarily first-run for the operator. A fresh LOCALAPPDATA
    folder having nothing in it does NOT mean no real settings exist
    anywhere; it may just mean the storage location moved. Checking
    legacy locations first is what prevents a relocation like that
    from ever silently reverting someone's real, working config back
    to generic defaults again — see this module's own docstring for
    the incident that made this necessary.

    Order of preference, per file:
      1. Already exists at ini_dir — never touched (an operator's own
         edits are never at risk from this running again on a later
         launch).
      2. Found in one of `legacy_dirs`, in the order given — copied
         forward. This is real, working, operator-configured settings.
      3. Found in `template_dir` (the bundled default) — copied only
         as a last resort, for a genuinely fresh install with no
         prior settings anywhere at all.
      4. Found nowhere — left absent; the app runs on cfg_get()'s own
         built-in fallback defaults rather than crashing."""
    ini_dir.mkdir(parents=True, exist_ok=True)
    for name in ("config.ini", "federation.ini"):
        dest = ini_dir / name
        if dest.exists():
            continue

        copied = False
        for legacy_dir in legacy_dirs:
            legacy_src = legacy_dir / name
            # Guard against a legacy dir that IS ini_dir itself (can
            # happen if LOCALAPPDATA is unset and both resolve to the
            # exe's own directory) — reading and writing the same path
            # would be a no-op at best, a truncation risk at worst.
            if legacy_src.resolve() == dest.resolve():
                continue
            if legacy_src.exists():
                dest.write_bytes(legacy_src.read_bytes())
                copied = True
                break
        if copied:
            continue

        template_src = template_dir / name
        if template_src.exists() and template_src.resolve() != dest.resolve():
            dest.write_bytes(template_src.read_bytes())
