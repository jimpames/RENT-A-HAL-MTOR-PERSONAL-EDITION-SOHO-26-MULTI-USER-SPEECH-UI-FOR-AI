-- realm/migrations/001_ledger.sql
-- Sprint 11 — the append-only, hash-chained ledger.
--
-- APPEND-ONLY is enforced at three layers, deliberately not just one:
--   1. The application (realm/ledger.py) never issues UPDATE or DELETE
--      against this table — there is no method on the Ledger class
--      that could.
--   2. The hash chain itself: any row edited or deleted out of band
--      (direct SQL, a compromised admin session, a bug) breaks the
--      chain at that point, and verify_chain() detects exactly where.
--   3. OPTIONAL, RECOMMENDED: run 002_ledger_permissions.sql.example
--      to create a restricted database role with INSERT+SELECT only
--      (no UPDATE/DELETE grants at all) for the application to connect
--      as. Not auto-applied by the migration runner — it involves
--      choosing a password/credential, which is an operator decision,
--      not something a migration script should silently do.
--
-- Every row's row_hash is SHA-256 over a canonical pipe-joined string
-- of (entry_type, account_id, amount_micros, reference, metadata_json,
-- created_at_epoch_micros, prev_hash). See realm/ledger.py's
-- _compute_row_hash for the exact canonicalization — this schema
-- doesn't enforce the hash's correctness itself (Postgres has no
-- built-in SHA-256 trigger without an extension), that's what
-- verify_chain() is for.
--
-- created_at_epoch_micros (an exact integer) is what's hashed, NOT the
-- created_at TIMESTAMPTZ column below — timestamp string formatting
-- has just enough platform/driver variation (fractional-second
-- padding, "+00:00" vs "Z") to make it a fragile hash input. The
-- TIMESTAMPTZ column exists purely for convenient human-readable
-- querying and is always derived from the same epoch value, so the
-- two never disagree.

CREATE TABLE IF NOT EXISTS ledger_entries (
    id                      BIGSERIAL PRIMARY KEY,
    entry_type              TEXT NOT NULL,
    account_id              TEXT NOT NULL,
    amount_micros           BIGINT NOT NULL,
    reference                TEXT NOT NULL DEFAULT '',
    metadata                 JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at_epoch_micros  BIGINT NOT NULL,
    created_at               TIMESTAMPTZ NOT NULL,
    prev_hash                TEXT NOT NULL,
    row_hash                 TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ledger_account
    ON ledger_entries (account_id, id);

CREATE INDEX IF NOT EXISTS idx_ledger_entry_type
    ON ledger_entries (entry_type, id);

-- entry_type values used by this codebase (documentation, not a CHECK
-- constraint — deliberately, since the economic layer will add entry
-- types across future sprints and a CHECK constraint would need a
-- migration for each one; the hash chain is the real integrity
-- guarantee here, not a closed enum):
--   'topup'                — Sprint 13, consumer prepaid balance credit
--   'debit'                — Sprint 13, one metered submit
--   'payout'                — Sprint 14, donor payout via Stripe Connect
--   'conscription_credit'    — Sprint 14, donor earns from confirmed work
