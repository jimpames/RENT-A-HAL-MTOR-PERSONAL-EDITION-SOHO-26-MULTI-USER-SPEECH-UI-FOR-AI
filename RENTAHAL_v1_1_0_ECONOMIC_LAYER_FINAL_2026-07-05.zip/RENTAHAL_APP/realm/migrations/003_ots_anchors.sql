-- realm/migrations/003_ots_anchors.sql
-- Sprint 12 — tracks OpenTimestamps proof state for ledger chain-tip
-- hashes. Deliberately NOT append-only like ledger_entries — this
-- table tracks the lifecycle of an EXTERNAL anchoring process
-- (pending -> complete), which genuinely needs to be mutable as
-- calendars confirm over time. Its trustworthiness doesn't come from
-- this table's own access controls the way ledger_entries' does; it
-- comes from the .ots proof itself being independently verifiable
-- against Bitcoin regardless of what this database says. See
-- realm/ots_anchor.py's module docstring for the full protocol.

CREATE TABLE IF NOT EXISTS ots_anchors (
    id                    BIGSERIAL PRIMARY KEY,
    chain_tip_row_id      BIGINT NOT NULL,   -- ledger_entries.id that was the tip when stamped
    chain_tip_hash        TEXT NOT NULL,     -- the hash that was actually submitted
    ots_proof             BYTEA NOT NULL,    -- current .ots file bytes (grows as it upgrades)
    is_complete           BOOLEAN NOT NULL DEFAULT false,
    stamped_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_upgrade_attempt_at TIMESTAMPTZ,
    completed_at          TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_ots_anchors_incomplete
    ON ots_anchors (id) WHERE is_complete = false;

CREATE INDEX IF NOT EXISTS idx_ots_anchors_chain_tip
    ON ots_anchors (chain_tip_row_id);
