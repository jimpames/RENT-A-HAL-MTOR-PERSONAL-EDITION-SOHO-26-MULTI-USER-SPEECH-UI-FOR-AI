-- realm/migrations/004_ledger_idempotency.sql
-- Sprint 13 — idempotency guarantee for Stripe webhook credits.
--
-- Stripe WILL retry webhook delivery (network hiccups, timeouts, a
-- slow response, Stripe's own infrastructure hiccups) — a webhook
-- handler that isn't idempotent will double-credit a user's balance
-- on a redelivered event. Rather than relying on application-level
-- "check if this reference exists, then insert" (which has a
-- race-condition window between the check and the insert if two
-- deliveries of the same event arrive nearly simultaneously),
-- correctness is enforced HERE, atomically, by Postgres itself: no
-- two 'topup' entries can ever share the same reference (the Stripe
-- event ID). A second delivery of the same event hits this
-- constraint and fails at the database level — see realm/ledger.py's
-- DuplicateEntryError for how the application turns that into a
-- clean, idempotent no-op instead of a crash.
--
-- Partial index (WHERE entry_type = 'topup') rather than a table-wide
-- unique constraint on `reference` alone — 'debit' entries (one per
-- submit) don't need this guarantee the same way and shouldn't be
-- constrained by it; each rank/purpose gets exactly the uniqueness
-- rule it actually needs, not a blanket one.
CREATE UNIQUE INDEX IF NOT EXISTS idx_ledger_topup_reference_unique
    ON ledger_entries (reference)
    WHERE entry_type = 'topup' AND reference != '';
