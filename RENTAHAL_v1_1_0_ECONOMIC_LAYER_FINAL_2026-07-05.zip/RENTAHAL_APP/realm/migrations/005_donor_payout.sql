-- realm/migrations/005_donor_payout.sql
-- Sprint 14 — bilateral confirmation for conscription payouts, plus
-- donor Stripe Connect account linking.
--
-- WHY BILATERAL CONFIRMATION (see ECONOMIC_LAYER_DESIGN.md Part C.3
-- for the full reasoning): federation's self-reported health averages
-- (llm_avg_s etc.) are fine to trust unilaterally because lying about
-- them only costs the LIAR their own routing quality. A donor
-- self-reporting "I served this conscripted request, pay me" is a
-- completely different risk class — lying is directly profitable.
-- Both the REQUESTER (who received an answer from a donor) and the
-- DONOR (who served it) independently submit a claim about the same
-- piece of work; a payout only ever releases for claims that match on
-- BOTH sides. A claim with no matching pair after a reasonable window
-- is flagged for review, never auto-paid.
--
-- conscription_claims is intentionally mutable (matched/credited flip
-- from false to true as reconciliation happens) — same category as
-- ots_anchors from Sprint 12, not the ledger_entries table itself
-- (which stays strictly append-only). The actual MONEY movement this
-- produces is still recorded as an ordinary append-only ledger_entries
-- row (entry_type='conscription_credit') once a match is confirmed —
-- this table is the bookkeeping that DECIDES whether that row gets
-- written, not a substitute for it.

CREATE TABLE IF NOT EXISTS conscription_claims (
    id                       BIGSERIAL PRIMARY KEY,
    role                     TEXT NOT NULL,        -- 'requester' | 'donor'
    donor_url                TEXT NOT NULL,
    requester_url            TEXT NOT NULL,
    rank                     TEXT NOT NULL,        -- 'chat' | 'vision' | 'imagine'
    claimed_at_epoch_micros  BIGINT NOT NULL,      -- when the work happened, per the claimant
    submitted_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    matched                  BOOLEAN NOT NULL DEFAULT false,
    matched_claim_id         BIGINT,               -- the OTHER side's claim, once matched
    credited                 BOOLEAN NOT NULL DEFAULT false,
    credit_ledger_entry_id   BIGINT                -- points at the ledger_entries row, once credited
);

CREATE INDEX IF NOT EXISTS idx_conscription_claims_unmatched
    ON conscription_claims (donor_url, requester_url, rank)
    WHERE matched = false;

CREATE INDEX IF NOT EXISTS idx_conscription_claims_donor
    ON conscription_claims (donor_url, credited);

-- Maps a realm's federation identity (its own_url, the same identity
-- already used throughout federation.py) to a Stripe Connect Express
-- account. Mutable (payouts_enabled flips true once onboarding
-- actually completes) — an operational record, not a financial one.
CREATE TABLE IF NOT EXISTS donor_payout_accounts (
    donor_url          TEXT PRIMARY KEY,
    stripe_account_id  TEXT NOT NULL,
    payouts_enabled    BOOLEAN NOT NULL DEFAULT false,
    linked_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_checked_at    TIMESTAMPTZ
);

-- Extends 004_ledger_idempotency.sql's guarantee to conscription_credit
-- entries too — a matched claim pair being reconciled twice (a retry,
-- a race, an operator re-running a reconciliation pass) must not
-- double-credit the donor, for exactly the same reason a Stripe
-- webhook redelivery must not double-credit a consumer's top-up.
-- DROP + CREATE rather than ALTER because partial-index conditions
-- aren't directly alterable in Postgres.
DROP INDEX IF EXISTS idx_ledger_topup_reference_unique;
CREATE UNIQUE INDEX IF NOT EXISTS idx_ledger_credit_reference_unique
    ON ledger_entries (entry_type, reference)
    WHERE entry_type IN ('topup', 'conscription_credit') AND reference != '';
