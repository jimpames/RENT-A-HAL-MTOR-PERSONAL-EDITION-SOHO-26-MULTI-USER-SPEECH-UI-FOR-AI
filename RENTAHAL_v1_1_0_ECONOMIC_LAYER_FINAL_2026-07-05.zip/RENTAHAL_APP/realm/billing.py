"""
realm/billing.py — Sprint 13: consumer prepaid balance rail.

Two halves, and they have very different testability from this
development environment — said plainly up front, same discipline as
Sprint 12's OpenTimestamps notes:

  1. CHECKOUT SESSION CREATION (create_checkout_session): a real
     network call to api.stripe.com. Uses the real Stripe Python SDK's
     real API (verified against the installed SDK's actual parameter
     types before writing this, not guessed) — but the HTTP round trip
     itself cannot be exercised live from this sandbox (same network
     allowlist restriction that blocked OpenTimestamps' calendar
     servers in Sprint 12 — api.stripe.com isn't reachable either).
     Tested via mocking the SDK call itself, clearly labeled as such
     rather than silently.

  2. WEBHOOK SIGNATURE VERIFICATION (verify_webhook) and the credit
     logic that follows it: PURE LOCAL CRYPTOGRAPHY, genuinely fully
     testable with zero network access. This is also the single most
     security-critical piece of this whole sprint — a forged webhook
     claiming "payment succeeded" is the most dangerous vulnerability
     class in any billing integration — so it gets the most thorough
     real testing, not the least.

ECONOMIC MODEL (see ECONOMIC_LAYER_DESIGN.md Part C.1 for the full
reasoning): a FLAT price per submit, not metered by compute time or
tokens. $0.0001 (100 micros) per submit was the original target —
cheap enough that a $5 top-up buys 50,000 submits, expensive enough to
be a real, honest cost recovery mechanism rather than free.

Consumer balance going negative is NOT hard-blocked in this sprint —
that's a deliberate scope decision, not an oversight. Sprint 10's PoW
gate already provides the anti-abuse backstop; this module's job is
economic (track usage honestly, let a user top up, feed Sprint 14's
donor payout), not a second independent rate limiter. A low-balance
BUS EVENT gets published instead (see orchestrator wiring), consistent
with this whole codebase's existing event-bus-driven UI pattern rather
than a new HTTP-layer hard gate — worth revisiting once real usage
patterns are understood, same "ship, then tune" posture as Sprint 10's
free-call threshold.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

import stripe

from realm.ledger import DuplicateEntryError, Ledger

# Default topup presets: $5 / $10 / $20, expressed in micros
# (1,000,000 micros = $1.00 — see realm/ledger.py's own convention).
DEFAULT_TOPUP_PRESETS_MICROS: Tuple[int, ...] = (5_000_000, 10_000_000, 20_000_000)


@dataclass
class BillingConfig:
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    # $0.0001 per submit — the original target price point. See module
    # docstring for the economics.
    price_per_submit_micros: int = 100
    # Below this balance, publish a low_balance bus event (see
    # orchestrator wiring) rather than hard-blocking service.
    low_balance_threshold_micros: int = 10_000     # $0.01
    checkout_success_url: str = ""
    checkout_cancel_url: str = ""
    topup_presets_micros: Tuple[int, ...] = field(
        default_factory=lambda: DEFAULT_TOPUP_PRESETS_MICROS)

    @property
    def enabled(self) -> bool:
        return bool(self.stripe_secret_key and self.stripe_webhook_secret)


def micros_to_cents(amount_micros: int) -> int:
    """1,000,000 micros = $1.00 = 100 cents, so 10,000 micros = 1 cent.
    Stripe's API works in the currency's smallest unit (cents for USD)
    — this is the one conversion point between our internal accounting
    unit and Stripe's."""
    return amount_micros // 10_000


def cents_to_micros(amount_cents: int) -> int:
    return int(amount_cents) * 10_000


def create_checkout_session(cfg: BillingConfig, account_id: str,
                            amount_micros: int) -> str:
    """Real Stripe API call — needs network access to api.stripe.com,
    which this development sandbox cannot reach (same restriction
    documented for OpenTimestamps in Sprint 12). Real code against the
    real SDK's real parameter shape, verified against the installed
    SDK's actual type definitions before writing this — see
    tests/test_billing.py for how the network call itself gets mocked
    for testing, clearly labeled as such rather than silently.

    Returns the checkout URL to redirect the user to. `account_id`
    rides in BOTH client_reference_id and metadata — belt and suspenders,
    since different Stripe API versions/dashboards surface one or the
    other more prominently, and the webhook handler checks both."""
    if amount_micros <= 0:
        raise ValueError("amount_micros must be positive")
    amount_cents = micros_to_cents(amount_micros)
    if amount_cents < 50:   # Stripe's own minimum charge is $0.50 in most currencies
        raise ValueError(
            f"amount_micros={amount_micros} is below Stripe's minimum "
            f"charge (~$0.50) — use a larger top-up preset")

    session = stripe.checkout.Session.create(
        api_key=cfg.stripe_secret_key,
        mode="payment",
        line_items=[{
            "price_data": {
                "currency": "usd",
                "unit_amount": amount_cents,
                "product_data": {"name": "RENT-A-HAL balance top-up"},
            },
            "quantity": 1,
        }],
        client_reference_id=account_id,
        metadata={"account_id": account_id, "amount_micros": str(amount_micros)},
        success_url=cfg.checkout_success_url or "https://example.com/topup/success",
        cancel_url=cfg.checkout_cancel_url or "https://example.com/topup/cancel",
    )
    return session.url


class WebhookVerificationError(Exception):
    """Raised when a webhook payload's signature doesn't verify —
    either a genuine forgery attempt, a wrong webhook secret
    configured, or a stale/replayed request outside the tolerance
    window. Callers should return 400, not 200 — returning 200 to a
    forged request would look like "processed successfully" even
    though nothing was credited, masking a real attack from whoever's
    watching response codes."""
    pass


def verify_webhook(payload: bytes, sig_header: str, webhook_secret: str,
                   tolerance_s: int = 300):
    """THE security-critical function in this module. Pure local
    cryptography (HMAC-SHA256 over the real Stripe signing scheme —
    see this module's own test suite for constructing genuinely valid
    AND deliberately forged/tampered/expired signatures using the same
    real algorithm Stripe itself uses, verified against the installed
    SDK's own implementation before writing a single test). No network
    access needed or used.

    Returns the verified, parsed stripe.Event on success. Raises
    WebhookVerificationError (never the raw stripe exception type, so
    callers don't need to import stripe just to catch errors) on any
    failure — bad signature, wrong secret, or timestamp outside
    tolerance (stops replay of an old, previously-valid signed
    payload)."""
    try:
        return stripe.Webhook.construct_event(
            payload, sig_header, webhook_secret, tolerance=tolerance_s)
    except (stripe.SignatureVerificationError, ValueError) as e:
        raise WebhookVerificationError(str(e)) from e


@dataclass
class WebhookResult:
    handled: bool                          # was this an event type we act on?
    credited: bool                          # did this call add a NEW credit?
    account_id: Optional[str] = None
    amount_micros: Optional[int] = None
    duplicate: bool = False                 # True if this was a redelivery, already credited


async def handle_checkout_completed_event(event, ledger: Ledger) -> WebhookResult:
    """Processes an ALREADY-VERIFIED checkout.session.completed event
    (call verify_webhook first — this function does not itself check
    the signature). Idempotent via the ledger's own DuplicateEntryError
    (see realm/ledger.py + 004_ledger_idempotency.sql): a redelivered
    event correctly reports duplicate=True, credited=False, rather than
    double-crediting the account. This is what makes it safe for the
    HTTP handler to always return 200 to Stripe regardless of whether
    this was the first delivery or the fifth — Stripe stops retrying on
    any 2xx response.

    `event` may be a real stripe.Event (from verify_webhook) or a plain
    dict (tests construct these directly, without needing a live
    Stripe object). Converted to a plain dict immediately via
    .to_dict() when it's a StripeObject — found the hard way that
    StripeObject does NOT implement Python's Mapping protocol despite
    supporting `[]` access: no .get(), and missing keys raise KeyError
    instead of returning None. Normalizing to a plain dict up front
    means the rest of this function can use ordinary, ergonomic dict
    semantics throughout instead of special-casing two different
    access patterns."""
    event_dict = event.to_dict() if hasattr(event, "to_dict") else event

    if event_dict.get("type") != "checkout.session.completed":
        return WebhookResult(handled=False, credited=False)

    session = event_dict["data"]["object"]
    account_id = (session.get("client_reference_id")
                  or (session.get("metadata") or {}).get("account_id"))
    if not account_id:
        raise ValueError(
            "checkout.session.completed has no client_reference_id or "
            "metadata.account_id — cannot determine which account to credit")

    amount_total_cents = session.get("amount_total")
    if amount_total_cents is None:
        raise ValueError("checkout.session.completed has no amount_total")
    amount_micros = cents_to_micros(amount_total_cents)

    event_id = event_dict["id"]
    try:
        await ledger.append_entry(
            "topup", account_id, amount_micros,
            reference=event_id,
            metadata={"stripe_session_id": session.get("id"),
                     "stripe_payment_intent": session.get("payment_intent")})
        return WebhookResult(handled=True, credited=True,
                             account_id=account_id, amount_micros=amount_micros)
    except DuplicateEntryError:
        return WebhookResult(handled=True, credited=False, duplicate=True,
                             account_id=account_id, amount_micros=amount_micros)
