"""
FederationLLMProvider — sits at the head of the LLM chain.

is_available() returns True only when:
  - federation_desire = ON
  - state == HEALTHY (recent successful check-in)
  - local LLM avg > prefer_federation_for_llm_avg_s threshold
  - the Federator has recommended a peer URL
  - the recommended peer is not ourselves
  - this query is NOT already a federated call (hop limit)

generate() POSTs the prompt to peer_url/api/ask with an
X-Federation-Hops: 1 header. The receiving realm reads this header and
runs its OWN /api/ask handler with allow_federation=False — so it
processes the prompt locally and doesn't try to re-federate.

The latency of the federated call naturally feeds back into THIS
realm's rolling LLM_avg_s metric (because the orchestrator records
the elapsed time of the LLM call regardless of which provider answered).
That creates the self-balancing loop: while we're federating, our avg
includes the slower federated calls; when our local LLM recovers, our
avg drops below the threshold and we resume serving locally.

Per-call allow_federation override: the LLMChain.generate() signature
gains a `allow_federation: bool = True` argument. The /api/ask endpoint
sets it to False when the inbound request has X-Federation-Hops >= 1.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Optional

import aiohttp

from realm.federation import FederationState

logger = logging.getLogger(__name__)


class FederationLLMProvider:
    """Implements the realm.engine_chain.LLMProvider contract.

    Note: we don't inherit from LLMProvider explicitly because it lives
    in realm.engine_chain and importing creates a circular dependency
    with our injection point. Python's duck typing makes this fine —
    LLMChain only requires `name`, `is_available()`, `generate()`.
    """
    name: str = "Federation (peer realms)"

    def __init__(self, state: FederationState,
                 chain=None,
                 on_local_recovery=None,
                 degraded_tracker=None):
        self.state = state
        # Injected lazily so we can probe the local LLM right before
        # firing the federation call. The chain reference is set by
        # the app at startup AFTER the chain is built (avoiding the
        # circular import that would happen if we typed it).
        self._chain = chain
        # Callback fired when the pre-flight probe finds local LLM
        # responding after we thought it was busy/dead. Signature:
        #   on_local_recovery(local_provider_name: str) -> Awaitable
        # Used to clear the rolling AI window, flip availability flag,
        # and broadcast the cockpit badge update.
        self._on_local_recovery = on_local_recovery
        # DegradedTracker (realm.degraded_tracker.DegradedTracker) —
        # wall-clock watchdog. When is_degraded() returns True, we
        # REFUSE to federate, returning None from generate so the
        # LLMChain falls through to Echo. Without this, a dead-local
        # realm would federate forever and the operator would never
        # know. See realm/degraded_tracker.py for full design rationale.
        self._degraded_tracker = degraded_tracker
        # last_usage uses the same shape as other providers so metrics
        # work uniformly
        self.last_usage: Optional[dict] = None

    def attach(self, chain, on_local_recovery, degraded_tracker=None):
        """Late-binds chain reference, recovery callback, and degraded
        tracker. Called by the app at startup once all three are
        constructed. Lets us decouple the provider's __init__ from the
        chain it lives inside. degraded_tracker is optional for backward
        compat with code paths that don't use the watchdog (tests)."""
        self._chain = chain
        self._on_local_recovery = on_local_recovery
        if degraded_tracker is not None:
            self._degraded_tracker = degraded_tracker

    def should_federate(self, local_llm_avg_s: float,
                        allow_federation: bool) -> bool:
        """Pure-logic gate (separately testable). Returns True if the
        federation provider should handle this request."""
        cfg = self.state.cfg
        if not allow_federation:
            return False                          # hop limit
        if not cfg.desire:
            return False                          # operator opted out
        if self.state.member_state != "HEALTHY":
            return False                          # we can't reach Federator
        # Degraded watchdog: if local has been unhealthy for too long,
        # REFUSE to federate. This forces the chain to fall through to
        # Echo, which makes the operator notice (instead of silently
        # federating forever and never knowing local is broken).
        if (self._degraded_tracker is not None
            and self._degraded_tracker.is_degraded()):
            return False
        if local_llm_avg_s < cfg.prefer_federation_for_llm_avg_s:
            return False                          # local is fast enough
        peer = self.state.best_llm_peer
        if not peer:
            return False                          # no peer to send to
        if peer.rstrip("/") == cfg.self_url.rstrip("/"):
            return False                          # don't federate to self
        return True

    async def is_available(self) -> bool:
        """Asked by LLMChain.generate() before trying this provider.

        We read the current local LLM avg from the FederationState's
        get_stats callable. Note that generate() itself re-checks the
        gate to handle the case where state changed between is_available
        and generate (rare but possible)."""
        stats = self.state.get_stats()
        local_avg = float(stats.get("llm_avg_s", 0.0))
        # is_available is called WITHOUT knowing the allow_federation
        # value — we assume True here; generate() does the final check
        # with the real value.
        return self.should_federate(local_avg, allow_federation=True)

    async def generate(self, prompt: str, max_tokens: int = 400,
                       allow_federation: bool = True) -> Optional[str]:
        """Federate the prompt to the recommended peer.

        Returns the answer text on success; None on any failure so the
        LLMChain falls through to the next provider (local GPT4All)."""
        stats = self.state.get_stats()
        local_avg = float(stats.get("llm_avg_s", 0.0))
        if not self.should_federate(local_avg, allow_federation):
            return None
        peer = self.state.best_llm_peer
        if not peer:
            return None
        # ── PRE-FLIGHT LOCAL PROBE ───────────────────────────────
        # Before committing to a federated call, give local LLM ONE
        # MORE chance. The threshold gate said local was slow (avg
        # elevated) — but recent federated calls themselves drove the
        # avg up, so local might actually be fine right now. A cheap
        # is_available() probe against the FIRST local LLM provider
        # tells us.
        #
        # On probe SUCCESS: clear the stale rolling avg, mark local
        # as available, fire an immediate Federator check-in so peer
        # advice updates, broadcast the cockpit badge flash, and
        # return None so the chain falls through to local.
        #
        # On probe FAILURE: proceed with the federated call as planned.
        if self._chain is not None:
            local_provider = await self._chain.probe_local()
            if local_provider is not None:
                logger.info(
                    "Federation HEAD: pre-flight probe found local %s "
                    "responding; disregarding peer hint %s and serving "
                    "locally",
                    local_provider.name, peer)
                # Clear the degraded watchdog FIRST — recovery hook may
                # depend on the tracker being clear (e.g., to fire its
                # own bus_status_update with the right flag value).
                if self._degraded_tracker is not None:
                    self._degraded_tracker.mark_local_recovered()
                if self._on_local_recovery is not None:
                    try:
                        await self._on_local_recovery(local_provider.name)
                    except Exception as e:
                        # Recovery callback failures must NOT block the
                        # query — log and continue. The query will still
                        # serve via the next chain provider.
                        logger.warning(
                            "Federation HEAD: recovery callback raised: %s",
                            e)
                return None
        url = peer.rstrip("/") + "/api/ask"
        headers = {
            "Content-Type": "application/json",
            # Hop limit: this header tells the receiver "don't re-federate
            # me; just run locally." Cooperative protocol — both ends
            # honor it. A misbehaving peer can still try to re-federate
            # but its OWN federation provider checks allow_federation
            # from the inbound /api/ask handler and refuses.
            "X-Federation-Hops": "1",
        }
        if self.state.cfg.token:
            headers["X-Federation-Token"] = self.state.cfg.token
        # Forward max_tokens so peer doesnt silently truncate at its
        # chain default. Without this, every long federated answer was
        # cut off at 400 tokens mid-sentence (the I Love Lucy bug).
        body = {"text": prompt, "max_tokens": max_tokens}
        timeout = aiohttp.ClientTimeout(total=self.state.cfg.request_timeout_s)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.post(url, json=body, headers=headers) as r:
                    if r.status != 200:
                        logger.info(
                            "Federation: peer %s returned HTTP %d; "
                            "falling back to local",
                            peer, r.status)
                        return None
                    data = await r.json()
                    answer = data.get("answer", "")
                    if not answer:
                        return None
                    # Record approximate usage (no token counts from /api/ask)
                    self.last_usage = {
                        "tokens_out": _approx_tokens(answer),
                        "tokens_in": _approx_tokens(prompt),
                        "approx": True,
                        "federated_to": peer,
                    }
                    # Tell the degraded watchdog we just served a query
                    # via federation. The tracker starts its wall-clock
                    # on the first such call and flips to degraded after
                    # the configured threshold of continuous federation.
                    if self._degraded_tracker is not None:
                        self._degraded_tracker.mark_federated()
                    logger.info("Federation: served by peer %s (%d chars)",
                                peer, len(answer))
                    return answer
        except asyncio.TimeoutError:
            logger.info(
                "Federation: peer %s timed out after %.1fs; falling back",
                peer, self.state.cfg.request_timeout_s)
            return None
        except Exception as e:
            logger.info("Federation: peer %s call failed: %s", peer, e)
            return None


def _approx_tokens(s: str) -> int:
    """Cheap token approximation — same as engine_chain's helper.
    A token is roughly 4 chars for English; this is good enough for
    cockpit metrics (not for billing)."""
    return max(1, len(s) // 4)


class FederationLLMFallbackProvider:
    """The TAIL of the LLM chain. Sits between the local providers
    (GPT4All, Claude, HuggingFace) and the Echo floor.

    Different from FederationLLMProvider (the HEAD) in one key way:
    no threshold check. The head provider fires on local SLOW (overflow);
    this provider fires on local DEAD (rescue). It gets a chance only
    if every preceding provider returned None from generate() — i.e.,
    the local LLM stack failed entirely. When it fires, the user gets
    a real answer from a peer instead of the "no LLM online" message
    from Echo.

    Self-healing: when the local LLM recovers, GPT4All's generate()
    starts succeeding again, the chain never reaches this provider,
    and routing returns to local automatically. No supervisor needed.

    Honors the same hop limit as the head provider — federated calls
    arriving here with X-Federation-Hops: 1 have allow_federation=False
    so we DON'T re-federate them. The receiver answers with Echo if
    its OWN local stack is also dead.
    """
    name: str = "Federation Fallback (peer realms)"

    def __init__(self, state: FederationState,
                 chain=None,
                 on_local_recovery=None,
                 degraded_tracker=None):
        self.state = state
        # Same late-binding pattern as the head provider — chain and
        # recovery callback are attached after the chain is built.
        self._chain = chain
        self._on_local_recovery = on_local_recovery
        # DegradedTracker — see FederationLLMProvider docstring for the
        # full design rationale. Both head and fallback consult the same
        # tracker so the wall-clock spans BOTH overflow (head) and rescue
        # (fallback) federation. A realm cycling between slow-local
        # (head) and dead-local (fallback) is still degraded if it never
        # reaches a healthy state.
        self._degraded_tracker = degraded_tracker
        self.last_usage: Optional[dict] = None

    def attach(self, chain, on_local_recovery, degraded_tracker=None):
        """Late-binds chain reference, recovery callback, and degraded
        tracker. See the head provider's attach() for the rationale."""
        self._chain = chain
        self._on_local_recovery = on_local_recovery
        if degraded_tracker is not None:
            self._degraded_tracker = degraded_tracker

    def should_federate(self, allow_federation: bool) -> bool:
        """Pure-logic gate (separately testable). Unlike the head
        provider, no avg-vs-threshold check — we're a fallback, not
        an overflow."""
        cfg = self.state.cfg
        if not allow_federation:
            return False                          # hop limit
        if not cfg.desire:
            return False                          # operator opted out
        if self.state.member_state != "HEALTHY":
            return False                          # we can't reach Federator
        # Degraded watchdog: same gate as the head. When local has been
        # federated-only for too long, we stop entirely and let the
        # chain fall to Echo. Operator sees the degraded badge and
        # knows to fix local.
        if (self._degraded_tracker is not None
            and self._degraded_tracker.is_degraded()):
            return False
        peer = self.state.best_llm_peer
        if not peer:
            return False                          # no peer to send to
        if peer.rstrip("/") == cfg.self_url.rstrip("/"):
            return False                          # don't federate to self
        return True

    async def is_available(self) -> bool:
        """We're available whenever federation is healthy and a peer
        exists. The chain will only reach us if earlier providers
        failed (returned None from generate()), so being "available"
        here doesn't mean we always fire — it means we'll catch the
        chain when local LLM dies."""
        return self.should_federate(allow_federation=True)

    async def generate(self, prompt: str, max_tokens: int = 400,
                       allow_federation: bool = True) -> Optional[str]:
        """Federate the prompt to the recommended peer. Same wire format
        as FederationLLMProvider — POST to peer/api/ask with
        X-Federation-Hops: 1. Returns None on any failure so the chain
        falls through to Echo (the absolute floor)."""
        if not self.should_federate(allow_federation):
            return None
        peer = self.state.best_llm_peer
        if not peer:
            return None
        # ── PRE-FLIGHT LOCAL PROBE (same as head provider) ───────
        # We reached the TAIL of the chain, meaning every local LLM
        # provider's is_available() returned False. But it's possible
        # local just came back between the start of the chain walk
        # and now. Probe once more right before federating. On success,
        # let the chain re-walk and find the now-available local.
        #
        # Note: returning None here causes the LLMChain.generate() loop
        # to move to the next provider (Echo). The chain doesn't re-walk
        # from the head. So the actual benefit of probing at the tail
        # is the recovery side effect — the callback flips state, clears
        # the rolling avg, and fires a Federator check-in so subsequent
        # queries route correctly. THIS query still falls to Echo.
        #
        # (To avoid Echo answering, the head provider's probe is the
        # one that matters most. The tail probe is belt-and-suspenders.)
        if self._chain is not None:
            local_provider = await self._chain.probe_local()
            if local_provider is not None:
                logger.info(
                    "Federation FALLBACK: pre-flight probe found local %s "
                    "responding; disregarding peer hint %s",
                    local_provider.name, peer)
                if self._degraded_tracker is not None:
                    self._degraded_tracker.mark_local_recovered()
                if self._on_local_recovery is not None:
                    try:
                        await self._on_local_recovery(local_provider.name)
                    except Exception as e:
                        logger.warning(
                            "Federation FALLBACK: recovery callback "
                            "raised: %s", e)
                return None
        url = peer.rstrip("/") + "/api/ask"
        headers = {
            "Content-Type": "application/json",
            "X-Federation-Hops": "1",
        }
        if self.state.cfg.token:
            headers["X-Federation-Token"] = self.state.cfg.token
        # Forward max_tokens so peer doesnt silently truncate at its
        # chain default. Without this, every long federated answer was
        # cut off at 400 tokens mid-sentence (the I Love Lucy bug).
        body = {"text": prompt, "max_tokens": max_tokens}
        timeout = aiohttp.ClientTimeout(total=self.state.cfg.request_timeout_s)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.post(url, json=body, headers=headers) as r:
                    if r.status != 200:
                        logger.info(
                            "Federation fallback: peer %s returned HTTP %d; "
                            "falling through to Echo",
                            peer, r.status)
                        return None
                    data = await r.json()
                    answer = data.get("answer", "")
                    if not answer:
                        return None
                    self.last_usage = {
                        "tokens_out": _approx_tokens(answer),
                        "tokens_in": _approx_tokens(prompt),
                        "approx": True,
                        "federated_to": peer,
                        "fallback": True,         # distinguish from overflow
                    }
                    # Tell the degraded watchdog we just rescued a query
                    # via the fallback path. Same wall-clock as the head;
                    # the tracker doesn't distinguish overflow vs rescue.
                    if self._degraded_tracker is not None:
                        self._degraded_tracker.mark_federated()
                    logger.info(
                        "Federation fallback: served by peer %s (%d chars) "
                        "— local LLM unavailable",
                        peer, len(answer))
                    return answer
        except asyncio.TimeoutError:
            logger.info(
                "Federation fallback: peer %s timed out after %.1fs; "
                "falling through to Echo",
                peer, self.state.cfg.request_timeout_s)
            return None
        except Exception as e:
            logger.info(
                "Federation fallback: peer %s call failed: %s; "
                "falling through to Echo",
                peer, e)
            return None


class FederationConscriptionProvider:
    """Sprint 9 — the CONSUMING side of conscription, extended for
    multiple simultaneous donors. Sits after FederationLLMFallbackProvider
    in the LLM chain: ordinary federation (HEAD, then local providers,
    then FALLBACK) is tried first, since best_peer_for("llm", ...)
    already finds the genuinely best chat-capable peer when one exists.
    This provider only matters when THAT wasn't enough — no healthy
    native chat peer existed at all, which is exactly the scenario the
    Federator's conscription decision engine (Sprint 8) exists to help
    with.

    Multi-donor: state.conscriptions is a LIST of contracts (the
    Federator can assign more than one donor to the same rank when
    demand persists — see FederationMatrix.maybe_assign_conscription).
    This provider tries them IN ORDER, falling through to the next
    donor on any failure (timeout, non-200, empty answer) before
    finally giving up to Echo — same "walk the list, fall through on
    failure" shape as every other chain in this codebase.

    IMPORTANT correctness note: contract dicts carry an `expires_at`
    computed from the FEDERATOR's own time.monotonic() clock. This
    provider does NOT compare that value against ITS OWN clock —
    time.monotonic() is per-process and NOT meaningfully comparable
    across two different machines/processes. Instead, this provider
    simply trusts whatever `state.conscriptions` the MOST RECENT
    check-in response set (see FederationClient._on_checkin_ok). If the
    Federator considers a contract expired, the next check-in (≤15s
    later) naturally returns a fresh list without it, and this provider
    picks that up. No independent expiry math happens here — that
    would be actively wrong, not just redundant.
    """
    name: str = "Federation Conscription (moonlighting peer)"

    def __init__(self, state: FederationState,
                 chain=None,
                 on_local_recovery=None,
                 degraded_tracker=None):
        self.state = state
        self._chain = chain
        self._on_local_recovery = on_local_recovery
        self._degraded_tracker = degraded_tracker
        self.last_usage: Optional[dict] = None

    def attach(self, chain, on_local_recovery, degraded_tracker=None):
        """Same late-binding pattern as the other two providers."""
        self._chain = chain
        self._on_local_recovery = on_local_recovery
        if degraded_tracker is not None:
            self._degraded_tracker = degraded_tracker

    def _usable_contracts(self) -> list:
        """The 'chat'-rank contracts this provider is allowed to use
        right now, filtered by the same pure-logic checks
        should_federate always applied — hop limit, operator opt-out,
        Federator reachability, degraded tracker, and never routing to
        self. Returns them in the order the Federator provided (the
        Federator's own ordering — typically assignment order)."""
        cfg = self.state.cfg
        contracts = self.state.conscriptions or []
        usable = []
        for contract in contracts:
            if contract.get("conscripted_as") != "chat":
                continue
            peer = contract.get("peer_url")
            if not peer:
                continue
            if peer.rstrip("/") == cfg.self_url.rstrip("/"):
                continue                              # don't federate to self
            usable.append(contract)
        return usable

    def should_federate(self, allow_federation: bool) -> bool:
        """Pure-logic gate. Unlike the head provider, no avg-vs-threshold
        check — like the fallback provider, we're a rescue path, not an
        overflow decision we make ourselves (the Federator already
        decided demand was high enough to warrant a contract at all)."""
        cfg = self.state.cfg
        if not allow_federation:
            return False                          # hop limit
        if not cfg.desire:
            return False                          # operator opted out
        if self.state.member_state != "HEALTHY":
            return False                          # can't reach Federator
        if (self._degraded_tracker is not None
            and self._degraded_tracker.is_degraded()):
            return False
        return len(self._usable_contracts()) > 0

    async def is_available(self) -> bool:
        return self.should_federate(allow_federation=True)

    async def _submit_conscription_claim(self, donor_url: str) -> None:
        """Sprint 14 — submits THIS realm's (the requester's) claim
        about a piece of conscripted work to the Federator, so it can
        be reconciled against the donor's own independent claim. See
        realm/donor_payout.py's module docstring for why bilateral
        confirmation matters here specifically (unlike most of this
        codebase's self-reported metrics, a claim like this is directly
        profitable to lie about).

        Deliberately swallows every failure — a Federator that's down,
        a network hiccup, a missing master_url — none of that should
        ever propagate back into the caller's successful answer. Worst
        case: this donor doesn't get paid for this one request, which
        is a real but bounded cost, versus breaking a chat response
        that already succeeded."""
        cfg = self.state.cfg
        if not cfg.master_url or not cfg.self_url:
            return
        url = cfg.master_url.rstrip("/") + "/conscription-claim"
        headers = {"Content-Type": "application/json"}
        if cfg.token:
            headers["X-Federation-Token"] = cfg.token
        body = {
            "role": "requester",
            "donor_url": donor_url,
            "requester_url": cfg.self_url,
            "rank": "chat",
        }
        try:
            timeout = aiohttp.ClientTimeout(total=10.0)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.post(url, json=body, headers=headers) as r:
                    if r.status != 200:
                        logger.info(
                            "Federation conscription: claim submission "
                            "to %s returned HTTP %d (non-fatal)", url, r.status)
        except Exception as e:
            logger.info(
                "Federation conscription: claim submission to %s "
                "failed: %s (non-fatal — this donor simply won't be "
                "credited for this one request)", url, e)

    async def _try_one_donor(self, contract: dict, prompt: str,
                             max_tokens: int) -> Optional[str]:
        """One donor attempt. Returns the answer text on success, None
        on any failure (caller moves on to the next donor in the list).
        Extracted from generate() so trying multiple donors doesn't
        duplicate the request-building/error-handling logic per donor."""
        peer = contract["peer_url"]
        url = peer.rstrip("/") + "/api/ask"
        headers = {
            "Content-Type": "application/json",
            "X-Federation-Hops": "1",
            # Diagnostic only. The receiver's /api/ask handler doesn't
            # read this; it's purely so a donor operator scanning their
            # own logs can tell "this request landed on me because of
            # conscription" apart from ordinary federation traffic.
            "X-Federation-Conscripted": "1",
            # Sprint 14: NOT diagnostic-only — the donor's own claim
            # submission (bilateral confirmation, see
            # realm/donor_payout.py) needs to know WHO to attribute the
            # work to. Without this, the donor would have no way to
            # identify the requester at all.
            "X-Federation-Requester-Url": self.state.cfg.self_url,
        }
        if self.state.cfg.token:
            headers["X-Federation-Token"] = self.state.cfg.token
        body = {"text": prompt, "max_tokens": max_tokens}
        timeout = aiohttp.ClientTimeout(total=self.state.cfg.request_timeout_s)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.post(url, json=body, headers=headers) as r:
                    if r.status != 200:
                        logger.info(
                            "Federation conscription: donor %s returned "
                            "HTTP %d; trying next donor if any",
                            peer, r.status)
                        return None
                    data = await r.json()
                    answer = data.get("answer", "")
                    if not answer:
                        return None
                    self.last_usage = {
                        "tokens_out": _approx_tokens(answer),
                        "tokens_in": _approx_tokens(prompt),
                        "approx": True,
                        "federated_to": peer,
                        "conscripted": True,     # distinguish in metrics/logs
                    }
                    if self._degraded_tracker is not None:
                        self._degraded_tracker.mark_federated()
                    logger.info(
                        "Federation conscription: served by moonlighting "
                        "donor %s (native role: %s, %d chars)",
                        peer, contract.get("native_role", "?"), len(answer))
                    # Sprint 14: bilateral confirmation — the REQUESTER
                    # side of the claim. Fire-and-forget: a claim
                    # submission failure must NEVER cause the answer we
                    # just successfully got to be discarded or delayed
                    # — the user already has their response, this is
                    # pure bookkeeping for a later payout, not part of
                    # the request/response path itself.
                    await self._submit_conscription_claim(peer)
                    return answer
        except asyncio.TimeoutError:
            logger.info(
                "Federation conscription: donor %s timed out after "
                "%.1fs; trying next donor if any",
                peer, self.state.cfg.request_timeout_s)
            return None
        except Exception as e:
            logger.info(
                "Federation conscription: donor %s call failed: %s; "
                "trying next donor if any",
                peer, e)
            return None

    async def generate(self, prompt: str, max_tokens: int = 400,
                       allow_federation: bool = True) -> Optional[str]:
        """Route to the conscripted donor(s). Same wire format as
        ordinary federation (POST to peer/api/ask, same hop-limit
        header) — the receiving realm's /api/ask handler needs no
        special-casing for conscripted requests; it just answers
        locally like any other federated call.

        Multi-donor: tries each usable contract in order, falling
        through to the next on any failure. Only returns None (letting
        the chain fall through to Echo) once EVERY usable donor has
        failed."""
        if not self.should_federate(allow_federation):
            return None
        # ── PRE-FLIGHT LOCAL PROBE (same as the other two providers) ──
        # Checked ONCE, not per-donor — if local has recovered, there's
        # no reason to try any conscripted donor at all.
        if self._chain is not None:
            local_provider = await self._chain.probe_local()
            if local_provider is not None:
                logger.info(
                    "Federation CONSCRIPTION: pre-flight probe found "
                    "local %s responding; disregarding conscripted "
                    "donor(s) and serving locally",
                    local_provider.name)
                if self._degraded_tracker is not None:
                    self._degraded_tracker.mark_local_recovered()
                if self._on_local_recovery is not None:
                    try:
                        await self._on_local_recovery(local_provider.name)
                    except Exception as e:
                        logger.warning(
                            "Federation CONSCRIPTION: recovery callback "
                            "raised: %s", e)
                return None
        for contract in self._usable_contracts():
            result = await self._try_one_donor(contract, prompt, max_tokens)
            if result is not None:
                return result
        return None   # every usable donor failed; fall through to Echo
