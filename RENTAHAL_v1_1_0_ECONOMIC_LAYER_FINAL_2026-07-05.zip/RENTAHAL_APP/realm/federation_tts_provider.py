"""
federation_tts_provider.py — Federation TTS providers (head + tail).

Parallel structure to federation_provider.py for LLM:
  - FederationTTSProvider:        head of TTS chain, overflow gate
  - FederationTTSFallbackProvider: tail of TTS chain, rescue gate

Both POST to peer_realm_url/api/speak with X-Federation-Hops: 1.
The receiving realm's /api/speak handler synthesizes locally and
returns audio (base64-encoded WAV/MP3) in JSON.

Hop limit prevents cascades — when a federated /api/speak request
arrives, the receiver synthesizes WITHOUT trying to re-federate.

Pre-flight probe: same as the LLM federation providers — before
committing to a federated synth, probe the local TTS chain. If local
is responding, disregard the peer hint, run recovery callback (clears
rolling TTS window + sets local_tts_available=True + fires immediate
Federator check-in + broadcasts cockpit badge update), and return None
so the TTS chain falls through to local.

Self-healing: when local TTS recovers between rescue and the next call,
the probe finds it and federation steps aside. No supervisor.
"""
from __future__ import annotations

import asyncio
import base64
import logging
from typing import Optional

import aiohttp

from realm.federation import FederationState

logger = logging.getLogger(__name__)


class FederationTTSProvider:
    """Head of the TTS chain. Implements the realm.engine_chain.TTSProvider
    contract via duck typing."""
    name: str = "Federation TTS (peer realms)"

    def __init__(self, state: FederationState,
                 chain=None, on_local_recovery=None,
                 degraded_tracker=None):
        self.state = state
        self._chain = chain
        # Callback fired when pre-flight probe finds local TTS responding.
        # Signature: on_local_recovery(local_provider_name: str) -> Awaitable
        self._on_local_recovery = on_local_recovery
        # DegradedTracker for TTS — INDEPENDENT from the LLM tracker.
        # TTS and LLM chains fail independently (GPT4All can crash while
        # Kokoro is fine, and vice versa). Each chain has its own watchdog
        # and its own degraded badge in the cockpit.
        self._degraded_tracker = degraded_tracker

    def attach(self, chain, on_local_recovery, degraded_tracker=None):
        self._chain = chain
        self._on_local_recovery = on_local_recovery
        if degraded_tracker is not None:
            self._degraded_tracker = degraded_tracker

    def should_federate(self, local_tts_avg_s: float,
                        allow_federation: bool) -> bool:
        """Same gate semantics as LLM head provider — fires when local
        TTS is SLOW (avg above threshold), not when it's dead."""
        cfg = self.state.cfg
        if not allow_federation:
            return False                          # hop limit
        if not cfg.desire:
            return False                          # operator opted out
        if self.state.member_state != "HEALTHY":
            return False                          # can't reach Federator
        # Degraded watchdog: refuse to federate when TTS has been
        # federated-only for too long. Forces fall-through to pyttsx3
        # so operator notices and can fix local Kokoro.
        if (self._degraded_tracker is not None
            and self._degraded_tracker.is_degraded()):
            return False
        if local_tts_avg_s < cfg.prefer_federation_for_tts_avg_s:
            return False                          # local is fast enough
        peer = self.state.best_tts_peer
        if not peer:
            return False                          # no peer to send to
        if peer.rstrip("/") == cfg.self_url.rstrip("/"):
            return False                          # don't federate to self
        return True

    async def is_available(self) -> bool:
        stats = self.state.get_stats()
        local_avg = float(stats.get("tts_avg_s", 0.0))
        return self.should_federate(local_avg, allow_federation=True)

    async def synth(self, text: str,
                    allow_federation: bool = True) -> Optional[str]:
        """Synthesize via the recommended TTS peer. Returns base64 audio
        on success, None on any failure (chain falls through to local TTS).
        """
        stats = self.state.get_stats()
        local_avg = float(stats.get("tts_avg_s", 0.0))
        if not self.should_federate(local_avg, allow_federation):
            return None
        peer = self.state.best_tts_peer
        if not peer:
            return None
        # Pre-flight probe — give local TTS a second chance before
        # firing the federated call. Same rationale as LLM head provider.
        if self._chain is not None:
            local_provider = await self._chain.probe_local()
            if local_provider is not None:
                logger.info(
                    "Federation TTS HEAD: pre-flight probe found local %s "
                    "responding; disregarding peer hint %s and synthing "
                    "locally", local_provider.name, peer)
                if self._degraded_tracker is not None:
                    self._degraded_tracker.mark_local_recovered()
                if self._on_local_recovery is not None:
                    try:
                        await self._on_local_recovery(local_provider.name)
                    except Exception as e:
                        logger.warning(
                            "Federation TTS HEAD: recovery callback "
                            "raised: %s", e)
                return None
        result = await _do_federated_synth(self.state, text, peer)
        # Mark federated only on SUCCESS (None means call failed and chain
        # will fall through; we don't want to count failed federation
        # attempts toward the degraded watchdog).
        if result is not None and self._degraded_tracker is not None:
            self._degraded_tracker.mark_federated()
        return result


class FederationTTSFallbackProvider:
    """Tail of the TTS chain. Fires when all local TTS providers failed.
    No threshold check — rescue, not overflow."""
    name: str = "Federation TTS Fallback (peer realms)"

    def __init__(self, state: FederationState,
                 chain=None, on_local_recovery=None,
                 degraded_tracker=None):
        self.state = state
        self._chain = chain
        self._on_local_recovery = on_local_recovery
        # Same tracker instance as head — both share one TTS watchdog.
        self._degraded_tracker = degraded_tracker

    def attach(self, chain, on_local_recovery, degraded_tracker=None):
        self._chain = chain
        self._on_local_recovery = on_local_recovery
        if degraded_tracker is not None:
            self._degraded_tracker = degraded_tracker

    def should_federate(self, allow_federation: bool) -> bool:
        """No threshold check — chain reaching us implies all local
        TTS providers failed."""
        cfg = self.state.cfg
        if not allow_federation:
            return False                          # hop limit
        if not cfg.desire:
            return False
        if self.state.member_state != "HEALTHY":
            return False
        # Degraded watchdog gate — same as head.
        if (self._degraded_tracker is not None
            and self._degraded_tracker.is_degraded()):
            return False
        peer = self.state.best_tts_peer
        if not peer:
            return False
        if peer.rstrip("/") == cfg.self_url.rstrip("/"):
            return False
        return True

    async def is_available(self) -> bool:
        return self.should_federate(allow_federation=True)

    async def synth(self, text: str,
                    allow_federation: bool = True) -> Optional[str]:
        if not self.should_federate(allow_federation):
            return None
        peer = self.state.best_tts_peer
        if not peer:
            return None
        # Pre-flight probe — same as LLM fallback. Belt-and-suspenders:
        # the actual benefit is the side effect (recovery callback fires,
        # clearing stale state). THIS query still falls through to the
        # next provider in the chain because we return None.
        if self._chain is not None:
            local_provider = await self._chain.probe_local()
            if local_provider is not None:
                logger.info(
                    "Federation TTS FALLBACK: probe found local %s "
                    "responding; disregarding peer hint %s",
                    local_provider.name, peer)
                if self._degraded_tracker is not None:
                    self._degraded_tracker.mark_local_recovered()
                if self._on_local_recovery is not None:
                    try:
                        await self._on_local_recovery(local_provider.name)
                    except Exception as e:
                        logger.warning(
                            "Federation TTS FALLBACK: recovery callback "
                            "raised: %s", e)
                return None
        result = await _do_federated_synth(self.state, text, peer)
        if result is not None and self._degraded_tracker is not None:
            self._degraded_tracker.mark_federated()
        return result


async def _do_federated_synth(state: FederationState, text: str,
                              peer: str) -> Optional[str]:
    """Shared HTTP call logic for both TTS federation providers.
    POSTs to peer/api/speak with X-Federation-Hops: 1 header.
    Receiver synthesizes locally and returns base64-encoded audio.

    Returns the base64 audio string on success, None on any failure
    (HTTP error, timeout, empty response). The TTS chain catches None
    and falls through to the next provider.
    """
    url = peer.rstrip("/") + "/api/speak"
    headers = {
        "Content-Type": "application/json",
        "X-Federation-Hops": "1",         # tell receiver: synth locally
    }
    if state.cfg.token:
        headers["X-Federation-Token"] = state.cfg.token
    body = {"text": text}
    timeout = aiohttp.ClientTimeout(total=state.cfg.request_timeout_s)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.post(url, json=body, headers=headers) as r:
                if r.status != 200:
                    logger.info(
                        "Federation TTS: peer %s returned HTTP %d; "
                        "falling back", peer, r.status)
                    return None
                data = await r.json()
                audio_b64 = data.get("audio_b64", "")
                if not audio_b64:
                    return None
                logger.info(
                    "Federation TTS: served by peer %s (%d audio bytes)",
                    peer, len(audio_b64))
                return audio_b64
    except asyncio.TimeoutError:
        logger.info(
            "Federation TTS: peer %s timed out after %.1fs; falling back",
            peer, state.cfg.request_timeout_s)
        return None
    except Exception as e:
        logger.info("Federation TTS: peer %s call failed: %s", peer, e)
        return None
