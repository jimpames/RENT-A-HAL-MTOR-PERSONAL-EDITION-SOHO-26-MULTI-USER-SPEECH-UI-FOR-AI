"""
realm/gate.py — Optional payment gate for RENT-A-HAL operators.

Lets an operator require visitors to pay N tokens of a chosen Solana SPL
token to the operator's wallet before accessing the instance. Once paid,
the realm issues a signed session cookie valid for the configured TTL.

This module is fully isolated from the rest of the realm:
  - When [Gate] enabled = false, none of this code activates
  - The verifier is a thin wrapper over Solana JSON-RPC
  - Replay protection is a bounded in-memory cache (TTL'd set)
  - Session tokens are HMAC-SHA256 signed, no third-party dep

Security model:
  - Browser-side gate page is UI only; the server is the source of truth
  - DevTools bypass on the gate page does NOTHING because the realm
    independently verifies on-chain payment before issuing the token
  - The session token is signed by the realm; can't be forged
  - Replay: same on-chain signature can't be used twice
  - Stale txs are rejected (only accept signatures from recent window)
  - The HMAC secret lives in [Gate] session_secret; regenerated if blank

Not in scope (out by design):
  - KYC/AML — operators are responsible for their own jurisdiction
  - Token economics (price, supply) — that's pump.fun and the market
  - Refunds — once paid, paid
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ───────────────────────── Errors ──────────────────────────


class GateError(Exception):
    """Base class for gate verification failures."""


class GateConfigError(GateError):
    """Misconfiguration (missing mint, missing wallet, etc)."""


class GateRpcError(GateError):
    """Solana RPC call failed (network, rate limit, etc)."""


class GateInvalidPayment(GateError):
    """On-chain transaction did not meet the payment requirements."""


# ─────────────────────── Replay cache ──────────────────────


class ReplayCache:
    """Bounded in-memory cache of seen transaction signatures with TTL.

    Used to reject payments that have already been redeemed for a session.
    When a signature has been used once, it stays in the cache for the
    configured window so it can't be reused — even if the underlying
    transaction is still on-chain and otherwise valid.

    Memory bounded: entries past their TTL are evicted on each call,
    AND the cache has a hard max size for catastrophic protection.
    """

    def __init__(self, ttl_seconds: int = 600, max_size: int = 10000):
        self._ttl = ttl_seconds
        self._max = max_size
        # signature → expiry_unix
        self._seen: Dict[str, float] = {}

    def has_seen(self, signature: str) -> bool:
        """Returns True if this signature was already redeemed within TTL."""
        self._evict_expired()
        return signature in self._seen

    def mark_seen(self, signature: str) -> None:
        """Record that this signature has been used. No-op if already there."""
        self._evict_expired()
        # Hard cap: if we somehow hit the max, drop the oldest 10% to recover
        if len(self._seen) >= self._max:
            # Sort by expiry, keep newest 90%
            keep = sorted(self._seen.items(), key=lambda x: x[1])[
                int(self._max * 0.1):
            ]
            self._seen = dict(keep)
        self._seen[signature] = time.time() + self._ttl

    def _evict_expired(self) -> None:
        now = time.time()
        # Iterate copy of items to allow deletion during loop
        for sig, exp in list(self._seen.items()):
            if exp < now:
                del self._seen[sig]

    def size(self) -> int:
        return len(self._seen)


# ─────────────────────── Session tokens ──────────────────────


@dataclass
class SessionToken:
    """A signed session token granting access through the gate.

    Encoded as base64-urlsafe(payload_json) + "." + base64-urlsafe(hmac).
    Compact, no third-party JWT lib needed, easy to inspect.
    """
    wallet: str
    issued_at: int      # unix seconds
    expires_at: int     # unix seconds
    operator_wallet: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "w": self.wallet,
            "iat": self.issued_at,
            "exp": self.expires_at,
            "op": self.operator_wallet,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "SessionToken":
        return cls(
            wallet=d["w"],
            issued_at=int(d["iat"]),
            expires_at=int(d["exp"]),
            operator_wallet=d["op"],
        )


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def sign_session_token(token: SessionToken, secret: str) -> str:
    """Returns a compact signed string: <payload>.<hmac>"""
    if not secret:
        raise GateConfigError("Gate session_secret is empty; refusing to sign")
    payload_bytes = json.dumps(
        token.to_dict(), separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    payload_b64 = _b64url_encode(payload_bytes)
    sig = hmac.new(
        secret.encode("utf-8"),
        payload_b64.encode("ascii"),
        hashlib.sha256,
    ).digest()
    sig_b64 = _b64url_encode(sig)
    return f"{payload_b64}.{sig_b64}"


def verify_session_token(
    token_string: str, secret: str, now_unix: Optional[int] = None
) -> Optional[SessionToken]:
    """Verifies a signed token. Returns the SessionToken on success, None on
    any failure (bad signature, expired, malformed). NEVER raises."""
    if not token_string or not secret:
        return None
    try:
        parts = token_string.split(".")
        if len(parts) != 2:
            return None
        payload_b64, sig_b64 = parts
        # Recompute the expected HMAC
        expected = hmac.new(
            secret.encode("utf-8"),
            payload_b64.encode("ascii"),
            hashlib.sha256,
        ).digest()
        actual = _b64url_decode(sig_b64)
        # Constant-time comparison
        if not hmac.compare_digest(expected, actual):
            return None
        # Decode payload
        payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
        tok = SessionToken.from_dict(payload)
        # Check expiry
        now = now_unix if now_unix is not None else int(time.time())
        if tok.expires_at <= now:
            return None
        return tok
    except Exception:
        return None


# ─────────────────── Solana RPC client (thin) ───────────────────


@dataclass
class TokenTransferDetails:
    """Extracted facts about an on-chain SPL token transfer."""
    signature: str
    from_wallet: str
    to_wallet: str
    mint: str
    amount_ui: float       # human-readable amount (after decimals)
    block_time: int        # unix seconds


class SolanaRpcClient:
    """Minimal Solana JSON-RPC client.

    We only need two methods:
      1. getMint to read the token's decimals at startup
      2. getTransaction(signature) to verify a specific payment

    Supports primary + fallback endpoints. If the primary returns a
    network error (NOT a logical 'tx not found'), we try the fallback.
    """

    def __init__(self, primary: str, fallback: Optional[str] = None,
                 timeout_s: float = 10.0):
        self.primary = primary.rstrip("/")
        self.fallback = fallback.rstrip("/") if fallback else None
        self.timeout = timeout_s

    async def _rpc(self, method: str, params: List[Any]) -> Dict[str, Any]:
        """POSTs a JSON-RPC request. Tries primary, then fallback on net error."""
        # Lazy import so import-time doesn't require aiohttp for module use
        import aiohttp
        body = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        }
        endpoints = [self.primary]
        if self.fallback:
            endpoints.append(self.fallback)
        last_err: Optional[Exception] = None
        for ep in endpoints:
            try:
                timeout = aiohttp.ClientTimeout(total=self.timeout)
                async with aiohttp.ClientSession(timeout=timeout) as sess:
                    async with sess.post(ep, json=body) as resp:
                        if resp.status != 200:
                            raise GateRpcError(
                                f"RPC {ep} returned status {resp.status}"
                            )
                        data = await resp.json()
                        if "error" in data:
                            # Logical RPC error — propagate, don't try fallback
                            return data
                        return data
            except (GateRpcError, asyncio.TimeoutError, Exception) as e:
                last_err = e
                logger.warning("RPC failed on %s: %s; trying next", ep, e)
                continue
        raise GateRpcError(f"All RPC endpoints failed: {last_err}")

    async def get_mint_decimals(self, mint: str) -> int:
        """Fetch the decimals field from the mint account. Cached by caller."""
        result = await self._rpc("getAccountInfo", [
            mint, {"encoding": "jsonParsed"}
        ])
        if "error" in result:
            raise GateRpcError(f"getAccountInfo failed: {result['error']}")
        try:
            info = result["result"]["value"]["data"]["parsed"]["info"]
            return int(info["decimals"])
        except (KeyError, TypeError) as e:
            raise GateRpcError(f"Could not parse mint decimals: {e}")

    async def get_transaction(self, signature: str) -> Optional[Dict[str, Any]]:
        """Fetch a transaction by signature. Returns the raw RPC result or
        None if the transaction is not found (could be too new, or fake)."""
        result = await self._rpc("getTransaction", [
            signature,
            {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0},
        ])
        if "error" in result:
            # Could be "tx not found" or actual error
            err_msg = str(result["error"])
            if "not found" in err_msg.lower():
                return None
            raise GateRpcError(f"getTransaction failed: {result['error']}")
        return result.get("result")


# ─────────────────── Payment verification ───────────────────


def extract_spl_transfer(
    tx: Dict[str, Any], expected_mint: str
) -> Optional[TokenTransferDetails]:
    """Scan a parsed Solana transaction for an SPL token transfer
    matching the expected mint. Returns the details of the first
    matching transfer found, or None if none found.

    The transaction format is documented at:
      https://docs.solana.com/api/http#gettransaction

    Parsed instructions for SPL token transfers look like:
      {"program": "spl-token",
       "parsed": {
         "type": "transferChecked" | "transfer",
         "info": {
           "source": "<account>",
           "destination": "<account>",
           "mint": "<mint>",          (transferChecked only)
           "tokenAmount": {           (transferChecked)
             "uiAmount": 10.0,
             "decimals": 6,
             ...
           },
           "amount": "10000000",      (transfer — raw amount, no decimals)
           "authority": "<wallet>"
         }}
      }
    """
    if not tx:
        return None
    try:
        msg = tx["transaction"]["message"]
        instructions = msg.get("instructions", [])
        # Also check inner instructions (some wallets wrap in compute budget)
        meta = tx.get("meta") or {}
        for inner_group in (meta.get("innerInstructions") or []):
            instructions = instructions + (inner_group.get("instructions") or [])

        # Token balances give the cleanest read of what changed
        # but we focus on the instruction-level transfer for explicit intent
        for inst in instructions:
            if not isinstance(inst, dict):
                continue
            if inst.get("program") != "spl-token":
                continue
            parsed = inst.get("parsed")
            if not isinstance(parsed, dict):
                continue
            ptype = parsed.get("type")
            if ptype not in ("transferChecked", "transfer"):
                continue
            info = parsed.get("info") or {}

            # Mint check — transferChecked includes it explicitly
            mint_in_tx = info.get("mint")
            if mint_in_tx and mint_in_tx != expected_mint:
                continue

            # Pull the source/destination/amount
            source = info.get("source") or ""
            destination = info.get("destination") or ""
            authority = info.get("authority") or ""

            # For transferChecked, prefer uiAmount from tokenAmount
            ui_amount: Optional[float] = None
            ta = info.get("tokenAmount")
            if isinstance(ta, dict) and "uiAmount" in ta:
                ui_amount = float(ta["uiAmount"] or 0)
            else:
                # Fallback to amount + need to know decimals separately
                # (the caller will handle conversion; we leave as None)
                pass

            if not source or not destination or ui_amount is None:
                continue

            return TokenTransferDetails(
                signature=tx.get("transaction", {}).get("signatures", [""])[0],
                from_wallet=authority or source,
                to_wallet=destination,
                mint=expected_mint,
                amount_ui=ui_amount,
                block_time=int(tx.get("blockTime") or 0),
            )
    except (KeyError, TypeError, ValueError) as e:
        logger.warning("Could not parse transaction: %s", e)
        return None
    return None


def validate_token_balance_owner(
    tx: Dict[str, Any],
    from_wallet: str,
    to_wallet_token_accounts: List[str],
) -> bool:
    """Optional cross-check: confirm the destination token account
    is owned by the operator's wallet by looking at the postTokenBalances.

    Returns True if the destination has at least one of the expected
    owner accounts, False otherwise. We don't fail hard on this because
    parsed transferChecked already gives us 'destination' explicitly.
    """
    try:
        meta = tx.get("meta") or {}
        balances = meta.get("postTokenBalances") or []
        for b in balances:
            if b.get("owner") in to_wallet_token_accounts:
                return True
    except Exception:
        pass
    return False


# ─────────────────────── Top-level config ───────────────────────


@dataclass
class GateConfig:
    """All knobs for the gate, loaded from [Gate] section."""
    enabled: bool = False
    token_mint: str = ""
    operator_wallet: str = ""
    required_payment: float = 10.0
    session_duration_hours: int = 24
    rpc_primary: str = "https://api.mainnet-beta.solana.com"
    rpc_fallback: str = ""
    session_secret: str = ""
    replay_window_minutes: int = 10
    operator_display_name: str = ""

    @property
    def session_duration_s(self) -> int:
        return self.session_duration_hours * 3600

    @property
    def replay_window_s(self) -> int:
        return self.replay_window_minutes * 60

    def validate(self) -> None:
        """Raises GateConfigError if enabled but misconfigured."""
        if not self.enabled:
            return  # nothing to check
        if not self.token_mint:
            raise GateConfigError("[Gate] token_mint is empty")
        if not self.operator_wallet:
            raise GateConfigError("[Gate] operator_wallet is empty")
        if self.required_payment <= 0:
            raise GateConfigError(
                f"[Gate] required_payment must be > 0, got {self.required_payment}"
            )
        if self.session_duration_hours <= 0:
            raise GateConfigError(
                f"[Gate] session_duration_hours must be > 0"
            )
        if not self.session_secret:
            raise GateConfigError(
                "[Gate] session_secret is empty; generate one with "
                "`python -c \"import secrets; print(secrets.token_urlsafe(48))\"`"
            )
        if not self.rpc_primary:
            raise GateConfigError("[Gate] rpc_primary is empty")


def generate_session_secret() -> str:
    """Returns a fresh 48-byte url-safe secret for [Gate] session_secret."""
    return secrets.token_urlsafe(48)


# ─────────────────────── The verifier ───────────────────────


@dataclass
class VerifyResult:
    """The outcome of /gate/verify."""
    ok: bool
    reason: str = ""
    session_token: str = ""
    expires_at: int = 0


class GateVerifier:
    """Main entry point for verifying a payment and issuing a session.

    Wires together: config + RPC client + replay cache.

    Lifecycle:
      gv = GateVerifier(config)
      result = await gv.verify_payment(wallet="...", signature="...")
      if result.ok:
          set_cookie(result.session_token)
    """

    def __init__(
        self,
        config: GateConfig,
        rpc_client: Optional[SolanaRpcClient] = None,
        replay_cache: Optional[ReplayCache] = None,
        clock: Optional[callable] = None,
    ):
        self.config = config
        self.config.validate()  # raises if enabled-but-broken
        self._rpc = rpc_client or SolanaRpcClient(
            primary=config.rpc_primary,
            fallback=config.rpc_fallback or None,
        )
        self._replay = replay_cache or ReplayCache(
            ttl_seconds=max(config.replay_window_s * 2, 3600),
        )
        # Clock injection for tests
        self._now = clock or (lambda: int(time.time()))

    async def verify_payment(
        self, wallet: str, signature: str
    ) -> VerifyResult:
        """Verifies an on-chain payment and issues a session token.

        Steps:
          1. Replay check (signature seen recently?)
          2. Fetch transaction from RPC
          3. Extract SPL transfer matching our mint
          4. Validate: from_wallet matches, to_wallet matches operator,
             amount >= required, block_time within window
          5. Mark signature seen
          6. Mint session token

        Returns VerifyResult with ok=True and the token on success,
        ok=False and a human-readable reason on failure.

        Never raises — all errors come back as VerifyResult(ok=False).
        """
        if not self.config.enabled:
            return VerifyResult(ok=False, reason="gate not enabled")

        if not wallet or not signature:
            return VerifyResult(
                ok=False, reason="wallet and signature are required"
            )

        # Step 1: Replay check
        if self._replay.has_seen(signature):
            return VerifyResult(
                ok=False,
                reason="this transaction has already been used"
            )

        # Step 2: Fetch the transaction
        try:
            tx = await self._rpc.get_transaction(signature)
        except GateRpcError as e:
            logger.warning("RPC error during gate verify: %s", e)
            return VerifyResult(
                ok=False,
                reason="could not verify on-chain right now; please try again"
            )

        if tx is None:
            return VerifyResult(
                ok=False,
                reason="transaction not found on-chain (try again in a few "
                       "seconds — new transactions take a moment to confirm)"
            )

        # Step 3: Extract the SPL transfer
        transfer = extract_spl_transfer(tx, self.config.token_mint)
        if transfer is None:
            return VerifyResult(
                ok=False,
                reason=f"no SPL transfer of mint {self.config.token_mint[:8]}…"
                       " found in transaction"
            )

        # Step 4: Validate fields
        if transfer.from_wallet != wallet:
            return VerifyResult(
                ok=False,
                reason="transaction was not signed by the connected wallet"
            )
        if transfer.to_wallet != self.config.operator_wallet:
            # The "destination" in transferChecked is the token account,
            # not necessarily the operator wallet directly. We accept the
            # operator_wallet as either the wallet OR a known token account.
            # For maximum safety we ALSO accept owner-matches via postTokenBalances.
            if not validate_token_balance_owner(
                tx, wallet, [self.config.operator_wallet]
            ):
                return VerifyResult(
                    ok=False,
                    reason="payment was not sent to the operator's wallet"
                )
        if transfer.amount_ui < self.config.required_payment:
            return VerifyResult(
                ok=False,
                reason=f"payment of {transfer.amount_ui} is less than "
                       f"required {self.config.required_payment}"
            )

        # Recency check: must be within the replay window
        now = self._now()
        if transfer.block_time and now - transfer.block_time > self.config.replay_window_s:
            age = now - transfer.block_time
            return VerifyResult(
                ok=False,
                reason=f"transaction is too old ({age // 60} minutes); "
                       f"only payments from the last "
                       f"{self.config.replay_window_minutes} minutes are accepted"
            )

        # Step 5: Mark seen (so it can't be reused)
        self._replay.mark_seen(signature)

        # Step 6: Issue session token
        expires_at = now + self.config.session_duration_s
        token = SessionToken(
            wallet=wallet,
            issued_at=now,
            expires_at=expires_at,
            operator_wallet=self.config.operator_wallet,
        )
        signed = sign_session_token(token, self.config.session_secret)

        logger.info(
            "Gate: issued session token for wallet=%s (expires %d)",
            wallet[:8] + "…", expires_at
        )

        return VerifyResult(
            ok=True,
            session_token=signed,
            expires_at=expires_at,
        )

    def check_session(self, token_string: str) -> Optional[SessionToken]:
        """Validates a session token from a cookie. Returns the
        SessionToken on success, None on failure."""
        return verify_session_token(
            token_string, self.config.session_secret, now_unix=self._now()
        )
