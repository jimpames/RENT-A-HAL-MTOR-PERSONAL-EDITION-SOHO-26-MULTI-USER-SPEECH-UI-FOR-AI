"""
intent.py — algebraic intent classifier riding the event bus.

Subscribes to prompt_text, emits intent_classified (and the special-case
intent_stop / intent_repeat). All routing decisions are made HERE; no other
component looks at the prompt string.

Why "algebraic": intent is a function of (tokens, n_gram_scores, slots). The
scoring table is data, not code — adding a new intent is editing the table,
not editing the classifier. STOP/REPEAT use doubling (two adjacent matches
required) to prevent false triggers, exactly the way wake-word systems
prevent false wakes.

Slot extraction is the same pattern: each intent has a list of slot
extractors (regexes or token-window matchers); the matched values become
the typed payload that the orchestrator routes on.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .event_bus import EventBus, Event


# ---------------------------------------------------------------------------
# Intent vocabulary — pure data. Add a new intent by adding to this table.
# ---------------------------------------------------------------------------

# Doubled action words: must appear TWICE adjacently to fire. Prevents
# "I want to STOP for coffee" from killing TTS mid-sentence.
DOUBLED_ACTION_WORDS = {
    "stop": "intent_stop",
    "repeat": "intent_repeat",
    "cancel": "intent_stop",
    "again": "intent_repeat",
}

# Single-word intents (top-level realm switches after wake)
SINGLE_INTENTS = {
    "weather": "weather",
    "forecast": "weather",
    "gmail": "gmail",
    "email": "gmail",
    "mail": "gmail",
    "news": "news",
    "music": "music",
    # ROUNDUP: radio-station style auto-shuffle of NPR + Guardian.
    # Distinct from "news" which is interactive cards. "roundup" alone
    # is enough — it's a distinctive word with no other meaning in this
    # vocabulary.
    "roundup": "roundup",
    # IMAGINE: routes to the ImagineChain (Automatic1111 txt2img, Echo
    # rickroll floor). "draw" is a deliberate second trigger — it's the
    # natural verb pairing for "draw a kitten" — accepted knowing it
    # carries a small false-positive risk (e.g. "draw the curtains"),
    # same risk class as existing single words like "mail". "imagine"
    # alone has effectively zero collision risk in this vocabulary.
    "imagine": "imagine",
    "draw": "imagine",
}

# Multi-word intent triggers. Checked BEFORE SINGLE_INTENTS so phrases
# like "service finder" win over their constituent words. Each key is a
# normalized space-separated bigram or trigram appearing at the start
# of the input (after wake word stripping).
PHRASE_INTENTS = {
    "service finder": "service",
    "find a": "service",        # "find a haircut", "find a pharmacy"
    "find me": "service",       # "find me a barber"
    "find nearby": "service",   # "find nearby gas station"
    # ROUNDUP phrase variants — natural speech leads with these
    "news roundup": "roundup",  # "computer news roundup newline"
    "play roundup": "roundup",
    "start roundup": "roundup",
    "start the roundup": "roundup",
    "play the roundup": "roundup",
    # VISION: routes to the VisionChain (LLaVA + webcam capture, Echo
    # Magoo floor). Deliberately full phrases, not a bare "look" —
    # "look" alone would false-positive on things like "look up the
    # weather" or "look for a pharmacy". Requiring the fuller phrase
    # keeps collision risk near zero while still covering the natural
    # ways people ask this.
    "what do you see": "vision",
    "what can you see": "vision",
    "can you see": "vision",
    "take a look": "vision",
    "look at this": "vision",
    "look at that": "vision",
}


# N-gram weights for the open-ended "ask" intent. Scoring isn't keyword
# matching; it's "how much does this phrase look like a question?"
QUESTION_NGRAMS = {
    # Unigrams
    "what": 2, "who": 2, "where": 2, "when": 2, "why": 2, "how": 2,
    "which": 2, "tell": 1, "explain": 2, "show": 1,
    # Bigrams (matched as adjacent token pairs)
    "what is": 3, "what are": 3, "who is": 3, "how do": 3, "how does": 3,
    "tell me": 3, "explain to": 2, "can you": 2,
}


@dataclass
class Intent:
    kind: str                       # 'stop' | 'repeat' | 'weather' | ...
    slots: Dict[str, str] = field(default_factory=dict)
    confidence: float = 0.0
    raw_text: str = ""


# ---------------------------------------------------------------------------
# Tokenization & scoring
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"[a-z0-9]+")

# Punctuation injected by Chrome's SpeechRecognition at silence boundaries.
# Match: a word/digit char, optional whitespace, then one or more punctuation
# chars, followed by whitespace or end-of-string. The (?=\s|$) lookahead
# protects in-token punctuation like "3.14" or "1,000" — those have
# digits AFTER the punctuation, not whitespace.
_INJECTED_PUNCT_RE = re.compile(
    r"([a-z0-9])\s*([.,;:!?]+)(?=\s|$)", re.IGNORECASE)
# Standalone punctuation "word" (e.g. " . ") from weird STT output.
_STANDALONE_PUNCT_RE = re.compile(r"(^|\s)[.,;:!?]+(?=\s|$)")


def sanitize_speech_text(text: str) -> str:
    """Strip end-of-word punctuation that browser SpeechRecognition can
    inject at silence boundaries. Returns a cleaned version suitable for
    regex matching. Preserves apostrophes (contractions), hyphens
    (drive-through), slashes (north/south), and in-token punctuation
    inside numbers (3.14, 1,000).

    Examples:
      "music. london calling"    → "music london calling"
      "what's the weather?"      → "what's the weather"
      "stop. stop."              → "stop stop"
      "service finder, haircut"  → "service finder haircut"
      "3.14"                     → "3.14"        (preserved)
      "drive-through"            → "drive-through" (preserved)
    """
    if not text:
        return ""
    s = _INJECTED_PUNCT_RE.sub(r"\1", text)
    s = _STANDALONE_PUNCT_RE.sub(r"\1", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def tokenize(text: str) -> List[str]:
    return _TOKEN_RE.findall(text.lower())


def find_doubled(tokens: List[str]) -> Optional[Tuple[str, int]]:
    """Returns (word, position) for the first doubled action word, or None."""
    for i in range(len(tokens) - 1):
        if tokens[i] == tokens[i + 1] and tokens[i] in DOUBLED_ACTION_WORDS:
            return tokens[i], i
    return None


def score_question(tokens: List[str]) -> float:
    score = 0
    for t in tokens:
        score += QUESTION_NGRAMS.get(t, 0)
    for i in range(len(tokens) - 1):
        bigram = f"{tokens[i]} {tokens[i+1]}"
        score += QUESTION_NGRAMS.get(bigram, 0)
    # Length-normalize so short angry "what??" doesn't dominate
    return score / max(3, len(tokens))


# ---------------------------------------------------------------------------
# Slot extractors — same pattern as the intent table: data, not code.
# ---------------------------------------------------------------------------

def extract_weather_slots(text: str, tokens: List[str]) -> Dict[str, str]:
    """Extract location and 'when' slots from weather queries.

    Robustness lessons learned (Jim Ames, RENT-A-HAL deployment):
    - iOS WebKit speech recognition adds punctuation (period, exclamation,
      question mark, comma) the original regex didn't anticipate
    - Users say things like "weather in Boston please", "weather in Tokyo
      right now", "weather in London thanks" — trailing politeness words
      must be stripped from the captured city name
    - Multi-word cities like "New York", "Los Angeles", "San Francisco"
      have to survive intact
    - iOS dictation sometimes drops or substitutes the preposition:
      "weather Boston" or "weather and Boston" or "weather of Boston"
      should still work
    - The OLD regex captured "boston please" / "london right now" /
      "los angeles thanks" — those failed at the geocoding step, and
      eventually we got reports of weather defaulting to Newburgh

    Strategy: capture aggressively (multiple preposition variants AND
    a fallback bare-city pattern), then clean the trailing junk.
    """
    slots: Dict[str, str] = {}
    lower = text.lower()

    # PASS 1: capture text after a recognized preposition.
    # Accept 'in', 'for', 'at', plus the iOS-mishear variants 'and', 'of'.
    location = None
    m = re.search(
        r"\b(?:in|for|at|and|of)\s+([a-z][a-z\s\-']{1,40})",
        lower
    )
    if m:
        location = m.group(1).strip()
    else:
        # PASS 2: fallback — bare "weather <city>" with no preposition.
        # Look for content words after "weather". Conservative: require
        # at least one word and reject if first word is a known
        # politeness/time/question word (means user meant nothing
        # specific, not a city).
        bare = re.search(r"\bweather\s+([a-z][a-z\s\-']{1,40})", lower)
        if bare:
            candidate = bare.group(1).strip()
            first = candidate.split()[0] if candidate else ""
            BLOCK_FIRST = {"please", "today", "tomorrow", "tonight", "now",
                           "right", "this", "next", "thanks", "thank",
                           "for", "is", "and", "or", "the"}
            if first and first not in BLOCK_FIRST:
                location = candidate

    if location:
        # Strip trailing punctuation
        location = re.sub(r"[.,!?;:]+$", "", location).strip()
        # Strip trailing time/politeness words (capture group might have
        # consumed them). Sort by length so longer phrases ("right now")
        # win over shorter ones ("now"). Repeat until none left so
        # "please thanks" both go.
        TRAIL_WORDS = sorted([
            "today", "tomorrow", "tonight", "now", "right now",
            "this week", "next week", "this morning", "this afternoon",
            "this evening", "please", "thanks", "thank you", "for me",
        ], key=len, reverse=True)
        changed = True
        while changed and location:
            changed = False
            for trail in TRAIL_WORDS:
                if location.endswith(" " + trail) or location == trail:
                    location = location[: -len(trail)].strip()
                    location = re.sub(r"[.,!?;:]+$", "", location).strip()
                    changed = True
                    break
        # Strip extra inner whitespace
        location = re.sub(r"\s+", " ", location).strip()
        if location and len(location) >= 2:
            slots["location"] = location

    # Detect 'when' phrases independently
    for when in ("today", "tomorrow", "tonight", "this week", "next week",
                 "right now"):
        if when in lower:
            slots["when"] = when
            break
    return slots


def extract_news_slots(text: str, tokens: List[str]) -> Dict[str, str]:
    """Examples:
      'play news feed AP News'        → {feed: 'ap news'}
      'news feed bbc'                 → {feed: 'bbc'}
      'news from npr'                 → {feed: 'npr'}
      'news left'                     → {category: 'left'}
      'play left news'                → {category: 'left'}
      'news'                          → {} (latest from all)
    The 'feed X' or 'from X' marker captures every remaining content word
    after it — so 'feed The Guardian' yields 'the guardian', matched
    case-insensitively against feed names by the service.
    """
    slots: Dict[str, str] = {}
    lower = text.lower()
    # Category words override (left/center/right are unambiguous)
    for cat in ("left", "center", "right"):
        if re.search(rf"\b{cat}\b", lower):
            slots["category"] = cat
            return slots
    # 'feed X' or 'from X' — grab everything up to a sentence-ender
    m = re.search(r"\b(?:feed|from|source)\s+([a-z][a-z0-9 .\-]{1,40}?)(?:[?.!,]|$)",
                  lower)
    if m:
        feed = m.group(1).strip()
        # Strip trailing stop words like 'please', 'today', etc.
        feed = re.sub(r"\s+(please|today|tonight|now)$", "", feed).strip()
        if feed:
            slots["feed"] = feed
    return slots


def extract_music_slots(text: str, tokens: List[str]) -> Dict[str, str]:
    """Capture the music search query as the 'query' slot.

    Examples:
      'music london calling'              → {query: 'london calling'}
      'music player london calling'       → {query: 'london calling'}
      'music play london calling'         → {query: 'london calling'}
      'play music london calling'         → {query: 'london calling'}
      'music kashmir by led zeppelin'     → {query: 'kashmir by led zeppelin'}

    The user provides the search terms; we pass them verbatim to YouTube's
    embedded player via the IFrame API's listType=search parameter. YouTube
    serves the results from the CLIENT'S browser/IP, NOT from our server —
    we never call the YouTube Data API.
    """
    slots: Dict[str, str] = {}
    lower = text.lower()

    # Match 'music' optionally with 'player'/'play' prefix variants.
    # CRITICAL: list longer alternatives FIRST so regex picks
    # 'music player' over 'music' when both could match.
    # Defense in depth: accept whitespace OR punctuation between the
    # trigger word and the query. Even though classify() now sanitizes
    # input, direct callers (tests, future code paths) might pass raw
    # text — and the small regex change costs nothing.
    m = re.search(
        r"\b(?:music\s+player|music\s+play|play\s+music|music)[\s.,;:!?]+(.+?)$",
        lower
    )
    if m:
        query = m.group(1).strip()
        # Strip trailing punctuation iOS adds
        query = re.sub(r"[.,!?;:]+$", "", query).strip()
        # Strip trailing politeness words
        TRAIL_WORDS = sorted([
            "please", "thanks", "thank you", "now", "for me",
        ], key=len, reverse=True)
        changed = True
        while changed and query:
            changed = False
            for trail in TRAIL_WORDS:
                if query.endswith(" " + trail) or query == trail:
                    query = query[: -len(trail)].strip()
                    query = re.sub(r"[.,!?;:]+$", "", query).strip()
                    changed = True
                    break
        # Reject queries that are JUST the music-trigger keywords —
        # e.g. "music player" with no song yields ('music', 'player')
        # captures, which is not a real song search.
        KEYWORD_ONLY = {"player", "play", "music", "music player",
                        "music play", "play music"}
        if query and query not in KEYWORD_ONLY:
            slots["query"] = query
    return slots


# Map natural English words to BizData's 37 OSM categories.
# When users say "haircut" we want OSM's "hairdresser", etc. Multiple
# words can map to the same category. Sorted longest-first when matching
# so "gas station" wins over "gas" alone.
SERVICE_CATEGORY_MAP = {
    # Personal services
    "haircut": "hairdresser",
    "barber": "hairdresser",
    "barbershop": "hairdresser",
    "hair salon": "hairdresser",
    "salon": "hairdresser",
    "beauty": "beauty",
    "spa": "beauty",
    "nails": "beauty",
    "manicure": "beauty",
    # Auto
    "gas": "gas_station",
    "gas station": "gas_station",
    "gasoline": "gas_station",
    "petrol": "gas_station",
    "fuel": "gas_station",
    "car repair": "car_repair",
    "mechanic": "car_repair",
    "auto repair": "car_repair",
    "car dealer": "car_dealer",
    # Food & drink
    "restaurant": "restaurant",
    "food": "restaurant",
    "dinner": "restaurant",
    "lunch": "restaurant",
    "cafe": "cafe",
    "coffee": "cafe",
    "coffee shop": "cafe",
    "bar": "bar",
    "pub": "bar",
    "bakery": "bakery",
    "bread": "bakery",
    # Groceries & shopping
    "groceries": "supermarket",
    "grocery": "supermarket",
    "grocery store": "supermarket",
    "supermarket": "supermarket",
    "market": "supermarket",
    "clothing": "clothing",
    "clothes": "clothing",
    "bookstore": "bookstore",
    "books": "bookstore",
    "electronics": "electronics",
    "florist": "florist",
    "flowers": "florist",
    "furniture": "furniture",
    "pet shop": "pet_shop",
    "pet store": "pet_shop",
    # Health
    "pharmacy": "pharmacy",
    "drug store": "pharmacy",
    "drugstore": "pharmacy",
    "doctor": "doctor",
    "physician": "doctor",
    "dentist": "dentist",
    "hospital": "hospital",
    # Money
    "bank": "bank",
    "atm": "bank",
    # Lodging
    "hotel": "hotel",
    "motel": "hotel",
    "guest house": "guest_house",
    "hostel": "hostel",
    "lodging": "hotel",
    # Fitness
    "gym": "gym",
    "fitness": "gym",
    "workout": "gym",
    # Professional services
    "lawyer": "lawyer",
    "attorney": "lawyer",
    "accountant": "accountant",
    "real estate": "real_estate",
    "realtor": "real_estate",
    "insurance": "insurance",
    "coworking": "coworking",
    # Entertainment & culture
    "cinema": "cinema",
    "movies": "cinema",
    "theater": "theatre",
    "theatre": "theatre",
    "museum": "museum",
    "gallery": "gallery",
    "art gallery": "gallery",
    # Other
    "parking": "parking",
    "school": "school",
    "university": "university",
    "college": "university",
}


def extract_service_slots(text: str, tokens: List[str]) -> Dict[str, str]:
    """Extract a service category from natural speech.

    Examples:
      'service finder haircut'            → {category: 'hairdresser'}
      'service finder gas station'        → {category: 'gas_station'}
      'find a pharmacy'                   → {category: 'pharmacy'}
      'find me a coffee shop'             → {category: 'cafe'}
      'find nearby grocery store'         → {category: 'supermarket'}

    We strip the trigger phrase first, then match the remaining words
    against SERVICE_CATEGORY_MAP. Multi-word matches (like 'gas station')
    win over single-word ones ('gas') because we sort by length.
    """
    slots: Dict[str, str] = {}
    lower = text.lower()

    # Strip trigger phrases from the front so we're left with the category
    TRIGGER_PHRASES = ["service finder", "find me a", "find me",
                       "find nearby", "find a", "find"]
    for trigger in TRIGGER_PHRASES:
        if lower.startswith(trigger + " "):
            lower = lower[len(trigger):].strip()
            break
        elif lower == trigger:
            return {}    # bare trigger, no category

    # Strip trailing punctuation iOS adds
    lower = re.sub(r"[.,!?;:]+$", "", lower).strip()

    # Strip trailing politeness words
    TRAIL_WORDS = sorted(
        ["please", "thanks", "thank you", "now", "for me",
         "near me", "nearby", "near here", "around here"],
        key=len, reverse=True)
    changed = True
    while changed and lower:
        changed = False
        for trail in TRAIL_WORDS:
            if lower.endswith(" " + trail) or lower == trail:
                lower = lower[: -len(trail)].strip()
                lower = re.sub(r"[.,!?;:]+$", "", lower).strip()
                changed = True
                break

    if not lower:
        return {}

    # Match longest category phrase first ('gas station' before 'gas')
    sorted_keys = sorted(SERVICE_CATEGORY_MAP.keys(), key=len, reverse=True)
    for phrase in sorted_keys:
        # Either exact or appears as a complete phrase (word-boundary)
        if lower == phrase or phrase in lower.split():
            slots["category"] = SERVICE_CATEGORY_MAP[phrase]
            slots["category_label"] = phrase
            return slots
        # Multi-word phrase match
        if " " in phrase and phrase in lower:
            slots["category"] = SERVICE_CATEGORY_MAP[phrase]
            slots["category_label"] = phrase
            return slots

    # No match — preserve the raw text so the handler can fall back
    slots["category_unmatched"] = lower
    return slots


def extract_imagine_slots(text: str, tokens: List[str]) -> Dict[str, str]:
    """Extract the image prompt from natural speech.

    Examples:
      'imagine a kitten wearing a hat'      → {prompt: 'a kitten wearing a hat'}
      'draw a sunset over the mountains'    → {prompt: 'a sunset over the mountains'}
      'imagine me a picture of a dragon'    → {prompt: 'a dragon'}
      'imagine a castle please'             → {prompt: 'a castle'}
      'imagine'                             → {} (bare trigger, no subject)

    Same shape as extract_service_slots: strip the trigger word(s) from
    the front, strip common filler right after it ('me', 'a picture
    of'), strip trailing politeness words, keep whatever's left as the
    prompt verbatim — Automatic1111 takes free-form text, so there's no
    category table to match against here.
    """
    slots: Dict[str, str] = {}
    lower = text.lower()

    TRIGGER_WORDS = ["imagine", "draw"]
    matched = False
    for trigger in TRIGGER_WORDS:
        if lower.startswith(trigger + " "):
            lower = lower[len(trigger):].strip()
            matched = True
            break
        elif lower == trigger:
            return {}    # bare trigger, no subject
    if not matched:
        # Extractor called directly (e.g. tests) without a leading
        # trigger word — treat the whole string as the prompt.
        pass

    lower = re.sub(r"[.,!?;:]+$", "", lower).strip()

    # Strip filler that commonly follows the trigger word. Longest
    # phrases first so "me a picture of" wins over bare "me".
    FILLER_PREFIXES = sorted([
        "me a picture of", "a picture of",
        "me an image of", "an image of",
        "me a photo of", "a photo of",
        "me",
    ], key=len, reverse=True)
    changed = True
    while changed and lower:
        changed = False
        for filler in FILLER_PREFIXES:
            if lower.startswith(filler + " "):
                lower = lower[len(filler):].strip()
                changed = True
                break

    # Strip trailing politeness words — same pattern as every other
    # slot extractor in this file.
    TRAIL_WORDS = sorted(
        ["please", "thanks", "thank you", "for me", "now"],
        key=len, reverse=True)
    changed = True
    while changed and lower:
        changed = False
        for trail in TRAIL_WORDS:
            if lower.endswith(" " + trail) or lower == trail:
                lower = lower[: -len(trail)].strip()
                lower = re.sub(r"[.,!?;:]+$", "", lower).strip()
                changed = True
                break

    if lower:
        slots["prompt"] = lower
    return slots


SLOT_EXTRACTORS = {
    "weather": extract_weather_slots,
    "news": extract_news_slots,
    "music": extract_music_slots,
    "service": extract_service_slots,
    "imagine": extract_imagine_slots,
}


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------

class IntentClassifier:
    """
    Subscribes to prompt_text on the bus. Emits:
      - intent_stop / intent_repeat (highest priority; doubled-word guard)
      - intent_classified (kind=weather|gmail|news|ask, slots, confidence)
    """

    def __init__(self, bus: EventBus, question_threshold: float = 0.5):
        self.bus = bus
        self.question_threshold = question_threshold

    async def attach(self):
        await self.bus.subscribe("prompt_text", self._on_prompt)

    def classify(self, text: str) -> Intent:
        # Sanitize the input: strip punctuation that browser STT can
        # inject at silence boundaries. The original text is still kept
        # in raw_text for display; matching uses the cleaned version.
        sanitized = sanitize_speech_text(text)
        tokens = tokenize(sanitized)
        if not tokens:
            return Intent(kind="ask", raw_text=text, confidence=0.0)

        # 1. Doubled action words win unconditionally
        doubled = find_doubled(tokens)
        if doubled:
            word, _ = doubled
            kind = DOUBLED_ACTION_WORDS[word].replace("intent_", "")
            return Intent(kind=kind, raw_text=text, confidence=1.0)

        # 2. Multi-word PHRASE intents (must check BEFORE single-word
        #    so "service finder" wins over standalone "find" or "service").
        #    Match against the leading text, longest phrases first.
        lower = sanitized.lower().strip()
        phrase_keys = sorted(PHRASE_INTENTS.keys(), key=len, reverse=True)
        for phrase in phrase_keys:
            if lower == phrase or lower.startswith(phrase + " "):
                kind = PHRASE_INTENTS[phrase]
                slots = SLOT_EXTRACTORS.get(kind, lambda *_: {})(sanitized, tokens)
                return Intent(kind=kind, slots=slots, raw_text=text,
                              confidence=0.95)

        # 3. Single-word realm intents (only if the realm word is dominant —
        #    "weather" alone or as the first content word, not buried in a sentence)
        for i, tok in enumerate(tokens[:3]):
            if tok in SINGLE_INTENTS:
                kind = SINGLE_INTENTS[tok]
                slots = SLOT_EXTRACTORS.get(kind, lambda *_: {})(sanitized, tokens)
                return Intent(kind=kind, slots=slots, raw_text=text,
                              confidence=0.9 - 0.1 * i)

        # 4. N-gram scored "ask anything"
        q_score = score_question(tokens)
        confidence = min(1.0, q_score / 3.0)
        return Intent(kind="ask", raw_text=text, confidence=confidence)

    async def _on_prompt(self, ev: Event):
        text = ev.payload.get("text", "")
        nonce = ev.payload.get("nonce", "")
        user_guid = ev.payload.get("user_guid", "anonymous")
        # Optional: a webcam frame the browser attached to this prompt in
        # anticipation of a vision intent (it can't know for sure ahead of
        # server-side classification — see orchestrator.py's vision
        # handler for what happens if the guess was wrong: the image is
        # simply unused, no harm done). None for every other prompt.
        image_b64 = ev.payload.get("image_b64")
        intent = self.classify(text)

        if intent.kind == "stop":
            await self.bus.publish("intent_stop", nonce=nonce, user_guid=user_guid)
            return
        if intent.kind == "repeat":
            await self.bus.publish("intent_repeat", nonce=nonce, user_guid=user_guid)
            return

        await self.bus.publish(
            "intent_classified",
            nonce=nonce,
            user_guid=user_guid,
            kind=intent.kind,
            slots=intent.slots,
            confidence=intent.confidence,
            text=text,
            image_b64=image_b64,
        )
