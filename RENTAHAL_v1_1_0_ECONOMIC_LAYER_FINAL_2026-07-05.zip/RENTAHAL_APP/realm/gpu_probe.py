"""Shared GPU detection utility.

Extracted from wizard.py 2026-06-24 so both the wizard (for gating GO
on CUDA-required installs) and the realm (for accurate footer display
of the actual hardware) call the same battle-tested code path. The
original probe_cuda lived in wizard.py since 2026-06-21 and has been
production-validated on rentahal.com and realnewslistener.com.

Why nvidia-smi rather than pynvml or torch: nvidia-smi is the most
universal probe — works on every supported Windows/Linux driver
version without additional Python dependencies. The realm and wizard
only need device identity (yes/no + name), not VRAM or utilization.
"""
from __future__ import annotations

import subprocess
from typing import Optional


def probe_cuda() -> dict:
    """Check for a usable CUDA GPU via `nvidia-smi -L`. Returns:
    {
      "ok": bool,             # is at least one CUDA device detected?
      "device_name": str,     # e.g. "NVIDIA GeForce RTX 4060"
      "error": str | None,
    }

    Used by:
      - wizard.py:  gates GO on `ok` unless [Hardware] require_cuda=false
                    in config.ini (cloud-only operators)
      - app.py:     surfaces device_name in the cockpit footer so every
                    operator sees their actual hardware, not a hardcoded
                    string that lies about their installation
    """
    try:
        result = subprocess.run(
            ["nvidia-smi", "-L"],
            capture_output=True, text=True, timeout=5.0,
        )
        if result.returncode != 0:
            return {"ok": False, "device_name": "",
                    "error": f"nvidia-smi exited {result.returncode}: "
                             f"{(result.stderr or '').strip()[:200]}"}
        out = (result.stdout or "").strip()
        if not out:
            return {"ok": False, "device_name": "",
                    "error": "nvidia-smi returned no GPU listing"}
        # Output shape: "GPU 0: NVIDIA GeForce RTX 4060 (UUID: GPU-...)"
        # Extract the human-readable device name between the colon and
        # the parenthesis.
        first_line = out.splitlines()[0]
        device = first_line.split("(")[0]
        # Strip the leading "GPU N: " prefix
        if ":" in device:
            device = device.split(":", 1)[1].strip()
        return {"ok": True, "device_name": device or first_line.strip(),
                "error": None}
    except FileNotFoundError:
        return {"ok": False, "device_name": "",
                "error": "nvidia-smi not found on PATH (NVIDIA driver "
                         "not installed?)"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "device_name": "",
                "error": "nvidia-smi timed out — driver may be hung"}
    except Exception as e:
        return {"ok": False, "device_name": "", "error": str(e)}
