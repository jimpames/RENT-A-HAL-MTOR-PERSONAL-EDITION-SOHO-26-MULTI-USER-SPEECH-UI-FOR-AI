"""
config_schema.py — single source of truth for RENT-A-HAL configuration.

Parses config.ini including the self-describing `; @label: ... @type: ...`
metadata comments. Three consumers:

  1. webgui.py            ->  get_config() / typed value access
  2. GET /api/config      ->  frontend_config() (scope: frontend|both, no secrets)
  3. tkinter settings GUI ->  schema() (labels, types, ranges, choices, help)

The grammar (one metadata comment line directly above each key):

  ; @label: Port @type: int @min: 1 @max: 65535 @scope: backend @help: Main port

Recognized attributes: label, type, min, max, choices, scope, help
Types: str | int | float | bool | secret | choice | list | path | url
Section tabs: `; @section-label: Server` directly above a [Section] header.

IMPORTANT: never write this file back with configparser.write() — that
destroys the metadata comments. The GUI must rewrite values in-place
(see save_value below, which edits the raw lines).
"""

import re
from pathlib import Path

CONFIG_PATH = Path(__file__).parent / "config.ini"

_META_RE = re.compile(r"@(\w[\w-]*):\s*")
_SECTION_RE = re.compile(r"^\[(.+)\]\s*$")
_KV_RE = re.compile(r"^([^;#=\s][^=]*)=(.*)$")


def _parse_meta(comment: str) -> dict:
    """Split '; @label: Port @type: int @help: Main port' into a dict."""
    body = comment.lstrip(";# \t")
    parts = _META_RE.split(body)
    # parts = ['', 'label', 'Port ', 'type', 'int ', 'help', 'Main port']
    meta = {}
    for i in range(1, len(parts) - 1, 2):
        meta[parts[i]] = parts[i + 1].strip()
    return meta


def load_schema(path: Path = CONFIG_PATH) -> dict:
    """
    Returns {section: {"_label": str, "keys": {key: {"value": str, **meta}}}}
    """
    schema: dict = {}
    section = None
    pending_meta: dict = {}
    pending_section_label = None

    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line.startswith(";") or line.startswith("#"):
            if "@section-label:" in line:
                pending_section_label = line.split("@section-label:", 1)[1].strip()
            elif "@" in line:
                # MERGE, don't overwrite. A key's metadata is often split
                # across consecutive comment lines, e.g.:
                #   ; @label: Enabled @type: bool @scope: frontend
                #   ; @help: When true, shows a "Support this project" link...
                # A plain overwrite here would let the @help line erase the
                # @label/@type/@scope set on the line above it. Concretely:
                # Supporters.enabled (@scope: frontend) was silently
                # vanishing from frontend_config() because its @scope got
                # wiped by the very next comment line, falling back to the
                # "backend" default and getting filtered out.
                pending_meta.update(_parse_meta(line))
            continue
        m = _SECTION_RE.match(line)
        if m:
            section = m.group(1)
            schema[section] = {"_label": pending_section_label or section, "keys": {}}
            pending_section_label = None
            pending_meta = {}
            continue
        m = _KV_RE.match(line)
        if m and section:
            key, value = m.group(1).strip(), m.group(2).strip()
            entry = {"value": value, "type": "str", "scope": "backend", "label": key}
            entry.update(pending_meta)
            if "choices" in entry:
                entry["choices"] = [c.strip() for c in entry["choices"].split("|")]
            schema[section]["keys"][key] = entry
            pending_meta = {}
    return schema


def _coerce(entry: dict):
    t, v = entry.get("type", "str"), entry["value"]
    if t == "int":
        return int(v)
    if t == "float":
        return float(v)
    if t == "bool":
        return v.strip().lower() in ("1", "true", "yes", "on")
    if t == "list":
        return [s.strip() for s in v.split(",") if s.strip()]
    return v  # str, secret, choice, path, url


class Config:
    """Typed access: cfg.get('Server', 'port') -> 5000 (int)."""

    def __init__(self, path: Path = CONFIG_PATH):
        self.path = path
        self.schema = load_schema(path)

    def get(self, section: str, key: str):
        return _coerce(self.schema[section]["keys"][key])

    def frontend_config(self) -> dict:
        """Whitelisted, secret-free dict for GET /api/config."""
        out: dict = {}
        for section, body in self.schema.items():
            for key, entry in body["keys"].items():
                if entry.get("scope") in ("frontend", "both") and entry.get("type") != "secret":
                    out.setdefault(section, {})[key] = _coerce(entry)
        return out

    def save_value(self, section: str, key: str, new_value):
        """Rewrite one value in-place, preserving every comment line."""
        lines = self.path.read_text(encoding="utf-8").splitlines(keepends=True)
        in_section = False
        for i, raw in enumerate(lines):
            s = raw.strip()
            m = _SECTION_RE.match(s)
            if m:
                in_section = m.group(1) == section
                continue
            if in_section:
                m = _KV_RE.match(s)
                if m and m.group(1).strip() == key:
                    lines[i] = f"{key} = {new_value}\n"
                    break
        self.path.write_text("".join(lines), encoding="utf-8")
        self.schema = load_schema(self.path)


_config = None


def get_config(path: Path = CONFIG_PATH) -> Config:
    global _config
    if _config is None:
        _config = Config(path)
    return _config


if __name__ == "__main__":
    import json
    cfg = get_config()
    print("Sections:", ", ".join(cfg.schema))
    print("\nFrontend payload:\n", json.dumps(cfg.frontend_config(), indent=2)[:2000])
