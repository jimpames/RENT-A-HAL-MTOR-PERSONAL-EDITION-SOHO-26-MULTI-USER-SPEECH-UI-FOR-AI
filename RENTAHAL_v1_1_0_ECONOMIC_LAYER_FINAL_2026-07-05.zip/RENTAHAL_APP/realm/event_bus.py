"""
event_bus.py — the architectural spine of the Star Trek realm.

Components emit and subscribe to typed events. They do NOT call each other.
This is what makes the realm event-driven instead of feature-driven, and
what lets us add STOP/REPEAT, waveform display, and the Gmail/weather realms
as bus subscribers without touching the core.

Design invariants (every one of these is enforced by a test):

  1. publish() NEVER raises. A bad subscriber cannot break the bus.
  2. Subscribers run concurrently (asyncio.gather), so a slow one does not
     starve a fast one — TTS playback does not stall the waveform painter.
  3. publish() is non-blocking from the caller's perspective: it schedules
     subscriber tasks and returns. Use publish_wait() if you need to await
     completion (only the test harness does).
  4. Subscribers can unsubscribe themselves from inside their handler
     (one-shot patterns: "wait for the next prompt_finalized then unsub")
     without mutating-during-iteration crashes.
  5. The bus carries soft ping/pong: subscribers can call ping() to ask
     "is anyone listening for X?" — the bus answers without invoking
     handlers. Used by the orchestrator to detect a missing TTS engine.
  6. Every event is timestamped at publish; subscribers can see ordering.

Event type is a string. Payload is a dict. That's it. No class explosion.
The KNOWN_EVENTS set is documentation, not validation — unknown events go
through too, so plugins can invent their own.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, Optional, Set

logger = logging.getLogger("event_bus")

# Documentation of the canonical event taxonomy.
# Star Trek voice loop:
KNOWN_EVENTS = {
    # Wake / capture
    "wake_detected",          # {source: 'voice'|'button'}
    "prompt_capture_started", # {nonce}
    "prompt_audio_chunk",     # {nonce, chunk_b64, seq}
    "prompt_finalized",       # {nonce, audio_b64}  -> goes to STT
    "prompt_text",            # {nonce, text, image_b64?} -> ready to classify
    # Intent layer (the algebraic part — text -> typed intent)
    "intent_classified",      # {nonce, kind, slots, confidence, image_b64?}
    "intent_stop",            # {nonce}             -> kills active TTS
    "intent_repeat",          # {nonce}             -> replays last result
    # Orchestrator
    "query_queued",           # {nonce, query}
    "query_processing",       # {nonce}
    "query_result",           # {nonce, text, audio_b64?}
    "query_failed",           # {nonce, error}
    # Vision / Imagine realms
    "imagine_result",         # {user_guid, prompt, image_b64} -> render in panel
    "easter_egg_video",       # {user_guid, youtube_id, source: 'vision'|'imagine'}
                               # -> shared floor event when Vision/Imagine's
                               #    Echo provider fires (no real model online)
    # TTS playback
    "tts_started",            # {nonce, duration_estimate}
    "tts_chunk",              # {nonce, audio_b64, seq}
    "tts_complete",           # {nonce}
    "tts_aborted",            # {nonce, reason}
    # Realm liveness
    "ping",                   # {from}
    "pong",                   # {from}
    # Sysop / observability
    "engine_health_changed",  # {engine, status: 'available'|'unavailable'}
    "setup_status",           # {gpt4all, kokoro, sd, ...}
    # Sprint 13: economic layer
    "low_balance",            # {user_guid, balance_micros} -> cockpit top-up prompt
}


@dataclass
class Event:
    type: str
    payload: Dict[str, Any] = field(default_factory=dict)
    ts: float = field(default_factory=time.monotonic)
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])


Subscriber = Callable[[Event], Awaitable[None]]


class EventBus:
    def __init__(self):
        # event_type -> set of subscriber callables
        self._subs: Dict[str, Set[Subscriber]] = {}
        # subscribers for ALL events (the recording / waveform / sysop log)
        self._wildcard: Set[Subscriber] = set()
        self._lock = asyncio.Lock()
        self._history: list[Event] = []         # last N events, for debugging
        self._history_max = 200

    async def subscribe(self, event_type: str, handler: Subscriber):
        async with self._lock:
            self._subs.setdefault(event_type, set()).add(handler)
        return lambda: asyncio.ensure_future(self.unsubscribe(event_type, handler))

    async def subscribe_all(self, handler: Subscriber):
        async with self._lock:
            self._wildcard.add(handler)
        return lambda: asyncio.ensure_future(self.unsubscribe_all(handler))

    async def unsubscribe(self, event_type: str, handler: Subscriber):
        async with self._lock:
            self._subs.get(event_type, set()).discard(handler)

    async def unsubscribe_all(self, handler: Subscriber):
        async with self._lock:
            self._wildcard.discard(handler)

    def ping(self, event_type: str) -> int:
        """Soft introspection: how many subscribers for this event type?
        Used by orchestrator to skip emitting tts_chunk if nobody's listening."""
        return len(self._subs.get(event_type, set())) + len(self._wildcard)

    async def publish(self, event_type: str, **payload):
        """Fire-and-forget. Schedules handlers, returns immediately."""
        ev = Event(type=event_type, payload=payload)
        self._history.append(ev)
        if len(self._history) > self._history_max:
            self._history = self._history[-self._history_max:]
        async with self._lock:
            handlers = list(self._subs.get(event_type, set())) + list(self._wildcard)
        for h in handlers:
            asyncio.create_task(self._run_handler(h, ev))
        return ev.id

    async def publish_wait(self, event_type: str, **payload):
        """Awaits all subscribers (test-only convenience)."""
        ev = Event(type=event_type, payload=payload)
        self._history.append(ev)
        async with self._lock:
            handlers = list(self._subs.get(event_type, set())) + list(self._wildcard)
        await asyncio.gather(*(self._run_handler(h, ev) for h in handlers))
        return ev.id

    async def _run_handler(self, handler: Subscriber, ev: Event):
        try:
            await handler(ev)
        except Exception:
            logger.exception("Subscriber %r failed on %s (contained)",
                             handler, ev.type)

    def recent(self, n: int = 50, type_filter: Optional[str] = None) -> list[Event]:
        events = self._history[-n:]
        if type_filter:
            events = [e for e in events if e.type == type_filter]
        return events
