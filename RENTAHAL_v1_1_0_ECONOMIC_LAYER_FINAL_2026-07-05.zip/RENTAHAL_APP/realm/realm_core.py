"""
realm_core.py — concurrency-safe core for RENT-A-HAL.

Fixes, relative to webgui.py:

  BUG-1  Event-loop blocking: STT/TTS engines are injected and MUST be async;
         the reference TorchEngines pattern (see PATCHES doc) runs ffmpeg via
         create_subprocess_exec and whisper/BARK via run_in_executor. The core
         never blocks the loop.
  BUG-2  ConnectionManager.broadcast: one dead socket no longer aborts the
         broadcast, raises into callers, or kills the queue processor. Dead
         sockets are evicted. All mutation is lock-guarded; iteration uses a
         snapshot, so concurrent connect/disconnect can't blow up iteration.
  BUG-3  SafeQueue: get() no longer holds the lock while waiting (the old code
         serialized put() behind a blocked get(), and asyncio.wait_for around
         it could CANCEL get() after an item was dequeued -> item silently
         lost). New design: blocking get with cancel-horizon tombstones; no
         polling, no wait_for, no item loss.
  BUG-4  Per-item error containment in the processor: a failed send to a gone
         client no longer raises inside the except handler; stats are recorded
         even when the client disconnected mid-query; the queue_update
         broadcast in `finally` can't kill the loop.
  BUG-5  Ghost connections: banned users and error paths always detach from
         the manager; a server-side ping/reap loop evicts silent sockets, so
         active_connections reflects reality.
  BUG-6  system_stats upsert wrote a NEW row per query (ON CONFLICT(id) can
         never fire on an autoincrement insert). The injected stats recorder
         contract is "accumulate"; the reference SQLite recorder uses a fixed
         id=1 row (see PATCHES doc).

Everything heavy (torch, bark, whisper, sqlite) is injected, so this module
imports in milliseconds and the test harness can hammer it.
"""

from __future__ import annotations

import asyncio
import itertools
import json
import logging
import secrets
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, Optional, Protocol, Tuple, Union

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

logger = logging.getLogger("realm_core")


# --------------------------------------------------------------------------
# Engine protocol — webgui.py supplies TorchEngines; tests supply fakes.
# --------------------------------------------------------------------------

class Engines(Protocol):
    async def stt(self, audio_b64: str) -> str: ...
    async def tts(self, text: str) -> str: ...
    async def infer(self, query: dict) -> Union[str, bytes]: ...


# --------------------------------------------------------------------------
# Cancellable query
# --------------------------------------------------------------------------

class CancellableQuery:
    def __init__(self, item: Dict[str, Any]):
        self.item = item
        self.task: Optional[asyncio.Task] = None
        self.cancelled = False

    async def run(self, processor: Callable[[dict], Awaitable[Any]]):
        if self.cancelled:                       # FIX: cancel-before-start race
            raise asyncio.CancelledError()
        self.task = asyncio.create_task(processor(self.item))
        try:
            return await self.task
        except asyncio.CancelledError:
            self.cancelled = True
            raise

    async def cancel(self):
        self.cancelled = True                    # effective even if not started
        if self.task and not self.task.done():
            self.task.cancel()
            try:
                await self.task
            except (asyncio.CancelledError, Exception):
                pass


# --------------------------------------------------------------------------
# SafeQueue v2 — no lock across the wait, no wait_for item loss
# --------------------------------------------------------------------------

class SafeQueue:
    """
    put()            -> bool (False if full; caller tells the user)
    get()            -> CancellableQuery (blocks until work; skips tombstoned)
    remove_by_guid() -> cancels everything queued OR in-flight for a guid
    pending()/inflight()/depth() replace the old overloaded qsize().
    """

    def __init__(self, maxsize: int = 0):
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._lock = asyncio.Lock()
        self._inflight: Dict[str, CancellableQuery] = {}
        self._seq = itertools.count()
        self._cancel_horizon: Dict[str, int] = {}   # guid -> seq; items <= are dead

    async def put(self, item: Dict[str, Any]) -> bool:
        item["_seq"] = next(self._seq)
        try:
            self._queue.put_nowait(item)
            return True
        except asyncio.QueueFull:
            return False

    async def get(self) -> CancellableQuery:
        while True:
            item = await self._queue.get()        # FIX: no lock held while waiting
            async with self._lock:
                guid = item["user_guid"]
                if item["_seq"] <= self._cancel_horizon.get(guid, -1):
                    continue                       # tombstoned while queued: skip
                cq = CancellableQuery(item)
                self._inflight[guid] = cq
                return cq

    async def remove_by_guid(self, guid: str):
        async with self._lock:
            self._cancel_horizon[guid] = next(self._seq) - 1
            cq = self._inflight.pop(guid, None)
        if cq:                                     # cancel OUTSIDE the lock
            await cq.cancel()

    async def clear_inflight(self, guid: str):
        async with self._lock:
            self._inflight.pop(guid, None)

    def pending(self) -> int:
        return self._queue.qsize()

    def inflight(self) -> int:
        return len(self._inflight)

    def depth(self) -> int:
        return self.pending() + self.inflight()


# --------------------------------------------------------------------------
# ConnectionManager v2 — dead sockets can't hurt anyone else
# --------------------------------------------------------------------------

class ConnectionManager:
    """Manages WebSocket connections with deterministic ordered delivery.

    Architecture: each connection has a dedicated outbound asyncio.Queue
    and a single drain task. Publishers call safe_send() which APPENDS to
    the queue (synchronous, ordered, never blocks on I/O). The drain task
    pulls from the queue in FIFO order and writes to the WebSocket.

    Why this matters: under the previous design, multiple concurrent
    tasks calling ws.send_json could be reordered by the asyncio
    scheduler, causing bus events to arrive at the browser out of order.
    Symptom: bus_query_result would arrive BEFORE bus_service_results,
    answer text would update, but the card panel never opened — "cards
    sometimes don't display." A per-connection lock prevented OVERLAP
    but not REORDERING — locks are FIFO at the acquire() call, but tasks
    might reach acquire() in arbitrary order under load.

    The queue captures order at the INSERTION POINT, which is synchronous
    with bus.publish(). Order is locked in before the event loop can
    reorder anything. The drain task is the single writer for that
    connection — no other code touches ws.send_json directly.

    Multi-user parallelism is preserved: each user has their own queue
    and their own drain task. Alice's events do not block Bob's events.
    """

    # Bound the per-user queue so a stuck consumer can't grow memory
    # without limit. 256 is plenty for a typical conversation (~5-10
    # events per query × dozens of in-flight queries). Hitting this cap
    # is an alarm condition, not a normal state.
    MAX_OUTBOUND_QUEUE = 256

    # ── ACK tracking ──────────────────────────────────────────────────
    # Events of these types REQUIRE an application-level ACK from the
    # browser. Browser sends {"type": "ack", "conn_token": ..., "seq": ...}
    # after the handler has processed the event. If no ACK arrives within
    # ACK_TIMEOUT_S, we log loudly — no retry, just diagnostic surfacing.
    #
    # Why only these types: TTS chunks fire constantly; metrics fire
    # every 2s; ping/pong are intrinsically liveness probes. ACKing those
    # would double traffic for no signal. These five are the user-visible
    # state-changing events — the ones where loss leaves the user looking
    # at the wrong screen.
    ACK_TRACKED_EVENT_TYPES = frozenset({
        "bus_service_results",
        "bus_music_search_request",
        "bus_news_bundle",
        "bus_news_stories",
        "bus_news_roundup_start",
        "bus_query_result",
    })
    ACK_TIMEOUT_S = 3.0

    def __init__(self, ping_interval: float = 20.0, stale_after: float = 75.0):
        self._conns: Dict[str, Any] = {}
        self._last_seen: Dict[str, float] = {}
        # Per-connection outbound queue: bus events for this user are
        # appended here. The drain task is the single consumer.
        self._send_queues: Dict[str, asyncio.Queue] = {}
        # Per-connection drain task: pulls from queue, writes to socket.
        self._drain_tasks: Dict[str, asyncio.Task] = {}
        # Per-connection identity token. Fresh on every connect() — this
        # is what makes ACK matching collision-proof. An ACK that arrives
        # bearing an old conn_token is rejected as stale; the realm can't
        # accidentally credit a NEW event with an OLD session's ACK.
        # Same property protects against multiple tabs (each gets its own
        # WebSocket → its own connection → its own conn_token).
        self._conn_tokens: Dict[str, str] = {}
        # Per-connection monotonic sequence number for outgoing events.
        # Resets on each connect; tagged onto every payload as `_seq`.
        # Combined with conn_token, gives globally-unique event identity.
        self._next_seq: Dict[str, int] = {}
        # Per-connection in-flight ACK registry:
        #   _pending_acks[guid][seq] = (event_type, sent_at_monotonic, timer_task)
        # Cleared when ACK arrives or on disconnect (cancels timers).
        self._pending_acks: Dict[str, Dict[int, Tuple[str, float, asyncio.Task]]] = {}
        self._lock = asyncio.Lock()
        self.ping_interval = ping_interval
        self.stale_after = stale_after
        self._reap_task: Optional[asyncio.Task] = None

    async def connect(self, websocket, guid: str):
        old_drain: Optional[asyncio.Task] = None
        old_ws = None
        old_pending: Dict[int, Tuple[str, float, asyncio.Task]] = {}
        async with self._lock:
            old_ws = self._conns.get(guid)
            old_drain = self._drain_tasks.get(guid)
            old_pending = self._pending_acks.get(guid, {})
            self._conns[guid] = websocket
            self._last_seen[guid] = time.monotonic()
            # Always allocate a FRESH queue + drain task on (re)connect.
            # The new queue is empty; the new drain task owns the new ws.
            # If there was an OLD drain task, we cancel it AFTER this
            # block — it would have been writing to the old ws.
            fresh_queue: asyncio.Queue = asyncio.Queue(
                maxsize=self.MAX_OUTBOUND_QUEUE)
            self._send_queues[guid] = fresh_queue
            self._drain_tasks[guid] = asyncio.create_task(
                self._drain_loop(guid, websocket, fresh_queue),
                name=f"ws_drain_{guid[:8]}",
            )
            # Fresh ACK identity for this connection. Old conn_token is
            # discarded — any ACK that arrives later bearing the old
            # token will be rejected by ack_received() as stale, so the
            # realm cannot accidentally credit a new event with an old
            # session's ACK. seq resets too; it's only meaningful within
            # the scope of one conn_token.
            self._conn_tokens[guid] = secrets.token_hex(6)  # 12 hex chars
            self._next_seq[guid] = 0
            self._pending_acks[guid] = {}
        # Tear down the old connection cleanly (outside the lock to
        # avoid blocking other operations).
        if old_drain is not None and not old_drain.done():
            old_drain.cancel()
        if old_ws is not None and old_ws is not websocket:
            try:
                await old_ws.close()
            except Exception:
                pass
        # Cancel any pending ACK-timeout timers from the OLD connection.
        # They no longer represent reality — the connection they were
        # tracking is gone, the events were either delivered or lost
        # before disconnect, and we shouldn't fire warnings post-hoc.
        for _seq, (_etype, _sent_at, timer) in old_pending.items():
            if not timer.done():
                timer.cancel()

    async def disconnect(self, guid: str):
        drain_to_cancel: Optional[asyncio.Task] = None
        pending_to_cancel: Dict[int, Tuple[str, float, asyncio.Task]] = {}
        async with self._lock:
            self._conns.pop(guid, None)
            self._last_seen.pop(guid, None)
            # Pop the queue so no new items can be enqueued for this
            # disconnected user. Pending items in the queue are
            # discarded — the connection is gone, there's nothing
            # to send them to.
            self._send_queues.pop(guid, None)
            drain_to_cancel = self._drain_tasks.pop(guid, None)
            # ACK identity is per-connection — gone on disconnect.
            self._conn_tokens.pop(guid, None)
            self._next_seq.pop(guid, None)
            pending_to_cancel = self._pending_acks.pop(guid, {})
        # Cancel outside the lock — cancellation triggers cleanup in
        # the drain task itself which may need to acquire the lock.
        if drain_to_cancel is not None and not drain_to_cancel.done():
            drain_to_cancel.cancel()
        # Cancel any pending ACK timeout timers. The events are gone
        # with the connection; no point alarming an operator about
        # ACKs that can never arrive.
        for _seq, (_etype, _sent_at, timer) in pending_to_cancel.items():
            if not timer.done():
                timer.cancel()

    def get_conn_token(self, guid: str) -> Optional[str]:
        """Return the current connection token for a guid, or None
        if no active connection. Used by tests and instrumentation."""
        return self._conn_tokens.get(guid)

    async def ack_received(self, guid: str, conn_token: str, seq: int) -> bool:
        """Mark an event as ACKed by the browser. Returns True if the
        ACK was credited to a pending event, False if it was stale,
        unknown, or for a different (likely previous) connection.

        Why we check conn_token: the browser may have an ACK in flight
        for a NOW-OLD connection (page reload + immediate ACK from the
        old page's last handler before the WebSocket closed). If we
        credited that ACK to the NEW connection's pending events, we'd
        incorrectly suppress the timeout warning. The conn_token rules
        that out — old ACK has old token, new pending list has new token,
        no match, ACK is silently discarded.
        """
        async with self._lock:
            current_token = self._conn_tokens.get(guid)
            if current_token is None or current_token != conn_token:
                # Stale ACK from a previous connection (or unknown user).
                # Silent reject — this is expected during page reloads
                # and is exactly what conn_token is here to catch.
                return False
            pending = self._pending_acks.get(guid)
            if not pending or seq not in pending:
                # ACK for an event we don't have on our pending list —
                # either it already timed out, or the seq is fabricated.
                # Either way, harmless.
                return False
            event_type, sent_at, timer = pending.pop(seq)
        # Cancel the timeout warning timer outside the lock.
        if not timer.done():
            timer.cancel()
        elapsed = time.monotonic() - sent_at
        logger.debug("ACK ok: %s %s seq=%d (%.1fms)",
                     guid[:8] + "...", event_type, seq, elapsed * 1000)
        return True

    async def _ack_timeout_warning(self, guid: str, seq: int,
                                    event_type: str, timeout: float):
        """Sleep until timeout, then log a warning if the ACK still
        hasn't arrived. Called from _drain_loop right after a tracked
        event is sent."""
        try:
            await asyncio.sleep(timeout)
        except asyncio.CancelledError:
            return
        async with self._lock:
            pending = self._pending_acks.get(guid)
            if not pending or seq not in pending:
                # Already ACKed during our sleep — nothing to do.
                return
            # Pop it so we don't double-warn if the ACK arrives late.
            pending.pop(seq, None)
        logger.warning(
            "ACK MISSING: guid=%s event=%s seq=%d (no client ack after %.1fs)"
            " — browser may not have processed this event",
            guid[:8] + "...", event_type, seq, timeout)

    def touch(self, guid: str):
        if guid in self._last_seen:
            self._last_seen[guid] = time.monotonic()

    def active_guids(self):
        return list(self._conns.keys())

    def count(self) -> int:
        return len(self._conns)

    async def safe_send(self, target, payload: dict) -> bool:
        """Enqueue a payload for delivery to a connection. Returns True
        if enqueued, False if the connection is unknown or queue is full.

        target: guid (str) or websocket. The websocket form is used by
        callers that have the ws directly (e.g. inside ws_endpoint).

        IMPORTANT: this method NEVER awaits ws.send_json directly. It
        appends to the per-connection queue. The drain task is the
        single writer for that connection — that's what makes ordering
        deterministic. Order is captured at queue insertion time, which
        is synchronous from the publisher's perspective; the event
        loop cannot reorder enqueued items.

        Returns False (without raising) on:
          - Unknown guid / closed connection
          - Queue full (slow consumer; alarm condition)
        """
        guid: Optional[str] = None
        if isinstance(target, str):
            guid = target
        else:
            # ws-based send: reverse-lookup the guid for queue routing
            async with self._lock:
                guid = next(
                    (g for g, w in self._conns.items() if w is target), None)
            if guid is None:
                return False

        async with self._lock:
            queue = self._send_queues.get(guid)

        if queue is None:
            return False

        try:
            # put_nowait: never block the publisher. If the queue is
            # full the consumer is stuck — that's a real problem we
            # want to surface, not paper over by blocking publishers.
            queue.put_nowait(payload)
            return True
        except asyncio.QueueFull:
            logger.warning(
                "Outbound queue full for %s (slow consumer); dropping payload",
                guid[:8] + "...")
            return False

    async def broadcast(self, payload: dict):
        """Enqueue payload to every connected user's outbound queue.

        Each user receives this broadcast in order relative to their own
        per-user events — metrics_snapshot cannot race against a service
        query for the same connection. Different connections receive the
        broadcast in parallel (each has its own drain task)."""
        async with self._lock:
            guids = list(self._send_queues.keys())
        for guid in guids:
            # safe_send handles the missing-queue case; we don't need
            # to re-check here
            await self.safe_send(guid, payload)

    async def _drain_loop(self, guid: str, ws, queue: asyncio.Queue):
        """The single writer for one connection.

        Reads payloads from the per-user queue in FIFO order, stamps each
        with the connection's conn_token + a monotonic seq (so the
        browser can ACK it back unambiguously), and writes to the
        WebSocket. This is the ONLY place ws.send_json is called for
        user-payload events (the ws_endpoint handler does the initial
        set_cookie/user_info handshake directly, before the drain task
        takes over — those happen synchronously inside the connect
        sequence so there's no concurrent send risk).

        For events listed in ACK_TRACKED_EVENT_TYPES, we register a
        timeout warning AFTER the send completes. If the browser doesn't
        ACK within ACK_TIMEOUT_S, the warning logs loudly so an operator
        can see exactly which event-for-which-user delivery was uncertain.

        On any send failure, this task triggers disconnect() and exits.
        On CancelledError (from disconnect or a fresh connect replacing
        us), exits cleanly.
        """
        try:
            while True:
                payload = await queue.get()
                # Stamp the payload with connection identity. We pull
                # token + seq under the lock so a concurrent reconnect
                # can't change conn_token mid-stamp. If the connection
                # was already replaced, conn_token will be None and we
                # skip ACK tracking (the send may still succeed on the
                # old ws, but we won't fire a stale ACK warning).
                event_type = payload.get("type", "")
                seq_for_ack: Optional[int] = None
                async with self._lock:
                    conn_token = self._conn_tokens.get(guid)
                    if conn_token is not None:
                        seq_for_ack = self._next_seq.get(guid, 0)
                        self._next_seq[guid] = seq_for_ack + 1
                        # Stamp identity directly on the payload that
                        # ships to the browser.
                        payload["_conn_token"] = conn_token
                        payload["_seq"] = seq_for_ack
                try:
                    await ws.send_json(payload)
                except Exception as e:
                    # Real network/state error — connection is gone.
                    # Schedule disconnect (which will also cancel us)
                    # and exit. We don't call disconnect here directly
                    # because it would deadlock waiting for us to die.
                    logger.info(
                        "Drain task for %s saw send error: %s; evicting",
                        guid[:8] + "...", e)
                    asyncio.create_task(self.disconnect(guid))
                    return
                # Send succeeded. If this is an ACK-tracked event type,
                # register a timeout warning. The timer is cancelled
                # when an ACK arrives (or when the connection ends).
                if (event_type in self.ACK_TRACKED_EVENT_TYPES
                        and seq_for_ack is not None
                        and conn_token is not None):
                    timer = asyncio.create_task(
                        self._ack_timeout_warning(
                            guid, seq_for_ack, event_type,
                            self.ACK_TIMEOUT_S),
                        name=f"ack_timeout_{guid[:8]}_{seq_for_ack}",
                    )
                    async with self._lock:
                        # Re-check the conn_token. If it changed during
                        # the send, we registered the wrong identity;
                        # cancel the timer and skip.
                        if self._conn_tokens.get(guid) == conn_token:
                            self._pending_acks.setdefault(guid, {})[seq_for_ack] = (
                                event_type, time.monotonic(), timer)
                        else:
                            timer.cancel()
        except asyncio.CancelledError:
            # Normal lifecycle event — disconnect or reconnect
            # cancelled us. Drain any pending items (they're going to
            # a closed socket anyway).
            return
        except Exception:
            # Belt and suspenders — never let an unhandled exception
            # in the drain loop kill the realm silently.
            logger.exception(
                "Unexpected error in drain task for %s", guid[:8] + "...")
            asyncio.create_task(self.disconnect(guid))

    async def ping_and_reap_loop(self):
        """Server-initiated liveness: app-level ping + staleness eviction."""
        while True:
            await asyncio.sleep(self.ping_interval)
            await self.broadcast({"type": "ping"})
            now = time.monotonic()
            async with self._lock:
                stale = [g for g, seen in self._last_seen.items()
                         if now - seen > self.stale_after]
            for guid in stale:
                async with self._lock:
                    ws = self._conns.get(guid)
                await self.disconnect(guid)
                logger.warning("Reaped stale connection %s", guid)
                if ws is not None:
                    try:
                        await ws.close()
                    except Exception:
                        pass


# --------------------------------------------------------------------------
# Queue processor v2 — per-item containment, stats always recorded
# --------------------------------------------------------------------------

@dataclass
class ProcessorStatus:
    last_heartbeat: float = field(default_factory=time.monotonic)
    is_running: bool = False
    processed: int = 0
    errors: int = 0


StatsRecorder = Callable[[dict, float, float], Awaitable[None]]
# signature: (queue_item, processing_time, cost)


class QueueProcessor:
    def __init__(self, queue: SafeQueue, manager: ConnectionManager,
                 engines: Engines, stats: StatsRecorder,
                 base_cost: float = 0.01, cost_per_second: float = 0.001,
                 extra_status: Optional[Callable[[], dict]] = None):
        self.queue = queue
        self.manager = manager
        self.engines = engines
        self.stats = stats
        self.base_cost = base_cost
        self.cost_per_second = cost_per_second
        self.extra_status = extra_status or (lambda: {})
        self.status = ProcessorStatus()
        self._stop = asyncio.Event()

    def stop(self):
        self._stop.set()

    async def _route(self, item: dict) -> dict:
        """Intent router. Returns {"result": ..., "result_type": ...}."""
        q = item["query"]
        qtype, mtype = q.get("query_type"), q.get("model_type")
        if qtype == "speech":
            q["prompt"] = await self.engines.stt(q.get("audio", ""))
            qtype = q["query_type"] = "chat"
        result = await self.engines.infer(q)
        if isinstance(result, bytes):
            import base64
            return {"result": base64.b64encode(result).decode(), "result_type": "image"}
        if mtype == "speech" and qtype != "imagine":
            return {"result": await self.engines.tts(result), "result_type": "audio"}
        return {"result": result, "result_type": "text"}

    async def run(self):
        self.status.is_running = True
        logger.info("Queue processor started")
        try:
            while not self._stop.is_set():
                self.status.last_heartbeat = time.monotonic()
                get_task = asyncio.ensure_future(self.queue.get())
                stop_task = asyncio.ensure_future(self._stop.wait())
                done, pend = await asyncio.wait(
                    {get_task, stop_task}, return_when=asyncio.FIRST_COMPLETED)
                for t in pend:
                    t.cancel()
                if stop_task in done:
                    if get_task in done and not get_task.cancelled():
                        cq = get_task.result()          # don't strand a dequeued item
                        await self._handle(cq)
                    break
                cq = get_task.result()
                await self._handle(cq)
        finally:
            self.status.is_running = False
            logger.info("Queue processor stopped")

    async def _handle(self, cq: CancellableQuery):
        guid = cq.item["user_guid"]
        started = time.monotonic()
        try:
            outcome = await cq.run(self._route)
            elapsed = time.monotonic() - started
            cost = self.base_cost + elapsed * self.cost_per_second
            # FIX BUG-4: stats recorded BEFORE attempting client delivery,
            # so a vanished client can't lose the accounting.
            try:
                await self.stats(cq.item, elapsed, cost)
            except Exception:
                logger.exception("Stats recorder failed (non-fatal)")
            await self.manager.safe_send(cq.item["websocket"], {
                "type": "query_result",
                **outcome,
                "processing_time": elapsed,
                "cost": cost,
            })
            self.status.processed += 1
        except asyncio.CancelledError:
            logger.info("Query cancelled for %s", guid)
        except Exception as e:
            self.status.errors += 1
            logger.exception("Query failed for %s", guid)
            await self.manager.safe_send(cq.item["websocket"],
                                         {"type": "error", "message": str(e)})
        finally:
            await self.queue.clear_inflight(guid)
            try:                                   # FIX: finally can't kill the loop
                await self.manager.broadcast({"type": "queue_update",
                                              "depth": self.queue.depth(),
                                              **self.extra_status()})
            except Exception:
                logger.exception("queue_update broadcast failed (contained)")


# --------------------------------------------------------------------------
# Watchdog v2 — restarts a wedged processor, parameterized for tests
# --------------------------------------------------------------------------

async def watchdog(processor_factory: Callable[[], QueueProcessor],
                   get_current: Callable[[], QueueProcessor],
                   set_current: Callable[[QueueProcessor], None],
                   interval: float = 300.0, heartbeat_timeout: float = 30.0,
                   on_restart: Optional[Callable[[], Awaitable[None]]] = None):
    while True:
        await asyncio.sleep(interval)
        proc = get_current()
        stale = time.monotonic() - proc.status.last_heartbeat
        if proc.status.is_running and stale > heartbeat_timeout:
            logger.error("Queue processor wedged (%.1fs); restarting", stale)
            proc.stop()
            new = processor_factory()
            set_current(new)
            asyncio.create_task(new.run())
            if on_restart:
                await on_restart()


# --------------------------------------------------------------------------
# Minimal realm app — the websocket protocol surface, wired to the core.
# webgui.py adopts these classes; the harness drives this app directly.
# --------------------------------------------------------------------------

def build_app(engines: Engines, *, max_queue_size: int = 100,
              ping_interval: float = 20.0, stale_after: float = 75.0,
              user_store: Optional[dict] = None,
              stats_log: Optional[list] = None):
    app = FastAPI()                                # FIX BUG: exactly ONE app
    users = user_store if user_store is not None else {}
    stats = stats_log if stats_log is not None else []
    queue = SafeQueue(maxsize=max_queue_size)
    manager = ConnectionManager(ping_interval=ping_interval, stale_after=stale_after)

    async def record_stats(item, elapsed, cost):
        stats.append({"guid": item["user_guid"],
                      "type": item["query"].get("query_type", "?"),
                      "time": elapsed, "cost": cost})

    processor = QueueProcessor(queue, manager, engines, record_stats)
    app.state.queue, app.state.manager, app.state.processor = queue, manager, processor

    @app.on_event("startup")
    async def _start():
        app.state.proc_task = asyncio.create_task(processor.run())
        app.state.reap_task = asyncio.create_task(manager.ping_and_reap_loop())

    @app.on_event("shutdown")
    async def _stop():
        processor.stop()
        app.state.reap_task.cancel()

    @app.websocket("/ws")
    async def ws_endpoint(websocket: WebSocket):
        await websocket.accept()
        guid = websocket.cookies.get("user_guid") or str(uuid.uuid4())
        user = users.setdefault(guid, {"guid": guid, "nickname": f"user_{guid[:8]}",
                                       "is_sysop": len(users) == 0,
                                       "is_banned": False})
        # FIX BUG-5: banned users are rejected BEFORE manager registration.
        if user["is_banned"]:
            await websocket.send_json({"type": "error", "message": "banned"})
            await websocket.close()
            return
        await manager.connect(websocket, guid)
        try:
            await websocket.send_json({"type": "set_cookie",
                                       "name": "user_guid", "value": guid})
            await websocket.send_json({"type": "user_info", "data": user})
            while True:
                data = await websocket.receive_json()
                mtype = data.get("type")
                manager.touch(guid)
                if mtype == "submit_query":
                    ok = await queue.put({"query": data["query"],
                                          "user_guid": guid,
                                          "websocket": websocket,
                                          "timestamp": time.time()})
                    if not ok:
                        await manager.safe_send(websocket,
                            {"type": "error", "message": "Queue is full"})
                    else:
                        await manager.broadcast({"type": "queue_update",
                                                 "depth": queue.depth()})
                elif mtype == "terminate_query" and user["is_sysop"]:
                    await queue.remove_by_guid(data["user_guid"])
                    await manager.broadcast({"type": "query_terminated",
                                             "guid": data["user_guid"]})
                elif mtype == "pong":
                    pass                            # touch already happened
                elif mtype == "ban_user" and user["is_sysop"]:
                    users.setdefault(data["user_guid"], {}).update(is_banned=True)
                else:
                    await manager.safe_send(websocket,
                        {"type": "error", "message": "Unknown message type"})
        except WebSocketDisconnect:
            pass
        except Exception:
            # FIX BUG-4: never try to send an error over a socket that just
            # failed — log and fall through to cleanup.
            logger.exception("ws loop error for %s", guid)
        finally:
            await manager.disconnect(guid)          # FIX BUG-5: no ghosts, ever

    return app
