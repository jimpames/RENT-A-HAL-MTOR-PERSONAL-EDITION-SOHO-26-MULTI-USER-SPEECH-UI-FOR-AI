"""
realm/pow_gate.py — Sprint 10: memory-hard proof-of-work anti-abuse gate.

Design recap (see ECONOMIC_LAYER_DESIGN.md Part A for the full
rationale): SHA-256 PoW is compute-bound, and RENT-A-HAL's own user
base is unusually GPU-rich (that's the whole premise of the project),
so a compute-bound puzzle is close to worthless as a toll against
exactly the population most likely to abuse it. Argon2id is
memory-hard instead — each attempt requires a dedicated block of RAM
(64MB below), and GPUs have comparatively limited memory bandwidth per
parallel thread, which collapses an attacker's parallelism advantage
from "billions of attempts/sec" to a few hundred, regardless of core
count.

Protocol shape (stateless, two round trips on paid tiers):
  1. Client calls a protected endpoint with no proof attached.
  2. If under the free-call threshold for their key (IP, or
     member_url for federation), served immediately — no puzzle, no
     round trip, the 99% case stays exactly as fast as it's always been.
  3. Past the free threshold, the server returns 402 with a signed,
     self-contained challenge (nothing stored server-side — see
     generate_challenge's docstring for why that matters).
  4. Client solves it, resubmits the SAME request with the solution
     attached. Server verifies cheaply first (HMAC + expiry), then
     spends real Argon2id compute ONLY on submissions that already
     passed the cheap check — see SubmissionThrottle's docstring for
     why even that ordering isn't sufficient on its own.

Two rate-limit identities, matching the two threat surfaces this
protects: source IP for the anonymous public endpoints (/api/ask,
/api/speak), member_url for federation endpoints (/federate/checkin)
where IP is a weaker signal (a peer realm's IP can be shared/dynamic
in ways an anonymous caller's usually isn't for a single session).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Tuple

from argon2.low_level import Type, hash_secret_raw

# ─── Argon2id parameters ─────────────────────────────────────────────
# Fixed regardless of tier — only the required leading-zero-bit count
# varies (see DEFAULT_TIERS). 64MB / time_cost=2 is roughly 50-100ms
# for a single honest attempt on ordinary hardware; the memory
# footprint is the load-bearing property, not the time.
ARGON2_MEMORY_COST_KIB = 65536     # 64 MB
ARGON2_TIME_COST = 2
ARGON2_PARALLELISM = 1
ARGON2_HASH_LEN = 32

# ─── Difficulty ladder ────────────────────────────────────────────────
# (call-count threshold, public tier label, required leading-zero bits)
# sorted ascending by threshold. See ECONOMIC_LAYER_DESIGN.md Part A.3
# for the wall-clock reasoning behind these specific numbers.
DEFAULT_TIERS: List[Tuple[int, str, int]] = [
    (0,   "free",     0),
    (10,  "pi-100",   4),
    (50,  "pi-1000",  8),
    (200, "pi-10000", 12),
]
# Beyond the last tier's threshold, difficulty keeps climbing rather
# than plateauing — sustained abuse past 200 calls/window gets
# proportionally more expensive, not capped at a fixed ceiling.
ESCALATION_STEP_CALLS = 200
ESCALATION_STEP_BITS = 2
# Hard cap so sustained abuse asymptotes to "extremely expensive"
# rather than "requires more compute than exists" — an unbounded
# difficulty is a footgun (a legitimate but very heavy user could
# wander into a puzzle nobody could ever solve), not extra security.
MAX_DIFFICULTY_BITS = 32


def tier_for_count(count: int,
                   tiers: List[Tuple[int, str, int]] = DEFAULT_TIERS
                   ) -> Tuple[str, int]:
    """Which tier applies for a key that has made `count` calls in the
    current rolling window. Pure function, no I/O — trivially testable
    in isolation from the rate tracker itself."""
    label, bits = tiers[0][1], tiers[0][2]
    for threshold, t_label, t_bits in tiers:
        if count >= threshold:
            label, bits = t_label, t_bits
    last_threshold = tiers[-1][0]
    if count > last_threshold:
        extra_steps = (count - last_threshold) // ESCALATION_STEP_CALLS
        bits = min(MAX_DIFFICULTY_BITS, bits + extra_steps * ESCALATION_STEP_BITS)
    return label, bits


def count_leading_zero_bits(data: bytes) -> int:
    """How many leading zero BITS (not bytes) `data` starts with —
    the classic hashcash difficulty measure, generalized below the
    byte level so difficulty can be tuned finely (each +1 here roughly
    doubles the expected attempt count)."""
    total = 0
    for byte in data:
        if byte == 0:
            total += 8
            continue
        total += 8 - byte.bit_length()
        break
    return total


def _sign(secret: bytes, challenge: bytes, expiry: float,
         difficulty_bits: int) -> str:
    """HMAC over (challenge, expiry, difficulty_bits) — ALL THREE,
    deliberately. Signing only (challenge, expiry) would let a client
    solve an easy puzzle honestly, then resubmit claiming a HIGHER
    difficulty_bits value than it actually solved for (since nothing
    would stop it from just editing that field). Signing bits too
    means the server can trust whatever difficulty_bits arrives in a
    solution: if the signature checks out, WE issued exactly that
    (challenge, expiry, bits) triple, unmodified."""
    msg = challenge + f"{expiry:.3f}".encode() + str(difficulty_bits).encode()
    return hmac.new(secret, msg, hashlib.sha256).hexdigest()


def _argon2_raw(challenge: bytes, nonce: bytes) -> bytes:
    """The actual memory-hard computation. `nonce` (the client's guess)
    plays the role Argon2 calls 'secret' (the thing being brute-forced
    across attempts); `challenge` (fixed per-puzzle, server-issued)
    plays 'salt'. This repurposing is intentional — Argon2id doesn't
    care what the caller calls the roles, only that salt is >= 8 bytes
    (our 16-byte challenge clears that easily)."""
    return hash_secret_raw(
        secret=nonce,
        salt=challenge,
        time_cost=ARGON2_TIME_COST,
        memory_cost=ARGON2_MEMORY_COST_KIB,
        parallelism=ARGON2_PARALLELISM,
        hash_len=ARGON2_HASH_LEN,
        type=Type.ID,
    )


def generate_challenge(secret: bytes, difficulty_bits: int, tier_label: str,
                       ttl_s: float = 60.0) -> dict:
    """A self-contained, signed challenge. Deliberately NOT stored
    anywhere server-side — no database write, no in-memory table of
    outstanding challenges to clean up, and it scales to any number of
    server processes for free (any instance holding the same
    `secret` can verify a challenge issued by any other instance).
    The signature is what makes statelessness safe: a client can't
    forge a challenge we never issued, because it can't produce a
    valid signature without the server's secret."""
    challenge = secrets.token_bytes(16)
    expiry = time.time() + ttl_s
    signature = _sign(secret, challenge, expiry, difficulty_bits)
    return {
        "challenge": base64.urlsafe_b64encode(challenge).decode("ascii"),
        "expiry": expiry,
        "difficulty_bits": difficulty_bits,
        "signature": signature,
        "tier": tier_label,
    }


def verify_solution(secret: bytes, solution: dict) -> Tuple[bool, str]:
    """Verify a submitted {challenge, expiry, difficulty_bits,
    signature, nonce} solution. Checks are ordered CHEAP-FIRST,
    EXPENSIVE-LAST on purpose:

      1. Well-formed?               (near-free)
      2. Signature valid?           (one HMAC — near-free)
      3. Not expired?               (a float comparison — free)
      4. Argon2id(challenge, nonce) has >= difficulty_bits leading
         zero bits?                 (~50-100ms + 64MB — the expensive
                                      check, deliberately last)

    This ordering is load-bearing, not cosmetic: a forged or expired
    submission gets rejected at step 2 or 3, before the server ever
    spends real compute on it. Only submissions that already prove
    "this really is a challenge we issued, and it hasn't expired"
    reach the Argon2id computation — see SubmissionThrottle for the
    additional cheap gate needed even so (a flood of otherwise-valid-
    looking-but-wrong nonces against a single still-live challenge can
    still force real server-side work through this door alone)."""
    try:
        challenge_b64 = solution["challenge"]
        expiry = float(solution["expiry"])
        difficulty_bits = int(solution["difficulty_bits"])
        signature = solution["signature"]
        nonce_b64 = solution["nonce"]
    except (KeyError, TypeError, ValueError):
        return False, "malformed solution"

    try:
        challenge = base64.urlsafe_b64decode(challenge_b64)
        nonce = base64.urlsafe_b64decode(nonce_b64)
    except Exception:
        return False, "malformed encoding"

    expected_sig = _sign(secret, challenge, expiry, difficulty_bits)
    if not hmac.compare_digest(expected_sig, signature):
        return False, "invalid signature"
    if time.time() > expiry:
        return False, "challenge expired"

    digest = _argon2_raw(challenge, nonce)
    actual_bits = count_leading_zero_bits(digest)
    if actual_bits < difficulty_bits:
        return False, "insufficient difficulty"
    return True, "ok"


def solve_challenge(challenge: dict, max_attempts: int = 50_000_000) -> Optional[dict]:
    """Reference CLIENT-side solver — brute force nonces until
    Argon2id(challenge, nonce) has enough leading zero bits. Included
    here (not just in a test file) because it's genuinely useful as
    the reference implementation any real client — including our own
    test suite — solves against. Not optimized; a real high-volume
    client would parallelize across processes, which is fine and
    expected (that's the honest cost the puzzle is supposed to impose)."""
    challenge_bytes = base64.urlsafe_b64decode(challenge["challenge"])
    bits = challenge["difficulty_bits"]
    for attempt in range(max_attempts):
        nonce = attempt.to_bytes(8, "big")
        digest = _argon2_raw(challenge_bytes, nonce)
        if count_leading_zero_bits(digest) >= bits:
            return {
                "challenge": challenge["challenge"],
                "expiry": challenge["expiry"],
                "difficulty_bits": bits,
                "signature": challenge["signature"],
                "nonce": base64.urlsafe_b64encode(nonce).decode("ascii"),
            }
    return None


# ─── Rate tracking ─────────────────────────────────────────────────

class RateLimitTracker:
    """Sliding-window call counter, per key. A plain dict-of-deques
    with no locking — correct for a single-process asyncio app the
    same way Metrics (orchestrator.py) has no locking either: asyncio
    tasks interleave cooperatively, never truly in parallel within one
    event loop, so simple append/pop operations don't need a lock
    here. If this ever runs across multiple worker processes, the
    tracker would need to move to a shared store (Redis) — not a
    concern for the current single-instance deployment story."""

    def __init__(self, window_s: float = 600.0):
        self.window_s = window_s
        self._calls: Dict[str, Deque[float]] = defaultdict(deque)

    def _prune(self, key: str, now: float) -> None:
        dq = self._calls.get(key)
        if not dq:
            return
        cutoff = now - self.window_s
        while dq and dq[0] < cutoff:
            dq.popleft()

    def count(self, key: str, now: Optional[float] = None) -> int:
        now = now if now is not None else time.time()
        self._prune(key, now)
        return len(self._calls.get(key, ()))

    def record(self, key: str, now: Optional[float] = None) -> None:
        now = now if now is not None else time.time()
        self._prune(key, now)
        self._calls[key].append(now)


class SubmissionThrottle:
    """Cheap, crypto-free first-line gate in front of verify_solution's
    Argon2id computation. Argon2id verification isn't free for the
    SERVER either — it pays the same ~50-100ms/64MB cost the client
    does, for every submission, right or wrong. Without this throttle,
    an attacker could flood the submission endpoint with garbage
    nonces against a single still-valid challenge and force the
    server to spend real compute on every one, even though none of
    them will ever pass. This is a plain O(1) counter with zero
    cryptographic work, so it can reject a flood cheaply before a
    single Argon2id hash runs — the cheap gate in front of the
    expensive gate, same principle as verify_solution's own internal
    ordering, one layer up."""

    def __init__(self, max_per_window: int = 20, window_s: float = 10.0):
        self.max_per_window = max_per_window
        self.window_s = window_s
        self._attempts: Dict[str, Deque[float]] = defaultdict(deque)

    def allow(self, key: str, now: Optional[float] = None) -> bool:
        now = now if now is not None else time.time()
        dq = self._attempts[key]
        cutoff = now - self.window_s
        while dq and dq[0] < cutoff:
            dq.popleft()
        if len(dq) >= self.max_per_window:
            return False
        dq.append(now)
        return True


@dataclass
class CheckResult:
    allowed: bool
    status_code: int = 402
    response_body: Optional[dict] = None


class PowGate:
    """The gate function endpoints actually call — same shape as
    app.py's federation_token_error(): a single call returns either
    "proceed" or "here's the response to send instead," so wiring it
    into an endpoint is a two-line addition, not a restructure.

    enabled=False makes every call trivially pass — the config-level
    off switch (matches every other feature in this codebase: opt-in,
    off means truly off, not just a higher free tier)."""

    def __init__(self, secret: bytes,
                 tiers: List[Tuple[int, str, int]] = DEFAULT_TIERS,
                 window_s: float = 600.0,
                 challenge_ttl_s: float = 60.0,
                 submission_max_per_window: int = 20,
                 submission_window_s: float = 10.0,
                 enabled: bool = True):
        if enabled and (not secret or len(secret) < 16):
            raise ValueError(
                "PowGate secret must be at least 16 bytes when enabled — "
                "a short/predictable secret defeats the whole signature "
                "scheme (see _sign's docstring for why the signature is "
                "load-bearing).")
        self.secret = secret
        self.tiers = tiers
        self.enabled = enabled
        self.challenge_ttl_s = challenge_ttl_s
        self._tracker = RateLimitTracker(window_s)
        self._throttle = SubmissionThrottle(submission_max_per_window,
                                            submission_window_s)

    def check(self, key: str, solution: Optional[dict]) -> CheckResult:
        if not self.enabled:
            return CheckResult(allowed=True)

        count = self._tracker.count(key)
        tier_label, bits = tier_for_count(count, self.tiers)

        if bits == 0:
            # Free tier — no puzzle, no round trip. This is the 99%
            # case and it must stay exactly as fast as it's always been.
            self._tracker.record(key)
            return CheckResult(allowed=True)

        if solution is None:
            challenge = generate_challenge(self.secret, bits, tier_label,
                                          self.challenge_ttl_s)
            return CheckResult(
                allowed=False,
                response_body={"error": "proof_of_work_required", **challenge})

        # Cheap gate before the expensive one.
        if not self._throttle.allow(key):
            return CheckResult(
                allowed=False, status_code=429,
                response_body={"error": "too_many_attempts",
                               "retry_after_s": self._throttle.window_s})

        ok, reason = verify_solution(self.secret, solution)
        if not ok:
            challenge = generate_challenge(self.secret, bits, tier_label,
                                          self.challenge_ttl_s)
            return CheckResult(
                allowed=False,
                response_body={"error": f"invalid_proof_of_work: {reason}",
                               **challenge})

        # Valid proof of whatever difficulty was SIGNED into the
        # challenge it solved — not re-derived against the CURRENT
        # count. This is deliberate: between issuance and resubmission,
        # the count for this key hasn't meaningfully changed (that's
        # the same request/response pair), and re-checking against a
        # possibly-drifted current tier would risk rejecting a
        # perfectly valid proof through no fault of the caller's.
        self._tracker.record(key)
        return CheckResult(allowed=True)
