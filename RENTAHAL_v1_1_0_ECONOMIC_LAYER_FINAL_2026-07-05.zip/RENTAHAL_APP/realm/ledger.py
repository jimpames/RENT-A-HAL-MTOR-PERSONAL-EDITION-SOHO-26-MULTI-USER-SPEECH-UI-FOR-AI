"""
realm/ledger.py — Sprint 11: the append-only, hash-chained ledger.

Not wired into app.py's boot path yet — that's Sprint 13 (consumer
balance) and Sprint 14 (donor payout). This sprint proves the ledger
primitive in isolation: a realm that never touches the economic layer
doesn't need Postgres running at all, matching every other feature in
this codebase (opt-in, nothing required).

Why Postgres, not SQLite (see ECONOMIC_LAYER_DESIGN.md Part B.1 for the
full reasoning): not a throughput question, a tamper-evidence one. A
SQLite file is bytes on disk anyone with filesystem access can silently
edit. This module's actual integrity guarantee comes from the hash
chain (verify_chain() below), not from which database engine happens
to store the bytes — Postgres is chosen for its mature concurrent-write
story and because a hand-rolled append-only discipline is much easier
to reason about with a real transactional database underneath it.

Append-only is enforced at three layers (see 001_ledger.sql's header
comment for the full breakdown): this module simply never exposes an
update/delete method, the hash chain makes any out-of-band tampering
detectable, and an optional DB-role hardening script
(002_ledger_permissions.sql.example) adds a third layer for real
deployments.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import asyncpg

MIGRATIONS_DIR = Path(__file__).parent / "migrations"

# The first row in the chain has no real predecessor — this fixed,
# publicly-known constant plays that role. Anyone verifying the chain
# from scratch starts by expecting THIS value as entry #1's prev_hash;
# a chain that doesn't start here is provably not the genuine one (or
# has been rewritten from row 1).
GENESIS_PREV_HASH = hashlib.sha256(b"RENT-A-HAL-LEDGER-GENESIS").hexdigest()

# A fixed, arbitrary 64-bit key for Postgres's advisory lock. Any
# constant works — what matters is that every Ledger instance
# (potentially in different processes) uses the SAME one, since the
# lock's whole purpose is serializing concurrent appends across
# however many connections are talking to this database.
_APPEND_LOCK_KEY = 0x52454E5441484C   # ASCII "RENTAHL", truncated to fit


@dataclass
class LedgerEntry:
    id: int
    entry_type: str
    account_id: str
    amount_micros: int
    reference: str
    metadata: Dict[str, Any]
    created_at_epoch_micros: int
    created_at: datetime
    prev_hash: str
    row_hash: str


@dataclass
class VerificationResult:
    valid: bool
    checked_count: int
    first_bad_id: Optional[int] = None
    reason: Optional[str] = None


class DuplicateEntryError(Exception):
    """Sprint 13 — raised by append_entry() when inserting a 'topup'
    entry would violate the topup-idempotency constraint (see
    004_ledger_idempotency.sql): the given `reference` was already used
    for a previous topup. This is the expected, correct outcome of a
    Stripe webhook redelivery — Stripe WILL retry webhook delivery, and
    a caller (the webhook handler) should catch this and treat it as
    an already-processed event (return success to Stripe, don't
    re-credit), not as an error condition."""
    def __init__(self, existing_entry: "LedgerEntry"):
        self.existing_entry = existing_entry
        super().__init__(
            f"Duplicate topup reference {existing_entry.reference!r} — "
            f"already recorded as entry id={existing_entry.id}")


def _canonical_metadata_json(metadata: Optional[Dict[str, Any]]) -> str:
    """Deterministic JSON serialization — sort_keys means the same
    dict always produces the same string regardless of insertion
    order, which matters because this string is hash input. A
    dict-ordering difference that didn't affect the hash would be a
    silent, subtle way for the tamper-evidence property to erode."""
    return json.dumps(metadata or {}, sort_keys=True, separators=(",", ":"))


def _compute_row_hash(entry_type: str, account_id: str, amount_micros: int,
                      reference: str, metadata_json: str,
                      created_at_epoch_micros: int, prev_hash: str) -> str:
    """The chain's core primitive. Deliberately does NOT include the
    row's own `id` — chain LINKAGE (this row's prev_hash equals the
    previous row's row_hash, checked by verify_chain) already detects
    reordering/insertion/deletion without needing id baked into the
    hash payload, which would create an awkward chicken-and-egg problem
    (id is only assigned by Postgres at INSERT time, after we'd already
    need the hash to insert)."""
    payload = "|".join([
        entry_type, account_id, str(amount_micros), reference,
        metadata_json, str(created_at_epoch_micros), prev_hash,
    ])
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class Ledger:
    """Async, connection-pooled ledger. Construct via `await
    Ledger.connect(dsn)`, not the constructor directly — connecting
    and running migrations are both async operations."""

    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    @classmethod
    async def connect(cls, dsn: str, run_migrations: bool = True) -> "Ledger":
        pool = await asyncpg.create_pool(dsn, min_size=1, max_size=10)
        ledger = cls(pool)
        if run_migrations:
            await ledger._run_migrations()
        return ledger

    async def close(self) -> None:
        await self._pool.close()

    # ─── Migrations ──────────────────────────────────────────────

    async def _run_migrations(self) -> None:
        """Deliberately NOT Alembic. This is a single-table schema at
        Sprint 11 — a full migration framework (versioned revision
        graph, autogenerate, env.py boilerplate) is real tooling
        weight this codebase has consistently avoided elsewhere
        (compare: FederationMatrix is a plain dict + asyncio.Lock, not
        an ORM). This is the minimal thing that actually needs to
        exist: a tracked-versions table, and any .sql file in
        migrations/ not yet applied gets applied in filename order,
        each in its own transaction. Deviates from
        ECONOMIC_LAYER_DESIGN.md's original Alembic mention on
        purpose — worth revisiting if the schema grows enough tables
        that a real migration graph starts paying for itself."""
        async with self._pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    version TEXT PRIMARY KEY,
                    applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
                )
            """)
            applied = {r["version"] for r in
                      await conn.fetch("SELECT version FROM schema_migrations")}
            # Only real .sql files — .sql.example (the optional hardening
            # script) is deliberately never auto-applied; see its own
            # header comment for why.
            migration_files = sorted(
                p for p in MIGRATIONS_DIR.glob("*.sql")
                if p.suffix == ".sql")
            for path in migration_files:
                version = path.name
                if version in applied:
                    continue
                sql = path.read_text(encoding="utf-8")
                async with conn.transaction():
                    await conn.execute(sql)
                    await conn.execute(
                        "INSERT INTO schema_migrations (version) VALUES ($1)",
                        version)

    # ─── Writing ─────────────────────────────────────────────────

    async def append_entry(self, entry_type: str, account_id: str,
                           amount_micros: int, reference: str = "",
                           metadata: Optional[Dict[str, Any]] = None
                           ) -> LedgerEntry:
        """Append one entry to the chain. Serialized via a Postgres
        advisory lock (pg_advisory_xact_lock) held for the duration of
        the transaction — this correctly serializes concurrent appends
        across MULTIPLE connections and even multiple app PROCESSES
        talking to the same database, not just within one Python
        process. An in-process asyncio.Lock alone wouldn't provide
        that guarantee if this ever runs as more than one worker.

        The lock is acquired BEFORE reading the current chain tip —
        acquiring it after would leave a window where two concurrent
        transactions could both read the same tip and compute
        conflicting next-hashes.

        Sprint 13: for entry_type='topup' with a non-empty reference,
        the database enforces (via 004_ledger_idempotency.sql's partial
        unique index) that the same reference can never be used twice.
        A second attempt — e.g. Stripe redelivering the same webhook
        event — raises DuplicateEntryError wrapping the ORIGINAL entry,
        rather than silently double-crediting or raising a raw,
        uncaught database exception. Callers that don't care about
        idempotency (any entry_type other than 'topup', or a topup with
        no reference) are completely unaffected — the constraint simply
        doesn't apply to them."""
        metadata_json = _canonical_metadata_json(metadata)
        now = datetime.now(timezone.utc)
        created_at_epoch_micros = int(now.timestamp() * 1_000_000)

        try:
            async with self._pool.acquire() as conn:
                async with conn.transaction():
                    await conn.execute(
                        "SELECT pg_advisory_xact_lock($1)", _APPEND_LOCK_KEY)
                    tip_row = await conn.fetchrow(
                        "SELECT row_hash FROM ledger_entries "
                        "ORDER BY id DESC LIMIT 1")
                    prev_hash = tip_row["row_hash"] if tip_row else GENESIS_PREV_HASH

                    row_hash = _compute_row_hash(
                        entry_type, account_id, amount_micros, reference,
                        metadata_json, created_at_epoch_micros, prev_hash)

                    record = await conn.fetchrow(
                        """
                        INSERT INTO ledger_entries
                            (entry_type, account_id, amount_micros, reference,
                             metadata, created_at_epoch_micros, created_at,
                             prev_hash, row_hash)
                        VALUES ($1, $2, $3, $4, $5::jsonb, $6, $7, $8, $9)
                        RETURNING id, entry_type, account_id, amount_micros,
                                 reference, metadata, created_at_epoch_micros,
                                 created_at, prev_hash, row_hash
                        """,
                        entry_type, account_id, amount_micros, reference,
                        metadata_json, created_at_epoch_micros, now,
                        prev_hash, row_hash,
                    )
        except asyncpg.UniqueViolationError:
            # The transaction above is already rolled back at this point
            # (Postgres aborts the whole transaction on any error inside
            # it) — this is a fresh, separate query, not a continuation
            # of the failed one.
            existing = await self._get_entry_by_reference(entry_type, reference)
            if existing is None:
                # Should be unreachable — the constraint only fires when
                # a matching row genuinely exists — but fail loudly
                # rather than silently if this invariant is ever wrong.
                raise RuntimeError(
                    f"UniqueViolationError on reference={reference!r} but "
                    f"no matching existing entry was found — this should "
                    f"be impossible; the topup-idempotency invariant may "
                    f"be broken.")
            raise DuplicateEntryError(existing)
        return _row_to_entry(record)

    async def _get_entry_by_reference(self, entry_type: str,
                                      reference: str) -> Optional[LedgerEntry]:
        async with self._pool.acquire() as conn:
            record = await conn.fetchrow(
                "SELECT * FROM ledger_entries WHERE entry_type = $1 "
                "AND reference = $2 LIMIT 1", entry_type, reference)
        return _row_to_entry(record) if record else None

    # ─── Reading ─────────────────────────────────────────────────

    async def get_balance(self, account_id: str) -> int:
        """Balance in micros, always DERIVED (SUM), never a stored/
        mutated running total — that's what makes the ledger
        authoritative rather than a cache that can silently drift from
        what the entries actually say."""
        async with self._pool.acquire() as conn:
            result = await conn.fetchval(
                "SELECT COALESCE(SUM(amount_micros), 0) FROM ledger_entries "
                "WHERE account_id = $1", account_id)
        return int(result)

    async def get_entries(self, account_id: str,
                          limit: int = 100) -> List[LedgerEntry]:
        async with self._pool.acquire() as conn:
            records = await conn.fetch(
                "SELECT * FROM ledger_entries WHERE account_id = $1 "
                "ORDER BY id DESC LIMIT $2", account_id, limit)
        return [_row_to_entry(r) for r in records]

    # ─── Verification ────────────────────────────────────────────

    async def verify_chain(self) -> VerificationResult:
        """Walk the entire table in id order, recomputing each
        row_hash from its own stored fields plus the PREVIOUS row's
        STORED row_hash, and confirm it matches. Any mismatch — a row
        edited, deleted, or reordered out of band — is caught here,
        regardless of how the tampering happened (direct SQL, a
        compromised credential, a bug that somehow bypassed the
        application layer). This is the actual integrity guarantee
        this whole module exists to provide; everything else is
        bookkeeping."""
        checked = 0
        expected_prev = GENESIS_PREV_HASH
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                async for record in conn.cursor(
                        "SELECT * FROM ledger_entries ORDER BY id ASC"):
                    checked += 1
                    entry = _row_to_entry(record)
                    if entry.prev_hash != expected_prev:
                        return VerificationResult(
                            valid=False, checked_count=checked,
                            first_bad_id=entry.id,
                            reason=(f"row {entry.id}: prev_hash does not "
                                   f"match previous row's row_hash — chain "
                                   f"broken (row deleted, reordered, or "
                                   f"this row's prev_hash was edited)"))
                    metadata_json = _canonical_metadata_json(entry.metadata)
                    recomputed = _compute_row_hash(
                        entry.entry_type, entry.account_id,
                        entry.amount_micros, entry.reference,
                        metadata_json, entry.created_at_epoch_micros,
                        entry.prev_hash)
                    if recomputed != entry.row_hash:
                        return VerificationResult(
                            valid=False, checked_count=checked,
                            first_bad_id=entry.id,
                            reason=(f"row {entry.id}: stored row_hash does "
                                   f"not match recomputed hash of its own "
                                   f"fields — this row's content was "
                                   f"edited after being written"))
                    expected_prev = entry.row_hash
        return VerificationResult(valid=True, checked_count=checked)


def _row_to_entry(record) -> LedgerEntry:
    metadata = record["metadata"]
    if isinstance(metadata, str):
        metadata = json.loads(metadata)
    return LedgerEntry(
        id=record["id"],
        entry_type=record["entry_type"],
        account_id=record["account_id"],
        amount_micros=record["amount_micros"],
        reference=record["reference"],
        metadata=metadata,
        created_at_epoch_micros=record["created_at_epoch_micros"],
        created_at=record["created_at"],
        prev_hash=record["prev_hash"],
        row_hash=record["row_hash"],
    )
