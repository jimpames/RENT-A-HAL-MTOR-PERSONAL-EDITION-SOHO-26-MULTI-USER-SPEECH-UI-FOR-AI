"""
RENT-A-HAL Federation — push-driven overflow routing between realms.

ARCHITECTURE
------------
A federated network of RENT-A-HAL instances ("members") share a single
"Federator" — a small coordination service that keeps a phonebook of
who's alive and how fast their LLM/TTS service is. No polling, no
central queue, no leader election.

Push-only check-in protocol:
  - Each member, every ~15s (with random startup jitter), POSTs its
    current LLM_avg_s, TTS_avg_s, and tokens_out to the Federator.
  - The Federator replies with the URL of the current best peer for
    LLM and for TTS.
  - When a member's LOCAL LLM_avg_s exceeds the configured threshold,
    a FederationLLMProvider at the head of the LLM chain routes the
    request to the suggested peer's /api/ask endpoint.
  - The latency of that federated call feeds back into the member's
    own avg, creating natural backoff (we stay in federation mode while
    we're slow, return to local automatically when we recover).

The Federator's "matrix" is just a dict[member_url] -> (llm_avg_s,
tts_avg_s, tokens_out, last_seen). The "matrix algebra" is argmin
over alive members. Members that miss 4 check-ins (60 seconds) are
sentinel-flagged as avg=1000 so the natural numeric comparison
deprioritizes them without any special branch.

TTS FEDERATION (next): the check-in protocol already carries tts_avg_s
and the matrix already returns best_tts_peer. When TTS gains a public
REST surface, a FederationTTSProvider will slot into the TTS chain
using exactly this infrastructure.

SECURITY
--------
RENT-A-HAL's /api/ask is intentionally open (see Little Johnny demo).
Federation does NOT change that posture — federated calls are just
regular /api/ask calls between members. Optional shared `token` in
federation.ini can gate the Federator endpoints if an operator wants
stronger control over who joins their phonebook.

Hop limit prevents cascades: federated calls include X-Federation-Hops:1
header. Receiving realm reads it and, if >= max_federation_hops, bypasses
its own federation provider for THIS request only (runs LLM locally).
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Set, Tuple

import aiohttp

logger = logging.getLogger(__name__)


# ─── Constants ────────────────────────────────────────────────────────

# Sentinel value for "this member missed too many check-ins". Any number
# this large will never win a min() comparison against a real average,
# so degraded members fall out of routing naturally with NO special
# branch in the matrix algorithm.
DEGRADED_AVG_S = 1000.0

# Default thresholds (overridable in federation.ini)
DEFAULTS = {
    "desire": "on",
    "master_url": "https://rentahal.com/federate/federator",
    "self_url": "",                              # operator must set
    "token": "",                                 # empty = open
    "prefer_federation_for_llm_avg_s": "31.0",
    "prefer_federation_for_tts_avg_s": "31.0",
    "checkin_interval_s": "15.0",
    "startup_jitter_s": "10.0",
    "degraded_after_missed_checkins": "4",
    "max_federation_hops": "1",
    "request_timeout_s": "20.0",                 # federated call timeout
    # Sprint 6: this node's declared primary role. Purely descriptive —
    # doesn't gate what capabilities get reported (that's driven by
    # which chains are actually configured; see app.py's
    # _federation_stats). Default 'chat' means every pre-Sprint-6
    # deployment is correctly classified with zero config changes.
    "node_type": "chat",
    # Comma list of capabilities beyond llm/tts to report in
    # capability_avg_s. Default preserves today's exact behavior.
    "report_capabilities": "vision,imagine",
}

FEDERATOR_DEFAULTS = {
    "enabled": "false",                          # is THIS realm the Federator?
    "state_file": "federation_state.json",
    "missed_after_s": "60.0",                    # 4 × 15s default
    "peer_advice_bump_s": "0.01",                # rotation defeat
    # Sprint 8: the Federator's OWN master switch for whether it ever
    # attempts conscription decisions at all, independent of any
    # individual member's own donor consent (Sprint 7's
    # allow_federation_conscription is per-DONOR; this is per-FEDERATOR
    # — two separate levels of control, matching "everything under
    # individual operator control" at both the member and the
    # federation-operator layer).
    "conscription_enabled": "true",
    # If the best NATIVE peer for a rank (i.e. a member whose own
    # declared node_type IS that rank) has an avg_s above this, demand
    # is considered high enough to look for a conscription donor.
    "conscription_trigger_avg_s": "10.0",
    # A donor candidate's OWN native-duty avg_s must be at or below
    # this to be considered "idle enough to spare." Deliberately a
    # separate number from conscription_trigger_avg_s — trigger is
    # about the SHORTAGE side, this is about the SPARE-CAPACITY side.
    "conscription_idle_avg_s": "2.0",
    # Ceiling applied when a donor doesn't report its own preferred
    # contract length (conscription_max_minutes absent from their
    # check-in). A donor that DOES report a shorter preference always
    # wins — this is only the fallback.
    "default_conscription_max_minutes": "15",
    # Multi-donor: how many simultaneous donors one rank may have
    # conscripted at once. Donors are added incrementally (at most one
    # per check-in cycle) while demand persists, up to this cap.
    "max_donors_per_rank": "2",
}

# Sprint 7: [FederationConscription] section — this realm's posture as a
# conscription DONOR. See federation.ini for the full explanation of
# each key; this is pure configuration with no behavioral effect until
# Sprint 8's Federator-side decision engine exists.
CONSCRIPTION_DEFAULTS = {
    "allow_federation_conscription": "on",
    "permitted_conscription_ranks": "",          # empty = opt-in required
    "max_conscription_minutes": "15",
}

# The three ranks conscription currently understands. Kept as a plain
# tuple (not derived from anywhere else) because it's a policy-layer
# vocabulary, not a capability-layer one — federation.py's capability
# reporting (Sprint 6) is genuinely open-ended (any string), but
# conscription's config surface intentionally names exactly the ranks
# an operator can reason about today.
CONSCRIPTION_RANKS = ("chat", "vision", "imagine")

# Sprint 8: translates conscription vocabulary ("chat") to capability-
# reporting vocabulary ("llm") for the one rank where they differ.
# 'chat' predates capability_avg_s entirely — its average has always
# lived in MemberRecord.llm_avg_s, a dedicated field, not a
# capability_avg_s entry (see _LEGACY_CAPABILITY_KINDS below). Vision
# and imagine happen to use the same name in both vocabularies, so
# they're identity mappings here, kept explicit rather than assumed.
RANK_TO_CAPABILITY_KIND = {"chat": "llm", "vision": "vision", "imagine": "imagine"}


# ─── Matrix entry ─────────────────────────────────────────────────────

# 'llm' and 'tts' stay as their own dataclass fields rather than folding
# into capability_avg_s below — every existing caller (the live
# rentahal.com Federator's persisted state file, FederationClient,
# the test suite) constructs and reads them directly as
# rec.llm_avg_s / rec.tts_avg_s. Changing that surface on a live
# production service is exactly the risk Sprint 6 rules out. New
# capabilities (vision, imagine, whatever comes after) get the open-
# ended dict from day one instead, with get_avg/set_avg as the one
# place that knows how to read either kind.
_LEGACY_CAPABILITY_KINDS = frozenset({"llm", "tts"})


@dataclass
class MemberRecord:
    """One member's stats as seen by the Federator."""
    url: str
    llm_avg_s: float = DEGRADED_AVG_S
    tts_avg_s: float = DEGRADED_AVG_S
    # Sprint 6: open-ended per-capability averages for anything beyond
    # the original two. Sparse by design — a key's ABSENCE means "this
    # member has never reported this capability" (no vision chain
    # configured, say), which is a different fact than "reporting the
    # DEGRADED sentinel" (configured but currently unhealthy). This
    # distinction matters for best_peer_for: a chat-only node must never
    # be selected as a vision peer just because everyone's default
    # vision average happens to collide at the sentinel value.
    capability_avg_s: Dict[str, float] = field(default_factory=dict)
    tokens_out: int = 0
    last_seen: float = 0.0          # monotonic timestamp, 0 = never seen
    # Sprint 8: this member's declared primary role, as sent in its
    # check-in (FederationConfig.node_type on the member's own side).
    # This field EXISTED conceptually since Sprint 6 (the wire payload
    # always included node_type) but the Federator never actually
    # stored it — a gap closed now because the conscription decision
    # engine needs to know who's NATIVE to a rank (no need to conscript
    # them into their own job) vs who'd be genuinely moonlighting.
    # Always present with a default, unlike the sparse capability_avg_s
    # — "chat" is a reasonable default for members from before this
    # field existed, and every member reports SOME node_type.
    node_type: str = "chat"
    # Sprint 7/8: which ranks THIS member has told us it's eligible to be
    # conscripted into (operator consent AND real configured provider,
    # already intersected client-side by FederationConfig.
    # eligible_conscription_ranks — see FederationClient._do_checkin).
    conscription_eligible_ranks: List[str] = field(default_factory=list)
    # Sprint 8: this donor's OWN preferred contract length, if reported
    # (their [FederationConscription] max_conscription_minutes). None
    # means "not reported" — the Federator falls back to its own
    # default_conscription_max_minutes ceiling. A donor's own SHORTER
    # preference always wins over the Federator's default; a donor
    # can't be assigned a LONGER contract than it explicitly wants.
    conscription_max_minutes: Optional[float] = None

    def get_avg(self, kind: str) -> float:
        """Unified accessor across legacy and open-ended capabilities.
        'llm'/'tts' read the dedicated fields; anything else reads
        capability_avg_s, defaulting to the DEGRADED sentinel for a
        kind this member has genuinely never reported."""
        if kind == "llm":
            return self.llm_avg_s
        if kind == "tts":
            return self.tts_avg_s
        return self.capability_avg_s.get(kind, DEGRADED_AVG_S)

    def set_avg(self, kind: str, value: float) -> None:
        if kind == "llm":
            self.llm_avg_s = value
        elif kind == "tts":
            self.tts_avg_s = value
        else:
            self.capability_avg_s[kind] = value

    def has_capability(self, kind: str) -> bool:
        """True if this member has ever reported this capability at all.
        Legacy kinds ('llm'/'tts') are always considered present — every
        check-in has always included both, going back to before
        capability_avg_s existed. Non-legacy kinds are present only if
        explicitly reported at least once."""
        if kind in _LEGACY_CAPABILITY_KINDS:
            return True
        return kind in self.capability_avg_s

    def is_alive(self, now: float, missed_after_s: float) -> bool:
        """True if last_seen is recent enough that we believe the member
        is healthy. Members past missed_after_s get DEGRADED sentinel
        applied to their averages instead of being deleted (so they can
        come back without re-registering)."""
        if self.last_seen == 0:
            return False
        return (now - self.last_seen) <= missed_after_s

    def effective_avg(self, kind: str, now: float,
                      missed_after_s: float) -> float:
        """The avg that matters for routing decisions. Returns the
        DEGRADED_AVG_S sentinel for stale members so they fall out of
        consideration naturally via argmin."""
        if not self.is_alive(now, missed_after_s):
            return DEGRADED_AVG_S
        return self.get_avg(kind)

    def to_dict(self) -> dict:
        d = {
            "url": self.url,
            "llm_avg_s": round(self.llm_avg_s, 3),
            "tts_avg_s": round(self.tts_avg_s, 3),
            "tokens_out": self.tokens_out,
            "last_seen": self.last_seen,
            # Sprint 8: always included, not sparse — every member has
            # SOME node_type (defaults to "chat"), unlike capability_avg_s
            # where absence is a meaningful signal in itself.
            "node_type": self.node_type,
        }
        # Only written when non-empty — keeps the persisted state file
        # and the /federate/matrix payload byte-identical to pre-Sprint-6
        # output for members that have never reported anything beyond
        # llm/tts. A future rollback to pre-Sprint-6 code reading this
        # file just ignores the extra key if present; an older reader
        # never sees it at all for members without it.
        if self.capability_avg_s:
            d["capability_avg_s"] = {
                k: round(v, 3) for k, v in self.capability_avg_s.items()}
        if self.conscription_eligible_ranks:
            d["conscription_eligible_ranks"] = list(self.conscription_eligible_ranks)
        if self.conscription_max_minutes is not None:
            d["conscription_max_minutes"] = self.conscription_max_minutes
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "MemberRecord":
        raw_caps = d.get("capability_avg_s") or {}
        capability_avg_s = {}
        for k, v in raw_caps.items():
            try:
                capability_avg_s[k] = float(v)
            except (TypeError, ValueError):
                continue    # tolerate a corrupted entry, drop just that key
        raw_ranks = d.get("conscription_eligible_ranks") or []
        conscription_eligible_ranks = [str(r) for r in raw_ranks
                                       if isinstance(r, str)]
        raw_max_minutes = d.get("conscription_max_minutes")
        try:
            conscription_max_minutes = (float(raw_max_minutes)
                                        if raw_max_minutes is not None else None)
        except (TypeError, ValueError):
            conscription_max_minutes = None
        return cls(
            url=d["url"],
            llm_avg_s=float(d.get("llm_avg_s", DEGRADED_AVG_S)),
            tts_avg_s=float(d.get("tts_avg_s", DEGRADED_AVG_S)),
            capability_avg_s=capability_avg_s,
            node_type=str(d.get("node_type") or "chat"),
            conscription_eligible_ranks=conscription_eligible_ranks,
            conscription_max_minutes=conscription_max_minutes,
            tokens_out=int(d.get("tokens_out", 0)),
            last_seen=float(d.get("last_seen", 0.0)),
        )


# ─── The matrix ───────────────────────────────────────────────────────


class FederationMatrix:
    """In-memory phonebook of federation members. Single source of truth
    for the Federator. Persistence is best-effort to a JSON state file.

    Lookups are simple argmin over alive members. The "slight bump" on
    the recommended peer (so consecutive lookups rotate through equally
    good peers) is applied to the in-memory value AFTER selection — the
    bump decays back when the peer's next genuine check-in lands.
    """

    def __init__(self, state_file: Optional[Path] = None,
                 missed_after_s: float = 60.0,
                 peer_advice_bump_s: float = 0.01,
                 conscription_enabled: bool = True,
                 conscription_trigger_avg_s: float = 10.0,
                 conscription_idle_avg_s: float = 2.0,
                 default_conscription_max_minutes: float = 15.0,
                 max_donors_per_rank: int = 2):
        self.members: Dict[str, MemberRecord] = {}
        self.state_file = state_file
        self.missed_after_s = missed_after_s
        # Bump value used to rotate through equally-good peers. Default
        # is small (10ms) — enough to deprioritize the just-recommended
        # peer slightly so a tied peer wins next time, without distorting
        # real load measurements meaningfully.
        self.peer_advice_bump_s = peer_advice_bump_s
        # Sprint 8: this Federator's own master switch and thresholds
        # for the conscription decision engine. See FEDERATOR_DEFAULTS
        # for the full explanation of each.
        self.conscription_enabled = conscription_enabled
        self.conscription_trigger_avg_s = conscription_trigger_avg_s
        self.conscription_idle_avg_s = conscription_idle_avg_s
        self.default_conscription_max_minutes = default_conscription_max_minutes
        # Multi-donor: how many SIMULTANEOUS donors one rank may have
        # conscripted at once. Default 2 — enough to meaningfully help
        # a genuinely overloaded rank without one shortage silently
        # eating every idle box in the network. See maybe_assign_
        # conscription for how donors get added incrementally, one
        # check-in cycle at a time, rather than all at once.
        self.max_donors_per_rank = max_donors_per_rank
        # Active contracts, keyed by rank -> LIST of donor contracts.
        # A rank can have zero, one, or (up to max_donors_per_rank)
        # multiple simultaneous donors. Deliberately NOT persisted to
        # state_file: contracts are ephemeral by design, and a
        # Federator restart naturally clearing them is the correct
        # behavior — the next check-in cycle re-evaluates from scratch
        # rather than resurrecting a possibly-stale assignment.
        self.active_contracts: Dict[str, List[dict]] = {}
        self._lock = asyncio.Lock()
        if state_file and state_file.exists():
            self._load_unsafe()

    def _load_unsafe(self):
        try:
            data = json.loads(self.state_file.read_text())
            for d in data.get("members", []):
                rec = MemberRecord.from_dict(d)
                self.members[rec.url] = rec
            logger.info("Federation matrix loaded %d members from %s",
                        len(self.members), self.state_file)
        except Exception as e:
            logger.warning("Federation matrix load failed: %s", e)

    def _save_unsafe(self):
        if not self.state_file:
            return
        try:
            tmp = self.state_file.with_suffix(self.state_file.suffix + ".tmp")
            tmp.write_text(json.dumps({
                "members": [rec.to_dict() for rec in self.members.values()],
                "saved_at": time.time(),
            }, indent=2))
            tmp.replace(self.state_file)
        except Exception as e:
            logger.warning("Federation matrix save failed: %s", e)

    async def upsert(self, url: str, llm_avg_s: float, tts_avg_s: float,
                     tokens_out: int,
                     capability_avg_s: Optional[Dict[str, float]] = None,
                     conscription_eligible_ranks: Optional[List[str]] = None,
                     node_type: str = "chat",
                     conscription_max_minutes: Optional[float] = None,
                     ) -> MemberRecord:
        """Record a check-in. Creates the member if first time we see
        them, otherwise updates their stats and bumps last_seen.

        capability_avg_s is optional and additive (Sprint 6). Members
        running pre-Sprint-6 code simply never pass it (None), and their
        llm_avg_s/tts_avg_s continue to update exactly as before. When
        the caller passes a dict — even an EMPTY one — it REPLACES the
        stored capability_avg_s wholesale, same "here's my current full
        set" semantics as conscription_eligible_ranks below. This is
        the fix for a staleness bug found after Sprint 6 shipped: the
        original merge-only logic meant a capability dropped from one
        check-in's payload (operator disabled LLaVA without restarting)
        kept advertising its last-known average forever, since nothing
        ever REMOVED a key. Passing None (not calling with this arg at
        all) is the only way to leave existing capability data
        untouched — every real caller (the check-in endpoint) always
        passes a dict, even {}, so this only matters for callers that
        generically don't know about capabilities at all.

        conscription_eligible_ranks is optional and additive (Sprint 7)
        — REPLACES the stored list wholesale each check-in (not merged),
        since it represents "here's my current full eligible set," not
        an incremental delta.

        node_type always overwrites (default "chat" — every member
        reports SOME value, unlike the genuinely-optional fields above).
        Sprint 8's decision engine is the first consumer: it needs to
        know who's NATIVE to a rank vs who'd be a genuine donor.

        conscription_max_minutes always overwrites too (including back
        to None if the caller doesn't pass one this check-in — a donor
        that stops reporting a preference correctly falls back to the
        Federator's own default ceiling, rather than being stuck with a
        stale preference forever)."""
        now = time.monotonic()
        async with self._lock:
            rec = self.members.get(url)
            if rec is None:
                rec = MemberRecord(url=url)
                self.members[url] = rec
            rec.llm_avg_s = float(llm_avg_s)
            rec.tts_avg_s = float(tts_avg_s)
            rec.node_type = node_type or "chat"
            rec.conscription_max_minutes = conscription_max_minutes
            if capability_avg_s is not None:
                validated = {}
                for k, v in capability_avg_s.items():
                    try:
                        validated[k] = float(v)
                    except (TypeError, ValueError):
                        continue    # tolerate one bad entry, drop just that key
                rec.capability_avg_s = validated   # REPLACE, not merge
            if conscription_eligible_ranks is not None:
                rec.conscription_eligible_ranks = [
                    str(r) for r in conscription_eligible_ranks
                    if isinstance(r, str)]
            rec.tokens_out = int(tokens_out)
            rec.last_seen = now
            self._save_unsafe()
            return rec

    async def best_peer_for(self, kind: str,
                            exclude_url: Optional[str] = None) -> Optional[str]:
        """Return URL of the alive member with smallest avg for the given
        capability kind ('llm', 'tts', or — Sprint 6 — any capability a
        member has reported, e.g. 'vision', 'imagine'), excluding
        `exclude_url` (typically the caller's own URL). Returns None if
        no alive peer exists.

        For 'llm'/'tts', every alive member is a candidate (unchanged
        from pre-Sprint-6 behavior — those two have always been present
        on every check-in). For any other kind, only members that have
        EXPLICITLY reported that capability at least once are
        candidates — this is what stops a chat-only node from being
        recommended as a vision peer just because its never-reported
        vision average and a real vision node's healthy-but-currently-
        degraded average could otherwise tie at the sentinel.

        After selection, applies a small bump to the chosen peer's avg
        so the next consecutive lookup will pick a different equally-good
        peer if one exists. The bump decays naturally when the peer's
        next genuine check-in lands."""
        now = time.monotonic()
        async with self._lock:
            candidates = [
                rec for url, rec in self.members.items()
                if url != exclude_url
                and rec.is_alive(now, self.missed_after_s)
                and rec.has_capability(kind)
            ]
            if not candidates:
                return None
            best = min(candidates, key=lambda r: r.get_avg(kind))
            # Apply rotation bump in place. This is intentionally
            # destructive to the in-memory matrix — the next genuine
            # check-in from `best` will overwrite the bumped value.
            best.set_avg(kind, best.get_avg(kind) + self.peer_advice_bump_s)
            return best.url

    def _select_conscription_donor_unsafe(self, rank: str,
                                          exclude_urls: Optional[Set[str]] = None
                                          ) -> Optional[str]:
        """Pick the best DONOR for conscripting into `rank`. Caller must
        already hold self._lock — this is a plain sync helper, not a
        re-entrant async method, because asyncio.Lock is not reentrant
        (calling back into best_peer_for's lock-acquiring pattern from
        inside another locked method would deadlock).

        A qualifying donor:
          - is alive
          - is NOT native to `rank` (their own node_type differs — a
            member whose job already IS `rank` isn't a "conscript",
            they're just... doing their job; ordinary best_peer_for
            already finds them)
          - has explicitly reported `rank` in conscription_eligible_ranks
            (operator consent AND a real configured provider — both
            already intersected client-side in Sprint 7)
          - has spare capacity, measured as: their OWN native-duty avg
            (get_avg on their own node_type's capability kind) is at or
            below conscription_idle_avg_s
          - is not in exclude_urls — the requester itself, AND (multi-
            donor) any donor already contracted for this SAME rank, so
            a second maybe_assign_conscription call looking to ADD a
            donor doesn't just re-pick the one already helping

        Among qualifiers, picks whichever has the MOST idle native duty
        (lowest own-avg) — the strongest signal of spare capacity
        available. We deliberately do NOT rank donors by how fast
        they'd be AT `rank` itself, because by definition a donor has
        never served it before (if they had, ordinary best_peer_for
        would already be finding them — conscription only matters for
        bringing genuinely new capacity online)."""
        now = time.monotonic()
        exclude_urls = exclude_urls or set()
        candidates = []
        for url, rec in self.members.items():
            if url in exclude_urls:
                continue
            if rec.node_type == rank:
                continue                     # native to this rank already
            if rank not in rec.conscription_eligible_ranks:
                continue                     # no consent + real provider
            if not rec.is_alive(now, self.missed_after_s):
                continue
            native_kind = RANK_TO_CAPABILITY_KIND.get(rec.node_type, "llm")
            native_avg = rec.get_avg(native_kind)
            if native_avg > self.conscription_idle_avg_s:
                continue                     # too busy at their own job
            candidates.append((native_avg, url))
        if not candidates:
            return None
        candidates.sort(key=lambda t: t[0])
        return candidates[0][1]

    async def maybe_assign_conscription(self, rank: str,
                                        requester_url: Optional[str] = None
                                        ) -> List[dict]:
        """The Sprint 8 decision engine, extended for multiple
        simultaneous donors. Called during a check-in from a member
        whose OWN native rank is `rank` — i.e. only a chat-native node
        ever asks about 'chat' contracts, since that's the rank whose
        demand is relevant to it. Returns the list of ALL currently
        active contracts for `rank` (possibly empty).

        Contract lifecycle, evaluated fresh on every call:
          1. Expired contracts are dropped from the list first.
          2. If the rank's native capacity is fine (best native peer's
             avg at or below conscription_trigger_avg_s), no NEW donor
             gets added — but existing live contracts are left running
             rather than yanked early; avoids thrashing a donor's
             workload the moment demand dips for one check-in cycle.
          3. If still under strain AND fewer than max_donors_per_rank
             donors are currently contracted, look for ONE additional
             qualifying donor (excluding the requester and every donor
             already contracted for this rank) and add it if found.
             This is deliberately incremental — one donor added per
             check-in cycle at most, not a rush to fill every slot
             immediately. If demand is still high next cycle, another
             donor can join then.

        Each contract's length = min(this Federator's default_
        conscription_max_minutes, that donor's OWN reported preference
        if any) — the donor's shorter preference always wins."""
        if not self.conscription_enabled:
            return []
        now = time.monotonic()
        async with self._lock:
            live = [c for c in self.active_contracts.get(rank, [])
                   if now < c["expires_at"]]
            self.active_contracts[rank] = live

            capability_kind = RANK_TO_CAPABILITY_KIND.get(rank, rank)
            native_candidates = [
                rec for rec in self.members.values()
                if rec.node_type == rank
                and rec.is_alive(now, self.missed_after_s)
                and rec.has_capability(capability_kind)
            ]
            if native_candidates:
                best_native_avg = min(r.get_avg(capability_kind)
                                      for r in native_candidates)
            else:
                # No native peers at all for this rank -> unambiguously
                # under strain (there's nothing to fall back to).
                best_native_avg = DEGRADED_AVG_S

            if best_native_avg <= self.conscription_trigger_avg_s:
                return live       # native capacity is fine; keep existing, add none

            if len(live) >= self.max_donors_per_rank:
                return live       # already at the cap for this rank

            exclude_urls = {requester_url} | {c["peer_url"] for c in live}
            donor_url = self._select_conscription_donor_unsafe(
                rank, exclude_urls=exclude_urls)
            if donor_url is None:
                return live       # demand is high, but no NEW donor to add

            donor = self.members[donor_url]
            minutes = self.default_conscription_max_minutes
            if donor.conscription_max_minutes is not None:
                minutes = min(minutes, donor.conscription_max_minutes)
            contract = {
                "peer_url": donor_url,
                "native_role": donor.node_type,
                "conscripted_as": rank,
                "assigned_at": now,
                "expires_at": now + minutes * 60.0,
            }
            live.append(contract)
            self.active_contracts[rank] = live
            return live

    async def get_donor_contracts(self, member_url: str) -> List[dict]:
        """Sprint 9 — donor-side visibility, extended for multi-donor.
        Any member checking in can ask 'which contracts am I currently
        serving as a donor for?' so ITS OWN cockpit can show
        'moonlighting as chat, N other realms also helping' — trust-
        building visibility for the operator whose idle GPU cycles are
        being used, symmetric to how the requester's own check-in
        response already tells THEM about the contracts via
        maybe_assign_conscription. A single member could in principle
        be a donor for more than one rank at once (though not the same
        rank twice), so this returns a list, not a single contract."""
        async with self._lock:
            return [c for contracts in self.active_contracts.values()
                   for c in contracts if c.get("peer_url") == member_url]

    async def get_all_contracts(self) -> Dict[str, List[dict]]:
        """Observability — every currently active contract, grouped by
        rank. Used by the /federate/contracts admin endpoint. Returns
        copies (both the outer dict and each inner list) so a caller
        mutating the result can't corrupt internal state. Ranks with
        no active contracts are omitted entirely (not present as an
        empty list) — both maybe_assign_conscription and revoke_contract
        leave a `[]` entry behind internally rather than deleting the
        key, so this filter is what keeps the observable dump clean of
        every rank that's ever merely been evaluated."""
        async with self._lock:
            return {rank: list(contracts)
                   for rank, contracts in self.active_contracts.items()
                   if contracts}

    async def revoke_contract(self, rank: str,
                              donor_url: Optional[str] = None
                              ) -> List[dict]:
        """Manually force-expire contract(s) for `rank` without waiting
        for natural expiry or restarting the Federator (which would
        clear every rank's contracts, not just the ones in question).

        donor_url=None (the default) revokes ALL contracts for `rank` —
        the original single-donor behavior, still the common case.
        Passing a specific donor_url revokes ONLY that donor's contract,
        leaving any OTHER donor still helping the same rank untouched —
        the multi-donor-aware fine-grained option.

        Returns the list of contracts that were actually revoked (empty
        list if none matched). The next check-in from any affected
        party naturally re-evaluates from scratch, exactly as if the
        contract(s) had expired on their own."""
        async with self._lock:
            live = self.active_contracts.get(rank, [])
            if donor_url is None:
                revoked = live
                self.active_contracts[rank] = []
            else:
                revoked = [c for c in live if c.get("peer_url") == donor_url]
                self.active_contracts[rank] = [
                    c for c in live if c.get("peer_url") != donor_url]
            return revoked

    async def get_state(self, member_url: str) -> str:
        """Return 'HEALTHY' / 'DEGRADED' / 'UNKNOWN' for a member."""
        now = time.monotonic()
        async with self._lock:
            rec = self.members.get(member_url)
            if rec is None:
                return "UNKNOWN"
            return "HEALTHY" if rec.is_alive(now, self.missed_after_s) \
                else "DEGRADED"

    async def snapshot(self) -> Dict[str, dict]:
        """Return a copy of the matrix for observability/debugging."""
        async with self._lock:
            return {url: rec.to_dict() for url, rec in self.members.items()}


# ─── Member-side check-in client ──────────────────────────────────────


@dataclass
class FederationConfig:
    """All federation knobs in one struct. Built from federation.ini."""
    desire: bool = True
    master_url: str = ""
    self_url: str = ""
    token: str = ""
    prefer_federation_for_llm_avg_s: float = 31.0
    prefer_federation_for_tts_avg_s: float = 31.0
    checkin_interval_s: float = 15.0
    startup_jitter_s: float = 10.0
    degraded_after_missed_checkins: int = 4
    max_federation_hops: int = 1
    request_timeout_s: float = 20.0
    # Sprint 6: this node's declared primary role — descriptive only,
    # see DEFAULTS["node_type"] above for why it doesn't gate reporting.
    node_type: str = "chat"
    # Sprint 7: conscription donor posture. See federation.ini and
    # CONSCRIPTION_DEFAULTS above for the full explanation.
    allow_federation_conscription: bool = True
    permitted_conscription_ranks: FrozenSet[str] = field(default_factory=frozenset)
    max_conscription_minutes: int = 15
    # Which capabilities beyond the built-in llm/tts get reported in
    # capability_avg_s. Default ("vision", "imagine") preserves exactly
    # today's behavior for every existing deployment. See app.py's
    # CAPABILITY_CHAINS registry for the chain-based capabilities that
    # get the full "only report if a REAL provider is configured"
    # safeguard; anything else in this list falls back to a weaker
    # "report if it's been served at least once" signal — see
    # _federation_stats' docstring in app.py for the full explanation
    # of that distinction and its limits.
    report_capabilities: FrozenSet[str] = field(
        default_factory=lambda: frozenset({"vision", "imagine"}))

    def permits_rank(self, rank: str) -> bool:
        """Pure policy check: does THIS realm's config permit itself to
        be conscripted into `rank`? Does NOT check whether the realm
        actually has a real provider for that rank — that's a separate
        fact combined in eligible_conscription_ranks() below. Kept
        split so each question stays independently testable."""
        if not self.allow_federation_conscription:
            return False
        if not self.permitted_conscription_ranks:
            return False
        if "any" in self.permitted_conscription_ranks:
            return True
        return rank in self.permitted_conscription_ranks

    def eligible_conscription_ranks(self, configured_ranks: Iterable[str]) -> Set[str]:
        """Intersect operator consent with actual configured capability.

        `configured_ranks` = the ranks THIS node currently has a REAL
        (non-Echo) provider for — e.g. {'chat', 'vision'} for a box
        with GPT4All + LLaVA but no Automatic1111 configured. A rank is
        eligible for conscription only if BOTH are true: the operator
        permits it in permitted_conscription_ranks, AND the node can
        actually serve it for real. This is the concrete answer to "a
        node with permitted_conscription_ranks=chat but no real LLM
        provider must never appear as a conscription candidate" — such
        a node has 'chat' permitted but not configured, so it's
        excluded here, before any Federator-side decision logic
        (Sprint 8) ever runs."""
        if not self.allow_federation_conscription:
            return set()
        configured = set(configured_ranks)
        if "any" in self.permitted_conscription_ranks:
            return configured
        return configured & self.permitted_conscription_ranks

    @classmethod
    def from_cfg(cls, cfg) -> "FederationConfig":
        def _get(key: str, default: str) -> str:
            try:
                return cfg.get("Federation", key, fallback=default).strip()
            except Exception:
                return default
        def _get_conscription(key: str, default: str) -> str:
            try:
                return cfg.get("FederationConscription", key,
                               fallback=default).strip()
            except Exception:
                return default
        raw_ranks = _get_conscription(
            "permitted_conscription_ranks",
            CONSCRIPTION_DEFAULTS["permitted_conscription_ranks"])
        # "none" is an explicit synonym for empty — see federation.ini.
        # Both parse to the empty frozenset (opt-out); "any" is kept as
        # a literal member of the set and interpreted by permits_rank()/
        # eligible_conscription_ranks() rather than expanded here, since
        # expansion requires knowing the node's configured capabilities,
        # which this parser doesn't have access to.
        if raw_ranks.strip().lower() == "none":
            permitted_ranks: FrozenSet[str] = frozenset()
        else:
            permitted_ranks = frozenset(
                r.strip().lower() for r in raw_ranks.split(",") if r.strip())
        raw_report_caps = _get("report_capabilities",
                              DEFAULTS["report_capabilities"])
        report_capabilities = frozenset(
            c.strip().lower() for c in raw_report_caps.split(",") if c.strip())
        return cls(
            desire=_get("desire", DEFAULTS["desire"]).lower() in ("on", "true", "1", "yes"),
            master_url=_get("master_url", DEFAULTS["master_url"]),
            self_url=_get("self_url", DEFAULTS["self_url"]),
            token=_get("token", DEFAULTS["token"]),
            node_type=_get("node_type", DEFAULTS["node_type"]) or DEFAULTS["node_type"],
            report_capabilities=report_capabilities,
            allow_federation_conscription=_get_conscription(
                "allow_federation_conscription",
                CONSCRIPTION_DEFAULTS["allow_federation_conscription"]
            ).lower() in ("on", "true", "1", "yes"),
            permitted_conscription_ranks=permitted_ranks,
            max_conscription_minutes=int(_get_conscription(
                "max_conscription_minutes",
                CONSCRIPTION_DEFAULTS["max_conscription_minutes"])),
            prefer_federation_for_llm_avg_s=float(
                _get("prefer_federation_for_llm_avg_s",
                     DEFAULTS["prefer_federation_for_llm_avg_s"])),
            prefer_federation_for_tts_avg_s=float(
                _get("prefer_federation_for_tts_avg_s",
                     DEFAULTS["prefer_federation_for_tts_avg_s"])),
            checkin_interval_s=float(_get("checkin_interval_s",
                                          DEFAULTS["checkin_interval_s"])),
            startup_jitter_s=float(_get("startup_jitter_s",
                                        DEFAULTS["startup_jitter_s"])),
            degraded_after_missed_checkins=int(
                _get("degraded_after_missed_checkins",
                     DEFAULTS["degraded_after_missed_checkins"])),
            max_federation_hops=int(_get("max_federation_hops",
                                         DEFAULTS["max_federation_hops"])),
            request_timeout_s=float(_get("request_timeout_s",
                                         DEFAULTS["request_timeout_s"])),
        )


class FederationState:
    """Live state for THIS realm as a federation member.

    Shared by the check-in client (writes member_state, reads stats)
    and by the FederationLLMProvider (reads best_peer_url).
    """
    def __init__(self, cfg: FederationConfig,
                 get_stats: callable):
        """get_stats is a no-arg callable returning a dict with at least
        llm_avg_s, tts_avg_s, tokens_out — the orchestrator's Metrics
        object satisfies this with a small adapter."""
        self.cfg = cfg
        self._get_stats = get_stats
        # State as seen by the UI:
        #   HEALTHY  — check-ins succeeding, federation usable
        #   DEGRADED — recent check-ins failing OR we're missing 4+
        #   OFF      — federation disabled by operator (desire=off)
        self.member_state: str = "OFF" if not cfg.desire else "HEALTHY"
        # Peers the Federator has recommended (advisory)
        self.best_llm_peer: Optional[str] = None
        self.best_tts_peer: Optional[str] = None
        # Sprint 6: generalized peer advice for any capability beyond
        # llm/tts (vision, imagine, ...), keyed by capability name. Kept
        # alongside best_llm_peer/best_tts_peer rather than replacing
        # them — those two fields are read directly by existing code
        # and tests; this is purely additive.
        self.best_peer: Dict[str, str] = {}
        # Sprint 8: the PRIMARY (first) active conscription contract
        # this realm has been offered by the Federator, if any —
        # {peer_url, native_role, conscripted_as, assigned_at,
        # expires_at}, or None. Kept for backward compat with any code
        # written against the single-donor shape; self.conscriptions
        # below is the full list (multi-donor aware) and is what new
        # code — FederationConscriptionProvider in particular — should
        # actually read, since it can fall through multiple donors if
        # the first one fails.
        self.conscription: Optional[dict] = None
        self.conscriptions: List[dict] = []
        # Sprint 9: the PRIMARY (first) contract THIS realm is currently
        # serving AS a donor, if any. self.donor_contracts below is the
        # full list — a realm can in principle donate to more than one
        # rank at once (though never the same rank twice). Independent
        # of self.conscription(s) above: a realm could theoretically be
        # BOTH struggling on its own native rank AND donating spare
        # capacity on a different rank at the same time, though in
        # practice a realm that's struggling is unlikely to also read
        # as idle.
        self.donor_contract: Optional[dict] = None
        self.donor_contracts: List[dict] = []
        # Diagnostic counters
        self.consecutive_failures: int = 0
        self.last_checkin_at: float = 0.0      # monotonic
        self.last_checkin_ok: bool = False
        self.last_checkin_error: str = ""

    def get_stats(self) -> dict:
        return self._get_stats()

    def to_ui_dict(self) -> dict:
        """Snapshot for the operator cockpit UI."""
        return {
            "desire": self.cfg.desire,
            "master_url": self.cfg.master_url,
            "self_url": self.cfg.self_url,
            "node_type": self.cfg.node_type,
            "state": self.member_state,
            "best_llm_peer": self.best_llm_peer,
            "best_tts_peer": self.best_tts_peer,
            "best_peer": dict(self.best_peer),
            "conscription": dict(self.conscription) if self.conscription else None,
            "conscriptions": [dict(c) for c in self.conscriptions],
            "donor_contract": dict(self.donor_contract) if self.donor_contract else None,
            "donor_contracts": [dict(c) for c in self.donor_contracts],
            "last_checkin_ok": self.last_checkin_ok,
            "consecutive_failures": self.consecutive_failures,
            "last_checkin_error": self.last_checkin_error,
            # Sprint 7: this realm's own conscription donor posture —
            # inert display data, no decision logic reads this yet.
            "allow_federation_conscription": self.cfg.allow_federation_conscription,
            "permitted_conscription_ranks": sorted(self.cfg.permitted_conscription_ranks),
            "max_conscription_minutes": self.cfg.max_conscription_minutes,
        }


class FederationClient:
    """Member-side: periodic check-in to the Federator. Pushes stats,
    receives peer advice."""

    def __init__(self, state: FederationState):
        self.state = state
        self._task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()

    async def start(self):
        if not self.state.cfg.desire:
            logger.info("Federation: desire=off, not starting check-in client")
            return
        if not self.state.cfg.self_url:
            logger.warning(
                "Federation: self_url is empty, can't check in. Set "
                "[Federation] self_url=https://your.realm/ in federation.ini")
            self.state.member_state = "OFF"
            return
        self._task = asyncio.create_task(self._loop(),
                                         name="federation_checkin")
        logger.info("Federation: check-in client started → %s",
                    self.state.cfg.master_url)

    async def stop(self):
        self._stop.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def immediate_checkin(self) -> bool:
        """Fire an out-of-band check-in NOW, outside the 15s loop.

        Used by the federation rescue path when local LLM/TTS recovers
        unexpectedly: we want the Federator's matrix to reflect our
        fresh stats immediately, not wait up to 15 seconds for the
        next scheduled check-in. Other realms will receive accurate
        peer advice on their next check-in.

        Returns True if the check-in succeeded, False otherwise. Safe
        to call concurrently with the background loop — if both fire
        at once, both update the matrix; last write wins, which is
        fine because we report the same stats.

        No-op when federation desire=off or self_url is unset (same
        gates as start())."""
        if not self.state.cfg.desire:
            return False
        if not self.state.cfg.self_url:
            return False
        before_state = self.state.member_state
        await self._do_checkin()
        # _do_checkin updates self.state.member_state. If it flipped
        # from non-HEALTHY to HEALTHY, the check-in worked.
        return self.state.member_state == "HEALTHY"

    async def _loop(self):
        # Random startup jitter so a whole datacenter restart doesn't
        # pile every member's first check-in on the Federator at once.
        jitter = random.uniform(0, self.state.cfg.startup_jitter_s)
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=jitter)
            return
        except asyncio.TimeoutError:
            pass
        while not self._stop.is_set():
            await self._do_checkin()
            try:
                await asyncio.wait_for(self._stop.wait(),
                                       timeout=self.state.cfg.checkin_interval_s)
                return
            except asyncio.TimeoutError:
                pass

    async def _do_checkin(self):
        stats = self.state.get_stats()
        payload = {
            "member_url": self.state.cfg.self_url,
            "llm_avg_s": float(stats.get("llm_avg_s", DEGRADED_AVG_S)),
            "tts_avg_s": float(stats.get("tts_avg_s", DEGRADED_AVG_S)),
            "tokens_out": int(stats.get("tokens_out", 0)),
            "token": self.state.cfg.token,
            # Sprint 6: purely additive. A Federator still running
            # pre-Sprint-6 code ignores unknown payload keys (it only
            # reads member_url/llm_avg_s/tts_avg_s/tokens_out/token),
            # so this is safe to send unconditionally even before every
            # Federator in a network has been upgraded.
            "node_type": self.state.cfg.node_type,
        }
        capability_avg_s = stats.get("capability_avg_s")
        # is not None (not just truthy) — an EMPTY dict must still be
        # sent. That's what lets the Federator distinguish "this node
        # has nothing to report right now" (clear any stale capability
        # data — see FederationMatrix.upsert's replace-not-merge fix)
        # from "this stats callable doesn't know about capabilities at
        # all" (the key is genuinely absent — true pre-Sprint-6 code).
        if capability_avg_s is not None:
            payload["capability_avg_s"] = dict(capability_avg_s)
        # Sprint 7: "configured_ranks" (from the stats callable, ultimately
        # app.py's chat_configured/vision_configured/imagine_configured
        # booleans) intersected with THIS realm's own consent config —
        # the actual answer to "what am I currently eligible to be
        # conscripted into." Computed here (not just forwarded from
        # stats) because the consent side of that intersection lives in
        # FederationConfig, not in the orchestrator's stats adapter.
        configured_ranks = stats.get("configured_ranks")
        if configured_ranks:
            eligible = self.state.cfg.eligible_conscription_ranks(configured_ranks)
            if eligible:
                payload["conscription_eligible_ranks"] = sorted(eligible)
                # Sprint 8: this donor's own preferred contract length —
                # the Federator respects whichever is SHORTER between
                # this and its own default ceiling. Only sent alongside
                # eligible ranks; a donor reporting no eligible ranks
                # has nothing for a contract length to apply to.
                payload["conscription_max_minutes"] = self.state.cfg.max_conscription_minutes
        url = self.state.cfg.master_url.rstrip("/") + "/checkin"
        try:
            timeout = aiohttp.ClientTimeout(total=self.state.cfg.request_timeout_s)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.post(url, json=payload) as r:
                    if r.status != 200:
                        raise RuntimeError(f"Federator returned {r.status}")
                    data = await r.json()
                    self._on_checkin_ok(data)
        except Exception as e:
            self._on_checkin_fail(str(e))

    def _on_checkin_ok(self, advice: dict):
        self.state.best_llm_peer = advice.get("best_llm_peer")
        self.state.best_tts_peer = advice.get("best_tts_peer")
        # Sprint 6: generalized advice for any capability beyond
        # llm/tts. A pre-Sprint-6 Federator's response simply won't
        # have this key — dict() of a missing key via `or {}` leaves
        # best_peer empty, which is exactly correct (nothing to route
        # to for a capability the Federator doesn't know how to advise
        # on yet).
        self.state.best_peer = dict(advice.get("best_peer") or {})
        # Multi-donor: the full list is authoritative; the singular
        # field is derived from it (first entry, or None) purely for
        # backward compat with any code still reading the old shape.
        # A pre-multi-donor Federator's response won't have
        # "conscriptions" at all — fall back to wrapping "conscription"
        # (the old singular field) in a one-element list, so a NEW
        # client talking to an OLD Federator still gets a usable list.
        conscriptions_raw = advice.get("conscriptions")
        if conscriptions_raw is not None:
            self.state.conscriptions = [dict(c) for c in conscriptions_raw]
        else:
            single = advice.get("conscription")
            self.state.conscriptions = [dict(single)] if single else []
        self.state.conscription = (dict(self.state.conscriptions[0])
                                   if self.state.conscriptions else None)

        donor_contracts_raw = advice.get("donor_contracts")
        if donor_contracts_raw is not None:
            self.state.donor_contracts = [dict(c) for c in donor_contracts_raw]
        else:
            single_donor = advice.get("donor_contract")
            self.state.donor_contracts = [dict(single_donor)] if single_donor else []
        self.state.donor_contract = (dict(self.state.donor_contracts[0])
                                     if self.state.donor_contracts else None)

        self.state.consecutive_failures = 0
        self.state.last_checkin_at = time.monotonic()
        self.state.last_checkin_ok = True
        self.state.last_checkin_error = ""
        self.state.member_state = "HEALTHY"
        logger.debug("Federation check-in OK: best_llm=%s best_tts=%s best_peer=%s "
                     "conscriptions=%d donor_contracts=%d",
                     self.state.best_llm_peer, self.state.best_tts_peer,
                     self.state.best_peer, len(self.state.conscriptions),
                     len(self.state.donor_contracts))

    def _on_checkin_fail(self, err: str):
        self.state.consecutive_failures += 1
        self.state.last_checkin_at = time.monotonic()
        self.state.last_checkin_ok = False
        self.state.last_checkin_error = err
        if (self.state.consecutive_failures
                >= self.state.cfg.degraded_after_missed_checkins):
            self.state.member_state = "DEGRADED"
        logger.info("Federation check-in failed (%d in a row): %s",
                    self.state.consecutive_failures, err)
