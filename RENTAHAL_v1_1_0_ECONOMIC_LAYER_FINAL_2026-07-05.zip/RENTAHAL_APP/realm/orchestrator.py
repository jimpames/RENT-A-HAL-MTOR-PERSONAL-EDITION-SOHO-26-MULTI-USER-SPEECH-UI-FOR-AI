"""
orchestrator.py — the conductor that lives on the event bus.

Subscribes to:
  intent_classified  -> queue the work, emit query_processing
  intent_stop        -> abort active TTS, abort in-flight LLM query
  intent_repeat      -> replay the last query_result for that user
  ping               -> pong (liveness)

Emits:
  query_queued, query_processing, query_result, query_failed
  tts_started, tts_chunk, tts_complete, tts_aborted
  pong

Per-user state (one Orchestrator instance manages all users):
  last_result[guid]    -> the most recent query_result event for REPEAT
  active_query[guid]   -> CancellableQuery handle for STOP
  active_tts[guid]     -> asyncio.Event flagged by tts cancellation

The orchestrator does NOT run inference itself. It delegates to:
  - the LLMChain (configurable provider order)
  - the TTSChain (configurable provider order)
  - the realm_core.QueueProcessor (the tested temporal queue)

This keeps the "ask anything" pipeline algebraic: each component does one
job, communicates through typed events, and is replaceable in isolation.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Dict, Optional

from .event_bus import EventBus, Event
from .engine_chain import LLMChain, TTSChain
from .realm_core import SafeQueue, CancellableQuery

logger = logging.getLogger("orchestrator")


@dataclass
class UserState:
    last_result: Optional[dict] = None     # for REPEAT
    active_query: Optional[CancellableQuery] = None
    active_tts_cancel: asyncio.Event = field(default_factory=asyncio.Event)
    # Browser-supplied geolocation for the service-finder realm.
    # Set when the browser sends a 'client_location' message after the user
    # grants geolocation permission. None until then; handler returns a
    # friendly error if no location is available.
    location: Optional[dict] = None       # {"lat": float, "lon": float, "ts": float}


def is_local_llm_provider(provider_name: Optional[str]) -> bool:
    """Classify a provider name as LOCAL LLM vs federation/fallback/echo.

    Used by the orchestrator to update Metrics.local_llm_available after
    each query, which in turn drives whether this realm advertises
    itself as a healthy LLM peer in federation check-ins.

    'Local LLM' means: a provider that does its OWN inference (GPT4All,
    Claude, HuggingFace, future local models). Federation providers
    (head and tail) forward to peer realms — they don't prove our local
    LLM is alive. Echo is the offline fallback — it explicitly means
    "no LLM available."

    Returns True if the provider name represents a local LLM, False
    otherwise. Extracted as a pure function so federation health
    classification is unit-testable without standing up the full
    orchestrator+chain machinery."""
    if not provider_name:
        return False
    name = provider_name.strip()
    if name in ("", "none"):
        return False
    if "Federation" in name:        # head FederationLLMProvider or tail Fallback
        return False
    if "Echo" in name:              # offline fallback
        return False
    return True


def is_local_tts_provider(provider_name: Optional[str]) -> bool:
    """TTS analogue of is_local_llm_provider. A 'local TTS' provider
    is one that synthesizes audio on this realm's machine (Kokoro,
    KokoroService, ElevenLabs, OpenAI TTS, SAPI5, pyttsx3 — all of
    them count as "we did the work locally" because the audio comes
    out of this realm even if the provider made a cloud API call).
    Federation TTS providers forward synth requests to peer realms,
    so they DON'T prove our local TTS is alive."""
    if not provider_name:
        return False
    name = provider_name.strip()
    if name in ("", "none"):
        return False
    if "Federation" in name:        # head or tail federation TTS
        return False
    return True


class Metrics:
    """Aggregate operator-visible counters across all users.

    Five gauges exposed via 'metrics_snapshot' bus events:
      - ai_queue_depth          (current pending+inflight in orchestrator queue)
      - tts_queue_depth         (in-flight TTS synth calls right now)
      - ai_avg_service_s        (rolling avg of recent AI query durations)
      - tts_avg_service_s       (rolling avg of recent Kokoro synth durations)
      - total_tokens_out        (cumulative since boot — savings vs cloud LLM)

    All metrics are best-effort; this class never raises, never blocks
    the hot path. Updates are O(1). Rolling averages use a fixed-size
    deque so memory is bounded regardless of uptime.
    """
    def __init__(self, window_size: int = 20):
        from collections import deque
        self._window_size = window_size
        # Rolling windows of (duration_seconds) for the last N queries
        self._ai_durations = deque(maxlen=window_size)
        self._tts_durations = deque(maxlen=window_size)
        # Sprint 6: per-capability rolling windows, keyed by intent kind
        # ('ask', 'weather', 'vision', 'imagine', ...). Created lazily
        # per kind on first use rather than pre-declared — new intent
        # kinds get tracking for free with zero code changes here.
        # This is what feeds federation's capability_avg_s reporting:
        # real measured latency per capability, not a blended average
        # across every kind of query the realm serves.
        self._kind_durations: Dict[str, "deque[float]"] = {}
        # Counters
        self.total_tokens_out = 0
        self.ai_queries_total = 0
        self.tts_calls_total = 0
        # Real-time gauges that callers will read
        self._tts_inflight = 0
        # Wallclock when realm started — for "uptime" display
        self.boot_time = time.time()
        # Health flag: is our LOCAL LLM actually serving queries?
        # Default optimistic (True) at boot, then updated by the
        # orchestrator after each query based on which provider answered.
        # Federation uses this to decide whether to advertise ourselves
        # as a healthy peer:
        #   - True  → report real llm_avg_s in check-ins; peers may federate to us
        #   - False → report DEGRADED_AVG_S sentinel; peers route elsewhere
        # The bug this fixes: when local LLM died and federation fallback
        # answered, llm_avg_s reflected the FEDERATED latency (e.g. 20s),
        # which was "healthy enough" to be advertised as a peer — but we
        # couldn't actually serve federation traffic, since our local
        # LLM was dead and the receiver's federation path is hop-blocked.
        # See FederationLLMFallbackProvider for the chain semantics.
        self.local_llm_available: bool = True
        # Same flag for TTS — drives whether we advertise as a healthy
        # TTS peer. Updated by the orchestrator after each TTS call.
        self.local_tts_available: bool = True

    def set_local_llm_available(self, available: bool) -> None:
        """Called by the orchestrator after each LLM query (and at boot
        after llm_chain.detect() probes providers). Idempotent — same
        value can be set repeatedly without side effects."""
        self.local_llm_available = bool(available)

    def reset_ai_window_to_local_recovery(self) -> None:
        """Clear the rolling AI duration window when local LLM recovers
        after a federation rescue period. Without this, stale federated
        call timings (e.g. 20-40s) would keep the rolling avg elevated
        for ~20 queries after recovery, causing the head federation
        provider to keep overflowing even though local is fast again.

        Called by the federation providers when their pre-flight probe
        finds local LLM responding. Also flips local_llm_available to
        True (the next check-in will report the realm as a healthy peer
        again). The next genuine LLM call will rebuild the window with
        real local timings.

        Why two effects in one method: the rolling window and the
        availability flag are both stale-state symptoms of "we thought
        local was dead but it's actually back." Clearing them together
        is one atomic recovery action — if you cleared one without the
        other, federation behavior would be inconsistent for the
        15-second window before the next check-in."""
        self._ai_durations.clear()
        self.local_llm_available = True

    def set_local_tts_available(self, available: bool) -> None:
        """TTS analogue of set_local_llm_available. Drives whether
        this realm advertises itself as a healthy TTS peer in
        federation check-ins."""
        self.local_tts_available = bool(available)

    def reset_tts_window_to_local_recovery(self) -> None:
        """TTS analogue of reset_ai_window_to_local_recovery. Clears
        the rolling TTS duration window and flips local_tts_available
        to True when the pre-flight probe finds local TTS responding."""
        self._tts_durations.clear()
        self.local_tts_available = True

    # ── AI side ──
    def record_ai_query(self, duration_s: float, tokens_out: Optional[int]):
        """Called when a query finishes. tokens_out is None for non-LLM kinds
        (weather/news/music/service); we only count LLM tokens toward the
        'savings vs cloud' total."""
        # Always count the query, even if duration/tokens are malformed.
        # We want ai_queries_total to be a reliable counter of "calls
        # made" even when individual fields are weird.
        self.ai_queries_total += 1
        try:
            if isinstance(duration_s, (int, float)) and duration_s > 0:
                self._ai_durations.append(float(duration_s))
        except Exception:
            pass
        try:
            if (isinstance(tokens_out, int) and tokens_out > 0):
                self.total_tokens_out += tokens_out
        except Exception:
            pass

    def record_capability_duration(self, kind: str, duration_s: float) -> None:
        """Sprint 6: record one query's elapsed time under its intent kind
        ('ask', 'weather', 'vision', 'imagine', ...), independent of
        record_ai_query's blended AI-wide window. Called by the
        orchestrator for EVERY kind, uniformly — this function doesn't
        know or care which kinds exist; a brand-new intent kind added
        next month gets its own rolling window automatically the first
        time it's recorded.

        Never raises — malformed duration is silently dropped, same
        defensive posture as record_ai_query."""
        from collections import deque
        try:
            if not (isinstance(duration_s, (int, float)) and duration_s > 0):
                return
        except Exception:
            return
        window = self._kind_durations.setdefault(
            kind, deque(maxlen=self._window_size))
        window.append(float(duration_s))

    def avg_for(self, kind: str) -> float:
        """Rolling average duration for one intent kind, or 0.0 if no
        samples yet. 0.0 (not the DEGRADED sentinel) is deliberate here —
        this is a raw measurement accessor; DEGRADED_AVG_S is a
        federation-layer policy concept (see app.py's _federation_stats
        adapter), not something Metrics itself should decide."""
        window = self._kind_durations.get(kind)
        if not window:
            return 0.0
        return sum(window) / len(window)

    # ── TTS side ──
    def tts_start(self):
        self._tts_inflight += 1

    def tts_end(self, duration_s: float):
        if self._tts_inflight > 0:
            self._tts_inflight -= 1
        self.tts_calls_total += 1
        try:
            if isinstance(duration_s, (int, float)) and duration_s > 0:
                self._tts_durations.append(float(duration_s))
        except Exception:
            pass

    @property
    def tts_queue_depth(self) -> int:
        return self._tts_inflight

    @property
    def ai_avg_service_s(self) -> float:
        if not self._ai_durations:
            return 0.0
        return sum(self._ai_durations) / len(self._ai_durations)

    @property
    def tts_avg_service_s(self) -> float:
        if not self._tts_durations:
            return 0.0
        return sum(self._tts_durations) / len(self._tts_durations)

    def snapshot(self, ai_queue_depth: int) -> dict:
        """Build a snapshot dict suitable for publishing on the bus.
        ai_queue_depth is passed in (the orchestrator's queue is the
        source of truth — we don't duplicate that counter)."""
        return {
            "ai_queue_depth": int(ai_queue_depth),
            "tts_queue_depth": int(self.tts_queue_depth),
            "ai_avg_service_s": round(self.ai_avg_service_s, 3),
            "tts_avg_service_s": round(self.tts_avg_service_s, 3),
            "total_tokens_out": int(self.total_tokens_out),
            "ai_queries_total": int(self.ai_queries_total),
            "tts_calls_total": int(self.tts_calls_total),
            "window_size": int(self._window_size),
            "uptime_s": round(time.time() - self.boot_time, 1),
        }


class Orchestrator:
    def __init__(self, bus: EventBus, llm: LLMChain, tts: TTSChain,
                 weather_handler=None, gmail_handler=None, news_handler=None,
                 music_handler=None, service_handler=None,
                 roundup_handler=None, vision_handler=None,
                 imagine_handler=None,
                 metrics_window: int = 20,
                 metrics_broadcast_interval_s: float = 2.0,
                 max_response_tokens: int = 1500,
                 ledger=None, billing_cfg=None):
        self.bus = bus
        self.llm = llm
        self.tts = tts
        self.weather_handler = weather_handler   # async (slots, guid) -> text
        self.gmail_handler = gmail_handler       # async (slots, guid) -> text
        self.news_handler = news_handler         # async (slots, guid, bus) -> text
        self.music_handler = music_handler       # async (slots, guid, bus) -> text
        self.service_handler = service_handler   # async (slots, guid, bus) -> text
        self.roundup_handler = roundup_handler   # async (slots, guid, bus) -> text
        # vision_handler gets the webcam frame (may be None if the browser's
        # pre-emptive capture guess was wrong, or capture failed) ahead of
        # slots/guid/bus — mirrors every other handler's trailing bus arg,
        # image is just an extra leading argument since it doesn't come
        # through slots (it's binary, not parsed from speech text).
        self.vision_handler = vision_handler     # async (image_b64, slots, guid, bus) -> text
        self.imagine_handler = imagine_handler   # async (slots, guid, bus) -> text
        # Ceiling for LLM answer length. Passed to llm.generate() for every
        # 'ask' query. Federation providers forward this to peer realms in
        # the POST body, so federated answers don't get silently truncated
        # to the chain's hardcoded 400-token default. Provided by app.py
        # from [LLMChain] max_response_tokens in config.ini.
        self.max_response_tokens = max_response_tokens
        # Sprint 13: optional prepaid-balance billing. Both None (the
        # default) means billing is entirely off — same "opt-in,
        # nothing required" posture as every other economic-layer
        # feature. Only meaningfully set when app.py has both [Ledger]
        # dsn AND [Billing] stripe keys configured.
        self.ledger = ledger
        self.billing_cfg = billing_cfg
        self.users: Dict[str, UserState] = {}
        self._queue = SafeQueue(maxsize=100)
        self._worker_task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()
        # ── Metrics ──
        self.metrics = Metrics(window_size=metrics_window)
        self._metrics_interval = metrics_broadcast_interval_s
        self._metrics_task: Optional[asyncio.Task] = None

    def _user(self, guid: str) -> UserState:
        return self.users.setdefault(guid, UserState())

    async def attach(self):
        await self.bus.subscribe("intent_classified", self._on_intent)
        await self.bus.subscribe("intent_stop", self._on_stop)
        await self.bus.subscribe("intent_repeat", self._on_repeat)
        await self.bus.subscribe("ping", self._on_ping)
        await self.bus.subscribe("client_location", self._on_client_location)
        self._worker_task = asyncio.create_task(self._worker_loop())
        self._metrics_task = asyncio.create_task(self._metrics_broadcast_loop())

    async def detach(self):
        self._stop.set()
        if self._worker_task:
            self._worker_task.cancel()
        if self._metrics_task:
            self._metrics_task.cancel()

    async def _metrics_broadcast_loop(self):
        """Periodically publish a snapshot of system metrics so all
        connected browsers can show queue depths + averages. Never raises;
        any exception just gets logged and the loop continues."""
        while not self._stop.is_set():
            try:
                snap = self.metrics.snapshot(self._queue.depth())
                # Broadcast to all users — no user_guid means ws_relay
                # delivers to every connection
                await self.bus.publish("metrics_snapshot", **snap)
            except Exception as e:
                logger.warning("metrics broadcast failed: %s", e)
            try:
                await asyncio.wait_for(self._stop.wait(),
                                       timeout=self._metrics_interval)
            except asyncio.TimeoutError:
                continue
            # _stop was set; exit
            return

    # ---------------- bus handlers ----------------

    async def _on_intent(self, ev: Event):
        guid = ev.payload.get("user_guid", "anonymous")
        nonce = ev.payload.get("nonce", "")
        kind = ev.payload.get("kind", "ask")
        slots = ev.payload.get("slots", {})
        text = ev.payload.get("text", "")
        # Only populated for a (guessed) vision intent — see intent.py's
        # _on_prompt for why this can legitimately be None even when
        # kind == "vision" (capture failed, permission denied, etc).
        image_b64 = ev.payload.get("image_b64")
        item = {"user_guid": guid, "nonce": nonce, "kind": kind,
                "slots": slots, "text": text, "image_b64": image_b64,
                "queued_at": time.monotonic()}
        if not await self._queue.put(item):
            await self.bus.publish("query_failed", nonce=nonce, user_guid=guid,
                                   error="queue full")
            return
        await self.bus.publish("query_queued", nonce=nonce, user_guid=guid,
                               kind=kind, depth=self._queue.depth())

    async def _on_stop(self, ev: Event):
        guid = ev.payload.get("user_guid", "anonymous")
        u = self._user(guid)
        # 1. Cancel anything queued OR in-flight for this user
        await self._queue.remove_by_guid(guid)
        # 2. Signal TTS to abort
        u.active_tts_cancel.set()
        await self.bus.publish("tts_aborted", user_guid=guid, reason="stop_stop")

    async def _on_repeat(self, ev: Event):
        guid = ev.payload.get("user_guid", "anonymous")
        u = self._user(guid)
        if u.last_result:
            # Re-speak the last text answer
            text = u.last_result.get("text", "")
            await self._speak(guid, text, nonce=ev.payload.get("nonce", ""))
        else:
            await self._speak(guid, "Nothing to repeat yet.",
                              nonce=ev.payload.get("nonce", ""))

    async def _on_ping(self, ev: Event):
        await self.bus.publish("pong", **ev.payload)

    async def _on_client_location(self, ev: Event):
        """Browser sends its lat/lon after the user grants geolocation
        permission. Cache it per user_guid so the service-finder handler
        can use it without round-tripping to the browser mid-query."""
        import time as _t
        guid = ev.payload.get("user_guid", "anonymous")
        lat = ev.payload.get("lat")
        lon = ev.payload.get("lon")
        # Basic sanity: real coordinates only. Anything else gets dropped
        # silently — a tampered browser sending lat=999 doesn't crash us.
        if not isinstance(lat, (int, float)) or not isinstance(lon, (int, float)):
            return
        if not (-90.0 <= lat <= 90.0) or not (-180.0 <= lon <= 180.0):
            return
        u = self._user(guid)
        u.location = {"lat": float(lat), "lon": float(lon), "ts": _t.time()}

    # ---------------- worker loop ----------------

    async def _worker_loop(self):
        while not self._stop.is_set():
            get_task = asyncio.ensure_future(self._queue.get())
            stop_task = asyncio.ensure_future(self._stop.wait())
            done, pending = await asyncio.wait(
                {get_task, stop_task}, return_when=asyncio.FIRST_COMPLETED)
            for t in pending:
                t.cancel()
            if stop_task in done and get_task not in done:
                break
            cq = get_task.result()
            await self._handle(cq)

    async def _handle(self, cq: CancellableQuery):
        import time as _time
        item = cq.item
        guid = item["user_guid"]
        nonce = item["nonce"]
        kind = item["kind"]
        prompt_text = item.get("text", "")
        u = self._user(guid)
        u.active_query = cq
        u.active_tts_cancel.clear()

        # Wallclock timestamps for the metric line. We send epoch seconds; the
        # browser formats them. Monotonic for elapsed so a system clock jump
        # mid-query can't produce a negative duration.
        start_wall = _time.time()
        start_mono = _time.monotonic()

        await self.bus.publish("query_processing", nonce=nonce, user_guid=guid,
                               started_at=start_wall, prompt=prompt_text)
        try:
            text = await cq.run(self._route)
        except asyncio.CancelledError:
            await self.bus.publish("query_failed", nonce=nonce, user_guid=guid,
                                   error="cancelled")
            await self._queue.clear_inflight(guid)
            return
        except Exception as e:
            logger.exception("query failed for %s", guid)
            await self.bus.publish("query_failed", nonce=nonce, user_guid=guid,
                                   error=str(e))
            await self._queue.clear_inflight(guid)
            return

        end_wall = _time.time()
        elapsed = _time.monotonic() - start_mono

        # Usage info from the chain (real or approximated). For weather/gmail
        # the LLM was never called, so leave usage blank — the UI will hide
        # the token portion of the metric line.
        usage = self.llm.last_usage if kind == "ask" else None
        tokens_out = usage["tokens_out"] if usage else None
        tokens_per_sec = (tokens_out / elapsed) if (tokens_out and elapsed > 0) else None
        approx = bool(usage and usage.get("approx"))

        result = {
            "text": text,
            "kind": kind,
            "nonce": nonce,
            "prompt": prompt_text,
            "llm_provider": self.llm.last_provider,
            "started_at": start_wall,
            "ended_at": end_wall,
            "elapsed_s": round(elapsed, 4),
            "tokens_out": tokens_out,
            "tokens_per_sec": round(tokens_per_sec, 2) if tokens_per_sec else None,
            "tokens_approx": approx,
        }
        u.last_result = result
        # Record metrics — duration and tokens_out (None for non-ask kinds).
        # We track ALL query durations (LLM and non-LLM), but only LLM
        # tokens count toward the "tokens saved" gauge.
        self.metrics.record_ai_query(elapsed, tokens_out)
        # Sprint 6: also record under the per-kind capability window.
        # Unlike record_ai_query's single blended window, this gives each
        # intent kind (weather, vision, imagine, ask, ...) its own rolling
        # average — the real number federation reports for that
        # capability, instead of an average diluted by every other kind
        # of query the realm happens to serve.
        self.metrics.record_capability_duration(kind, elapsed)
        # Sprint 13: flat per-submit debit, same hook as the metrics
        # recording just above (reusing the point where we already
        # know "a query was genuinely processed," not a duplicate
        # accounting path). Failures here are logged, never allowed to
        # break the actual response — a Postgres hiccup shouldn't take
        # down chat. Entirely inert when ledger/billing_cfg are None
        # (the default — see __init__).
        if self.ledger is not None and self.billing_cfg is not None:
            try:
                await self._debit_and_check_balance(guid)
            except Exception as e:
                logger.warning("Billing: debit failed for %s: %s", guid, e)
        # Update local-LLM health flag based on which provider answered.
        # This drives federation self-reporting: a realm whose local LLM
        # is dead must NOT advertise itself as a healthy peer to other
        # realms (their federated calls would fail).
        #
        # Classification lives in is_local_llm_provider() so it can be
        # unit-tested in isolation. We update only for kind="ask" —
        # non-LLM kinds (weather/music/service) don't touch the LLM
        # and shouldn't move the flag either way.
        if kind == "ask":
            is_local_llm = is_local_llm_provider(self.llm.last_provider)
            self.metrics.set_local_llm_available(is_local_llm)
        await self.bus.publish("query_result", user_guid=guid, **result)
        await self._queue.clear_inflight(guid)
        await self._speak(guid, text, nonce=nonce)

    async def _debit_and_check_balance(self, guid: str) -> None:
        """Sprint 13: debit one submit's flat price from `guid`'s
        ledger balance, then publish a low_balance bus event if the
        RESULTING balance has dropped below the configured warning
        threshold. Deliberately NOT a hard pre-flight gate — this
        codebase's PoW gate (Sprint 10) already provides the anti-abuse
        backstop; this is purely economic bookkeeping plus a UX nudge,
        consistent with the whole event-bus-driven UI pattern already
        used everywhere else (easter eggs, status badges, etc.) rather
        than a second independent HTTP-layer gate. See
        ECONOMIC_LAYER_DESIGN.md Sprint 13 notes for the full reasoning
        behind this scope decision.

        `reference=""` on the debit is deliberate: unlike topups
        (which must never double-credit on a Stripe webhook redelivery
        — see 004_ledger_idempotency.sql), a debit has no equivalent
        "this exact event might arrive twice" concern, so it doesn't
        need — and the partial unique index doesn't apply to — a
        unique reference."""
        price = self.billing_cfg.price_per_submit_micros
        await self.ledger.append_entry("debit", guid, -price, reference="")
        balance = await self.ledger.get_balance(guid)
        if balance < self.billing_cfg.low_balance_threshold_micros:
            await self.bus.publish("low_balance", user_guid=guid,
                                   balance_micros=balance)

    async def _route(self, item: dict) -> str:
        kind = item["kind"]
        text = item["text"]
        slots = item["slots"]
        if kind == "weather":
            if self.weather_handler:
                return await self.weather_handler(slots, item["user_guid"])
            return "Weather realm not configured."
        if kind == "gmail":
            if self.gmail_handler:
                return await self.gmail_handler(slots, item["user_guid"])
            return "Gmail realm not configured."
        if kind == "news":
            if self.news_handler:
                # News handler signature is different: it can also push a
                # story bundle to the browser via the bus. Returns the
                # spoken summary text.
                return await self.news_handler(slots, item["user_guid"],
                                               self.bus)
            return "News realm not configured."
        if kind == "music":
            # The music handler searches DuckDuckGo for a YouTube video ID
            # and publishes a 'music_search_request' bus event with the
            # video_id. The browser then embeds youtube.com/embed/<id>.
            # The realm never calls the YouTube API.
            if self.music_handler:
                return await self.music_handler(slots, item["user_guid"],
                                                self.bus)
            return "Music realm not configured."
        if kind == "service":
            # The service-finder handler reverse-geocodes the user's
            # browser location to a city name via Nominatim, then queries
            # BizData (OSM-backed) for nearby businesses in the requested
            # category. Publishes 'service_results' bus event with the
            # top 3 results; browser shows tappable cards with phone +
            # address + map link. Brief spoken summary for #1.
            if self.service_handler:
                return await self.service_handler(slots, item["user_guid"],
                                                  self.bus)
            return "Service finder not configured."
        if kind == "roundup":
            # ROUNDUP — voice trigger for radio-style auto-shuffle of
            # NPR + Guardian. The handler fetches stories from the Kokoro
            # service, builds the shuffled bundle, and publishes a
            # 'news_roundup_start' bus event. The browser's handler
            # for that event calls startRoundup(msg.stories) — same
            # code path as the ROUNDUP button click, but pre-loaded.
            if self.roundup_handler:
                return await self.roundup_handler(slots, item["user_guid"],
                                                  self.bus)
            return "Roundup not configured."
        if kind == "vision":
            # The vision handler runs the webcam frame through the
            # VisionChain (LLaVA, falling through to the Echo floor,
            # which also publishes the shared easter_egg_video bus event
            # so the client's video panel picks it up). Its return value
            # IS the answer text — it flows through the exact same
            # query_result -> answer box -> TTS path as every other kind,
            # so "the description lands in the same box as other AI
            # answers" falls out of the existing pipeline for free.
            if self.vision_handler:
                return await self.vision_handler(item.get("image_b64"),
                                                 slots, item["user_guid"],
                                                 self.bus)
            return "Vision realm not configured."
        if kind == "imagine":
            # The imagine handler runs the ImageChain (Automatic1111,
            # falling through to the Echo floor). Mirrors the music
            # handler's shape: publishes the actual image (or, on the
            # floor, the shared easter_egg_video event) via the bus for
            # the panel, and returns a short spoken confirmation text.
            if self.imagine_handler:
                return await self.imagine_handler(slots, item["user_guid"],
                                                   self.bus)
            return "Imagine realm not configured."
        # 'ask' and everything else: free-form LLM
        # Pass max_response_tokens so the chain — and any federation
        # provider downstream — respects the operator's configured ceiling
        # instead of the hardcoded 400-token default that was silently
        # truncating long answers mid-sentence.
        return await self.llm.generate(text, max_tokens=self.max_response_tokens)

    # ---------------- TTS ----------------

    async def _speak(self, guid: str, text: str, nonce: str = ""):
        if not text:
            return
        if self.bus.ping("tts_started") == 0:
            # Soft ping: nobody is listening for TTS. Skip work.
            logger.debug("No TTS subscribers; skipping synth")
            return
        u = self._user(guid)
        u.active_tts_cancel.clear()
        await self.bus.publish("tts_started", user_guid=guid, nonce=nonce,
                               text=text, provider=None)
        # ── TTS metrics: track in-flight count + service time ──
        self.metrics.tts_start()
        tts_start_mono = time.monotonic()
        try:
            synth_task = asyncio.create_task(self.tts.synth(text))
            cancel_task = asyncio.create_task(u.active_tts_cancel.wait())
            done, pending = await asyncio.wait(
                {synth_task, cancel_task}, return_when=asyncio.FIRST_COMPLETED)
            for t in pending:
                t.cancel()
        finally:
            # Always record the end so the gauge can't get stuck up.
            self.metrics.tts_end(time.monotonic() - tts_start_mono)
        # Update local-TTS health flag based on which provider answered.
        # Parallel to LLM: a realm whose local TTS is dead must NOT
        # advertise as a healthy TTS peer. Classification lives in
        # is_local_tts_provider() so it's testable in isolation.
        is_local_tts = is_local_tts_provider(self.tts.last_provider)
        self.metrics.set_local_tts_available(is_local_tts)
        if cancel_task in done and synth_task not in done:
            await self.bus.publish("tts_aborted", user_guid=guid, nonce=nonce,
                                   reason="cancelled_during_synth")
            return
        audio = synth_task.result()
        if audio is None:
            await self.bus.publish("tts_aborted", user_guid=guid, nonce=nonce,
                                   reason="no_provider")
            return

        # Deferred-mode (click-to-listen): the provider returned the empty
        # sentinel and stashed an audio_id we can hand to the browser. The
        # browser shows a "click to listen" button and GETs the URL when
        # the user is ready. Useful when autoplay is blocked.
        if audio == "":
            provider = self.tts.providers[
                next(i for i, p in enumerate(self.tts.providers)
                     if p.name == self.tts.last_provider)
            ] if self.tts.last_provider else None
            audio_id = getattr(provider, "last_audio_id", None)
            if audio_id:
                # Build the URL the browser will fetch
                base = getattr(provider, "base_url", "")
                audio_url = f"{base}/audio/{audio_id}" if base else None
                await self.bus.publish("tts_audio_ref", user_guid=guid,
                                       nonce=nonce, audio_id=audio_id,
                                       audio_url=audio_url,
                                       provider=self.tts.last_provider)
                await self.bus.publish("tts_complete", user_guid=guid,
                                       nonce=nonce,
                                       provider=self.tts.last_provider)
                return
            # Sentinel without audio_id = misconfiguration; treat as abort
            await self.bus.publish("tts_aborted", user_guid=guid, nonce=nonce,
                                   reason="deferred_no_audio_id")
            return

        # Inline-mode (default): a single chunk for now. When we want true
        # streaming, the provider yields chunks; same event shape per chunk.
        await self.bus.publish("tts_chunk", user_guid=guid, nonce=nonce,
                               seq=0, audio_b64=audio,
                               provider=self.tts.last_provider)
        await self.bus.publish("tts_complete", user_guid=guid, nonce=nonce,
                               provider=self.tts.last_provider)
