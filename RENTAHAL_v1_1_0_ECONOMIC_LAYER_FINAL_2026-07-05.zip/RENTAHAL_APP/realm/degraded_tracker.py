"""
realm/degraded_tracker.py — Wall-clock degradation watchdog.

Tracks how long the LOCAL LLM (or TTS) has been continuously unhealthy
and federating to peers. After a configurable wall-clock threshold has
elapsed without local recovery, the chain enters DEGRADED state:

  - Federation provider refuses to federate (returns None from generate)
  - LLMChain falls through to Echo (or TTSChain falls through to pyttsx3)
  - Cockpit badge shows LocalSystemLLMDegraded.xpy / LocalSystemTTSDegraded.xpy
  - A loud ERROR-level log line fires
  - Federator is notified via the next check-in (sentinel value)

Why wall-clock and not call-count: a busy realm doing 60 queries/min
hits a 15-call cap in 15 seconds (false positive before real overheat
clears), while a quiet realm doing 1 query / 10 min takes 2.5 hours
to hit the same cap (operator never notified for an entire afternoon).
Time is the right axis.

Recovery is aggressive (matches the pre-flight probe pattern): the FIRST
successful local probe clears degraded immediately and fires the existing
recovery dance. If the model is wobbly post-restart and we bounce, we
re-enter degraded at the configured threshold again — the cost of a
wrong-direction bounce is one false-positive log line, not a system
hang. Worth it.

Why two independent trackers (LLM vs TTS): the two chains fail
independently. GPT4All can crash while Kokoro is fine, and vice versa.
The cockpit shows them separately, the dead-local sentinel reports them
separately, the degraded state must follow suit.

Sabotage-verified invariants:
  - mark_federated() called repeatedly with local still dead → degraded
    flips to True after `degraded_after_s` of monotonic time
  - mark_local_recovered() resets the tracker (degraded flips to False,
    elapsed timer cleared)
  - is_degraded() returns False before the first federation call (we
    haven't observed unhealthy behavior yet)
"""
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("realm.degraded_tracker")


@dataclass
class DegradedTracker:
    """Wall-clock watchdog for one chain (LLM or TTS).

    State machine:
      INITIAL          — no federation observed yet; is_degraded() = False
      FEDERATING       — mark_federated() called; observing wall-clock
      DEGRADED         — wall-clock exceeded threshold; is_degraded() = True
      RECOVERED        — mark_local_recovered() called; back to INITIAL

    There are three transitions and they're all explicit. No implicit
    state changes on time passing — degradation is computed lazily when
    is_degraded() is asked.
    """
    # Chain label for log messages. "LLM" or "TTS". Used in operator-
    # facing messages so they know which chain went degraded.
    chain_label: str = "LLM"

    # Wall-clock threshold. Once mark_federated() has been called and
    # `degraded_after_s` of wall-clock time has elapsed without a
    # recovery, is_degraded() flips to True.
    degraded_after_s: float = 300.0      # 5 minutes default

    # monotonic timestamp of the FIRST mark_federated() call since the
    # last recovery (or program start). Zero means "we haven't seen
    # federation yet". Never decreases except via mark_local_recovered.
    _first_federated_at: float = 0.0

    # Has the threshold been crossed? Sticky-true until recovery.
    # We cache this so we only log the transition ONCE per degraded
    # episode (not every is_degraded() call).
    _is_degraded_cached: bool = False

    # Monotonic timestamp of the most recent mark_federated() call.
    # Used by the operator-facing "how long degraded" diagnostic.
    _last_federated_at: float = 0.0

    # Optional callback fired ONCE per transition into degraded state.
    # Signature: on_degraded(chain_label: str, elapsed_s: float).
    # The orchestrator wires this to: ERROR log line + bus_status_update
    # + dead-local sentinel update.
    on_degraded: Optional[callable] = field(default=None, repr=False)

    # Optional callback fired ONCE per transition OUT of degraded state.
    # Signature: on_recovered(chain_label: str).
    # The orchestrator wires this to: INFO log line + bus_status_update
    # + immediate Federator check-in.
    on_recovered: Optional[callable] = field(default=None, repr=False)

    def mark_federated(self) -> None:
        """Called every time the federation provider serves a query
        because local was unhealthy. Starts the wall-clock timer on
        first call after a recovery (or program start). Logs a transition
        to degraded state if the threshold has been crossed.

        Idempotent: calling this many times per second is safe (only the
        first call after a recovery sets the timer; subsequent calls
        just update _last_federated_at)."""
        now = time.monotonic()
        if self._first_federated_at == 0.0:
            # First federation since recovery (or boot). Start the clock.
            self._first_federated_at = now
            logger.info(
                "Degraded watchdog (%s): federation started; %.0fs until "
                "degraded if local doesn't recover",
                self.chain_label, self.degraded_after_s)
        self._last_federated_at = now
        # Check threshold. If we just crossed it, fire the transition
        # callback ONCE.
        elapsed = now - self._first_federated_at
        if elapsed >= self.degraded_after_s and not self._is_degraded_cached:
            self._is_degraded_cached = True
            logger.error(
                "Degraded watchdog (%s): LOCAL %s DEGRADED — federated "
                "continuously for %.0fs (threshold %.0fs). Falling through "
                "to Echo/pyttsx3 floor. Operator: check local engine.",
                self.chain_label, self.chain_label,
                elapsed, self.degraded_after_s)
            if self.on_degraded is not None:
                try:
                    self.on_degraded(self.chain_label, elapsed)
                except Exception as e:
                    # Callback failures must NOT propagate — they would
                    # block the query path. Log and continue.
                    logger.warning(
                        "Degraded watchdog (%s): on_degraded callback "
                        "raised: %s", self.chain_label, e)

    def mark_local_recovered(self) -> None:
        """Called by the existing pre-flight probe recovery hook when
        local is observed responding again. Clears the timer and the
        degraded flag, fires the recovery callback once.

        Idempotent: calling on a tracker that was never federated
        (initial state) is a no-op. Calling on a tracker that was
        federating but hadn't crossed the threshold yet clears the
        timer without firing the recovery callback (no observable
        transition to recover from)."""
        was_degraded = self._is_degraded_cached
        if self._first_federated_at == 0.0 and not was_degraded:
            # Never federated, nothing to clear. Common case during
            # normal healthy operation when the recovery hook fires
            # speculatively (pre-flight probe always succeeded).
            return
        self._first_federated_at = 0.0
        self._last_federated_at = 0.0
        self._is_degraded_cached = False
        if was_degraded:
            logger.info(
                "Degraded watchdog (%s): LOCAL %s RECOVERED — exiting "
                "degraded state. Routing returns to local.",
                self.chain_label, self.chain_label)
            if self.on_recovered is not None:
                try:
                    self.on_recovered(self.chain_label)
                except Exception as e:
                    logger.warning(
                        "Degraded watchdog (%s): on_recovered callback "
                        "raised: %s", self.chain_label, e)
        else:
            # Federated some but didn't cross threshold. Quiet log only.
            logger.debug(
                "Degraded watchdog (%s): local responsive again before "
                "degraded threshold; timer cleared",
                self.chain_label)

    def is_degraded(self) -> bool:
        """Has the wall-clock threshold been crossed? Lazy evaluation —
        checks elapsed time on each call rather than relying on a timer
        thread. Returns False until mark_federated has accumulated enough
        wall-clock time. Sticky-true until mark_local_recovered.

        Used by the federation providers as a gate: when True, they
        refuse to federate and return None, forcing the LLMChain to
        fall through to Echo (or TTSChain to pyttsx3)."""
        if self._is_degraded_cached:
            return True
        if self._first_federated_at == 0.0:
            return False
        elapsed = time.monotonic() - self._first_federated_at
        if elapsed >= self.degraded_after_s:
            # Edge case: threshold crossed between calls without
            # mark_federated() being called. Flip to degraded and fire
            # the callback once. (Rare — usually mark_federated runs first.)
            self._is_degraded_cached = True
            logger.error(
                "Degraded watchdog (%s): LOCAL %s DEGRADED — wall-clock "
                "%.0fs since first federation (threshold %.0fs).",
                self.chain_label, self.chain_label, elapsed,
                self.degraded_after_s)
            if self.on_degraded is not None:
                try:
                    self.on_degraded(self.chain_label, elapsed)
                except Exception as e:
                    logger.warning(
                        "Degraded watchdog (%s): on_degraded callback "
                        "raised: %s", self.chain_label, e)
            return True
        return False

    def elapsed_s(self) -> float:
        """Seconds since first federation (zero if not federating).
        Used for cockpit diagnostics."""
        if self._first_federated_at == 0.0:
            return 0.0
        return time.monotonic() - self._first_federated_at

    def to_ui_dict(self) -> dict:
        """Snapshot for the cockpit UI / sentinel reporting."""
        return {
            "chain": self.chain_label,
            "degraded": self.is_degraded(),
            "elapsed_s": self.elapsed_s(),
            "threshold_s": self.degraded_after_s,
        }
