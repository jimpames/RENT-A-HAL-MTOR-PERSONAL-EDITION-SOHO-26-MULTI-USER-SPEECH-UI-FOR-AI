# RENT-A-HAL Personal Edition — Pre-Compile Checkpoint

**Snapshot date:** July 1, 2026 (revision 4 — multi-donor conscription, arbitrary capability reporting)
**Build status:** Release-ready. Inno packaging pending.
**Tests:** 1012 backend pytest (full `pytest tests/`, no exclusions needed) + 31 browser test layers (all green) + 37 smoke checks. Triple-run validated.

---

## Revision 4: the two deferred items from Revision 3, actually built

### Multi-donor conscription

`active_contracts` went from `Dict[str, dict]` (one donor per rank) to
`Dict[str, List[dict]]` (up to `max_donors_per_rank`, default 2). Donors
are added INCREMENTALLY — at most one new donor per check-in cycle while
demand persists, never all at once. `FederationConscriptionProvider` on
the consuming side now walks the list in order, falling through to the
next donor on any failure (timeout, non-200, empty answer) before
finally giving up to Echo — the same "walk the list, fall through"
shape every other provider chain in this codebase already uses.

Fine-grained revocation: `/federate/contracts/revoke {"rank": "chat",
"donor_url": "..."}` (optional) now revokes just ONE donor, leaving
others helping the same rank untouched; omitting `donor_url` still
revokes all, matching the original behavior.

Wire compat: the check-in response carries BOTH the new plural fields
(`conscriptions`, `donor_contracts` — the authoritative full lists) and
the original singular fields (`conscription`, `donor_contract` — first-
or-null, kept for anything still reading the pre-multi-donor shape).
`FederationClient._on_checkin_ok` derives the singular from the plural
automatically either direction, so a client talking to an old-shape
Federator (or vice versa) still gets something usable.

### Arbitrary capability reporting

`_federation_stats()`'s two copy-pasted if-blocks (one for vision, one
for imagine) became a data-driven `CAPABILITY_CHAINS` registry — adding
a future chain-based capability is now a one-line registry entry, not a
third copy-pasted block. A new `[Federation] report_capabilities`
config (default `vision,imagine`, preserving exact prior behavior)
controls which capabilities get reported at all.

Two different signals depending on the capability's nature, documented
explicitly rather than glossed over: capabilities in the
`CAPABILITY_CHAINS` registry (vision, imagine) keep the full Sprint-6
safeguard — only reported when a REAL, non-Echo provider is configured.
Anything else added to `report_capabilities` (weather, music, etc.)
falls back to a weaker signal — reported once it's been served at
least once this session, with NO floor-vs-real-provider distinction
available, since those aren't chain/provider-based capabilities at all.
An operator adding a non-chain name to this list should understand that
limitation; it's why the default only contains the two capabilities
that have the strong safeguard.

### Test rewrite scope

Both changes touched enough of the existing conscription test surface
(three files: engine, provider, revocation) that the honest move was a
systematic rewrite for the new list-based shapes, not compatibility
shims bolted onto the old dict-based API. ~40 existing tests updated,
~25 new ones added for genuinely new behavior (second-donor addition,
donor-cap enforcement, per-donor revocation, multi-donor provider
fallback).

---

## Revision 3: Vision, Imagine, and Federation Conscription

Nine sprints plus a loose-ends pass. The headline: RENT-A-HAL now supports
three "modes" — chat, vision, imagine — each with its own local backend,
and a federation layer smart enough to notice when one realm's idle GPU
cycles could help another realm's overflow, entirely under operator
consent on both sides.

### New realms

**Vision** — "computer take a look" / "what do you see". Webcam frame
capture (client, single frame, camera released immediately after — not a
live stream) → `VisionChain` → LLaVA via Ollama, falling through to an
Echo floor. The floor plays a Mr. Magoo clip via the same YouTube-iframe
mechanism the music panel already used, so an operator watching the
cockpit instantly recognizes "nothing is online" without us shipping any
actual video content in the repo.

**Imagine** — "computer imagine a kitten wearing a hat" / "draw a
sunset...". `ImagineChain` → AUTOMATIC1111 (txt2img API mode), same
Echo-floor pattern — the floor plays the rickroll. Both floors share ONE
bus event (`easter_egg_video {youtube_id, source}`), not two, so the
client only needed one code path.

Both new chains follow the exact Provider/Chain/factory shape LLM/TTS
already used — no new architecture, just two more rows in the same
algebra.

### Federation generalization

The Federator's matrix went from two hardcoded columns (`llm_avg_s`,
`tts_avg_s`) to an open-ended per-capability dict, fully backward
compatible with the live rentahal.com Federator (old-format state files
load fine; a member that's never heard of `capability_avg_s` simply never
sends it, and its data is left untouched — see the staleness bug below
for the one place this needed real care).

### Conscription

The idea: a realm's idle GPU cycles (say, a vision-primary box during a
lull) can temporarily help another realm's overflow — chat, most likely —
under TWO independent layers of consent: the DONOR's own
`[FederationConscription]` settings, and the FEDERATOR operator's own
master switch. Neither alone is enough; both must agree.

The Federator's decision engine (`FederationMatrix.maybe_assign_
conscription`) only assigns a NEW contract when a rank's native peers are
genuinely struggling AND a qualifying donor exists — never reassigns a
still-live contract every 15s (no thrashing), and a donor's own preferred
contract length always wins over the Federator's default when it's
shorter, never when it's longer.

**The one subtlety that mattered most:** contract timestamps
(`assigned_at`/`expires_at`) are the Federator's own `time.monotonic()`
values — meaningless to compare against a DIFFERENT process's clock. The
consuming provider (`FederationConscriptionProvider`) never does that
comparison; it just trusts whichever `conscription` value the most recent
check-in response set. Same discipline applied to the cockpit UI: no fake
countdown timer computed from a number the browser has no business
interpreting.

### The wizard now supports all three modes

`is_go_allowed()` is now `node_type`-aware. A realm declaring itself
`[Federation] node_type = vision` gates on Ollama/LLaVA instead of
GPT4All — chat genuinely isn't required for a vision-primary deployment.
This was a DELIBERATE reversal of an earlier, more conservative design
(vision/imagine "can never influence the gate") made once the actual
multi-mode use case was concretely in front of us, not a casual scope
creep — see `wizard.py`'s `is_go_allowed` docstring for the full
reasoning either way.

### Real bugs found along the way (not hypothetical)

1. **Video-freeze-during-YouTube-playback**, reported live. Root cause
   turned out to be two independent things: (a) a waveform-visualizer
   `requestAnimationFrame` loop reallocating a buffer 60×/sec forever
   (GC churn stalling the main thread), and (b) a metrics status row
   using `flex-wrap` with no reserved height, occasionally flipping
   between one and two lines and pushing the video panel — forcing an
   iframe repaint mid-playback. Both fixed; neither alone fully explained
   the symptom, which is why the user's own testing (isolating wake-word
   state) mattered in narrowing it down.
2. **A pre-existing `config_schema.py` parser bug**: metadata split across
   two comment lines (`; @label: ... @type: ...` then `; @help: ...` on
   the next line) silently lost everything from the first line —
   `Supporters.enabled` never reached the frontend regardless of its
   actual config value. One-line fix (merge instead of overwrite), 18
   previously-silently-broken keys fixed at once.
3. **Capability staleness**: `FederationMatrix.upsert()` used to MERGE
   incoming `capability_avg_s` instead of REPLACING it — a capability
   dropped from a node's reporting (operator disables LLaVA, restarts)
   would advertise its last-known average FOREVER, since nothing ever
   removed a stale key. Fixed by distinguishing "key absent from payload"
   (true backward compat, leave untouched) from "key present, possibly
   empty" (this node's authoritative current set — replace wholesale).
4. **`bus_tts_complete` silently dropped by the browser** — the server
   published this event since before the original release; the client's
   `handleMsg` switch had no case for it at all. Added as an ADDITIVE
   longer echo-guard extension, deliberately NOT replacing
   `playAudio`'s own per-chunk `onended` release — a near-miss here: an
   earlier, more aggressive version of this fix (removing `onended`'s
   release entirely, plus nuking card panels on every query) turned out
   to be a previously-diagnosed-and-reverted regression, caught by a
   test file (`run_silence_button_test.js`) explicitly written to pin
   the reverted, known-good behavior. Worth remembering: an old failing
   test isn't always the stale one.

5. **`tests/test_cors.py` had been silently erroring on every run** —
   its fixture called `from app import build_app`, a function that
   never existed in `app.py` (that name belongs to `wizard.py`'s
   separate FastAPI app builder). pytest reports this as a setup ERROR,
   not a FAILURE, which is easy to miss buried in a large run's summary
   line — this had apparently been quietly excluded from every full-
   suite run for some time. Fixed to use the same `load_ini()` +
   `setup_logging()` + `create_app(cfg, logger)` boot pattern every
   other test file in the suite already used. 12 tests, previously
   never actually executing, all pass.

### New: manual conscription contract revocation

`GET /api/federate/contracts` (dump active contracts) and `POST
/api/federate/contracts/revoke {"rank": "chat"}` — a Federator operator
can now force-expire a contract without editing `federation.ini` and
restarting the whole process (which used to clear EVERY rank's contract,
not just the one in question). Same no-auth posture as the existing
`/api/federate/matrix` endpoint, documented as a deliberate, consistent
choice rather than an oversight — this whole admin surface already
assumes a trusted local operator, same as everywhere else in the
Federator's debugging endpoints.

One related gap flagged but NOT fixed here, since it's a bigger,
separate decision: the check-in protocol's `token` field is sent by
members but never actually validated server-side anywhere. Federation
is effectively open by default today — possibly intentional (low-
friction adoption, matching "everything under individual operator
control"), possibly an oversight. Worth a deliberate decision, not a
quiet fix bundled into an unrelated feature.

### Follow-up: the token gap above got its deliberate decision

Closed the same morning. The decision: empty token (the default) means
zero validation anywhere — no behavior change for any existing
deployment. Once an operator sets one, it's enforced consistently
across all six federation-facing endpoints (`/federate/checkin`,
`/federate/matrix`, `/federate/contracts`, `/federate/contracts/revoke`,
plus `/api/ask` and `/api/speak` — but ONLY for calls that identify
themselves as federated via `X-Federation-Hops`). The "Little Johnny"
principle — direct curl callers to `/api/ask`/`/api/speak` stay open
regardless of token config — is preserved exactly; the token protects
the federation network, not general endpoint availability. One shared
value plays both roles per realm: what you SEND when federating out,
what you REQUIRE when others federate in. `federation_token_error()` is
the single function all six endpoints go through, so none of them can
silently become the accidental unprotected exception again.

### JS test suite: fully green for the first time

Two long-standing failures (footer content mismatches — a stale test
naming a specific Claude model variant instead of the shipped generic
"Claude (Anthropic)" credit, and a hardcoded GPU name where the footer
now correctly renders `{{ gpu_name }}` dynamically) turned out to be
stale test expectations, not app bugs — fixed by updating the tests to
match the more-correct shipped content, not the reverse.

---


## Latest addition: Degraded watchdog (revision 2)

Found in the shower at 8:30 AM on compile day. Fixed before compile. **This is exactly the kind of bug you want to find pre-release, not post-release.**

### The bug

The federation provider would happily federate dead-local queries **forever**. A realm whose GPT4All crashed would silently route every query to its peers, cheat the federation matrix (reporting as "healthy" by virtue of forwarding), and the operator would never know their local engine was broken.

### The fix

New module `realm/degraded_tracker.py` — a wall-clock watchdog with three states:

1. **Initial** — no federation observed, behaves as before
2. **Federating** — first federation call starts a monotonic timer
3. **Degraded** — after `local_degraded_after_s` (default 300s = 5 min) of continuous federation, the federation provider REFUSES to federate

When degraded:
- Federation provider returns `None` from `generate()` / `synth()`
- LLM chain falls through to Echo (the "I can't help" floor)
- TTS chain falls through to pyttsx3 (the SAPI5 "robot voice" floor)
- A loud ERROR-level log line fires once
- The cockpit gets a `bus_status_update` with provider name `LocalSystemLLMDegraded.xpy` / `LocalSystemTTSDegraded.xpy`
- Operator sees the realm is technically working but local is dead — actionable signal

The existing **pre-flight probe** still fires on every query, so the moment local comes back, degraded clears, normal routing resumes, and the recovery dance fires (badge flash, immediate Federator check-in).

### Design decisions explained

**Wall-clock, not call-count.** A busy realm doing 60 q/min hits a 15-call cap in 15 seconds (false positive). A quiet realm doing 1 q / 10 min takes 2.5 hours to hit the same cap (operator never notified). Time is the right axis. The cap is "how long has local been unhealthy" in seconds, not "how many queries have we forwarded."

**Independent LLM and TTS trackers.** GPT4All can crash while Kokoro is fine and vice versa. Two trackers, two badges, two log lines. The chains fail independently; the watchdogs follow suit.

**Aggressive recovery.** The first successful local probe clears degraded immediately, matching the existing pre-flight probe pattern. If the model is wobbly post-restart and we bounce, we re-enter degraded — cost is one false-positive log line, not a system hang. Better UX than waiting for two consecutive probes.

**Callback exception isolation.** Both `on_degraded` and `on_recovered` callbacks are wrapped in try/except. A buggy operator-signal callback cannot block the query path. Sabotage-verified.

### What got added

| File | Lines | Purpose |
|---|---|---|
| `realm/degraded_tracker.py` | 184 (new) | The watchdog itself, fully self-contained |
| `realm/federation_provider.py` | ~40 changed | LLM head + fallback gate on degraded, mark on success |
| `realm/federation_tts_provider.py` | ~50 changed | TTS head + fallback gate on degraded, mark on success |
| `app.py` | ~80 added | Tracker construction, callbacks, attach() wiring |
| `config.ini` | 12 added | `[LLMChain] local_degraded_after_s = 300` + same for TTS |
| `tests/test_degraded_tracker.py` | 280 (new) | 18 tests covering all transitions |
| `tests/test_federation.py` | ~60 added | 5 integration tests for provider gating |

### Test counts

- **Pre-watchdog:** 656 realm pytest
- **Post-watchdog:** 679 realm pytest (+23)
- Sabotage-verified across 4 critical invariants

### Why this isn't in the wizard UI

Conscious decision: the 300s default is sensible, operators who want to tune it can edit `config.ini` (the field is fully schema-annotated with `@label`, `@help`, `@min`, `@max`), and the wizard surface is already busy with 5 hard gates + 7 form panels. **Adding a single tunable to UI for a knob most operators will never touch was the wrong trade.** If real operators in the field request UI exposure post-release, we can add it then.

---

## What's in this ZIP

A complete, working snapshot of RENT-A-HAL Personal Edition MTOR after seven months of engineering work. Everything needed to run the realm, federate with peers, serve voice queries, and ship a public release.

### Top-level files

| File | Purpose |
|---|---|
| `app.py` | The realm process — FastAPI server, WebSocket, all REST endpoints |
| `wizard.py` | Boot wizard — gates GO behind CUDA + GPT4All + completion test |
| `config.ini` | Master configuration, comment-preserving, self-describing schema |
| `federation.ini` | Federation tuning (overflow thresholds, timeouts, master URL) |
| `run.bat` | Direct realm startup (skips wizard, for power operators) |
| `launch.bat` | Wizard startup (recommended for new operators) |
| `requirements.txt` | Python dependencies |
| `smoke_test.py` | 24-check boot validation (no GPU required) |
| `pytest.ini` | Test runner config |
| `README.md` | Project overview |
| `MULTI_USER_AND_LAN.md` | Multi-user + LAN deployment notes |

### `realm/` — The engine room

| Module | Role |
|---|---|
| `realm_core.py` | Per-user state, WebSocket handlers, audio pipeline |
| `orchestrator.py` | Query queue, intent dispatch, metrics, federation health |
| `engine_chain.py` | LLM + TTS provider chains with `probe_local()` |
| `federation.py` | Matrix, FederationClient, sentinel reporting, `immediate_checkin` |
| `federation_provider.py` | Head (overflow) + Fallback (rescue) LLM federation |
| `federation_tts_provider.py` | Head + Fallback TTS federation (parallel architecture) |
| `degraded_tracker.py` | **NEW (rev 2)** — wall-clock watchdog preventing infinite federation |
| `intent.py` | Intent vocabulary classifier (weather, news, music, service, ask) |
| `gate.py` | Wake-word state machine, doubled-action guards, hop-limit |
| `config_schema.py` | Comment-preserving INI read/write |
| `event_bus.py` | Pub-sub bus connecting WebSocket and orchestrator |

### `templates/` — The cockpit

| File | Role |
|---|---|
| `index.html` | Star Trek BETA-5 cockpit — voice loop, federation badge, status panels |
| `wizard.html` | Boot wizard UI — Star Trek styled, hard gates visible |
| `supporters.html` | Operator-configurable "ways to support this project" page |

### `tests/` — 679 backend + 25 browser layers

Backend: `test_federation.py`, `test_federation_tts.py`, `test_chain_probe.py`, `test_metrics.py`, `test_wizard.py`, `test_supporters.py`, **`test_degraded_tracker.py` (new)**, and the existing realm tests.

Browser layers: `run_*_test.js` for every UI-critical path — ACK protocol, federation polling, status updates, privacy beacon, IO audio unlock, panel mutex, wake timer, etc.

---

## Architecture summary (the 30-second mental model)

```
                Browser (anywhere)
                       │
                  WebSocket /ws
                       │
                       ▼
              ┌─────────────────┐
              │  Realm Process  │  ── /api/ask, /api/speak, /api/news,
              │   (port 9999)   │     /api/federate/checkin, /supporters
              └─────────────────┘
                  │           │
        ┌─────────┘           └─────────┐
        ▼                               ▼
  ┌─────────────┐               ┌─────────────┐
  │ Local LLM   │               │ Local TTS   │
  │ (GPT4All)   │               │ (Kokoro)    │
  └─────────────┘               └─────────────┘
        │                               │
        └───────────┬───────────────────┘
                    ▼ if local slow/dead (capped by degraded watchdog)
            ┌──────────────────┐
            │ Federation Peer  │
            │  (other realms)  │
            └──────────────────┘
                    │
                    ▼ after 5 min continuous federation
            ┌──────────────────┐
            │ Echo / pyttsx3   │  ← operator-visible floor: "fix local"
            └──────────────────┘
```

Voice in → STT in browser → text over WebSocket → intent classified → handler routes to weather/news/music/service/LLM → response (text + audio) streams back → browser plays.

Federation kicks in transparently when local is slow or dead. **After 5 minutes of continuous federation, the realm declares LOCAL DEGRADED**, refuses to federate further, falls through to Echo/pyttsx3, and surfaces a loud operator signal. Self-healing when local returns.

---

## What was completed in the seven-month run

This is the work this snapshot represents:

**Foundation (months 1-3)**
- Multi-user state isolation
- Per-user FIFO outbound queues
- WebSocket protocol with ACK delivery confirmation
- Star Trek voice loop (wake word, doubled-action guards, barge-in)
- iOS Safari audio unlock pattern
- Intent classification via declarative INI vocabulary

**Service realms (months 3-5)**
- Weather via OpenWeatherMap free tier
- News aggregation with audio ROUNDUP playlists
- Music via DuckDuckGo → YouTube embed (no API key needed)
- Service Finder via BizData + Nominatim (no API key needed)
- Per-user geolocation flow with iOS gesture-bound permission

**Federation v1 (months 5-7)**
- Push-driven check-ins (no polling), 15s default interval
- Sentinel value (1000.0) for unreachable/dead peers
- Hop limit (`X-Federation-Hops: 1`) prevents cascades
- Head + Fallback federation providers for both LLM and TTS
- Pre-flight `probe_local()` before federating — second-chance for local
- Recovery callback: clear rolling avg + flip availability flag + immediate Federator check-in + cockpit badge flash
- Dead-local self-reporting (sentinel when our own LLM/TTS is down)
- Cockpit truth fix (per-query badge updates from `bus_query_result`)
- TTS federation as first-class with public `/api/speak` endpoint
- **Degraded watchdog** (rev 2) — wall-clock cap on continuous federation, prevents silent dependency on peers

**Boot wizard (final week)**
- Standalone FastAPI on port 9100 (separate from realm port 9999)
- Five hard gates before GO is enabled
- Auto-spawns `ngrok http --url=<reserved> 9999` as child process
- HALT button kills realm + ngrok subprocesses (SIGTERM → SIGKILL fallback)
- ngrok output tail visible in dashboard

**Polish & bug fixes (final week)**
- Wake-word duration in config (SHORT default, 15s)
- Privacy beacon (browser Web Speech API speaks "Rent A Hal" at 25% volume every 30s while wake is on — zero cost)
- BETA-5 tagline customizable via `[Branding] tagline`
- API key prompts in wizard (OpenWeather, ngrok auth token)
- Federation tuning knobs in wizard (LLM/TTS overflow thresholds, federated call timeout)
- Max-tokens truncation fix (the "I Love Lucy" bug) — forwards `max_tokens` across federation, caps on receive
- Operator-controlled `/supporters` page (default OFF, no promotional content in shipped defaults)
- Defensive inline-comment stripping for paste-error tolerance

---

## How to run from this snapshot

### Quick start (recommended)

1. Unpack the ZIP to a working directory.
2. `cd RENTAHAL_APP`
3. `pip install -r requirements.txt`
4. Install GPT4All (gpt4all.io), load a model, enable Local Server (Settings → Application).
5. Double-click `launch.bat` (Windows) or run `python wizard.py`.
6. Browser opens to `http://localhost:9100`.
7. Wizard probes everything. When all 5 gates green, click GO.
8. Cockpit opens at `http://localhost:9999`.
9. Click "Enable wake word", say "computer, what's the weather".

### Direct run (skip wizard)

`python app.py` — boots realm on port 9999, federation per `federation.ini`.

---

## Methodology summary (for engineers reading the code)

- **Algebraic INI design.** Every operator-tunable knob lives in `config.ini` with self-describing schema annotations. No magic numbers in code.
- **Comment-preserving config writes.** `realm/config_schema.py:save_value` rewrites individual fields without touching surrounding comments. The wizard relies on this.
- **Sabotage-verified tests.** Every critical invariant has a test that fails when the protection is deliberately removed. See git history for the sabotage logs.
- **Triple-run validation.** Test suite must produce identical results across three consecutive clean runs before any feature is considered shipped.
- **Provenance-cited bug fixes.** Every fix has a comment block explaining the bug it addresses, often with the literal symptom (e.g. "the I Love Lucy bug" or "shower thought 2026-06-22").
- **Read the code first.** No theorizing about behavior before reading the implementation. This was the core working agreement throughout the project.

---

## What's next (post-checkpoint)

1. **Compile Kokoro microservice** — standalone TTS process binary
2. **Compile RENT-A-HAL realm + wizard** — Python → executable
3. **Inno installer** — bundle both with config wizard, GPT4All check, ngrok install hint
4. **GitHub release** — tag, upload Inno installer, write release notes
5. **Public announcement** — blog post, Hacker News, r/selfhosted, r/LocalLLaMA

The codebase is feature-complete for this release.

---

## Acknowledgments

Built by Jim Ames (callsign N2NHU, Newburgh NY) at N2NHU Lab.
Engineering collaboration with Anthropic's Claude across approximately seven months of sustained pair-engineering.
"Coded by Claude Fable" — the footer line Jim wrote that meant a lot.

The MTOR name is a nod to Dr. Daystrom's M-5 Multitronic Unit from *Star Trek: The Original Series* ("The Ultimate Computer," 1968). The system aims to fulfill the M-5 design vision (a self-contained intelligent realm) while explicitly avoiding the M-5 design failure (autonomous operation without human oversight). **The realm does what M-5 was supposed to do, with humans in the loop.**

Live long and prosper. 🖖

---

## Architecture summary (the 30-second mental model)

```
                Browser (anywhere)
                       │
                  WebSocket /ws
                       │
                       ▼
              ┌─────────────────┐
              │  Realm Process  │  ── /api/ask, /api/speak, /api/news,
              │   (port 9999)   │     /api/federate/checkin, /supporters
              └─────────────────┘
                  │           │
        ┌─────────┘           └─────────┐
        ▼                               ▼
  ┌─────────────┐               ┌─────────────┐
  │ Local LLM   │               │ Local TTS   │
  │ (GPT4All)   │               │ (Kokoro)    │
  └─────────────┘               └─────────────┘
        │                               │
        └───────────┬───────────────────┘
                    ▼ if local slow/dead
            ┌──────────────────┐
            │ Federation Peer  │
            │  (other realms)  │
            └──────────────────┘
```

Voice in → STT in browser → text over WebSocket → intent classified → handler routes to weather/news/music/service/LLM → response (text + audio) streams back → browser plays.

Federation kicks in transparently when local is slow or dead. Self-healing on local recovery (pre-flight probe + immediate Federator check-in + cockpit badge flash).

---

## What was completed in the seven-month run

This is the work this snapshot represents:

**Foundation (months 1-3)**
- Multi-user state isolation
- Per-user FIFO outbound queues
- WebSocket protocol with ACK delivery confirmation
- Star Trek voice loop (wake word, doubled-action guards, barge-in)
- iOS Safari audio unlock pattern
- Intent classification via declarative INI vocabulary

**Service realms (months 3-5)**
- Weather via OpenWeatherMap free tier
- News aggregation with audio ROUNDUP playlists
- Music via DuckDuckGo → YouTube embed (no API key needed)
- Service Finder via BizData + Nominatim (no API key needed)
- Per-user geolocation flow with iOS gesture-bound permission

**Federation v1 (months 5-7)**
- Push-driven check-ins (no polling), 15s default interval
- Sentinel value (1000.0) for unreachable/dead peers
- Hop limit (`X-Federation-Hops: 1`) prevents cascades
- Head + Fallback federation providers for both LLM and TTS
- Pre-flight `probe_local()` before federating — second-chance for local
- Recovery callback: clear rolling avg + flip availability flag + immediate Federator check-in + cockpit badge flash
- Dead-local self-reporting (sentinel when our own LLM/TTS is down)
- Cockpit truth fix (per-query badge updates from `bus_query_result`)
- TTS federation as first-class with public `/api/speak` endpoint

**Boot wizard (final week)**
- Standalone FastAPI on port 9100 (separate from realm port 9999)
- Five hard gates before GO is enabled:
  1. CUDA GPU detected via `nvidia-smi -L`
  2. GPT4All API responding (`GET /v1/models`)
  3. At least one model loaded
  4. Selected model actually answers a test prompt (catches "loaded but broken" cases)
  5. Federation desire ON requires ngrok URL configured
- Auto-spawns `ngrok http --url=<reserved> 9999` as child process
- HALT button kills realm + ngrok subprocesses (SIGTERM → SIGKILL fallback)
- ngrok output tail visible in dashboard

**Polish & bug fixes (final week)**
- Wake-word duration in config (SHORT default, 15s)
- Privacy beacon (browser Web Speech API speaks "Rent A Hal" at 25% volume every 30s while wake is on — zero cost)
- BETA-5 tagline customizable via `[Branding] tagline`
- API key prompts in wizard (OpenWeather, ngrok auth token)
- Federation tuning knobs in wizard (LLM/TTS overflow thresholds, federated call timeout)
- Max-tokens truncation fix (the "I Love Lucy" bug) — forwards `max_tokens` across federation, caps on receive
- Operator-controlled `/supporters` page (default OFF, no promotional content in shipped defaults)
- Defensive inline-comment stripping for paste-error tolerance

---

## How to run from this snapshot

### Quick start (recommended)

1. Unpack the ZIP to a working directory.
2. `cd RENTAHAL_APP`
3. `pip install -r requirements.txt`
4. Install GPT4All (gpt4all.io), load a model, enable Local Server (Settings → Application).
5. Double-click `launch.bat` (Windows) or run `python wizard.py`.
6. Browser opens to `http://localhost:9100`.
7. Wizard probes everything. When all 5 gates green, click GO.
8. Cockpit opens at `http://localhost:9999`.
9. Click "Enable wake word", say "computer, what's the weather".

### Direct run (skip wizard)

`python app.py` — boots realm on port 9999, federation per `federation.ini`.

---

## Methodology summary (for engineers reading the code)

- **Algebraic INI design.** Every operator-tunable knob lives in `config.ini` with self-describing schema annotations. No magic numbers in code.
- **Comment-preserving config writes.** `realm/config_schema.py:save_value` rewrites individual fields without touching surrounding comments. The wizard relies on this.
- **Sabotage-verified tests.** Every critical invariant has a test that fails when the protection is deliberately removed. See git history for the sabotage logs.
- **Triple-run validation.** Test suite must produce identical results across three consecutive clean runs before any feature is considered shipped.
- **Provenance-cited bug fixes.** Every fix has a comment block explaining the bug it addresses, often with the literal symptom (e.g. "the I Love Lucy bug").
- **Read the code first.** No theorizing about behavior before reading the implementation. This was the core working agreement throughout the project.

---

## What's next (post-checkpoint)

1. **Compile Kokoro microservice** — standalone TTS process binary
2. **Compile RENT-A-HAL realm + wizard** — Python → executable
3. **Inno installer** — bundle both with config wizard, GPT4All check, ngrok install hint
4. **GitHub release** — tag, upload Inno installer, write release notes
5. **Public announcement** — blog post, Hacker News, r/selfhosted, r/LocalLLaMA

The codebase is feature-complete for this release. Future versions might add: token streaming during LLM generation, RAG/memory layer, mobile native app (PWA likely), multilingual TTS, vision input. **None of those are needed for v1.**

---

## Acknowledgments

Built by Jim Ames (callsign N2NHU, Newburgh NY) at N2NHU Lab.
Engineering collaboration with Anthropic's Claude across approximately seven months of sustained pair-engineering.
"Coded by Claude Fable" — the footer line Jim wrote that meant a lot.

The MTOR name is a nod to Dr. Daystrom's M-5 Multitronic Unit from *Star Trek: The Original Series* ("The Ultimate Computer," 1968). The system aims to fulfill the M-5 design vision (a self-contained intelligent realm) while explicitly avoiding the M-5 design failure (autonomous operation without human oversight). **The realm does what M-5 was supposed to do, with humans in the loop.**

Live long and prosper. 🖖
