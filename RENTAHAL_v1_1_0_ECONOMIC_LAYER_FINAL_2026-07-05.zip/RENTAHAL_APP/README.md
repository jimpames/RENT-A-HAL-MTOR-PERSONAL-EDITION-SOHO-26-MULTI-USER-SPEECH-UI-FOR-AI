# RENT-A-HAL — Star Trek Computer Realm

Ask anything by voice, get the answer instantly by voice.
Algebraic, intent-driven, event-bus architecture.
**No PyTorch. No CUDA. Works on a clean Win11 venv.**

## Quickstart (Windows 11 cmd-line, ~2 minutes)

```cmd
cd RENTAHAL_APP
py -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://localhost:9999 in Chrome or Edge. Click **Enable wake word**, say
`computer what time is it`, and the realm answers.

### Bolt to ngrok

```cmd
ngrok http 9999
```

Use the public https URL from ngrok. WebSockets work over ngrok automatically.

### Verify everything before going public

```cmd
set RENTAHAL_FAKE_ENGINES=1
python smoke_test.py
```

Boots the real app, drives the full voice loop with Echo providers (no
network, no API keys), proves STOP STOP cancellation and REPEAT REPEAT
replay work end-to-end, plus Vision/Imagine round-trips through their
Echo floors. Should print `37/37 checks passed`.

```cmd
python -m pytest tests/
```

Runs the full harness — bus invariants, intent algebra, chain fall-through,
orchestrator integration, concurrency core, chaos tests, federation
matrix/conscription, wizard gate logic, CORS. Should print `1205 passed`.

## Engine providers (chain order, edit config.ini)

### LLM (`[LLMChain]` and per-provider sections)

| Provider | Cost | Notes |
|---|---|---|
| **GPT4All** | free, local | Install GPT4All app → Settings → Enable API Server. Realm picks it up on next request, no restart. |
| **Claude** | cloud, paid | Paste `sk-ant-...` in `[Claude] api_key`. Best quality. |
| **HuggingFace** | free tier | Paste `hf_...` in `[HuggingFace] api_key`. |
| **Echo** | always works | Floor. Says "no LLM online" politely. |

### TTS (`[TTSChain]` and per-provider sections)

| Provider | Cost | Notes |
|---|---|---|
| **Kokoro** | free, local | Optional. Install `kokoro-onnx`, point `[Kokoro] model_path` at the .onnx file. CUDA via `onnxruntime-gpu`. |
| **ElevenLabs** | premium online | Best voice quality. Paste key in `[ElevenLabs]`. |
| **OpenAI** | cheap online | Solid quality, fast. Paste key in `[OpenAITTS]`. |
| **pyttsx3** | free, always | OS speech (SAPI5 on Windows). Floor. |

Want a different order? Edit `llm_order` / `tts_order`. Want to skip one?
Remove it from the list. The chain skips uninstalled or unavailable
providers silently.

### Vision (`[VisionChain]` / `[LLaVA]`) — optional

| Provider | Cost | Notes |
|---|---|---|
| **LLaVA (via Ollama)** | free, local | `ollama pull llava`, then `ollama serve`. Realm picks it up on next request, no restart. |
| **Echo** | always works | Floor. Plays a Mr. Magoo clip on the panel and says so politely. |

Say **"computer take a look"** or **"what do you see"** — the browser
grabs a single webcam frame (not a live stream; camera released
immediately after) and sends it along with the question.

### Imagine (`[ImagineChain]` / `[Automatic1111]`) — optional

| Provider | Cost | Notes |
|---|---|---|
| **AUTOMATIC1111** | free, local | Launch the webui with `--api`. Realm picks it up on next request. |
| **Echo** | always works | Floor. Plays a well-known rickroll on the panel and says so politely. |

Say **"computer imagine a kitten wearing a hat"** or **"draw a sunset
over the mountains"**.

Neither Vision nor Imagine is required — a realm with neither configured
is a complete, valid, chat-only deployment. Both are entirely optional
capabilities layered onto the same chain pattern as LLM/TTS.

### Federation (`federation.ini`) — optional

Realms can help each other. If your local LLM/TTS gets slow or dies, a
federated peer picks up the slack automatically; when local recovers,
routing flips back with no operator action. Fully opt-in
(`[Federation] desire = off` by default) and works with or without a
public URL.

**Conscription** (`[FederationConscription]`) is the newer layer: a
realm's idle capacity on one capability (say, an idle vision box) can
temporarily help another realm's overflow on a DIFFERENT capability
(chat, most likely) — always time-boxed, always under the donor's
explicit consent, never silent. See `federation.ini`'s own comments for
the full knob-by-knob explanation; it's deliberately conservative by
default (`permitted_conscription_ranks` empty = opt-in required).

Declare this realm's primary role with `[Federation] node_type =
chat|vision|imagine` — the setup wizard gates on whichever backend
matches your declared role, not always GPT4All.

Optionally set `[Federation] token` to a shared secret — once set, it's
required on every federation-facing endpoint (check-in, the admin/
observability endpoints, and federated forwarding into `/api/ask` /
`/api/speak`). Empty (the default) means fully open, exactly as before.
Direct callers to `/api/ask`/`/api/speak` (curl, casual local testing)
are never gated by this regardless — only calls that identify
themselves as federated forwards are.

Conscription supports multiple simultaneous donors per rank
(`[Federator] max_donors_per_rank`, default 2) — added incrementally
while demand persists, never all at once. `[Federation]
report_capabilities` (default `vision,imagine`) controls which
capabilities get reported at all; vision/imagine keep a safeguard
against an Echo floor masquerading as a real peer, anything else added
to that list uses a weaker "has it actually been served" signal.

## Economic layer (optional — off by default)

A five-piece opt-in layer, fully off unless explicitly configured:

- **Anti-abuse gate** (`[AbuseGate]`) — memory-hard Argon2id
  proof-of-work, tiered by recent call volume. Enabled by default;
  casual use never sees a puzzle.
- **Ledger** (`[Ledger]`) — an append-only, hash-chained Postgres
  ledger, publicly verifiable via OpenTimestamps anchoring to Bitcoin.
  Requires a real Postgres instance (see `ECONOMIC_LAYER_DESIGN.md`).
- **Billing** (`[Billing]`) — Stripe Checkout consumer top-ups, flat
  price per submit, idempotent webhook crediting.
- **Payout** (`[Payout]`) — Stripe Connect donor payouts for confirmed
  conscription work, with bilateral confirmation (both the requester
  and the donor must independently claim the same work before a
  payout releases) protecting against a single lying party.
- **Wizard/cockpit visibility** — informational panels and live status
  indicators for all of the above; none of it gates the wizard's GO
  button.

Full design, every config knob explained, and the honest limitations
of what could/couldn't be tested against a live Stripe/Bitcoin network
during development: see `ECONOMIC_LAYER_DESIGN.md`. A standalone
end-to-end acceptance check exists separately from the pytest suite:

```cmd
python economic_layer_acceptance.py
```

Runs the whole economic layer story against a real (if locally-test)
Postgres — PoW tiers, ledger tamper detection, OpenTimestamps
verification, billing crediting, bilateral confirmation — and reports
PASS/FAIL per check, same style as `smoke_test.py`. Gracefully skips
(not fails) anything that needs infrastructure you haven't set up.

## How it works

The architecture is a typed event bus. Every component subscribes and emits;
nothing calls anything directly.

```
"computer what is the realm"
    │
    ▼  (browser SpeechRecognition)
prompt_text {text, nonce, user_guid}
    │
    ▼  (IntentClassifier — n-gram, doubled-word, slots)
intent_classified {kind: 'ask', slots: {}, confidence: 0.86}
    │
    ▼  (Orchestrator → SafeQueue → LLMChain)
query_processing → query_result {text, llm_provider}
    │
    ▼  (Orchestrator → TTSChain)
tts_started → tts_chunk {audio_b64} → tts_complete
    │
    ▼  (browser <audio>)
voice
```

**STOP STOP** at any moment: `intent_stop` fires, the orchestrator cancels
in-flight queue work AND active TTS, only for that user.

**REPEAT REPEAT**: `intent_repeat` replays the last `query_result` for that
user through TTS.

Doubling (two adjacent words) is what prevents "I want to STOP for coffee"
from killing TTS mid-sentence.

Vision and Imagine are two more rows in the same `kind` algebra —
`intent_classified {kind: 'vision'|'imagine', ...}` routes through the
orchestrator exactly like `ask`/`weather`/`music`, just with their own
handler and chain. When neither has a real backend configured, the Echo
floor fires and publishes a shared `easter_egg_video {youtube_id, source}`
bus event — one event shape, one client code path, for both floors.

## Files

```
RENTAHAL_APP/
├── app.py                      ← launcher (no torch imports)
├── config.ini                  ← self-describing schema; everything tunable
├── federation.ini              ← federation + conscription config
├── wizard.py                   ← guided setup: probes GPT4All/LLaVA/A1111/CUDA
├── requirements.txt            ← Win11 venv-clean
├── run.bat                     ← Windows one-click launcher
├── smoke_test.py               ← end-to-end against real app (Echo providers)
├── pytest.ini
├── realm/
│   ├── event_bus.py            ← the spine (typed events, async subs, ping/pong)
│   ├── intent.py                ← algebraic classifier (n-gram, doubled, slots)
│   ├── engine_chain.py         ← LLM + TTS + Vision + Imagine chains
│   ├── orchestrator.py         ← bus subscriber, per-user STOP/REPEAT, per-kind metrics
│   ├── federation.py            ← matrix, config, client, conscription decision engine
│   ├── federation_provider.py  ← HEAD/FALLBACK/CONSCRIPTION LLM providers
│   ├── federation_tts_provider.py
│   ├── realm_core.py           ← SafeQueue, ConnectionManager, QueueProcessor
│   └── config_schema.py        ← parses @label/@type/@scope metadata
├── templates/
│   ├── index.html              ← Star Trek voice UI, waveform canvas, panels
│   └── wizard.html             ← guided setup UI
├── static/                     ← (empty; for future static assets)
└── tests/                      ← 48 Python files + 31 browser (JS) files, all green
```

## What's NOT in this drop (deliberately)

- **No PyTorch / Whisper / BARK**. The chain pattern made them optional; on
  Windows they're a fragile install ritual that doesn't pay for itself. STT
  is the browser's `SpeechRecognition` API (free, instant, no setup); TTS
  goes through Kokoro/ElevenLabs/OpenAI/pyttsx3.
- **No SQLite user database, no sysop panel, no banned-user logic, no
  worker registry.** This is the Star Trek voice loop, integrated. The full
  multi-tenant realm from session 4 (`webgui.py`) is preserved as a
  parallel artifact; this is the new front door.
- **No Microsoft Store / Nuitka pipeline.** Pure Python as requested.

## Acceptance ritual

After install:

1. `python smoke_test.py` → `37/37 checks passed`
2. `python -m pytest tests/` → `1205 passed`
3. `python app.py` and open http://localhost:9999
4. Click **Type a question**, type `what is the realm`, hit OK.
   The UI shows the intent classification, the LLM answer, and plays TTS.
5. `ngrok http 9999` → share the public URL → it works there too.
6. Say "computer take a look" and "computer imagine a kitten" — both work
   via their Echo floors even with no LLaVA/AUTOMATIC1111 configured.

If all six pass, you're live.
