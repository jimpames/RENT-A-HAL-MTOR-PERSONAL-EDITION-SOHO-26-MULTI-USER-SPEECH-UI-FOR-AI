#!/usr/bin/env python3
"""
payout_batch_job.py — Sprint 14: batched donor payouts.

Run this weekly or monthly (cron, Task Scheduler). For every donor
with an onboarded Stripe Connect account (payouts_enabled=true) whose
accrued CONFIRMED balance (from bilaterally-matched conscription_credit
ledger entries — see realm/donor_payout.py) is at or above
[Payout] minimum_payout_micros, sends a real Stripe Transfer and
records a matching 'payout' ledger entry (negative, reducing their
balance), using the Stripe transfer ID as the idempotency reference —
same pattern as Sprint 13's checkout session ID.

Deliberately NOT real-time: Stripe's own transfer fee makes a payout
for every single confirmed request wasteful. Batching lets a donor's
confirmed credits accumulate to a sensible size first.

This script does NOT reconcile claims itself — that happens live, as
claims arrive at /api/federate/conscription-claim (see
realm/donor_payout.py's ClaimStore.submit_claim). This script only
ever moves money for ALREADY-CONFIRMED credits sitting in the ledger.

Also checks (and updates) each linked account's payouts_enabled status
via the real Stripe API before attempting a transfer — an account that
started onboarding but never finished shouldn't get a transfer
attempt that will just fail.

Usage:
    python payout_batch_job.py                    # uses config.ini
    python payout_batch_job.py --dsn postgresql://... --stripe-key sk_live_...
    python payout_batch_job.py --dry-run           # report what WOULD be paid, don't call Stripe
"""
import argparse
import asyncio
import configparser
import sys
from pathlib import Path

from realm.billing import micros_to_cents
from realm.donor_payout import (
    DonorAccountStore, PayoutConfig, check_payouts_enabled, execute_payout,
)
from realm.ledger import DuplicateEntryError, Ledger


def _config_from_ini() -> tuple:
    cfg = configparser.ConfigParser()
    cfg.read(Path(__file__).parent / "config.ini")
    dsn = cfg.get("Ledger", "dsn", fallback="") if cfg.has_section("Ledger") else ""
    stripe_key = (cfg.get("Payout", "stripe_secret_key", fallback="")
                 if cfg.has_section("Payout") else "")
    minimum = int(cfg.get("Payout", "minimum_payout_micros", fallback="5000000")) \
        if cfg.has_section("Payout") else 5_000_000
    return dsn, stripe_key, minimum


async def run(dsn: str, payout_cfg: PayoutConfig, dry_run: bool) -> int:
    ledger = await Ledger.connect(dsn)
    account_store = DonorAccountStore(ledger)
    exit_code = 0
    try:
        accounts = await account_store.get_payout_ready_accounts()
        print(f"{len(accounts)} donor account(s) marked payouts_enabled.")
        paid_count = 0
        for account in accounts:
            donor_url = account["donor_url"]
            stripe_account_id = account["stripe_account_id"]

            # Re-verify with Stripe directly rather than trusting our
            # own possibly-stale flag — onboarding status can change
            # (a donor can un-onboard, Stripe can restrict an account).
            if not dry_run:
                try:
                    still_enabled = await asyncio.to_thread(
                        check_payouts_enabled, payout_cfg, stripe_account_id)
                except Exception as e:
                    print(f"  {donor_url}: could not verify Stripe status "
                         f"({e}), skipping this run")
                    exit_code = 1
                    continue
                if not still_enabled:
                    await account_store.mark_payouts_enabled(donor_url, False)
                    print(f"  {donor_url}: Stripe reports payouts no longer "
                         f"enabled, skipping")
                    continue

            balance = await ledger.get_balance(donor_url)
            if balance < payout_cfg.minimum_payout_micros:
                print(f"  {donor_url}: balance ${balance/1_000_000:.4f} below "
                     f"minimum ${payout_cfg.minimum_payout_micros/1_000_000:.2f}, "
                     f"skipping")
                continue

            print(f"  {donor_url}: balance ${balance/1_000_000:.4f} — "
                 f"{'WOULD PAY (dry run)' if dry_run else 'paying now'}")
            if dry_run:
                continue

            try:
                transfer_id = await asyncio.to_thread(
                    execute_payout, payout_cfg, stripe_account_id, balance)
            except Exception as e:
                print(f"    Stripe transfer failed: {e}")
                exit_code = 1
                continue

            try:
                await ledger.append_entry(
                    "payout", donor_url, -balance, reference=transfer_id,
                    metadata={"stripe_transfer_id": transfer_id,
                             "stripe_account_id": stripe_account_id})
                paid_count += 1
                print(f"    Paid via Stripe transfer {transfer_id}")
            except DuplicateEntryError:
                # Genuinely shouldn't happen (transfer IDs are unique
                # per real Stripe call), but if it somehow does, don't
                # silently lose track of a real transfer that happened.
                print(f"    WARNING: transfer {transfer_id} succeeded at "
                     f"Stripe but a ledger entry with that reference "
                     f"already existed — investigate manually, do not "
                     f"re-run this donor blindly")
                exit_code = 1

        print(f"\n{paid_count} payout(s) completed.")
        return exit_code
    finally:
        await ledger.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--dsn", help="Postgres DSN (overrides config.ini)")
    parser.add_argument("--stripe-key", help="Stripe secret key (overrides config.ini)")
    parser.add_argument("--minimum-micros", type=int,
                        help="minimum payout threshold in micros (overrides config.ini)")
    parser.add_argument("--dry-run", action="store_true",
                        help="report what would be paid without calling Stripe")
    args = parser.parse_args()

    ini_dsn, ini_stripe_key, ini_minimum = _config_from_ini()
    dsn = args.dsn or ini_dsn
    stripe_key = args.stripe_key or ini_stripe_key
    minimum = args.minimum_micros if args.minimum_micros is not None else ini_minimum

    if not dsn:
        print("No DSN provided and [Ledger] dsn is not set in config.ini.")
        sys.exit(2)
    if not stripe_key and not args.dry_run:
        print("No Stripe key provided and [Payout] stripe_secret_key is not "
             "set in config.ini. Use --dry-run to preview without one.")
        sys.exit(2)

    payout_cfg = PayoutConfig(stripe_secret_key=stripe_key,
                              minimum_payout_micros=minimum)
    sys.exit(asyncio.run(run(dsn, payout_cfg, args.dry_run)))


if __name__ == "__main__":
    main()
