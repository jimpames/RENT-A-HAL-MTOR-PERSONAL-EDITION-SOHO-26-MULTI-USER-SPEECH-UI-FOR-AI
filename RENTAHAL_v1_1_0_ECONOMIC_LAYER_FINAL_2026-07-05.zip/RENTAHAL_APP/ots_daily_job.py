#!/usr/bin/env python3
"""
ots_daily_job.py — Sprint 12: the daily anchoring job.

Run this once a day (cron, Task Scheduler, whatever your platform
uses). Each run does two independent things:

  1. If the ledger's chain tip has changed since the last stamp,
     submit the new tip hash to OpenTimestamps calendars (STAMP).
  2. For every anchor still waiting on Bitcoin confirmation, poll the
     calendars to see if it's confirmed yet (UPGRADE). Calendars
     batch for hours before committing a Bitcoin transaction, so most
     runs will find yesterday's stamp still pending — that's normal,
     not a failure, and the job just tries again tomorrow.

After both steps, the most complete available proof gets written to
--public-dir (default ./public_proofs/) as `ledger.ots` plus a
`ledger.txt` sidecar containing the chain-tip hash in hex — publish
this directory however you publish anything else (a public repo, a
page on rentahal.com, whatever). Anyone with these two files can
independently verify the ledger's integrity claim without trusting
this codebase, this operator, or Anthropic's word for any of it —
that's the entire point.

Usage:
    python ots_daily_job.py                       # uses [Ledger] dsn from config.ini
    python ots_daily_job.py --dsn postgresql://...
    python ots_daily_job.py --public-dir ./docs/proofs
"""
import argparse
import asyncio
import configparser
import sys
from pathlib import Path

from realm.ledger import GENESIS_PREV_HASH, Ledger
from realm.ots_anchor import (
    OtsAnchorStore, deserialize, local_verify, serialize,
    submit_to_calendars, upgrade,
)


def _dsn_from_config() -> str:
    cfg = configparser.ConfigParser()
    cfg.read(Path(__file__).parent / "config.ini")
    if cfg.has_section("Ledger"):
        return cfg.get("Ledger", "dsn", fallback="")
    return ""


async def _get_chain_tip(ledger: Ledger) -> tuple:
    """Returns (row_id, hash_hex) of the current chain tip, or
    (0, GENESIS_PREV_HASH) if the ledger is empty."""
    async with ledger._pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT id, row_hash FROM ledger_entries ORDER BY id DESC LIMIT 1")
    if row is None:
        return 0, GENESIS_PREV_HASH
    return row["id"], row["row_hash"]


async def run(dsn: str, public_dir: Path) -> int:
    ledger = await Ledger.connect(dsn)
    store = OtsAnchorStore(ledger)
    exit_code = 0
    try:
        # ── Step 1: stamp the current tip if it's new ──
        tip_row_id, tip_hash_hex = await _get_chain_tip(ledger)
        latest_anchor = await store.get_latest_anchor()
        if latest_anchor is not None and latest_anchor["chain_tip_hash"] == tip_hash_hex:
            print(f"Chain tip unchanged since last stamp ({tip_hash_hex[:16]}...) "
                 f"— skipping a redundant submission.")
        else:
            print(f"New chain tip: {tip_hash_hex[:16]}... (row {tip_row_id}). Stamping...")
            try:
                digest = bytes.fromhex(tip_hash_hex)
                dts, count = submit_to_calendars(digest)
                anchor_id = await store.record_new_stamp(
                    tip_row_id, tip_hash_hex, serialize(dts))
                print(f"  Stamped via {count} calendar(s), anchor id={anchor_id}.")
            except RuntimeError as e:
                print(f"  STAMP FAILED: {e}")
                exit_code = 1

        # ── Step 2: try to upgrade every still-pending anchor ──
        incomplete = await store.get_incomplete_anchors()
        print(f"\n{len(incomplete)} anchor(s) awaiting Bitcoin confirmation.")
        for anchor in incomplete:
            dts = deserialize(anchor["ots_proof"])
            digest = bytes.fromhex(anchor["chain_tip_hash"])
            updated_dts, became_more_complete = upgrade(dts)
            result = local_verify(updated_dts, digest)
            is_complete = result.has_complete_attestation
            await store.mark_upgrade_attempted(
                anchor["id"], serialize(updated_dts), is_complete)
            status = "CONFIRMED" if is_complete else "still pending"
            print(f"  anchor {anchor['id']} ({anchor['chain_tip_hash'][:16]}...): {status}")

        # ── Step 3: publish the best available proof ──
        latest_anchor = await store.get_latest_anchor()
        if latest_anchor is not None:
            public_dir.mkdir(parents=True, exist_ok=True)
            (public_dir / "ledger.ots").write_bytes(latest_anchor["ots_proof"])
            (public_dir / "ledger.txt").write_text(latest_anchor["chain_tip_hash"] + "\n")
            print(f"\nPublished to {public_dir}/ledger.ots + ledger.txt "
                 f"(complete={latest_anchor['is_complete']}).")
            print(f"Anyone can verify with: ots verify {public_dir}/ledger.ots")
        else:
            print("\nNo anchors exist yet — nothing to publish.")

        return exit_code
    finally:
        await ledger.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--dsn", help="Postgres DSN (overrides config.ini)")
    parser.add_argument("--public-dir", default="public_proofs",
                        help="directory to publish the proof into (default: ./public_proofs)")
    args = parser.parse_args()

    dsn = args.dsn or _dsn_from_config()
    if not dsn:
        print("No DSN provided and [Ledger] dsn is not set in config.ini.")
        sys.exit(2)

    sys.exit(asyncio.run(run(dsn, Path(args.public_dir))))


if __name__ == "__main__":
    main()
