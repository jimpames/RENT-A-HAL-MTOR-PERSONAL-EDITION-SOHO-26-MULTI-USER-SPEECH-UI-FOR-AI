"""
wizard.py — RENT-A-HAL boot wizard

Single-file FastAPI app that runs BEFORE the realm. Its job:
  1. Show the operator the current configuration in plain English
  2. Let them edit the 5 high-impact fields (ngrok domain, Federator URL,
     federation desire, GPT4All model, realm name)
  3. Gate GO behind a check that GPT4All is actually running in API mode
     — prevents accidentally joining the federation with a dead LLM
  4. On GO: save config (preserving comments) and spawn the realm
  5. On HALT: terminate the realm subprocess gracefully (SIGTERM → SIGKILL)

The wizard runs on port 9100 (not 9999 — that's the realm). After GO,
the operator typically closes the wizard tab and opens the cockpit at
their realm's URL. The wizard stays open in the background so they can
HALT from the same browser.

Design choices:
- Standalone script, NOT integrated into app.py. The realm shouldn't
  have a wizard mode. The wizard runs PRE-realm and SUPERVISES it.
- Reuses realm/config_schema.py's comment-preserving save_value().
  No new INI parsing logic.
- Subprocess management is best-effort. If the operator kills the
  wizard, the realm keeps running (intentional — separate concerns).
  If the realm dies, the wizard notices on next status poll.
- GPT4All probe is the same code path the realm uses (GET /v1/models).
  If it works for the wizard, it works for the realm.

Defaults are baked in: master_url=https://rentahal.com/api/federate,
desire=on. A fresh install joins the public federation correctly without
the operator having to know anything about federation.
"""
from __future__ import annotations

import asyncio
import configparser
import logging
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import aiohttp
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

# Import the comment-preserving save function from the realm's existing
# config schema. No reason to re-invent.
APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))
from realm.config_schema import Config as RealmConfig
from realm.pow_gate import DEFAULT_TIERS
from realm.ini_location import (
    resolve_ini_dir, ensure_default_ini_files, is_compiled,
    known_legacy_ini_dirs,
)

logger = logging.getLogger("wizard")
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(message)s")


# ─── Constants & defaults ─────────────────────────────────────────────
# These are the SHIPPING DEFAULTS for a new install. The wizard will use
# them as initial values if the relevant ini fields are empty/missing.
# Critical: master_url and desire are pre-set so a fresh install joins
# the public federation by default. The operator can opt out by toggling
# desire=off in the wizard — but they have to do it consciously.

# Compiled-EXE behavior: INI files live in %LOCALAPPDATA%\RentAHalSOHO-Settings\
# <version>\ — the wizard and the realm must read and write the SAME
# config.ini and federation.ini, so this resolution logic lives in ONE
# shared place (realm/ini_location.py) that both entry points import,
# rather than two independently-maintained copies. Those two copies
# DID quietly drift apart at one point (app.py resolved "next to the
# exe" instead of LOCALAPPDATA) — found while reviewing the Nuitka
# compile command, fixed by deleting the duplicate rather than
# re-syncing it by hand, since a duplicate that needs manual syncing is
# exactly what drifted in the first place.
_IS_COMPILED = is_compiled()
INI_DIR = resolve_ini_dir(APP_DIR)

if _IS_COMPILED:
    # First-run bootstrap: a fresh LOCALAPPDATA folder has nothing in
    # it. Copies default config.ini/federation.ini from the bundled
    # templates (see the compile command's --include-data-files) —
    # idempotent, never overwrites an existing/edited file.
    ensure_default_ini_files(INI_DIR, APP_DIR,
                             legacy_dirs=known_legacy_ini_dirs())

CONFIG_INI = INI_DIR / "config.ini"
FEDERATION_INI = INI_DIR / "federation.ini"

# Startup diagnostics — show the operator (and future-us) exactly where
# the wizard is looking for INI files. This MUST match the realm's
# INI lookup path; otherwise wizard edits won't reach the realm.
logger.info("Wizard INI lookup: compiled_mode=%s", _IS_COMPILED)
logger.info("Wizard INI lookup: INI_DIR=%s (REALM's AppData)", INI_DIR)
logger.info("Wizard INI lookup: config.ini exists=%s (%s)",
            CONFIG_INI.exists(), CONFIG_INI)
logger.info("Wizard INI lookup: federation.ini exists=%s (%s)",
            FEDERATION_INI.exists(), FEDERATION_INI)
if _IS_COMPILED and not CONFIG_INI.exists():
    logger.warning("Wizard: config.ini NOT FOUND at realm AppData path. "
                   "First-run install? Wizard will create a default "
                   "config.ini at: %s", CONFIG_INI)
WIZARD_PORT = 9100                                    # different from realm
DEFAULT_FEDERATOR = "https://rentahal.com/api/federate"
DEFAULT_REALM_NAME = "Star Trek Computer Realm"
GPT4ALL_PROBE_TIMEOUT_S = 3.0                         # cheap probe
REALM_LAUNCH_GRACE_S = 5.0                            # boot time before health
REALM_HALT_GRACE_S = 8.0                              # SIGTERM → SIGKILL window


# ─── State ────────────────────────────────────────────────────────────
# The wizard has minimal global state — it doesn't pretend to be a
# durable process supervisor. If the wizard crashes, the realm keeps
# running and the operator can restart the wizard later to halt it
# (we re-discover the realm process if it exists).

_realm_proc: Optional[subprocess.Popen] = None
# ngrok process supervision is parallel to the realm. We track it
# separately so HALT can kill both, and so a missing/broken ngrok
# install doesn't take down the realm launch.
_ngrok_proc: Optional[subprocess.Popen] = None
_ngrok_last_lines: list = []                   # last ~20 stdout/stderr lines


# ─── Config read/write ────────────────────────────────────────────────


def _read_federation_ini() -> dict:
    """Read federation.ini and return current values. If the file
    doesn't exist, return shipping defaults."""
    cfg = configparser.ConfigParser()
    if FEDERATION_INI.exists():
        cfg.read(FEDERATION_INI, encoding="utf-8")
    return {
        "desire": cfg.get("Federation", "desire", fallback="on").strip().lower(),
        "master_url": cfg.get("Federation", "master_url",
                              fallback=DEFAULT_FEDERATOR).strip(),
        "self_url": cfg.get("Federation", "self_url", fallback="").strip(),
        # Federation tuning knobs surfaced in the wizard. Defaults match
        # the shipping federation.ini values.
        "prefer_federation_for_llm_avg_s": cfg.getfloat(
            "Federation", "prefer_federation_for_llm_avg_s", fallback=31.0),
        "prefer_federation_for_tts_avg_s": cfg.getfloat(
            "Federation", "prefer_federation_for_tts_avg_s", fallback=31.0),
        "request_timeout_s": cfg.getfloat(
            "Federation", "request_timeout_s", fallback=59.0),
        # This realm's declared primary role — drives is_go_allowed's
        # node_type-aware gating (chat/vision/imagine). Default "chat"
        # matches every pre-existing deployment with zero config change.
        "node_type": cfg.get("Federation", "node_type",
                             fallback="chat").strip().lower(),
    }


def _write_federation_ini(desire: bool, master_url: str, self_url: str,
                           prefer_llm: Optional[float] = None,
                           prefer_tts: Optional[float] = None,
                           request_timeout_s: Optional[float] = None):
    """Write federation.ini preserving any existing content. If the
    file doesn't exist, write a minimal version with the three fields
    the wizard manages. The full default template is shipped with the
    project — wizard only edits, doesn't regenerate.

    Optional kwargs (prefer_llm, prefer_tts, request_timeout_s) are the
    federation tuning knobs exposed in the wizard. When None, keep
    existing values; when supplied, update in place."""
    # Map of (key -> value) for the optional knobs. Skipped entries
    # don't get rewritten.
    tuning_updates: dict = {}
    if prefer_llm is not None:
        tuning_updates["prefer_federation_for_llm_avg_s"] = str(prefer_llm)
    if prefer_tts is not None:
        tuning_updates["prefer_federation_for_tts_avg_s"] = str(prefer_tts)
    if request_timeout_s is not None:
        tuning_updates["request_timeout_s"] = str(request_timeout_s)
    if FEDERATION_INI.exists():
        # In-place edit: preserve all other settings & comments
        lines = FEDERATION_INI.read_text(encoding="utf-8").splitlines(keepends=True)
        new_lines = []
        in_federation = False
        seen_desire = seen_master = seen_self = False
        seen_tuning = set()
        for raw in lines:
            stripped = raw.strip()
            if stripped.startswith("["):
                in_federation = stripped == "[Federation]"
                new_lines.append(raw)
                continue
            if in_federation and "=" in stripped and not stripped.startswith(("#", ";")):
                key = stripped.split("=", 1)[0].strip()
                if key == "desire":
                    new_lines.append(f"desire = {'on' if desire else 'off'}\n")
                    seen_desire = True
                    continue
                if key == "master_url":
                    new_lines.append(f"master_url = {master_url}\n")
                    seen_master = True
                    continue
                if key == "self_url":
                    new_lines.append(f"self_url = {self_url}\n")
                    seen_self = True
                    continue
                if key in tuning_updates:
                    new_lines.append(f"{key} = {tuning_updates[key]}\n")
                    seen_tuning.add(key)
                    continue
            new_lines.append(raw)
        # Append any fields that weren't present (handles partial inis)
        missing_required = not (seen_desire and seen_master and seen_self)
        missing_tuning = set(tuning_updates.keys()) - seen_tuning
        if missing_required or missing_tuning:
            for i, raw in enumerate(new_lines):
                if raw.strip() == "[Federation]":
                    insert = []
                    if not seen_desire:
                        insert.append(f"desire = {'on' if desire else 'off'}\n")
                    if not seen_master:
                        insert.append(f"master_url = {master_url}\n")
                    if not seen_self:
                        insert.append(f"self_url = {self_url}\n")
                    for k in missing_tuning:
                        insert.append(f"{k} = {tuning_updates[k]}\n")
                    new_lines[i + 1:i + 1] = insert
                    break
        FEDERATION_INI.write_text("".join(new_lines), encoding="utf-8")
    else:
        # Minimal fresh-write — operator can later add federator config
        body = (
            "[Federation]\n"
            f"desire = {'on' if desire else 'off'}\n"
            f"master_url = {master_url}\n"
            f"self_url = {self_url}\n"
        )
        for k, v in tuning_updates.items():
            body += f"{k} = {v}\n"
        body += "\n[Federator]\nenabled = false\n"
        FEDERATION_INI.write_text(body, encoding="utf-8")


def _read_config_ini() -> dict:
    """Read config.ini relevant fields. Uses configparser for read-only
    parsing — that's safe; we use the comment-preserving save_value
    when writing."""
    cfg = configparser.ConfigParser()
    cfg.read(CONFIG_INI, encoding="utf-8")
    return {
        "gpt4all_host": cfg.get("GPT4All", "host", fallback="localhost"),
        "gpt4all_port": cfg.getint("GPT4All", "port", fallback=4891),
        "gpt4all_model": cfg.get("GPT4All", "model",
                                  fallback="Llama 3 8B Instruct"),
        "kokoro_host": cfg.get("KokoroService", "host", fallback="localhost"),
        "kokoro_port": cfg.getint("KokoroService", "port", fallback=9998),
        "server_host": cfg.get("Server", "host", fallback="0.0.0.0"),
        "server_port": cfg.getint("Server", "port", fallback=9999),
        "realm_name": cfg.get("Branding", "realm_name",
                              fallback=DEFAULT_REALM_NAME),
        # Tagline (the orange brag line). Default to BETA-5 for backward
        # compat with installs that don't have this field yet.
        "tagline": cfg.get("Branding", "tagline",
                           fallback="BETA-5 System Terminal"),
        # Voice loop knobs surfaced in wizard (timer default, beacon).
        "wake_word_duration": cfg.get("VoiceLoop", "wake_word_duration",
                                       fallback="short"),
        "privacy_beacon": cfg.getboolean("VoiceLoop", "privacy_beacon",
                                          fallback=True),
        # Secret keys — empty default; wizard masks them in UI as
        # ********* if present but doesn't echo the value back to JS.
        "weather_api_key": cfg.get("Weather", "api_key", fallback=""),
        "ngrok_authtoken": cfg.get("ngrok", "authtoken", fallback=""),
        "ngrok_url": cfg.get("ngrok", "url", fallback=""),
        # CUDA gate override for cloud-only operators (Claude/HF keys).
        "require_cuda": cfg.getboolean("Hardware", "require_cuda",
                                        fallback=True),
        # Vision (LLaVA via Ollama) and Imagine (Automatic1111) — both
        # OPTIONAL capabilities, unlike GPT4All. Read the same way for
        # symmetry, but see get_state()/is_go_allowed() for why neither
        # ever blocks the GO button: a realm with no vision/imagine
        # backend configured is a completely valid, complete deployment
        # (Echo answers "what do you see"/"imagine X" gracefully either
        # way — see engine_chain.py's Echo floors).
        "llava_host": cfg.get("LLaVA", "host", fallback="localhost"),
        "llava_port": cfg.getint("LLaVA", "port", fallback=11434),
        "llava_model": cfg.get("LLaVA", "model", fallback="llava"),
        "automatic1111_host": cfg.get("Automatic1111", "host",
                                       fallback="localhost"),
        "automatic1111_port": cfg.getint("Automatic1111", "port",
                                          fallback=7860),
        # Sprint 15: economic layer config, surfaced for the wizard's
        # own informational panels — none of this gates GO, same
        # posture as Vision/Imagine. All three sections ([Ledger],
        # [Billing], [Payout]) live in config.ini, matching exactly
        # how app.py itself reads them.
        "ledger_dsn": cfg.get("Ledger", "dsn", fallback=""),
        "billing_stripe_secret_key": cfg.get("Billing", "stripe_secret_key",
                                              fallback=""),
        "billing_stripe_webhook_secret": cfg.get(
            "Billing", "stripe_webhook_secret", fallback=""),
        "billing_price_per_submit_micros": cfg.getint(
            "Billing", "price_per_submit_micros", fallback=100),
        "billing_low_balance_threshold_micros": cfg.getint(
            "Billing", "low_balance_threshold_micros", fallback=10000),
        "payout_stripe_secret_key": cfg.get("Payout", "stripe_secret_key",
                                             fallback=""),
        "payout_conscription_rate_micros": cfg.getint(
            "Payout", "conscription_payout_rate_micros", fallback=80),
        "payout_minimum_micros": cfg.getint(
            "Payout", "minimum_payout_micros", fallback=5000000),
    }


def _write_config_ini_fields(fields: dict):
    """Write multiple fields in one go, preserving comments. Each entry
    in `fields` is (section, key) -> value."""
    realm_cfg = RealmConfig(CONFIG_INI)
    for (section, key), value in fields.items():
        # Only write if the section exists in schema. The schema has
        # entries for all the wizard-managed fields after this drop, but
        # we guard against typos.
        try:
            realm_cfg.save_value(section, key, value)
        except Exception as e:
            logger.warning("Skipped writing [%s] %s: %s", section, key, e)


def _write_config_ini(gpt4all_model: str, realm_name: str):
    """Legacy two-field write (kept for backward compat with existing
    test calls). New code should use _write_config_ini_fields."""
    _write_config_ini_fields({
        ("GPT4All", "model"): gpt4all_model,
        ("Branding", "realm_name"): realm_name,
    })


# ─── GPT4All probe ────────────────────────────────────────────────────


async def probe_gpt4all(host: str, port: int) -> dict:
    """Hit GPT4All's OpenAI-compatible /v1/models endpoint. Returns:
    {
      "up": bool,              # is the API responding at all?
      "models": [str, ...],    # list of model names (empty if down)
      "error": str | None,     # error message if down
    }

    This is the ONLY external probe the wizard does. We don't pre-flight
    Kokoro because the realm degrades gracefully if Kokoro is down
    (falls back to SAPI5/pyttsx3). GPT4All is the only hard gate."""
    url = f"http://{host}:{port}/v1/models"
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, timeout=GPT4ALL_PROBE_TIMEOUT_S) as r:
                if r.status != 200:
                    return {"up": False, "models": [],
                            "error": f"HTTP {r.status}"}
                data = await r.json()
                # OpenAI API shape: {"data": [{"id": "model-name", ...}, ...]}
                models = []
                for item in (data.get("data") or []):
                    name = item.get("id") or item.get("name")
                    if name:
                        models.append(name)
                return {"up": True, "models": models, "error": None}
    except asyncio.TimeoutError:
        return {"up": False, "models": [],
                "error": "Timed out connecting to GPT4All"}
    except aiohttp.ClientConnectorError:
        return {"up": False, "models": [],
                "error": "GPT4All API not running"}
    except Exception as e:
        return {"up": False, "models": [], "error": str(e)}


# GPT4All completion probe: catches "loaded but broken" models like
# certain TheBloke quants that respond to /v1/models but don't actually
# generate. Without this, the wizard would say "GO" and the operator
# would launch a realm that returns empty answers forever.
GPT4ALL_COMPLETION_TIMEOUT_S = 15.0           # generous for slow CPUs


async def probe_gpt4all_completion(host: str, port: int,
                                    model: str) -> dict:
    """Send a tiny test prompt to /v1/chat/completions and verify the
    model returns non-empty text. This catches the silent-broken case
    where the API responds, models list is populated, but the selected
    model can't actually generate (corrupt weights, wrong arch, etc.).

    Returns:
    {
      "answers": bool,             # did the model produce non-empty text?
      "elapsed_s": float,
      "preview": str,              # first ~80 chars of the answer
      "error": str | None,
    }

    Test prompt is deliberately tiny: 'Reply with just OK' + max_tokens=10.
    Most working models answer in <5s. Timeout at 15s catches genuinely
    stuck ones without making the wizard feel slow."""
    url = f"http://{host}:{port}/v1/chat/completions"
    body = {
        "model": model,
        "messages": [{"role": "user", "content": "Reply with just OK"}],
        "max_tokens": 10,
        "temperature": 0.0,        # deterministic
    }
    start = time.monotonic()
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(url, json=body,
                              timeout=GPT4ALL_COMPLETION_TIMEOUT_S) as r:
                elapsed = time.monotonic() - start
                if r.status != 200:
                    return {"answers": False, "elapsed_s": elapsed,
                            "preview": "",
                            "error": f"HTTP {r.status}"}
                data = await r.json()
                # OpenAI shape: {"choices": [{"message": {"content": "..."}}]}
                choices = data.get("choices") or []
                if not choices:
                    return {"answers": False, "elapsed_s": elapsed,
                            "preview": "",
                            "error": "Empty choices array in response"}
                content = (choices[0].get("message") or {}).get("content", "")
                content = (content or "").strip()
                if not content:
                    return {"answers": False, "elapsed_s": elapsed,
                            "preview": "",
                            "error": "Model returned empty text"}
                return {"answers": True, "elapsed_s": elapsed,
                        "preview": content[:80], "error": None}
    except asyncio.TimeoutError:
        return {"answers": False,
                "elapsed_s": GPT4ALL_COMPLETION_TIMEOUT_S,
                "preview": "",
                "error": f"Model did not respond within "
                         f"{GPT4ALL_COMPLETION_TIMEOUT_S}s "
                         f"(common with broken/corrupt model files)"}
    except Exception as e:
        return {"answers": False,
                "elapsed_s": time.monotonic() - start,
                "preview": "", "error": str(e)}


# ─── Vision (LLaVA via Ollama) probe ───────────────────────────────────
# Same shape as probe_gpt4all — {"up", "models", "error"} — but this
# capability is OPTIONAL. It's surfaced in get_state() purely as status
# information; it is deliberately NEVER passed to is_go_allowed(). A
# realm with no vision backend configured is a complete, valid
# deployment (see engine_chain.py's EchoVisionProvider floor).
VISION_PROBE_TIMEOUT_S = 3.0


async def probe_llava(host: str, port: int) -> dict:
    """Hit Ollama's /api/tags endpoint and list installed models. Does
    NOT verify LLaVA can actually describe an image — that would need
    a real test frame and is more than a first-run wizard needs. A
    model appearing in this list plus a successful health check is a
    reasonable enough bar; the realm's own EchoVisionProvider floor
    covers the rest gracefully at runtime if a model turns out to be
    broken."""
    url = f"http://{host}:{port}/api/tags"
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, timeout=VISION_PROBE_TIMEOUT_S) as r:
                if r.status != 200:
                    return {"up": False, "models": [],
                            "error": f"HTTP {r.status}"}
                data = await r.json()
                # Ollama shape: {"models": [{"name": "llava:latest", ...}]}
                models = [m.get("name") for m in (data.get("models") or [])
                         if m.get("name")]
                return {"up": True, "models": models, "error": None}
    except asyncio.TimeoutError:
        return {"up": False, "models": [],
                "error": "Timed out connecting to Ollama"}
    except aiohttp.ClientConnectorError:
        return {"up": False, "models": [],
                "error": "Ollama not running (this is OK — vision is optional)"}
    except Exception as e:
        return {"up": False, "models": [], "error": str(e)}


# ─── Imagine (Automatic1111) probe ─────────────────────────────────────
# Same shape and same "informational only, never gates GO" posture as
# probe_llava above.
IMAGINE_PROBE_TIMEOUT_S = 3.0


async def probe_automatic1111(host: str, port: int) -> dict:
    """Hit AUTOMATIC1111's /sdapi/v1/sd-models endpoint (available
    whenever the webui was launched with --api) and list installed
    checkpoints. Does NOT generate a test image — a real txt2img call
    is slow (seconds, not milliseconds) and unnecessary for a first-run
    wizard; EchoImagineProvider's floor (the rickroll) covers the
    "configured but broken" case gracefully at runtime."""
    url = f"http://{host}:{port}/sdapi/v1/sd-models"
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, timeout=IMAGINE_PROBE_TIMEOUT_S) as r:
                if r.status != 200:
                    return {"up": False, "models": [],
                            "error": f"HTTP {r.status}"}
                data = await r.json()
                # AUTOMATIC1111 shape: [{"title": "...", "model_name": "...", ...}]
                models = [m.get("model_name") or m.get("title")
                         for m in (data or []) if isinstance(m, dict)]
                models = [m for m in models if m]
                return {"up": True, "models": models, "error": None}
    except asyncio.TimeoutError:
        return {"up": False, "models": [],
                "error": "Timed out connecting to AUTOMATIC1111"}
    except aiohttp.ClientConnectorError:
        return {"up": False, "models": [],
                "error": "AUTOMATIC1111 not running (this is OK — "
                         "imagine is optional)"}
    except Exception as e:
        return {"up": False, "models": [], "error": str(e)}


# ─── Economic layer probes (Sprint 15) ─────────────────────────────
# Same "informational only, never gates GO" posture as Vision/Imagine
# above — the economic layer is entirely opt-in. These probes are what
# actually let the wizard tell an operator "your Postgres connection
# string works" or "your Stripe key is valid" before they save a
# config that silently doesn't work, mirroring the value GPT4All's own
# probe already provides for the required capability.
LEDGER_PROBE_TIMEOUT_S = 5.0
STRIPE_PROBE_TIMEOUT_S = 5.0


async def probe_ledger(dsn: str) -> dict:
    """Attempts a real, lightweight Postgres connection using the
    configured [Ledger] dsn — connect, run one trivial query, close.
    Does NOT run migrations here (that's Ledger.connect()'s own job,
    invoked for real at app.py boot) — this is purely "can we even
    reach this database with these credentials," the same tier of
    check GPT4All's own probe does before ever trying anything
    heavier. Lazy-imports asyncpg — an optional dependency the wizard
    itself doesn't otherwise need."""
    if not dsn:
        return {"up": False, "error": "not configured"}
    try:
        import asyncpg
    except ImportError:
        return {"up": False,
                "error": "asyncpg not installed (pip install asyncpg)"}
    try:
        conn = await asyncio.wait_for(asyncpg.connect(dsn),
                                      timeout=LEDGER_PROBE_TIMEOUT_S)
        try:
            await conn.fetchval("SELECT 1")
        finally:
            await conn.close()
        return {"up": True, "error": None}
    except asyncio.TimeoutError:
        return {"up": False, "error": "Timed out connecting to Postgres"}
    except Exception as e:
        return {"up": False, "error": str(e)}


async def probe_stripe_key(secret_key: str) -> dict:
    """Attempts a real, cheap Stripe API call to validate a secret key
    actually works — stripe.Account.retrieve() with no ID returns the
    PLATFORM account itself (the account the key belongs to), which is
    about as lightweight a real validity check as the API offers.
    Lazy-imports stripe — an optional dependency. Distinguishes
    'not configured' from 'configured but invalid/unreachable' so the
    wizard can say something more useful than a bare failure."""
    if not secret_key:
        return {"valid": False, "error": "not configured"}
    try:
        import stripe
    except ImportError:
        return {"valid": False,
                "error": "stripe not installed (pip install stripe)"}
    try:
        account = await asyncio.to_thread(
            stripe.Account.retrieve, api_key=secret_key)
        return {"valid": True, "error": None,
               "account_id": getattr(account, "id", None)}
    except Exception as e:
        return {"valid": False, "error": str(e)}


def probe_cuda() -> dict:
    """Compatibility shim. The real implementation now lives in
    realm/gpu_probe.py so both the wizard and the realm cockpit footer
    use the same battle-tested probe. Kept as a local name to minimize
    diff for callers (line 721 below, gates logic in passes_gates)."""
    from realm.gpu_probe import probe_cuda as _probe
    return _probe()


# ─── Gate logic — can the operator click GO? ──────────────────────────


def is_go_allowed(gpt4all_probe: dict, self_url: str, desire: bool,
                  selected_model: str,
                  completion_probe: Optional[dict] = None,
                  cuda_probe: Optional[dict] = None,
                  require_cuda: bool = True,
                  node_type: str = "chat",
                  vision_probe: Optional[dict] = None,
                  imagine_probe: Optional[dict] = None) -> tuple[bool, str]:
    """Pure function — returns (allowed, reason). The wizard greys
    the GO button when not allowed, and shows the reason inline.

    Gate order (first failure wins, surface the most actionable error):
      1. CUDA GPU detected — unless require_cuda=False (cloud-only mode)
      2. node_type == 'chat' (the default): GPT4All API responding, a
         model loaded, a model selected, and it actually answers a test
         prompt. node_type == 'vision'/'imagine': the corresponding
         backend (Ollama/AUTOMATIC1111) responding with at least one
         model/checkpoint installed — GPT4All is NOT required at all
         for these deployment shapes. This is a deliberate reversal of
         an earlier design note (see test_wizard_vision_imagine.py's
         history) that said vision/imagine must NEVER influence the
         gate: that was correct for a CHAT-primary realm, where
         vision/imagine really are optional extras, but wrong for a
         realm explicitly declaring itself vision- or imagine-primary
         via [Federation] node_type — for THAT realm, chat is the
         extra, and its own declared capability is the one that
         actually needs to work before GO makes sense.
      3. Federation desire=on but self_url empty"""
    # CUDA first — operator can't fix anything else without it (or without
    # consciously opting into cloud-only mode). Applies to every mode;
    # vision/imagine backends benefit from a GPU at least as much as
    # GPT4All does, arguably more (LLaVA/Automatic1111 are typically
    # heavier than a quantized chat model).
    if require_cuda:
        if cuda_probe is None:
            # Caller didn't run the probe — assume failure to be safe.
            return False, ("CUDA probe missing. Re-run wizard.")
        if not cuda_probe.get("ok"):
            return False, (
                "No CUDA GPU detected. " +
                (cuda_probe.get("error") or "") +
                "\nInstall NVIDIA drivers and verify with `nvidia-smi` "
                "in cmd. If running cloud-only with API keys, set "
                "[Hardware] require_cuda = false in config.ini."
            )

    node_type = (node_type or "chat").strip().lower()

    if node_type == "vision":
        vp = vision_probe or {"up": False, "models": [], "error": None}
        if not vp.get("up"):
            return False, (
                "This realm is configured as a vision-primary node "
                "([Federation] node_type = vision), but Ollama is not "
                "responding. " + (vp.get("error") or "") +
                "\nInstall Ollama, run `ollama pull llava`, and the "
                "wizard will detect it automatically."
            )
        if not vp.get("models"):
            return False, (
                "Ollama is running but no vision model is installed. "
                "Run `ollama pull llava` and the wizard will detect it."
            )
    elif node_type == "imagine":
        ip = imagine_probe or {"up": False, "models": [], "error": None}
        if not ip.get("up"):
            return False, (
                "This realm is configured as an imagine-primary node "
                "([Federation] node_type = imagine), but AUTOMATIC1111 "
                "is not responding. " + (ip.get("error") or "") +
                "\nLaunch AUTOMATIC1111's webui with --api and the "
                "wizard will detect it automatically."
            )
        if not ip.get("models"):
            return False, (
                "AUTOMATIC1111 is running but no checkpoint is loaded. "
                "Place a checkpoint in its models/Stable-diffusion "
                "folder and the wizard will detect it."
            )
    else:
        # node_type == 'chat' (the default) — exactly the pre-existing
        # gate, unchanged, so every deployment that's never touched
        # [Federation] node_type behaves identically to before.
        if not gpt4all_probe["up"]:
            return False, (
                "GPT4All API is not responding. Install GPT4All, load a "
                "model, and enable the Local Server in Settings → "
                "Application → Enable Local Server. The wizard will "
                "detect it automatically."
            )
        if not gpt4all_probe["models"]:
            return False, (
                "GPT4All is running but no model is loaded. Open "
                "GPT4All, download a model (Llama 3 8B Instruct "
                "recommended), and the wizard will detect it."
            )
        if not selected_model:
            return False, "Pick a model from the dropdown."
        # Completion probe — catches models that load but don't generate.
        # Skipped if caller didn't run it (during initial render before
        # we've had time to do a 15s test call).
        if completion_probe is not None:
            if not completion_probe.get("answers"):
                return False, (
                    f"Model '{selected_model}' is loaded but didn't "
                    f"answer a test prompt. " +
                    (completion_probe.get("error") or "") +
                    "\nTry selecting a different model "
                    "(Llama 3 8B Instruct is known-good)."
                )

    if desire and not self_url.strip():
        return False, (
            "Federation is ON but no ngrok domain is set. Fill in your "
            "public realm URL (e.g. https://yourrealm.ngrok.app) or turn "
            "Federation OFF to run standalone."
        )
    return True, ""


# ─── Realm subprocess management ──────────────────────────────────────


def launch_realm() -> Optional[int]:
    """Spawn `python app.py` as a child process. Returns the PID on
    success, None on failure. The child inherits stdout/stderr so the
    operator can see boot logs in their terminal.

    Best-effort: we don't supervise the realm beyond keeping its Popen
    handle. If the realm crashes after boot, that's visible in the
    realm's own log. If the wizard is killed, the realm keeps running
    (intentional — the realm is the important process).

    Compiled-EXE behavior: When the wizard is compiled to a Nuitka
    one-file EXE, sys.executable points to RentAHalWizard.exe — not
    to a Python interpreter. Running `RentAHalWizard.exe app.py` would
    spawn another wizard. To handle this, detect compiled mode and
    launch the SIBLING realm EXE (RentAHalSOHO.exe) directly. Inno
    installs both EXEs in the same directory so APP_DIR (which is the
    Nuitka extraction temp dir at runtime) is NOT where the EXEs live;
    we use the actual EXE directory instead, which IS where Inno
    installed the sibling realm EXE. Source mode is unchanged."""
    global _realm_proc
    if _realm_proc is not None and _realm_proc.poll() is None:
        # Already running — don't start a second one
        return _realm_proc.pid
    try:
        if _IS_COMPILED:
            # Compiled EXE mode — find the sibling RentAHalSOHO.exe.
            #
            # CRITICAL: In Nuitka onefile mode, sys.executable points to
            # the EXTRACTED Python interpreter inside %LOCALAPPDATA%, NOT
            # to the EXE the operator launched. We must use sys.argv[0]
            # which Nuitka populates with the original EXE path.
            user_exe_path = Path(sys.argv[0]).resolve()
            user_exe_dir = user_exe_path.parent
            realm_exe = user_exe_dir / "RentAHalSOHO.exe"
            logger.info("Realm launch: wizard EXE at %s", user_exe_path)
            logger.info("Realm launch: looking for sibling realm at %s", realm_exe)
            logger.info("Realm launch: realm EXE exists=%s", realm_exe.exists())
            if not realm_exe.exists():
                logger.error(
                    "Realm launch FAILED: RentAHalSOHO.exe not found at %s. "
                    "Place RentAHalSOHO.exe in the same directory as "
                    "RentAHalWizard.exe (the Inno installer does this "
                    "automatically; if you're testing manually, copy it "
                    "next to the wizard).", realm_exe)
                _realm_proc = None
                return None
            realm_cmd = [str(realm_exe)]
            realm_cwd = str(user_exe_dir)
        else:
            # Source mode — original behavior: spawn `python app.py`
            realm_cmd = [sys.executable, str(APP_DIR / "app.py")]
            realm_cwd = str(APP_DIR)
        _realm_proc = subprocess.Popen(realm_cmd, cwd=realm_cwd)
        logger.info("Realm subprocess started (pid=%d, cmd=%s)",
                    _realm_proc.pid, realm_cmd)
        return _realm_proc.pid
    except Exception as e:
        logger.error("Failed to launch realm: %s", e)
        _realm_proc = None
        return None


def halt_realm() -> bool:
    """Terminate the realm subprocess. Returns True if a realm was
    running and is now stopped, False if no realm was running or halt
    failed.

    Two-phase shutdown: SIGTERM first (let it close ports cleanly),
    SIGKILL after REALM_HALT_GRACE_S if it didn't exit. The realm's
    own FastAPI lifespan handles cleanup on SIGTERM — federation
    check-in client, bus subscribers, etc."""
    global _realm_proc
    if _realm_proc is None:
        return False
    if _realm_proc.poll() is not None:
        # Already exited
        _realm_proc = None
        return False
    try:
        _realm_proc.terminate()
        try:
            _realm_proc.wait(timeout=REALM_HALT_GRACE_S)
        except subprocess.TimeoutExpired:
            logger.warning("Realm did not exit after SIGTERM; sending SIGKILL")
            _realm_proc.kill()
            _realm_proc.wait(timeout=2.0)
        logger.info("Realm subprocess halted")
        _realm_proc = None
        return True
    except Exception as e:
        logger.error("Halt failed: %s", e)
        return False


def realm_status() -> dict:
    """Returns {running: bool, pid: int|None}."""
    global _realm_proc
    if _realm_proc is None:
        return {"running": False, "pid": None}
    rc = _realm_proc.poll()
    if rc is None:
        return {"running": True, "pid": _realm_proc.pid}
    # Exited
    _realm_proc = None
    return {"running": False, "pid": None, "last_exit_code": rc}


# ─── ngrok subprocess (best-effort, independent of realm) ────────────


def launch_ngrok(reserved_url: str, server_port: int) -> dict:
    """Spawn ngrok as a child process if a reserved URL is configured.
    Returns a status dict the wizard surfaces in the dashboard. Best-
    effort: ngrok failure NEVER blocks the realm launch — the realm
    still runs on its local port; the operator either fixes ngrok or
    uses the realm without a public tunnel.

    Returns:
    {
      "started": bool,
      "pid": int|None,
      "command": str,        # the actual command we ran (or would have)
      "error": str|None,
    }"""
    global _ngrok_proc, _ngrok_last_lines
    _ngrok_last_lines = []
    if not reserved_url:
        return {"started": False, "pid": None,
                "command": "", "error": "no reserved URL configured"}
    if _ngrok_proc is not None and _ngrok_proc.poll() is None:
        return {"started": True, "pid": _ngrok_proc.pid,
                "command": "(already running)", "error": None}
    # Build the command. Strip https:// if operator pasted it.
    url = reserved_url.replace("https://", "").replace("http://", "").strip("/")
    cmd = ["ngrok", "http", f"--url={url}", str(server_port)]
    cmd_str = " ".join(cmd)
    try:
        _ngrok_proc = subprocess.Popen(
            cmd,
            cwd=str(APP_DIR),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1,                      # line-buffered
        )
        # Spawn a reader thread to capture the rolling tail of ngrok output.
        # Without this the operator has no idea why ngrok died if it does.
        import threading
        def _reader():
            global _ngrok_last_lines
            try:
                for line in _ngrok_proc.stdout:
                    _ngrok_last_lines.append(line.rstrip())
                    # Cap rolling window at 20 lines so memory stays bounded
                    if len(_ngrok_last_lines) > 20:
                        _ngrok_last_lines = _ngrok_last_lines[-20:]
            except Exception:
                pass
        threading.Thread(target=_reader, daemon=True).start()
        logger.info("ngrok started: %s (pid=%d)", cmd_str, _ngrok_proc.pid)
        return {"started": True, "pid": _ngrok_proc.pid,
                "command": cmd_str, "error": None}
    except FileNotFoundError:
        _ngrok_proc = None
        return {"started": False, "pid": None, "command": cmd_str,
                "error": "ngrok not found on PATH. Install ngrok and "
                         "verify with `ngrok version` in cmd."}
    except Exception as e:
        _ngrok_proc = None
        return {"started": False, "pid": None, "command": cmd_str,
                "error": str(e)}


def halt_ngrok() -> bool:
    """Terminate the ngrok subprocess if running."""
    global _ngrok_proc
    if _ngrok_proc is None:
        return False
    if _ngrok_proc.poll() is not None:
        _ngrok_proc = None
        return False
    try:
        _ngrok_proc.terminate()
        try:
            _ngrok_proc.wait(timeout=3.0)
        except subprocess.TimeoutExpired:
            _ngrok_proc.kill()
            _ngrok_proc.wait(timeout=2.0)
        logger.info("ngrok subprocess halted")
        _ngrok_proc = None
        return True
    except Exception as e:
        logger.error("ngrok halt failed: %s", e)
        return False


def ngrok_status() -> dict:
    """Returns {running, pid, last_lines}. Used by the wizard dashboard."""
    global _ngrok_proc, _ngrok_last_lines
    if _ngrok_proc is None:
        return {"running": False, "pid": None,
                "last_lines": list(_ngrok_last_lines)}
    rc = _ngrok_proc.poll()
    if rc is None:
        return {"running": True, "pid": _ngrok_proc.pid,
                "last_lines": list(_ngrok_last_lines)}
    # Exited
    _ngrok_proc = None
    return {"running": False, "pid": None,
            "last_lines": list(_ngrok_last_lines),
            "last_exit_code": rc}


# ─── FastAPI app ──────────────────────────────────────────────────────


def build_app() -> FastAPI:
    app = FastAPI(title="RENT-A-HAL Boot Wizard")

    # Cached completion probe — the test call takes up to 15s, so we don't
    # run it on every 2s poll. Re-runs when host/port/model changes or
    # when the operator explicitly clicks "re-test".
    _completion_cache: dict = {"key": None, "result": None,
                                "stamp": 0.0}

    @app.get("/", response_class=HTMLResponse)
    async def index():
        html_path = APP_DIR / "templates" / "wizard.html"
        return HTMLResponse(html_path.read_text(encoding="utf-8"))

    @app.get("/api/wizard/state")
    async def get_state():
        """Single endpoint the wizard polls every 2 seconds. Returns
        everything the UI needs to render: config values, GPT4All
        probe results, CUDA probe, gate status, realm + ngrok status."""
        cfg = _read_config_ini()
        fed = _read_federation_ini()
        probe = await probe_gpt4all(cfg["gpt4all_host"], cfg["gpt4all_port"])
        cuda = probe_cuda()
        desire = fed["desire"] in ("on", "true", "1", "yes")

        # Completion probe — cached because it's expensive (up to 15s).
        # Re-fires on key change (model selection or endpoint change),
        # or after 5 minutes for liveness.
        completion = None
        if probe["up"] and probe["models"] and cfg["gpt4all_model"]:
            key = (cfg["gpt4all_host"], cfg["gpt4all_port"],
                   cfg["gpt4all_model"])
            cached_age = time.time() - _completion_cache["stamp"]
            if (_completion_cache["key"] == key
                and _completion_cache["result"] is not None
                and cached_age < 300):
                completion = _completion_cache["result"]
            else:
                completion = await probe_gpt4all_completion(
                    cfg["gpt4all_host"], cfg["gpt4all_port"],
                    cfg["gpt4all_model"])
                _completion_cache["key"] = key
                _completion_cache["result"] = completion
                _completion_cache["stamp"] = time.time()

        # Vision/Imagine probes — needed for informational display
        # regardless of node_type, AND as the actual gate inputs when
        # node_type is vision/imagine (see is_go_allowed). Cheap (3s
        # timeout each) so no caching needed, unlike GPT4All's
        # completion probe.
        vision = await probe_llava(cfg["llava_host"], cfg["llava_port"])
        imagine = await probe_automatic1111(cfg["automatic1111_host"],
                                            cfg["automatic1111_port"])

        # Sprint 15: economic layer probes — PURELY informational,
        # never passed to is_go_allowed(). A realm that's never touched
        # the economic layer (the overwhelming default) sees clean
        # "not configured" badges here, same posture as an unconfigured
        # Vision/Imagine backend.
        ledger_probe = await probe_ledger(cfg["ledger_dsn"])
        billing_probe = await probe_stripe_key(cfg["billing_stripe_secret_key"])
        payout_probe = await probe_stripe_key(cfg["payout_stripe_secret_key"])

        allowed, reason = is_go_allowed(
            probe, fed["self_url"], desire, cfg["gpt4all_model"],
            completion_probe=completion, cuda_probe=cuda,
            require_cuda=cfg["require_cuda"],
            node_type=fed["node_type"],
            vision_probe=vision, imagine_probe=imagine)

        return {
            "config": {
                "gpt4all_host": cfg["gpt4all_host"],
                "gpt4all_port": cfg["gpt4all_port"],
                "gpt4all_model": cfg["gpt4all_model"],
                "server_host": cfg["server_host"],
                "server_port": cfg["server_port"],
                "realm_name": cfg["realm_name"],
                "tagline": cfg["tagline"],
                "kokoro_host": cfg["kokoro_host"],
                "kokoro_port": cfg["kokoro_port"],
                "wake_word_duration": cfg["wake_word_duration"],
                "privacy_beacon": cfg["privacy_beacon"],
                # Secrets — surfaced as bool "has-value" to UI, never
                # echoed back so they can't leak via the wizard page.
                "has_weather_api_key": bool(cfg["weather_api_key"]),
                "has_ngrok_authtoken": bool(cfg["ngrok_authtoken"]),
                "ngrok_url": cfg["ngrok_url"],
                "require_cuda": cfg["require_cuda"],
                "llava_host": cfg["llava_host"],
                "llava_port": cfg["llava_port"],
                "llava_model": cfg["llava_model"],
                "automatic1111_host": cfg["automatic1111_host"],
                "automatic1111_port": cfg["automatic1111_port"],
                # Sprint 15: economic layer — secrets surfaced as
                # has-value bools only, same "never echo a secret back"
                # discipline as weather_api_key/ngrok_authtoken above.
                "ledger_dsn": cfg["ledger_dsn"],
                "has_billing_stripe_secret_key": bool(cfg["billing_stripe_secret_key"]),
                "has_billing_stripe_webhook_secret": bool(cfg["billing_stripe_webhook_secret"]),
                "billing_price_per_submit_micros": cfg["billing_price_per_submit_micros"],
                "billing_low_balance_threshold_micros": cfg["billing_low_balance_threshold_micros"],
                "has_payout_stripe_secret_key": bool(cfg["payout_stripe_secret_key"]),
                "payout_conscription_rate_micros": cfg["payout_conscription_rate_micros"],
                "payout_minimum_micros": cfg["payout_minimum_micros"],
            },
            "federation": {
                "desire": desire,
                "master_url": fed["master_url"],
                "self_url": fed["self_url"],
                "prefer_federation_for_llm_avg_s":
                    fed.get("prefer_federation_for_llm_avg_s", 31.0),
                "prefer_federation_for_tts_avg_s":
                    fed.get("prefer_federation_for_tts_avg_s", 31.0),
                "request_timeout_s":
                    fed.get("request_timeout_s", 59.0),
                "node_type": fed.get("node_type", "chat"),
            },
            "gpt4all": probe,
            "completion": completion,
            "cuda": cuda,
            "vision": vision,
            "imagine": imagine,
            # Sprint 15: economic layer probe results + the static
            # abuse-gate tier ladder (no probe needed — it's config,
            # not a live connection — see realm/pow_gate.py's own
            # DEFAULT_TIERS for the source of truth this mirrors).
            "ledger": ledger_probe,
            "billing": billing_probe,
            "payout": payout_probe,
            "abuse_gate_tiers": [
                {"threshold": t, "label": label, "bits": bits}
                for t, label, bits in DEFAULT_TIERS
            ],
            "gate": {"allowed": allowed, "reason": reason},
            "realm": realm_status(),
            "ngrok": ngrok_status(),
        }

    @app.post("/api/wizard/save")
    async def save(payload: dict):
        """Write the operator's chosen values to config.ini and
        federation.ini. Doesn't launch — the GO button calls /launch
        after a successful save."""
        try:
            gpt4all_model = (payload.get("gpt4all_model") or "").strip()
            realm_name = (payload.get("realm_name") or DEFAULT_REALM_NAME).strip()
            tagline = payload.get("tagline", "BETA-5 System Terminal")
            wake_duration = (payload.get("wake_word_duration") or "short").strip().lower()
            if wake_duration not in ("short", "medium", "long", "infinite", "off"):
                wake_duration = "short"
            privacy_beacon = bool(payload.get("privacy_beacon", True))
            desire = bool(payload.get("desire", True))
            master_url = (payload.get("master_url") or DEFAULT_FEDERATOR).strip()
            self_url = (payload.get("self_url") or "").strip()
            # Federation tuning — keep within sane bounds
            prefer_llm = float(payload.get("prefer_federation_for_llm_avg_s", 31.0))
            prefer_tts = float(payload.get("prefer_federation_for_tts_avg_s", 31.0))
            req_timeout = float(payload.get("request_timeout_s", 59.0))
            # Secrets — write only if non-empty (preserves existing value)
            weather_key = payload.get("weather_api_key", "")
            ngrok_token = payload.get("ngrok_authtoken", "")
            ngrok_url_val = (payload.get("ngrok_url") or "").strip()
            # Vision/Imagine — optional, so empty values are fine; we
            # still write them (unlike secrets, there's no "keep
            # existing on empty" concern — host/port/model have sane
            # defaults in config.ini's own schema either way).
            llava_host = (payload.get("llava_host") or "localhost").strip()
            llava_port = str(payload.get("llava_port") or 11434)
            llava_model = (payload.get("llava_model") or "llava").strip()
            a1111_host = (payload.get("automatic1111_host")
                         or "localhost").strip()
            a1111_port = str(payload.get("automatic1111_port") or 7860)
            # Sprint 15: economic layer. Secrets (dsn contains
            # credentials, stripe keys ARE credentials) follow the same
            # "write only if non-empty" pattern as weather_key/
            # ngrok_token below — an empty field means "leave whatever's
            # already there," not "erase it." Non-secret numeric config
            # writes unconditionally, same as llava_host/port above.
            ledger_dsn_val = payload.get("ledger_dsn", "")
            billing_stripe_secret_key = payload.get("billing_stripe_secret_key", "")
            billing_stripe_webhook_secret = payload.get("billing_stripe_webhook_secret", "")
            billing_price = str(payload.get("billing_price_per_submit_micros") or 100)
            billing_threshold = str(payload.get(
                "billing_low_balance_threshold_micros") or 10000)
            payout_stripe_secret_key = payload.get("payout_stripe_secret_key", "")
            payout_rate = str(payload.get("payout_conscription_rate_micros") or 80)
            payout_minimum = str(payload.get("payout_minimum_micros") or 5000000)

            # Write config.ini fields in one comment-preserving pass.
            # NOTE: this used to be gated behind `if gpt4all_model:` for
            # the WHOLE dict — meaning a vision-primary or imagine-
            # primary deployment (no GPT4All model selected at all,
            # which is a completely valid "mode" per the multi-mode
            # federation design) would never get ITS OWN fields saved
            # either. Only the GPT4All model field itself stays
            # conditional now (don't overwrite a real value with blank);
            # everything else — including the new LLaVA/Automatic1111
            # fields — writes unconditionally.
            fields = {
                ("Branding", "realm_name"): realm_name,
                ("Branding", "tagline"): tagline,
                ("VoiceLoop", "wake_word_duration"): wake_duration,
                ("VoiceLoop", "privacy_beacon"): "true" if privacy_beacon else "false",
                ("ngrok", "url"): ngrok_url_val,
                ("LLaVA", "host"): llava_host,
                ("LLaVA", "port"): llava_port,
                ("LLaVA", "model"): llava_model,
                ("Automatic1111", "host"): a1111_host,
                ("Automatic1111", "port"): a1111_port,
                ("Billing", "price_per_submit_micros"): billing_price,
                ("Billing", "low_balance_threshold_micros"): billing_threshold,
                ("Payout", "conscription_payout_rate_micros"): payout_rate,
                ("Payout", "minimum_payout_micros"): payout_minimum,
            }
            if gpt4all_model:
                fields[("GPT4All", "model")] = gpt4all_model
            if weather_key:
                fields[("Weather", "api_key")] = weather_key
            if ngrok_token:
                fields[("ngrok", "authtoken")] = ngrok_token
            if ledger_dsn_val:
                fields[("Ledger", "dsn")] = ledger_dsn_val
            if billing_stripe_secret_key:
                fields[("Billing", "stripe_secret_key")] = billing_stripe_secret_key
            if billing_stripe_webhook_secret:
                fields[("Billing", "stripe_webhook_secret")] = billing_stripe_webhook_secret
            if payout_stripe_secret_key:
                fields[("Payout", "stripe_secret_key")] = payout_stripe_secret_key
            _write_config_ini_fields(fields)

            # Write federation.ini including the three tuning knobs
            _write_federation_ini(desire, master_url, self_url,
                                   prefer_llm=prefer_llm,
                                   prefer_tts=prefer_tts,
                                   request_timeout_s=req_timeout)

            # Invalidate completion cache so the operator sees a fresh
            # probe with the new model selection
            _completion_cache["key"] = None
            _completion_cache["result"] = None
            return {"saved": True}
        except Exception as e:
            logger.error("Save failed: %s", e)
            return JSONResponse({"saved": False, "error": str(e)},
                                status_code=500)

    @app.post("/api/wizard/launch")
    async def launch():
        """Spawn the realm AND ngrok tunnel (if configured). The wizard
        re-renders as a dashboard with HALT button + link to the cockpit.
        ngrok failure does NOT block realm launch — realm runs locally
        even if the public tunnel can't be established."""
        cfg = _read_config_ini()
        fed = _read_federation_ini()
        probe = await probe_gpt4all(cfg["gpt4all_host"], cfg["gpt4all_port"])
        cuda = probe_cuda()
        desire = fed["desire"] in ("on", "true", "1", "yes")
        # Re-fire completion probe to confirm the model is still answering
        completion = None
        if probe["up"] and cfg["gpt4all_model"]:
            completion = await probe_gpt4all_completion(
                cfg["gpt4all_host"], cfg["gpt4all_port"],
                cfg["gpt4all_model"])
        # Same node_type-aware re-verification as get_state() — a
        # vision/imagine-primary realm's launch check must test ITS
        # OWN declared backend, not demand GPT4All be up too.
        vision = await probe_llava(cfg["llava_host"], cfg["llava_port"])
        imagine = await probe_automatic1111(cfg["automatic1111_host"],
                                            cfg["automatic1111_port"])
        allowed, reason = is_go_allowed(
            probe, fed["self_url"], desire, cfg["gpt4all_model"],
            completion_probe=completion, cuda_probe=cuda,
            require_cuda=cfg["require_cuda"],
            node_type=fed["node_type"],
            vision_probe=vision, imagine_probe=imagine)
        if not allowed:
            return JSONResponse(
                {"launched": False, "error": reason}, status_code=400)
        pid = launch_realm()
        if pid is None:
            return JSONResponse(
                {"launched": False, "error": "realm subprocess spawn failed"},
                status_code=500)
        # Best-effort ngrok — failure doesn't fail the launch
        ngrok_result = launch_ngrok(cfg["ngrok_url"], cfg["server_port"])
        return {"launched": True, "pid": pid,
                "cockpit_url": f"http://localhost:{cfg['server_port']}",
                "ngrok": ngrok_result}

    @app.post("/api/wizard/halt")
    async def halt():
        """Terminate both the realm and ngrok subprocesses."""
        realm_halted = halt_realm()
        ngrok_halted = halt_ngrok()
        return {"halted": realm_halted, "ngrok_halted": ngrok_halted}

    return app


def main():
    """Entry point: serve the wizard on port 9100 and print the URL.
    The operator opens their browser to that URL."""
    app = build_app()
    print()
    print("=" * 70)
    print("  RENT-A-HAL Boot Wizard")
    print(f"  Open in browser: http://localhost:{WIZARD_PORT}")
    print("=" * 70)
    print()
    # Run uvicorn in single-worker mode — the wizard is one operator,
    # not a multi-user service. Log level WARNING to keep terminal clean.
    uvicorn.run(app, host="127.0.0.1", port=WIZARD_PORT,
                log_level="warning")


if __name__ == "__main__":
    main()
