#!/usr/bin/env python3
"""
pow_benchmark.py — Sprint 10 acceptance check: does the difficulty
ladder's real wall-clock cost actually match ECONOMIC_LAYER_DESIGN.md's
table, on THIS machine?

Deliberately a standalone script, not a pytest test: solving the
pi-10000 tier honestly takes real minutes, and has no business slowing
down a routine `pytest tests/` run that otherwise finishes in about 20
seconds. Run this by hand when you want to sanity-check the tuning:

    python pow_benchmark.py                  # all tiers
    python pow_benchmark.py --tier pi-1000    # just one
    python pow_benchmark.py --skip-slow       # everything except pi-10000

Numbers will vary by machine — the point isn't to hit the design
doc's table exactly, it's to confirm the SHAPE (free is instant,
pi-100 is barely noticeable, pi-1000 is a real pause, pi-10000 is
genuinely expensive) holds on whatever hardware you're actually
running.
"""
import argparse
import statistics
import sys
import time

from realm.pow_gate import DEFAULT_TIERS, generate_challenge, solve_challenge

SECRET = b"benchmark-secret-not-for-production!!"


def benchmark_tier(label: str, bits: int, trials: int = 3) -> list:
    times = []
    for i in range(trials):
        challenge = generate_challenge(SECRET, difficulty_bits=bits,
                                       tier_label=label, ttl_s=3600.0)
        t0 = time.monotonic()
        solution = solve_challenge(challenge, max_attempts=200_000_000)
        elapsed = time.monotonic() - t0
        if solution is None:
            print(f"  trial {i+1}: FAILED TO SOLVE within attempt cap")
            continue
        times.append(elapsed)
        print(f"  trial {i+1}: {elapsed:.2f}s")
    return times


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tier", help="only benchmark this tier label")
    parser.add_argument("--trials", type=int, default=3,
                        help="solves per tier (default 3, for a median)")
    parser.add_argument("--skip-slow", action="store_true",
                        help="skip pi-10000 and beyond (can take minutes)")
    args = parser.parse_args()

    print("Argon2id params: 64MB memory, time_cost=2, parallelism=1")
    print("(see realm/pow_gate.py ARGON2_* constants for the exact values)\n")

    results = {}
    for threshold, label, bits in DEFAULT_TIERS:
        if bits == 0:
            print(f"{label} (0 bits): instant by construction, no puzzle issued")
            continue
        if args.tier and label != args.tier:
            continue
        if args.skip_slow and bits >= 12:
            print(f"{label} ({bits} bits): skipped (--skip-slow)")
            continue
        print(f"{label} ({bits} bits, ~{2**bits} expected attempts):")
        times = benchmark_tier(label, bits, args.trials)
        if times:
            results[label] = statistics.median(times)
            print(f"  median: {results[label]:.2f}s\n")
        else:
            print("  (no successful trials)\n")

    if results:
        print("-" * 50)
        print("Summary:")
        for label, median_s in results.items():
            print(f"  {label:12s} {median_s:8.2f}s median")
        print()
        print("Compare against ECONOMIC_LAYER_DESIGN.md Part A.3's table.")
        print("Exact numbers will differ by machine -- check the SHAPE:")
        print("each tier should be meaningfully more expensive than the")
        print("last, and pi-100 should stay well under a couple seconds")
        print("so the second-lightest tier doesn't feel broken to a")
        print("normal user who happens to cross the free-call threshold.")


if __name__ == "__main__":
    main()
